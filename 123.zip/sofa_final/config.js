import fs from 'fs-extra';
import path from 'path';

// أرقام المالكين — يمكن تعديلها من هنا فقط.
const OWNER_NUMBER = "201018766845"; // المالك الأول
const OWNER_NUMBERS = [OWNER_NUMBER, "15793877488"]; // المالك الثاني
const DEVELOPERS_FILE = './data/developers.json';
// رقم البوت الأساسي (جلسة الواتساب)
const BOT_NUMBER = "201043872680";

export const config = {
    BOT_NAME: "𝐒𝐎𝐅𝐀 𝐁𝐎𝐓 𝐕𝐈𝐏",
    DEVELOPER: "𝑺𝑶𝑭𝑨 𝑽𝑰𝑷",
    OWNER_NUMBER,
    OWNER_NUMBERS,
    BOT_NUMBER,
    OWNERERROR: `${OWNER_NUMBER}@s.whatsapp.net`,
    VERSION: "6.1.0-VIP",

    PREFIX: ".",

    // 🔇 الأرقام الساكتة: الجلسة اللي رقمها هنا ما بتردش غير للأونر/صاحب الرقم.
    // سيبها فاضية عشان البوت يرد على الكل. حط رقم الجلسة هنا لو عايزها خاصة.
    SILENT_NUMBERS: [],

    // ================= 🔒 DEV MODE =================
    // أوامر المطور والنظام تظهر وتعمل للمالكين والمطورين المسجلين؛ الأوامر ذات ownerOnly تظل للمالكين فقط.
    // المطورون المسجلون منفصلون عن المالكين؛ الجلسات المربوطة تظل لها صلاحياتها الحالية.
    DEV_ONLY_COMMANDS: [
        // قسم المطورين في القايمة
        "apicheck", "setgroq", "اعادة_تشغيل", "ايقاف", "تنظيف", "سكربتي",
        "باتش", "ملف", "ملفات", "اضافه", "تعديل", "حذف", "عدل",
        // أوامر مخفية
        "رشق", "ادخل",
        // أوامر إدارة الأرقام المربوطة (بتشتغل من رقم الأونر بس)
        "مين", "اسكا", "اذاعه", "احضرو", "ابعت", "فحص_قنوات",
        "اضف_مطور", "حذف_مطور", "المطورين"
    ],
    SESSION_PATH: "./sessions",
    AUTO_READ_MESSAGES: false,
    AUTO_TYPING: false,
    MAX_FILE_SIZE: 200,
    AUTO_RECONNECT: true,
    RECONNECT_DELAY: 3000,
    SECURITY: {
        BLOCKED_USERS: []
    },

    PERFORMANCE: {
        MAX_CACHE_SIZE: 500,
        MEMORY_MONITOR: false
    }
};

// المالكين لهم كل الصلاحيات. المطورون أرقام منفصلة قابلة للتعديل من data/developers.json.
function normalizeDevNumber(value) {
    return String(value || '').split('@')[0].split(':')[0].replace(/\D/g, '');
}

const OWNER_SET = new Set(OWNER_NUMBERS.map(normalizeDevNumber).filter(Boolean));

function loadDevelopers() {
    const set = new Set();
    try {
        if (fs.existsSync(DEVELOPERS_FILE)) {
            const data = fs.readJSONSync(DEVELOPERS_FILE);
            const list = Array.isArray(data) ? data : (Array.isArray(data?.developers) ? data.developers : []);
            for (const value of list) {
                const n = normalizeDevNumber(value);
                if (n && !OWNER_SET.has(n)) set.add(n);
            }
        }
    } catch (e) {
        console.error('⚠️ Failed to load developers:', e.message);
    }
    return [...set];
}

function saveDevelopers(numbers) {
    const unique = [...new Set(numbers.map(normalizeDevNumber).filter((n) => n && !OWNER_SET.has(n)))];
    fs.ensureDirSync(path.dirname(DEVELOPERS_FILE));
    fs.writeJSONSync(DEVELOPERS_FILE, { developers: unique }, { spaces: 2 });
    return unique;
}

config.DEVELOPERS = loadDevelopers().map((n) => `${n}@s.whatsapp.net`);

export const developerManager = {
    list() {
        return config.DEVELOPERS.map(normalizeDevNumber).filter(Boolean);
    },
    has(value) {
        const n = normalizeDevNumber(value);
        return !!n && this.list().includes(n);
    },
    add(value) {
        const n = normalizeDevNumber(value);
        if (!n) return { ok: false, reason: 'invalid' };
        if (OWNER_SET.has(n)) return { ok: false, reason: 'owner' };
        const current = this.list();
        if (current.includes(n)) return { ok: false, reason: 'exists', number: n };
        const saved = saveDevelopers([...current, n]);
        config.DEVELOPERS = saved.map((x) => `${x}@s.whatsapp.net`);
        return { ok: true, number: n };
    },
    remove(value) {
        const n = normalizeDevNumber(value);
        if (!n) return { ok: false, reason: 'invalid' };
        if (OWNER_SET.has(n)) return { ok: false, reason: 'owner' };
        const current = this.list();
        if (!current.includes(n)) return { ok: false, reason: 'missing', number: n };
        const saved = saveDevelopers(current.filter((x) => x !== n));
        config.DEVELOPERS = saved.map((x) => `${x}@s.whatsapp.net`);
        return { ok: true, number: n };
    }
};

const stores = new Set();

export class DataStore {
    constructor(name = 'global') {
        this.name = name;
        this.filePath = `./data/${name}.json`;
        this.data = new Map();
        this.dirty = false;
        this.saveTimer = null;

        this.ensureDirectory();
        this.load();
        stores.add(this);
    }

    ensureDirectory() {
        fs.ensureDirSync(path.dirname(this.filePath));
    }

    // تحميل متزامن عشان البيانات تكون جاهزة قبل أول استخدام
    load() {
        try {
            if (fs.existsSync(this.filePath)) {
                const stored = fs.readJSONSync(this.filePath);
                if (stored && typeof stored === 'object') {
                    this.data = new Map(Object.entries(stored));
                }
            }
        } catch (error) {
            // الملف تالف: نحتفظ بنسخة منه بدل ما نمسح البيانات
            console.error(`⚠️ DataStore [${this.name}] corrupted, backing up:`, error.message);
            try {
                fs.moveSync(this.filePath, `${this.filePath}.corrupt-${Date.now()}`, { overwrite: true });
            } catch {}
            this.data = new Map();
        }
    }

    // حفظ تلقائي بعد ثانية من آخر تعديل
    scheduleSave() {
        this.dirty = true;
        if (this.saveTimer) return;
        this.saveTimer = setTimeout(() => {
            this.saveTimer = null;
            this.save();
        }, 1000);
        this.saveTimer.unref?.();
    }

    async save() {
        try {
            const tmp = `${this.filePath}.tmp`;
            await fs.writeJSON(tmp, Object.fromEntries(this.data));
            await fs.move(tmp, this.filePath, { overwrite: true });
            this.dirty = false;
        } catch (error) {
            console.error(`⚠️ DataStore [${this.name}] save failed:`, error.message);
        }
    }

    saveSync() {
        try {
            fs.writeJSONSync(this.filePath, Object.fromEntries(this.data));
            this.dirty = false;
        } catch {}
    }

    set(key, value) {
        this.data.set(key, value);
        this.scheduleSave();
        return this;
    }

    // يرجع القيمة حتى لو كانت 0 أو false أو ""
    get(key, defaultValue = null) {
        const value = this.data.get(key);
        return value === undefined || value === null ? defaultValue : value;
    }

    has(key) {
        return this.data.has(key);
    }

    delete(key) {
        const result = this.data.delete(key);
        if (result) this.scheduleSave();
        return result;
    }

    clear() {
        this.data.clear();
        this.scheduleSave();
    }

    size() {
        return this.data.size;
    }

    keys() {
        return Array.from(this.data.keys());
    }

    values() {
        return Array.from(this.data.values());
    }

    entries() {
        return Array.from(this.data.entries());
    }

    find(predicate) {
        for (const [key, value] of this.data) {
            if (predicate(value, key)) return value;
        }
        return null;
    }

    filter(predicate) {
        const results = [];
        for (const [key, value] of this.data) {
            if (predicate(value, key)) results.push(value);
        }
        return results;
    }

    increment(key, amount = 1) {
        const newValue = Number(this.get(key, 0)) + amount;
        this.set(key, newValue);
        return newValue;
    }

    decrement(key, amount = 1) {
        const newValue = Number(this.get(key, 0)) - amount;
        this.set(key, newValue);
        return newValue;
    }

    push(key, value) {
        const array = this.get(key, []);
        array.push(value);
        this.set(key, array);
        return array;
    }

    setProperty(key, property, value) {
        const obj = this.get(key, {});
        obj[property] = value;
        this.set(key, obj);
        return obj;
    }

    getProperty(key, property, defaultValue = null) {
        const value = this.get(key, {})[property];
        return value === undefined || value === null ? defaultValue : value;
    }
}

// حفظ أي تعديلات معلقة عند إغلاق البوت
process.on('exit', () => {
    for (const store of stores) {
        if (store.dirty) store.saveSync();
    }
});

export const dataStore = new DataStore('global');
export const userStore = new DataStore('users');
export const groupStore = new DataStore('groups');

// يحوّل أي JID (فيه @ أو :device) لأرقام فقط
const toDigits = (value) =>
    String(value || '').split('@')[0].split(':')[0].replace(/\D/g, '');

export const configHelper = {
    isDeveloper(number) {
        const clean = toDigits(number);
        if (!clean) return false;
        return config.DEVELOPERS.some((dev) => toDigits(dev) === clean);
    },

    isOwner(number) {
        const clean = toDigits(number);
        return !!clean && (config.OWNER_NUMBERS || [config.OWNER_NUMBER]).some((owner) => toDigits(owner) === clean);
    },

    isPrivateMode() {
        return config.MODE === 'private';
    },

    getPrefix() {
        return config.PREFIX;
    }
};

export default config;
