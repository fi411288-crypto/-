import fs from 'fs';
import path from 'path';

// مفاتيح Groq: بتتحفظ في keys.local.json (أو بأمر .setgroq من واتساب)
const file = path.join(process.cwd(), 'keys.local.json');
let local = {};
try { local = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {}

export const GROQ_API_KEYS = (local.GROQ_API_KEYS?.length ? local.GROQ_API_KEYS
    : [process.env.GROQ_KEY_1, process.env.GROQ_KEY_2, process.env.GROQ_KEY_3]).filter(Boolean);
export const GROQ_API_KEY = local.GROQ_API_KEY || process.env.GROQ_API_KEY || '';

// تحديث المفتاح فوراً من غير ريستارت
export function setGroqKey(key) {
    GROQ_API_KEYS.splice(0, GROQ_API_KEYS.length, key);
    let cur = {};
    try { cur = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {}
    fs.writeFileSync(file, JSON.stringify({ ...cur, GROQ_API_KEYS: [key] }, null, 2));
}
