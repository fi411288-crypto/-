# Realistic anime-style voices

The bot supports high-quality cloud TTS for original voices that you have permission to use.

Set these environment variables on your server:

ELEVENLABS_API_KEY=your_key
SOFA_ANIME_VOICE_ID=your_allowed_voice_id
SOFA_TTS_MODEL=eleven_v4

Then:

.صوت_انمي غوجو مرحباً يا أصدقاء
.صوت_انمي لوفي هيا بنا!

The character name is a label/profile; the generated voice must be an original/authorized voice and is not intended to reproduce an anime actor's voice or copyrighted recording.
