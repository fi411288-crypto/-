import { getGroupMode } from './lib/groupMode.js';
import { isPrivateOnly } from './lib/privateMode.js';
import { isBannedWA } from './lib/bans.js';
import { getMetadata as __gmMeta, getAdminFlags as __gmFlags } from './lib/compat.js';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import fs from 'fs-extra';
import { pathToFileURL } from 'url';
import path from 'path';
import chalk from 'chalk';
import gradient from 'gradient-string';
import { enrichContext, toPlugin, unwrap } from './lib/compat.js';
import { moderate } from './lib/moderation.js';
import { trackGroup } from './lib/community.js';

class Handler {
    constructor(bot) {
        this.bot = bot;
        this.commands = new Map();
        this.aliases = new Map();
        this.plugins = new Map();
        this.pluginDir = './plugins';
        this.stats = {
            commandsExecuted: 0,
            messagesProcessed: 0,
            errors: 0,
            startTime: Date.now()
        };
        
        // أنظمة متقدمة محسنة
        this.cooldowns = new Map();
        this.userData = new Map();
        this.groupData = new Map();
        this.cache = new Map();
        this.sessions = new Map();
        this.continuousCommands = new Map();
        this.autoCommands = new Map();
        this.gameSessions = new Map(); 
        
        this.security = {
            blockedUsers: new Set(),
            spamDetection: new Map(),
            rateLimits: new Map(),
            commandPermissions: new Map()
        };


        this.messageQueue = [];
        this.isProcessing = false;
        this.responseCache = new Map();
        this.cacheTTL = 30000;

        this.watcher = null;
        this.isReloading = false;
        this.isInitialized = false;
        this.coreWatcher = null; 
        this.configWatcher = null; 
        this.ensureDirectories();
        this.loadData();
        this.startCleanupCycle();
        this.startPerformanceMonitor();
        
        console.log(gradient.rainbow(`
        
█████╗ ██████╗ ██████╗  ██████╗ 
██╔══██╗██╔══██╗██╔══██╗ ██╔═══██╗
███████║██████╔╝██║  ██║ ██║   ██║
██╔══██║██╔══██╗██║  ██║ ██║   ██║
██║  ██║██████╔╝██████╔╝ ╚██████╔╝
╚═╝  ╚═╝╚═════╝ ╚═════╝   ╚═════╝

        `));
    }

    ensureDirectories() {
        const dirs = [this.pluginDir, './data', './temp'];
        dirs.forEach(dir => {
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
        });
    }

    // ==================== نظام التخزين المحسن ====================
    saveData() {
        try {
            const data = {
                userData: Object.fromEntries(this.userData),
                groupData: Object.fromEntries(this.groupData),
                stats: this.stats,
                security: {
                    blockedUsers: Array.from(this.security.blockedUsers)
                }
            };
            fs.writeJSONSync('./data/bot_data.json', data, { spaces: 2 });
        } catch (error) {
            console.log(chalk.red('❌ Save data error:'), error.message);
        }
    }

    loadData() {
        try {
            if (fs.existsSync('./data/bot_data.json')) {
                const data = fs.readJSONSync('./data/bot_data.json');
                this.userData = new Map(Object.entries(data.userData || {}));
                this.groupData = new Map(Object.entries(data.groupData || {}));
                this.stats = { ...this.stats, ...data.stats };
                if (data.security) {
                    this.security.blockedUsers = new Set(data.security.blockedUsers || []);
                }
            }
        } catch (error) {
            console.log(chalk.red('❌ Load data error:'), error.message);
        }
    }

    // ==================== نظام المستخدمين المحسن ====================
    getUserData(userJid) {
        if (!this.userData.has(userJid)) {
            this.userData.set(userJid, {
                messageCount: 0,
                commandCount: 0,
                firstSeen: Date.now(),
                lastSeen: Date.now(),
                level: 1,
                exp: 0,
                permissions: {
                    isAdmin: false,
                    isPremium: false,
                    canUseAllCommands: true,
                    restrictedCommands: []
                },
                stats: {
                    gamesPlayed: 0,
                    downloads: 0,
                    queries: 0,
                    adminCommandsUsed: 0,
                    gameCommandsUsed: 0,
                    infoCommandsUsed: 0,
                    mediaCommandsUsed: 0
                }
            });
        }
        return this.userData.get(userJid);
    }

    // ==================== نظام الصلاحيات (أونر + أرقام مربوطة) ====================
    // الأونر = OWNER_NUMBER بس. الأرقام المربوطة = المفاتيح في data/sessionOwners.json (global.bot.sessionOwners)
    _d(j) { return String(j || '').split('@')[0].split(':')[0].replace(/\D/g, ''); }

    isOwnerNumber(jid) {
        const d = this._d(jid);
        const owners = this.bot.config?.OWNER_NUMBERS || [this.bot.config?.OWNER_NUMBER];
        return !!d && owners.some((owner) => d === this._d(owner));
    }

    // المالك أو المطور المسجل فقط؛ لا يشمل أرقام الجلسات المربوطة العادية.
    isStaffMessage(message) {
        if (this.isOwnerMessage(message)) return true;
        const developers = (this.bot.config?.DEVELOPERS || []).map((n) => this._d(n));
        return this._senderIds(message).some((jid) => {
            const n = this._d(jid);
            return !!n && developers.includes(n);
        });
    }

    isLinkedNumber(jid) {
        const d = this._d(jid);
        const owners = global.bot?.sessionOwners;
        return !!d && !!owners && owners.has(d);
    }

    // أونر أو أي رقم مربوط (بيتستخدم في حماية الأرقام من الطرد وغيره)
    isDeveloper(jid) {
        if (!jid || typeof jid !== 'string') return false;
        const d = this._d(jid);
        const configured = (this.bot.config?.DEVELOPERS || []).some((dev) => this._d(dev) === d);
        return this.isOwnerNumber(jid) || configured || this.isLinkedNumber(jid);
    }

    // كل الصيغ الممكنة لمرسل الرسالة (رقم / LID / participantPn ...)
    _senderIds(message) {
        const k = message?.key || {};
        return [k.participant, k.participantPn, k.participantAlt, k.remoteJidAlt, k.remoteJid]
            .filter(Boolean).filter(j => !String(j).endsWith('@g.us'));
    }

    // الجلسة اللي الـ handler ده شغال عليها هي جلسة الأونر؟
    isOwnerSession() {
        const owners = this.bot.config?.OWNER_NUMBERS || [this.bot.config?.OWNER_NUMBER];
        const phone = this._d(this.bot.phone);
        return !!phone && owners.some((owner) => phone === this._d(owner));
    }

    // الجلسة دي رقمها من الأرقام الساكتة (config.SILENT_NUMBERS)؟
    isSilentSession() {
        const list = (this.bot.config?.SILENT_NUMBERS || []).map((n) => this._d(n));
        return list.includes(this._d(this.bot.phone));
    }

    // هل مرسل الرسالة هو الأونر؟
    isOwnerMessage(message) {
        if (message?.key?.fromMe) return this.isOwnerSession();
        return this._senderIds(message).some(j => this.isOwnerNumber(j));
    }

    // هل المرسل أونر أو رقم مربوط (أو نفس رقم الجلسة)؟
    isPowerMessage(message) {
        if (this.isOwnerMessage(message)) return true;
        if (this.isSessionOwner(message)) return true;
        return this._senderIds(message).some(j => this.isLinkedNumber(j));
    }

    // صاحب الرقم المربوط بالبوت (نفس حساب الواتساب اللي البوت شغال عليه)
    isSessionOwner(message) {
        if (message?.key?.fromMe) return true;
        const u = this.bot.sock?.user;
        if (!u) return false;
        const d = (j) => String(j || '').split('@')[0].split(':')[0];
        const sender = d(message?.key?.participant || message?.key?.participantAlt || message?.key?.remoteJid);
        return !!sender && (sender === d(u.id) || sender === d(u.lid));
    }

    // ==================== نظام تحويل LID إلى JID ====================
    convertLidToJid(lid) {
        try {
            if (!lid || typeof lid !== 'string') return null;
            
            console.log(chalk.blue(`🔄 convertLidToJid input: ${lid}`));

            if (lid.includes('@s.whatsapp.net')) {
                return lid;
            }
            
            if (lid.includes('@lid')) {
                const numberPart = lid.split('@')[0];
                const cleanNumber = numberPart.split(':')[0];
                console.log(chalk.blue(`🔢 Extracted from LID: ${cleanNumber}`));
                return `${cleanNumber}@s.whatsapp.net`;
            }
            
            const cleanNumber = lid.replace(/[^0-9]/g, '');
            if (cleanNumber.length > 5) {
                return `${cleanNumber}@s.whatsapp.net`;
            }
            
            console.log(chalk.yellow(`⚠️ Cannot convert LID: ${lid}`));
            return null;
        } catch (error) {
            console.log(chalk.red('❌ convertLidToJid error:'), error);
            return null;
        }
    }

    // ==================== نظام التحقق من البوت في المجموعة ====================
    async checkBotInGroup(groupJid, sock) {
        try {
            const metadata = await sock.groupMetadata(groupJid);
            const botJid = sock.user?.id;
            
            console.log(chalk.blue(`🤖 Bot JID: ${botJid}`));
            console.log(chalk.blue(`👥 Participants count: ${metadata.participants.length}`));

            let botParticipant = metadata.participants.find(p => p.id === botJid);
            
            if (!botParticipant) {
                const botNumber = botJid.split('@')[0];
                console.log(chalk.blue(`🔍 Searching by number: ${botNumber}`));
                
                botParticipant = metadata.participants.find(p => {
                    const participantNumber = p.id.split('@')[0].split(':')[0];
                    return participantNumber === botNumber;
                });
            }

            if (!botParticipant) {
                console.log(chalk.blue(`🔍 Searching by LID conversion`));
                const botLid = this.convertLidToJid(botJid);
                if (botLid) {
                    botParticipant = metadata.participants.find(p => p.id === botLid);
                }
            }

            if (botParticipant) {
                console.log(chalk.green(`✅ Bot found in group: ${botParticipant.id} - Admin: ${botParticipant.admin}`));
                return {
                    found: true,
                    participant: botParticipant,
                    isAdmin: botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin',
                    jid: botParticipant.id
                };
            } else {
                console.log(chalk.red(`❌ Bot not found in participants list`));
                console.log(chalk.yellow(`📋 Participants sample:`, metadata.participants.slice(0, 3).map(p => p.id)));
                return { 
                    found: false, 
                    participant: null, 
                    isAdmin: false,
                    jid: botJid
                };
            }
            
        } catch (error) {
            console.log(chalk.red('❌ checkBotInGroup error:'), error);
            return { 
                found: false, 
                participant: null, 
                isAdmin: false,
                jid: sock.user?.id 
            };
        }
    }

    // ==================== نظام البحث في المشاركين مع تحويل LID ====================
    async findParticipantByAnyId(groupJid, targetId, sock) {
        try {
            const metadata = await sock.groupMetadata(groupJid);
            const participants = metadata.participants;
            
            console.log(chalk.blue(`🔍 Searching for: ${targetId} in ${participants.length} participants`));

            let participant = null;
            
            const searchMethods = [
                () => participants.find(p => p.id === targetId),
                
                () => {
                    const convertedJid = this.convertLidToJid(targetId);
                    if (convertedJid) {
                        return participants.find(p => p.id === convertedJid);
                    }
                    return null;
                },
                
                () => {
                    const targetNumber = targetId.split('@')[0].split(':')[0];
                    return participants.find(p => p.id.split('@')[0].split(':')[0] === targetNumber);
                },
                
                () => {
                    const searchTerm = targetId.split('@')[0];
                    return participants.find(p => p.id.includes(searchTerm));
                },
                
                () => {
                    const cleanNumber = targetId.replace(/[^0-9]/g, '');
                    if (cleanNumber.length > 5) {
                        return participants.find(p => {
                            const participantNumber = p.id.split('@')[0].replace(/[^0-9]/g, '');
                            return participantNumber === cleanNumber;
                        });
                    }
                    return null;
                }
            ];
            
            for (const method of searchMethods) {
                participant = method();
                if (participant) {
                    console.log(chalk.green(`✅ Participant found: ${participant.id}`));
                    return {
                        found: true,
                        participant: participant,
                        jid: participant.id,
                        displayName: participant.notify || participant.id.split('@')[0],
                        isAdmin: participant.admin === 'admin' || participant.admin === 'superadmin'
                    };
                }
            }
            
            console.log(chalk.yellow(`⚠️ Participant not found: ${targetId}`));
            return {
                found: false,
                participant: null,
                jid: this.convertLidToJid(targetId) || targetId,
                displayName: targetId.split('@')[0],
                isAdmin: false
            };
            
        } catch (error) {
            console.log(chalk.red('❌ findParticipantByAnyId error:'), error);
            return {
                found: false,
                participant: null,
                jid: this.convertLidToJid(targetId) || targetId,
                displayName: targetId.split('@')[0],
                isAdmin: false
            };
        }
    }

    // ==================== نظام معلومات المستخدم المحسن ====================
    async getUserInfo(sock, message, args = []) {
        try {
            const isGroup = message.key.remoteJid.endsWith('@g.us');
            const selfJid = sock.user?.id;
            
            console.log(chalk.blue(`🔍 getUserInfo called - Group: ${isGroup}, Args: ${args.length}`));

            let groupMetadata = null;
            let participants = [];
            if (isGroup) {
                try {
                    groupMetadata = await sock.groupMetadata(message.key.remoteJid);
                    participants = groupMetadata.participants || [];
                    console.log(chalk.blue(`👥 Group has ${participants.length} participants`));
                } catch (error) {
                    console.log(chalk.red('❌ Failed to get group metadata:'), error.message);
                }
            }

            let targetJid = null;
            let source = 'unknown';

            if (message.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                targetJid = message.message.extendedTextMessage.contextInfo.participant;
                source = 'reply';
                
            }
            
            else if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetJid = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
                source = 'mention';
                
            }
            
            else if (args.length > 0) {
                const arg = args[0].replace('@', '').trim();
                if (arg.length > 5) {
                    targetJid = arg;
                    source = 'args';
                    
                }
            }
            
            if (!targetJid) {
                targetJid = message.key.participant || message.key.remoteJid;
                source = 'sender';
                
            }

            

            if (isGroup && participants.length > 0) {
                
                
                let participant = null;
                
                const searchMethods = [
                    () => participants.find(p => p.id === targetJid),
                    
                    () => {
                        const targetNumber = targetJid.split('@')[0];
                        return participants.find(p => p.id.split('@')[0] === targetNumber);
                    },
                    
                    () => {
                        const targetSearch = targetJid.split('@')[0];
                        return participants.find(p => p.id.includes(targetSearch));
                    },
                    
                    () => {
                        if (source === 'args') {
                            const cleanArg = targetJid.replace(/[^0-9]/g, '');
                            return participants.find(p => p.id.split('@')[0].includes(cleanArg));
                        }
                        return null;
                    }
                ];
                
                for (const method of searchMethods) {
                    participant = method();
                    if (participant) {
                        console.log(chalk.green(`✅ Found participant: ${participant.id}`));
                        const userData = this.getUserData(participant.id);
                        return {
                            jid: participant.id,
                            lid: participant.id,
                            displayName: participant.notify || participant.id.split('@')[0] || 'Unknown',
                            isAdmin: participant.admin === 'admin' || participant.admin === 'superadmin',
                            isBot: participant.id === selfJid,
                            isDeveloper: this.isDeveloper(participant.id),
                            userData: userData,
                            groupRole: participant.admin || 'member',
                            foundInGroup: true
                        };
                    }
                }
                
                console.log(chalk.yellow(`⚠️ Participant not found in group: ${targetJid}`));
            }

            let cleanJid = targetJid;
            if (!cleanJid.includes('@s.whatsapp.net') && !cleanJid.includes('@g.us') && !cleanJid.includes('@lid')) {
                cleanJid = `${cleanJid}@s.whatsapp.net`;
            }

            const userData = this.getUserData(cleanJid);
            const displayName = message.pushName || cleanJid.split('@')[0] || 'Unknown';
            
            console.log(chalk.cyan(`👤 Returning default user info: ${displayName} (${cleanJid})`));
            
            return {
                jid: cleanJid,
                lid: cleanJid,
                displayName: displayName,
                isAdmin: false,
                isBot: cleanJid === selfJid,
                isDeveloper: this.isDeveloper(cleanJid),
                userData: userData,
                groupRole: null,
                foundInGroup: false
            };

        } catch (error) {
            console.log(chalk.red('❌ getUserInfo error:'), error.message);
            return null;
        }
    }

    // ==================== نظام تحميل البلجنات المحسن ====================
    async loadPlugins() {
        try {
            console.log(chalk.cyan('🔄 Loading plugins...'));
            
            if (!fs.existsSync(this.pluginDir)) {
                console.log(chalk.yellow('📁 Creating plugins directory...'));
                fs.mkdirSync(this.pluginDir, { recursive: true });
                return;
            }

            const files = fs.readdirSync(this.pluginDir)
                .filter(file => file.endsWith('.js'));
            
            console.log(chalk.blue(`📁 Found ${files.length} plugin files`));
            
            let loadedCount = 0;
            
            for (const file of files) {
                try {
                    await this.loadSinglePlugin(file);
                    loadedCount++;
                } catch (error) {
                    console.log(chalk.red(`❌ Failed to load ${file}:`), error.message);
                }
            }
            
            console.log(gradient.rainbow(`✅ Loaded ${loadedCount} plugins with ${this.commands.size} commands`));
            
            this.showLoadedCommands();
            await this.startPluginWatcher();
            await this.startConfigWatcher(); 
            this.isInitialized = true;
            
        } catch (error) {
            console.log(chalk.red('❌ Plugin load error:'), error.message);
        }
    }

    async loadSinglePlugin(filename) {
        try {
            // مهم: أسماء الملفات ممكن تكون #U0627... (ترميز يونيكود) — متتمسحش #
            const cleanFilename = String(filename || '').trim();
            if (!cleanFilename.endsWith('.js') || cleanFilename.includes('..') || cleanFilename.includes('/') || cleanFilename.includes('\\')) {
                throw new Error(`Invalid plugin filename: ${filename}`);
            }
            
            const pluginPath = path.resolve(this.pluginDir, cleanFilename);

            if (!fs.existsSync(pluginPath)) {
                throw new Error(`File not found: ${cleanFilename}`);
            }

            const importPath = `${pathToFileURL(pluginPath).href}?v=${Date.now()}`;
            const pluginModule = await import(importPath);
            
            const plugin = toPlugin(pluginModule, cleanFilename.replace(/\.js$/i, ''), this.bot);

            if (!plugin || (!plugin.name && !plugin.commands)) {
                throw new Error('Invalid plugin structure: missing name or commands array');
            }

            await this.registerPlugin(plugin, cleanFilename);
            console.log(chalk.green(`✅ Loaded: ${plugin.name || cleanFilename}`));

        } catch (error) {
            console.log(chalk.red(`❌ Failed to load ${filename}:`), error.message);
            throw error;
        }
    }

    async registerPlugin(plugin, filename) {
        this.plugins.set(filename, {
            ...plugin,
            filename: filename,
            loadTime: Date.now()
        });
        
        if (plugin.commands && Array.isArray(plugin.commands)) {
            plugin.commands.forEach(cmd => {
                this.registerCommand(cmd, plugin.name);
            });
        } else if (plugin.run && typeof plugin.run === 'function' && plugin.name) {
            this.registerCommand({
                name: plugin.name,
                run: plugin.run,
                aliases: plugin.aliases || [],
                description: plugin.description || '',
                developer: plugin.developer || false,
                vip: plugin.vip || false,
                foreign: !!plugin.foreign,
                cooldown: plugin.cooldown || 2000
            }, plugin.name);
        }

        if (plugin.onLoad && typeof plugin.onLoad === 'function') {
            try {
                await plugin.onLoad();
            } catch (error) {
                console.log(chalk.red(`❌ Plugin onLoad failed: ${plugin.name}`), error.message);
            }
        }

        return true;
    }

    registerCommand(command, pluginName = 'unknown') {
        if (!command || !command.name || typeof command.run !== 'function') {
            return false;
        }

        // منع تكرار نفس الأمر: أول تعريف صالح يحتفظ به البوت،
        // وأي Plugin لاحق بنفس الاسم يتم تجاهله مع تسجيل واضح في الطرفية.
        if (this.commands.has(command.name)) {
            const existing = this.commands.get(command.name);
            console.warn(`⚠️ Duplicate command skipped: ${command.name} (${pluginName}) — already registered by ${existing.plugin}`);
            return false;
        }

        const enhancedCommand = {
            ...command,
            plugin: pluginName,
            usageCount: 0,
            lastUsed: null,
            category: command.category || 'general',
            permissions: command.permissions || {
                group: command.group || false,
                admin: command.admin || false,
                developer: command.developer || false,
                vip: command.vip || false,
                private: command.private || false
            }
        };

        this.commands.set(command.name, enhancedCommand);
        
        if (command.aliases && Array.isArray(command.aliases)) {
            command.aliases.forEach(alias => {
                this.aliases.set(alias, command.name);
            });
        }

        return true;
    }

    showLoadedCommands() {
        const commands = Array.from(this.commands.keys());
        if (commands.length > 0) {
            const commandList = commands.map(cmd => `${(this.bot.config?.PREFIX || ".")}${cmd}`).join(' | ');
            const title = chalk.cyan('✅ Loaded Commands:');
            const coloredCommands = gradient('lime', 'cyan')(commandList);
            console.log(`\n${title}\n${coloredCommands}\n`);
        }
    }

    // ==================== نظام معالجة متوازي كامل ====================
    async handleMessage(message) {
        if (!this.isInitialized || !message.message || !message.key.remoteJid) {
            return false;
        }

        // 🆔 تحويل @lid لرقم الهاتف الحقيقي (عشان الأونر يتعرف عليه حتى لو واتساب بعت LID)
        try {
            const k = message.key;
            if (!k.fromMe && !k.participantPn) {
                const raw = k.participant || (String(k.remoteJid).endsWith('@g.us') ? null : k.remoteJid);
                if (raw && String(raw).includes('@lid')) {
                    const pn = await this.bot.sock?.signalRepository?.lidMapping?.getPNForLID?.(raw);
                    const n = this._d(pn);
                    if (n) k.participantPn = `${n}@s.whatsapp.net`;
                }
            }
        } catch {}

        // 🔇 الأرقام الساكتة فقط (config.SILENT_NUMBERS): مفيش رد لغير الأونر/صاحب الجلسة
        // ملاحظة: جلسة الأونر مش صامتة تلقائياً — لو عايزها صامتة حط رقمها في SILENT_NUMBERS
        if (this.isSilentSession() && !this.isOwnerMessage(message) && !this.isSessionOwner(message)) {
            return false;
        }

        // تجهيز جميع أنواع أزرار وتفاعلات واتساب قبل استخراج النص
        this.normalizeAllInteractions(message);

        // تنفيذ فوري بدون أي انتظار - كل أمر مستقل
        Promise.resolve().then(async () => {
            try {
                await this.processSingleMessage(message);
            } catch (error) {
                console.log(chalk.red('❌ Async processing error:'), error.message);
            }
        });

        return true;
    }

    // ==================== نظام دعم جميع أزرار وتفاعلات واتساب ====================
    normalizeAllInteractions(message) {
        try {
            const msg = message?.message;
            if (!msg || typeof msg !== 'object') return null;

            let interactionId = null;
            let interactionText = null;

            // أزرار WhatsApp Buttons القديمة
            if (msg.buttonsResponseMessage) {
                interactionId =
                    msg.buttonsResponseMessage.selectedButtonId ||
                    msg.buttonsResponseMessage.selectedId ||
                    msg.buttonsResponseMessage.buttonId ||
                    null;

                interactionText =
                    msg.buttonsResponseMessage.selectedDisplayText ||
                    msg.buttonsResponseMessage.displayText ||
                    msg.buttonsResponseMessage.title ||
                    null;
            }

            // أزرار Template
            if (msg.templateButtonReplyMessage) {
                interactionId =
                    interactionId ||
                    msg.templateButtonReplyMessage.selectedId ||
                    msg.templateButtonReplyMessage.selectedButtonId ||
                    msg.templateButtonReplyMessage.buttonId ||
                    null;

                interactionText =
                    interactionText ||
                    msg.templateButtonReplyMessage.selectedDisplayText ||
                    msg.templateButtonReplyMessage.displayText ||
                    msg.templateButtonReplyMessage.title ||
                    null;
            }

            // أزرار Interactive
            if (msg.interactiveResponseMessage) {
                const interactive = msg.interactiveResponseMessage;
                const nativeFlow = interactive.nativeFlowResponseMessage;

                if (nativeFlow) {
                    try {
                        const params = JSON.parse(nativeFlow.paramsJson || '{}');

                        interactionId =
                            interactionId ||
                            params.id ||
                            params.button_id ||
                            params.buttonId ||
                            params.selectedId ||
                            params.selectedButtonId ||
                            params.selectedRowId ||
                            params.rowId ||
                            params.command ||
                            params.value ||
                            params.action ||
                            null;

                        interactionText =
                            interactionText ||
                            params.display_text ||
                            params.displayText ||
                            params.title ||
                            params.text ||
                            params.label ||
                            null;
                    } catch (error) {
                    }

                    if (!interactionId) {
                        interactionId =
                            nativeFlow.name ||
                            nativeFlow.messageParamsJson ||
                            null;
                    }
                }

                if (!interactionText) {
                    interactionText =
                        interactive.body?.text ||
                        interactive.header?.text ||
                        interactive.footer?.text ||
                        null;
                }
            }

            // Native Flow Response بصيغة مباشرة
            if (msg.nativeFlowResponseMessage) {
                const nativeFlow = msg.nativeFlowResponseMessage;

                try {
                    const params = JSON.parse(nativeFlow.paramsJson || '{}');

                    interactionId =
                        interactionId ||
                        params.id ||
                        params.button_id ||
                        params.buttonId ||
                        params.selectedId ||
                        params.selectedButtonId ||
                        params.selectedRowId ||
                        params.rowId ||
                        params.command ||
                        params.value ||
                        params.action ||
                        null;

                    interactionText =
                        interactionText ||
                        params.display_text ||
                        params.displayText ||
                        params.title ||
                        params.text ||
                        params.label ||
                        null;
                } catch (error) {
                }

                interactionId =
                    interactionId ||
                    nativeFlow.name ||
                    nativeFlow.messageParamsJson ||
                    null;
            }

            // أزرار Button Reply بصيغ مختلفة
            if (msg.buttonReplyMessage) {
                interactionId =
                    interactionId ||
                    msg.buttonReplyMessage.selectedId ||
                    msg.buttonReplyMessage.selectedButtonId ||
                    msg.buttonReplyMessage.buttonId ||
                    null;

                interactionText =
                    interactionText ||
                    msg.buttonReplyMessage.selectedDisplayText ||
                    msg.buttonReplyMessage.displayText ||
                    msg.buttonReplyMessage.title ||
                    null;
            }

            // List Response
            if (msg.listResponseMessage) {
                interactionId =
                    interactionId ||
                    msg.listResponseMessage.singleSelectReply?.selectedRowId ||
                    msg.listResponseMessage.selectedRowId ||
                    msg.listResponseMessage.rowId ||
                    msg.listResponseMessage.selectedId ||
                    null;

                interactionText =
                    interactionText ||
                    msg.listResponseMessage.title ||
                    msg.listResponseMessage.description ||
                    msg.listResponseMessage.singleSelectReply?.selectedRowId ||
                    null;
            }

            // List Message / Product / Shop interactions
            if (msg.listMessage) {
                interactionId =
                    interactionId ||
                    msg.listMessage.buttonText ||
                    msg.listMessage.title ||
                    null;
            }

            // Template Button Reply إضافي
            if (msg.templateButtonReplyMessage) {
                interactionId =
                    interactionId ||
                    msg.templateButtonReplyMessage.selectedId ||
                    msg.templateButtonReplyMessage.selectedButtonId ||
                    null;
            }

            // Message Context Info
            if (msg.messageContextInfo) {
                const context = msg.messageContextInfo;

                interactionId =
                    interactionId ||
                    context.selectedButtonId ||
                    context.selectedId ||
                    context.selectedRowId ||
                    context.buttonId ||
                    context.rowId ||
                    context.interactionId ||
                    null;
            }

            // البحث عن الحقول العامة المستخدمة في إصدارات Baileys المختلفة
            if (!interactionId) {
                const possibleFields = [
                    'selectedButtonId',
                    'selectedId',
                    'selectedRowId',
                    'buttonId',
                    'interactionId',
                    'rowId',
                    'selectedRow',
                    'selectedButton',
                    'actionId'
                ];

                for (const field of possibleFields) {
                    if (msg[field]) {
                        interactionId = msg[field];
                        break;
                    }
                }
            }

            // دعم النص الموجود داخل Native Flow / JSON
            if (!interactionId) {
                const possibleJsonFields = [
                    msg.paramsJson,
                    msg.messageParamsJson,
                    msg.selectedParamsJson
                ];

                for (const json of possibleJsonFields) {
                    if (!json || typeof json !== 'string') continue;

                    try {
                        const params = JSON.parse(json);

                        interactionId =
                            params.id ||
                            params.button_id ||
                            params.buttonId ||
                            params.selectedId ||
                            params.selectedButtonId ||
                            params.selectedRowId ||
                            params.rowId ||
                            params.command ||
                            params.value ||
                            params.action ||
                            null;

                        interactionText =
                            interactionText ||
                            params.display_text ||
                            params.displayText ||
                            params.title ||
                            params.text ||
                            params.label ||
                            null;

                        if (interactionId) break;
                    } catch (error) {
                    }
                }
            }

            if (!interactionId) return null;

            // حفظ كل أسماء الحقول حتى تتعامل معها البلجنات والأوامر
            message.buttonId = interactionId;
            message.selectedButtonId = interactionId;
            message.selectedId = interactionId;
            message.selectedRowId = interactionId;
            message.interactionId = interactionId;
            message.rowId = interactionId;
            message.actionId = interactionId;

            if (interactionText) {
                message.buttonText = interactionText;
                message.selectedDisplayText = interactionText;
                message.interactionText = interactionText;
            }

            // حفظ التفاعل داخل message نفسه
            message.interaction = {
                id: interactionId,
                text: interactionText || interactionId,
                type: this.getInteractionType(msg)
            };

            // جعل كل زر/تفاعل يُعامل كنص أمر عادي
            // الأولوية دائماً للـ ID لأنه غالباً هو الـ command الحقيقي
            if (!msg.conversation) {
                msg.conversation = interactionId;
            }

            // بعض الأنظمة تعتمد على extendedTextMessage
            if (!msg.extendedTextMessage) {
                msg.extendedTextMessage = {
                    text: interactionId
                };
            } else if (!msg.extendedTextMessage.text) {
                msg.extendedTextMessage.text = interactionId;
            }

            return interactionId;

        } catch (error) {
            console.log(chalk.red('❌ normalizeAllInteractions error:'), error.message);
            return null;
        }
    }

    getInteractionType(msg) {
        if (!msg) return 'unknown';

        if (msg.buttonsResponseMessage) return 'buttons';
        if (msg.templateButtonReplyMessage) return 'template';
        if (msg.listResponseMessage) return 'list';
        if (msg.interactiveResponseMessage) return 'interactive';
        if (msg.nativeFlowResponseMessage) return 'native_flow';
        if (msg.buttonReplyMessage) return 'button';
        if (msg.messageContextInfo) return 'context';

        return 'unknown';
    }

    // معالجة كل أمر في thread منفصل
    async processSingleMessage(message) {
        return new Promise((resolve) => {
            // بدء المعالجة في دورة event منفصلة
            setImmediate(async () => {
                let cmdName = '';
                try {
                    this.stats.messagesProcessed++;
                    
                    const userJid = this.getUserJid(message);
                    if (this.security.blockedUsers.has(userJid)) {
                        return resolve(false);
                    }

                    // ✅ كل جلسات البوت (الرئيسية والفرعية) تعالج رسائل جميع المستخدمين.
                    // صلاحيات الأوامر الخاصة تظل محمية داخل checkPermissions (ownerOnly / developer / vip).

                    const text = this.extractText(message);

                    // 🔒 وضع الخاص فقط: تجاهل الجروبات تماماً (ماعدا أمر .خاص من المطور عشان يقدر يرجّعه)
                    if (this.isGroup(message) && isPrivateOnly(this.bot.sock)) {
                        const pre = String(this.bot.config?.PREFIX || '.').toLowerCase();
                        const t = String(text || '').trim().toLowerCase();
                        const cmd = t.startsWith(pre) ? t.slice(pre.length).trim().split(/\s+/)[0] : '';
                        const isToggle = ['خاص', 'private', 'privateonly', 'خاص-فقط'].includes(cmd) && this.isPowerMessage(message);
                        if (!isToggle) return resolve(false);
                    }

                    // 📊 نظام المجتمع: نقاط / إحصائيات / كتم الأعضاء / إجابات الألغاز
                    if (this.isGroup(message)) {
                        try {
                            const muted = await trackGroup(message, text || '', this.bot.sock, (this.bot.config?.PREFIX || "."), this.isPowerMessage(message), this.bot.phone);
                            if (muted) return resolve(true);
                        } catch (e) { console.log(chalk.red('❌ community track error:'), e.message); }
                    }

                    if (!text) return resolve(false);

                    const isGroup = this.isGroup(message);
                    // في الجروبات واتساب ساعات بيبعت LID بدل الرقم، فنفحص كمان الرقم الحقيقي (participantPn / participantAlt)
                    // صلاحيات كاملة = الأونر أو أي رقم مربوط (ماعدا أوامر DEV_ONLY_COMMANDS للأونر بس)
                    const isDev = this.isPowerMessage(message);
                    // 🚫 المحظورين من البوت (الأونر والأرقام المربوطة مستثنيين)
                    if (!isDev) {
                        try { if (isBannedWA(this._senderIds(message))) return resolve(false); } catch {}
                    }
                    if (isGroup && !this.isOwnerMessage(message)) {
                        try { if (await moderate(message, text, this.bot.sock)) return resolve(true); } catch (e) { console.log('❌ moderation error:', e.message); }
                    }
                    // 🛡️ وضع الجروب: لو "المشرفين فقط" يبقى غير المشرفين مالهمش استخدام للبوت
                    if (isGroup && !isDev && getGroupMode(this.bot.sock, message.key.remoteJid) === 'admins') {
                        let allowed = false;
                        try {
                            const meta = await __gmMeta(this.bot.sock, message.key.remoteJid);
                            allowed = __gmFlags(this.bot.sock, message, meta).isAdmin;
                        } catch {}
                        if (!allowed) return resolve(false);
                    }
                    const prefix = (this.bot.config?.PREFIX || ".");
                    const hasPrefix = text.toLowerCase().startsWith(prefix.toLowerCase());

                    const userData = this.getUserData(userJid);
                    userData.messageCount++;
                    userData.lastSeen = Date.now();

                    // 💬 الردود الذكية التلقائية
                    if (!hasPrefix && await this.handleSmartReply(message, text, userJid, isGroup)) {
                        return resolve(true);
                    }

                    // كل أمر بيتنفذ بشكل مستقل
                    if (hasPrefix) {
                        const result = await this.handlePrefixCommand(message, text, userJid, isGroup, isDev);
                        if (result) return resolve(true);
                    }

                    const autoResult = await this.handleAutoCommand(message, text, userJid, isGroup, isDev);
                    if (autoResult) return resolve(true);
                    
                    const continuousResult = await this.handleContinuousCommand(message, text, userJid);
                    if (continuousResult) return resolve(true);

                    resolve(false);
                } catch (error) {
                    this.stats.errors++;
                    console.log(chalk.red(`❌ Command error in [${cmdName || 'unknown'}]:`), error.message);
                    resolve(false);
                }
            });
        });
    }

    async handlePrefixCommand(message, text, userJid, isGroup, isDev) {
        const prefix = (this.bot.config?.PREFIX || ".");
        const args = text.slice(prefix.length).trim().split(/ +/);
        const cmdName = args.shift().toLowerCase();
        
        const command = this.commands.get(cmdName) || this.commands.get(this.aliases.get(cmdName));
        if (!command) return false;

        // ⚡ نظام تحقق سريع مع كاش
        const permissionCheck = await this.checkPermissions(command, userJid, isGroup, isDev, message);
        if (!permissionCheck.allowed) {
            if (permissionCheck.message && message) {
                await this.sendMessage(message.key.remoteJid, { text: permissionCheck.message });
            }
            return false;
        }

  
        console.log(gradient.mind(`🎯 Executing: ${command.name} from ${this.getSenderInfo(message)}`));

        const userData = this.getUserData(userJid);
        userData.commandCount++;
        command.usageCount = (command.usageCount || 0) + 1;
        command.lastUsed = Date.now();
        this.updateCooldown(command, message);

        this.updateCommandStats(userData, command.category);

        const __compat = command.foreign ? await enrichContext(message, this.bot.sock) : {};
        const runOptions = {
            ...__compat,
            bot: this.bot,
            sock: this.bot.sock,
            m: message,
            message: message,
            args: args,
            text: args.join(' '),
            handler: this,
            command: command.name,
            prefix: prefix,
            user: userData,
            userJid: userJid,
            isGroup: isGroup,
            isDeveloper: isDev,
            isOwner: this.isOwnerMessage(message),
            interaction: message.interaction || null,
            buttonId: message.buttonId || null,
            selectedButtonId: message.selectedButtonId || null,
            selectedId: message.selectedId || null,
            selectedRowId: message.selectedRowId || null,
            interactionId: message.interactionId || null,
            rowId: message.rowId || null,
            buttonText: message.buttonText || null,
            reply: (content, options = {}) => this.sendMessage(
                message.key.remoteJid,
                (typeof content === 'string' ? { text: content } : content),
                { quoted: message, ...options }
            ),
            react: (emoji) => this.react(message, emoji),
            sendMessage: (jid, content, options) => this.sendMessage(jid, content, options),
            getUserInfo: (targetArgs = args) => this.getUserInfo(this.bot.sock, message, targetArgs),
            getGroupInfo: () => this.getGroupInfo(message.key.remoteJid),
            startContinuous: (data = {}) => this.startContinuousCommand(userJid, command, data),
            endContinuous: () => this.endContinuousCommand(userJid),
            wait: (ms) => new Promise(resolve => setTimeout(resolve, ms)),
            log: (msg, type = 'info') => {
                const colors = { info: chalk.blue, warn: chalk.yellow, error: chalk.red };
                console.log(colors[type](`[${command.name}]`), msg);
            },
            formatNumber: (num) => new Intl.NumberFormat().format(num),
            formatTime: (ms) => this.formatUptime(ms),
            downloadMedia: () => this.downloadMedia(message),
            sendMedia: (jid, buffer, type, options) => this.sendMedia(jid, buffer, type, options),
            createButtons: (buttons, text, title) => this.createButtons(buttons, text, title),
            createList: (sections, title, text) => this.createList(sections, title, text),
        };
        
        try {
            await command.run(runOptions);
            this.stats.commandsExecuted++;
            return true;
        } catch (error) {
            console.log(chalk.red(`❌ Command execution error [${command.name}]:`), error);
            await this.sendMessage(message.key.remoteJid, { 
                text: `❌ حدث خطأ أثناء تنفيذ الأمر: ${error.message}` 
            });
            return true;
        }
    }

    // 🎮 نظام جلسات الألعاب
    createGameSession(userJid, gameType, initialData = {}) {
        const sessionId = `${userJid}_${gameType}_${Date.now()}`;
        const session = {
            id: sessionId,
            userJid: userJid,
            gameType: gameType,
            data: initialData,
            state: 'waiting',
            players: [userJid],
            createdAt: Date.now(),
            lastActivity: Date.now(),
            maxPlayers: initialData.maxPlayers || 10,
            settings: {
                private: initialData.private || false,
                password: initialData.password || null,
                timeLimit: initialData.timeLimit || 300000
            }
        };

        this.gameSessions.set(sessionId, session);
        
        setTimeout(() => {
            if (this.gameSessions.has(sessionId)) {
                this.endGameSession(sessionId);
            }
        }, session.settings.timeLimit);

        return session;
    }

    joinGameSession(sessionId, userJid, password = null) {
        const session = this.gameSessions.get(sessionId);
        if (!session) return { success: false, reason: 'SESSION_NOT_FOUND' };

        if (session.settings.private && session.settings.password !== password) {
            return { success: false, reason: 'INVALID_PASSWORD' };
        }

        if (session.players.length >= session.maxPlayers) {
            return { success: false, reason: 'SESSION_FULL' };
        }

        if (!session.players.includes(userJid)) {
            session.players.push(userJid);
            session.lastActivity = Date.now();
        }

        return { success: true, session: session };
    }

    endGameSession(sessionId) {
        const session = this.gameSessions.get(sessionId);
        if (session) {
            this.gameSessions.delete(sessionId);
            return true;
        }
        return false;
    }

    getActiveGameSessions(gameType = null) {
        const now = Date.now();
        const activeSessions = [];

        for (const [sessionId, session] of this.gameSessions) {
            if (now - session.lastActivity < 600000) {
                if (!gameType || session.gameType === gameType) {
                    activeSessions.push(session);
                }
            } else {
                this.endGameSession(sessionId);
            }
        }

        return activeSessions;
    }

    // ==================== ✨ نظام التحقق من الصلاحيات (محسن مع Cache) ✨ ====================
    async checkPermissions(command, userJid, isGroup, isDev, message) {
        const fromOwner = this.isOwnerMessage(message);

        // أوامر إدارة النظام متاحة لأي واحد من المالكين، بغض النظر عن جلسة البوت الحالية.
        if (command.ownerSession && !fromOwner) return { allowed: false };

        // أوامر إدارة المطورين والمالكين لا ينفذها إلا أحد المالكين.
        if (command.ownerOnly && !fromOwner) {
            return { allowed: false, message: '❌ هذا الأمر للمالكين فقط' };
        }

        // أوامر المطور والنظام محصورة بالمالكين والمطورين المسجلين.
        const devOnly = this.bot.config?.DEV_ONLY_COMMANDS || [];
        if (devOnly.includes(command.name) && !this.isStaffMessage(message)) {
            return { allowed: false, message: '❌ هذا الأمر للمالك والمطورين فقط' };
        }

        // أوامر المطورين متاحة للمالكين والمطورين المسجلين فقط.
        if (command.developer && !this.isStaffMessage(message)) {
            return { allowed: false, message: '❌ هذا الأمر للمالك والمطورين فقط' };
        }

        // 👑 VIP check
        if (command.vip) {
            try {
                const { isVip } = await import('./lib/vip.js');
                const senderNum = String(userJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
                if (!isVip(senderNum) && !fromOwner) {
                    return { allowed: false, message: '👑 هذا الأمر للـ VIP فقط\nاشترك في VIP عشان تستخدمه .vip' };
                }
            } catch (e) {
                console.log('[VIP check]', e.message);
            }
        }

        if (command.group && !isGroup) return { allowed: false, message: '❌ هذا الأمر للمجموعات فقط' };
        
        if (command.private && isGroup) return { allowed: false, message: '❌ هذا الأمر للخاص فقط' };

        if (!isGroup || (!command.admin && !command.botAdmin)) {
            return { allowed: true };
        }

        const groupJid = message.key.remoteJid;
        let groupMetadata = this.cache.get(groupJid);
        if (!groupMetadata) {
            console.log(chalk.yellow(`[Cache] Miss for group: ${groupJid}`));
            groupMetadata = await this.bot.sock.groupMetadata(groupJid);
            this.cache.set(groupJid, groupMetadata);
        } else {
            console.log(chalk.green(`[Cache] Hit for group: ${groupJid}`));
        }

        // التحقق من صلاحيات المشرف (بيدعم LID + الأرقام الحقيقية)
        const { isAdmin: senderIsAdmin, isBotAdmin } = __gmFlags(this.bot.sock, message, groupMetadata);

        if (command.admin) {
            if (!senderIsAdmin && !isDev) {
                return { allowed: false, message: '❌ هذا الأمر للمشرفين فقط' };
            }
        }

        if (command.botAdmin) {
            if (!isBotAdmin) {
                return { allowed: false, message: '❌ يجب أن يكون البوت مشرفًا' };
            }
        }

        return { allowed: true };
    }

    // ==================== نظام إدارة الجروبات المحسن ====================
    async isGroupAdmin(groupJid, userJid) {
        try {
            const metadata = await this.bot.sock.groupMetadata(groupJid);
            const participant = metadata.participants.find(p => p.id === userJid);
            return participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
        } catch (error) {
            console.log(chalk.red('❌ Check group admin error:'), error.message);
            return false;
        }
    }

    async getGroupInfo(groupJid) {
        try {
            const metadata = await this.bot.sock.groupMetadata(groupJid);
            return {
                id: metadata.id,
                subject: metadata.subject,
                description: metadata.desc,
                size: metadata.participants.length,
                creation: metadata.creation,
                owner: metadata.owner,
                admins: metadata.participants.filter(p => p.admin).map(p => p.id),
                participants: metadata.participants
            };
        } catch (error) {
            console.log(chalk.red('❌ Get group info error:'), error.message);
            return null;
        }
    }

    // ==================== نظام الإحصائيات المحسن ====================
    updateCommandStats(userData, category) {
        if (!userData.stats) return;

        const statMap = {
            admin: 'adminCommandsUsed',
            game: 'gameCommandsUsed',
            info: 'infoCommandsUsed',
            media: 'mediaCommandsUsed',
            download: 'downloads',
            tool: 'queries'
        };

        const statKey = statMap[category] || 'queries';
        userData.stats[statKey] = (userData.stats[statKey] || 0) + 1;
    }


    // ==================== نظام Cooldown المحسن ====================
    checkCooldown(command, message) {
        const userJid = this.getUserJid(message);
        const cooldownKey = `${userJid}:${command.name}`;
        const now = Date.now();

        if (this.cooldowns.has(cooldownKey)) {
            const expirationTime = this.cooldowns.get(cooldownKey) + (command.cooldown || 2000);
            if (now < expirationTime) {
                const remaining = Math.ceil((expirationTime - now) / 1000);
                return { allowed: false, remaining };
            }
        }

        return { allowed: true, remaining: 0 };
    }

    updateCooldown(command, message) {
        const userJid = this.getUserJid(message);
        const cooldownKey = `${userJid}:${command.name}`;
        this.cooldowns.set(cooldownKey, Date.now());
    }

    // ==================== نظام الأوامر المستمرة ====================
    startContinuousCommand(userJid, command, initialData = {}) {
        this.continuousCommands.set(userJid, {
            command,
            data: initialData,
            step: 0,
            timestamp: Date.now()
        });

        setTimeout(() => {
            if (this.continuousCommands.get(userJid)?.timestamp === Date.now() - 600000) {
                this.endContinuousCommand(userJid);
            }
        }, 600000);

        return true;
    }

    endContinuousCommand(userJid) {
        this.continuousCommands.delete(userJid);
        return true;
    }

    async handleContinuousCommand(message, text, userJid) {
        const continuousData = this.continuousCommands.get(userJid);
        if (!continuousData) return false;

        const { command, data, step } = continuousData;
        
        if (command.onContinue && typeof command.onContinue === 'function') {
            try {
                const result = await command.onContinue({
                    bot: this.bot,
                    sock: this.bot.sock,
                    message: message,
                    text: text,
                    userJid: userJid,
                    data: data,
                    step: step,
                    handler: this,
                    reply: (content) => this.sendMessage(message.key.remoteJid, 
                        typeof content === 'string' ? { text: content } : content, 
                        { quoted: message }
                    ),
                    endContinuous: () => this.endContinuousCommand(userJid)
                });

                if (result === true || result === 'continue') {
                    this.continuousCommands.set(userJid, {
                        command,
                        data: result.data || data,
                        step: step + 1,
                        timestamp: Date.now()
                    });
                } else if (result === false || result === 'end') {
                    this.endContinuousCommand(userJid);
                }

                return true;
            } catch (error) {
                console.log(chalk.red(`❌ Continuous command error:`), error.message);
                this.endContinuousCommand(userJid);
                return true;
            }
        }

        return false;
    }

    // ==================== 💬 نظام الردود الذكية التلقائية ====================
    async handleSmartReply(message, text, userJid, isGroup) {
        const clean = String(text || '')
            .toLowerCase()
            .replace(/[ًٌٍَُِّْـ]/g, '')
            .replace(/[إأآ]/g, 'ا')
            .replace(/ة/g, 'ه')
            .replace(/ؤ/g, 'و')
            .replace(/ئ/g, 'ي')
            .trim();

        if (!clean || clean.startsWith(this.bot.config?.PREFIX || '.')) return false;

        // 🚫 البوت مايردش على نفسه ولا على رسايل البوتات التانية (منع لفة الترحيب اللانهائية)
        if (message?.key?.fromMe) return false;
        if (/^(BAE5|SOFA)/i.test(String(message?.key?.id || ''))) return false;

        // منع تكرار الرد من نفس الشخص بسرعة.
        const key = `smart:${userJid}:${isGroup ? message.key.remoteJid : 'private'}`;
        const now = Date.now();
        const last = this.cache.get(key);
        if (last && now - last < 7000) return false;

        const rules = [
            { re: /^(اهلا|اهلين|هلا|هلاو|مرحبا|مرحباً|السلام عليكم|سلام عليكم|هاي|هلو|helo|hello|hi)(\s|!|؟|\?|$)/i, replies: [
                'اهلين وسهلين 🌷 نورت المكان يا غالي ❤️',
                'يا هلااا 😎✨ نورت SOFA BOT',
                'أهلاً بيك 🌟 منورنا والله',
                'هلا بالغالي 👑 نورتنا'
            ]},
            { re: /^(شكرا|شكراً|تسلم|تسلمي|مشكور|مشكورة|ثانكس|thanks)(\s|!|؟|\?|$)/i, replies: [
                'العفو يا نجم ❤️',
                'ولا يهمك ✨ تحت أمرك',
                'حبيبي، ده واجبي 😎',
                'العفو 🌷 أي وقت'
            ]},
            { re: /^(باي|سلام|مع السلامه|مع السلامة|اشوفكم|تصبحون على خير)(\s|!|؟|\?|$)/i, replies: [
                'مع السلامة 👋 نورتنا',
                'في أمان الله 🌙 ارجع لنا قريب',
                'باي يا نجم ❤️ ننتظرك'
            ]},
            { re: /^(صباح الخير|صباح النور)(\s|!|؟|\?|$)/i, replies: [
                'صباح النور والسرور ☀️🌷',
                'صباحك جميل يا نجم ✨',
                'صباح الفل 🌸 نورت'
            ]},
            { re: /^(مساء الخير|مساء النور)(\s|!|؟|\?|$)/i, replies: [
                'مساء النور 🌙✨',
                'مساءك جميل يا غالي 🌷',
                'مساء الفل 😎'
            ]},
            { re: /^(بوت|يا بوت|يا سوفا|سوفا)(\s|!|؟|\?|$)/i, replies: [
                'معاك SOFA BOT 🤖✨',
                'أيوه يا نجم؟ 😎',
                'قول بس 👑 أنا سامعك'
            ]},
            { re: /(بوت غبي|يا غبي|غبي|اهبل|أهبل|مجنون|يا حمار|حمار)/i, replies: [
                '😂😂 بالراحة يا نجم، خلينا نهزر من غير تجريح.',
                'ههههه مش كده يا صاحبي 😎 قول طلبك وأنا أساعدك.',
                'يا عم اهدى 😂 أنا بوت مسالم، قول عايز إيه.'
            ]},
            { re: /(بحبك|احبك|love you|luv u)/i, replies: [
                'وأنا مبسوط إنك مبسوط مع SOFA BOT 🤖❤️',
                'تسلم يا نجم 🌟 خلينا أصحاب وبس 😄',
                '❤️✨ منور البوت يا غالي'
            ]}
        ];

        // لو النص ده هو نفسه واحد من ردود البوت (جلسة تانية للبوت في نفس الجروب) متردش عليه
        const norm = (t) => String(t || '').toLowerCase().replace(/[ًٌٍَُِّْـ]/g, '').replace(/[إأآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').trim();
        if (rules.some((r) => r.replies.some((x) => norm(x) === clean))) return false;

        for (const rule of rules) {
            if (!rule.re.test(clean)) continue;
            this.cache.set(key, now);
            const reply = rule.replies[Math.floor(Math.random() * rule.replies.length)];
            await this.sendMessage(message.key.remoteJid, { text: reply }, { quoted: message });
            return true;
        }

        return false;
    }


    // ==================== نظام الأوامر التلقائية ====================
    async handleAutoCommand(message, text, userJid, isGroup, isDev) {
        for (const [cmdName, command] of this.autoCommands.entries()) {
            if (this.textMatchesCommand(text, cmdName, command.aliases)) {
                const permissionCheck = await this.checkPermissions(command, userJid, isGroup, isDev, message);
                if (!permissionCheck.allowed) {
                    continue;
                }

                const args = this.extractAutoCommandArgs(text, cmdName, command.aliases);
                
                console.log(gradient.mind(`🎯 Executing AUTO: ${command.name} from ${this.getSenderInfo(message)}`));

                const userData = this.getUserData(userJid);
                userData.messageCount++;
                userData.lastSeen = Date.now();
                command.usageCount = (command.usageCount || 0) + 1;
                command.lastUsed = Date.now();
                userData.commandCount++;
                this.updateCooldown(command, message);

                const __compat = command.foreign ? await enrichContext(message, this.bot.sock) : {};
        const runOptions = {
            ...__compat,
                    bot: this.bot,
                    sock: this.bot.sock,
                    message: message,
                    args: args,
                    text: args.join(' '),
                    handler: this,
                    command: command.name,
                    prefix: (this.bot.config?.PREFIX || "."),
                    user: userData,
                    userJid: userJid,
                    isGroup: isGroup,
                    isDeveloper: isDev,
                    isAuto: true,
                    interaction: message.interaction || null,
                    buttonId: message.buttonId || null,
                    selectedButtonId: message.selectedButtonId || null,
                    selectedId: message.selectedId || null,
                    selectedRowId: message.selectedRowId || null,
                    interactionId: message.interactionId || null,
                    rowId: message.rowId || null,
                    buttonText: message.buttonText || null,
                    reply: (content, options = {}) => this.sendMessage(
                        message.key.remoteJid,
                        (typeof content === 'string' ? { text: content } : content),
                        { quoted: message, ...options }
                    ),
                    react: (emoji) => this.react(message, emoji),
                    sendMessage: (jid, content, options) => this.sendMessage(jid, content, options),
                    getUserInfo: (targetArgs = args) => this.getUserInfo(this.bot.sock, message, targetArgs),
                    startContinuous: (data = {}) => this.startContinuousCommand(userJid, command, data),
                    endContinuous: () => this.endContinuousCommand(userJid)
                };
                
                await command.run(runOptions);

                this.stats.commandsExecuted++;
                return true;
            }
        }
        return false;
    }

    textMatchesCommand(text, cmdName, aliases = []) {
        const cleanText = text.toLowerCase().trim();
        const patterns = [cmdName.toLowerCase(), ...aliases.map(a => a.toLowerCase())];
        
        return patterns.some(pattern => {
            return cleanText === pattern || 
                   cleanText.startsWith(pattern + ' ') ||
                   cleanText.includes(' ' + pattern + ' ') ||
                   cleanText.endsWith(' ' + pattern);
        });
    }

    extractAutoCommandArgs(text, cmdName, aliases = []) {
        const patterns = [cmdName, ...aliases].map(p => p.toLowerCase());
        let cleanText = text.toLowerCase();
        
        for (const pattern of patterns) {
            if (cleanText.includes(pattern)) {
                cleanText = cleanText.replace(pattern, '').trim();
                break;
            }
        }
        
        return cleanText.split(/ +/).filter(arg => arg.length > 0);
    }

    // ==================== دوال مساعدة محسنة ====================
    getSenderInfo(message) {
        const jid = message.key.remoteJid;
        const name = message.pushName || 'Unknown';
        const isGroup = jid.endsWith('@g.us');
        const isFromMe = message.key.fromMe;
        
        if (isFromMe) return 'BOT';
        if (isGroup) return `${name} (Group)`;
        return name;
    }

    getUserJid(message) {
        if (message.key.fromMe) {
            const id = this.bot.sock?.user?.id;
            if (id) return String(id).split(':')[0].split('@')[0] + '@s.whatsapp.net';
        }
        return message.key.participant || message.key.remoteJid;
    }

    isGroup(message) {
        return message.key.remoteJid.endsWith('@g.us');
    }

    // ==================== استخراج النص ودعم جميع أنواع الأزرار ====================
    extractText(message) {
        // فك الرسائل المغلّفة (جروبات الرسائل المؤقتة / عرض لمرة واحدة) وإلا الردود والأوامر فيها بتتجاهل
        const msg = unwrap(message?.message);
        if (!msg) return null;

        // النصوص العادية
        if (msg.conversation) return msg.conversation;
        if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;

        // Captions
        if (msg.imageMessage?.caption) return msg.imageMessage.caption;
        if (msg.videoMessage?.caption) return msg.videoMessage.caption;
        if (msg.documentMessage?.caption) return msg.documentMessage.caption;

        // Buttons Response
        if (msg.buttonsResponseMessage) {
            return (
                msg.buttonsResponseMessage.selectedButtonId ||
                msg.buttonsResponseMessage.selectedId ||
                msg.buttonsResponseMessage.buttonId ||
                msg.buttonsResponseMessage.selectedDisplayText ||
                null
            );
        }

        // Template Button
        if (msg.templateButtonReplyMessage) {
            return (
                msg.templateButtonReplyMessage.selectedId ||
                msg.templateButtonReplyMessage.selectedButtonId ||
                msg.templateButtonReplyMessage.buttonId ||
                msg.templateButtonReplyMessage.selectedDisplayText ||
                null
            );
        }

        // List Response
        if (msg.listResponseMessage) {
            return (
                msg.listResponseMessage.singleSelectReply?.selectedRowId ||
                msg.listResponseMessage.selectedRowId ||
                msg.listResponseMessage.rowId ||
                msg.listResponseMessage.selectedId ||
                msg.listResponseMessage.title ||
                null
            );
        }

        // Button Reply
        if (msg.buttonReplyMessage) {
            return (
                msg.buttonReplyMessage.selectedId ||
                msg.buttonReplyMessage.selectedButtonId ||
                msg.buttonReplyMessage.buttonId ||
                msg.buttonReplyMessage.selectedDisplayText ||
                null
            );
        }

        // Interactive Response / Native Flow
        if (msg.interactiveResponseMessage) {
            const nativeFlow =
                msg.interactiveResponseMessage.nativeFlowResponseMessage;

            if (nativeFlow) {
                try {
                    const params = JSON.parse(nativeFlow.paramsJson || '{}');

                    return (
                        params.id ||
                        params.button_id ||
                        params.buttonId ||
                        params.selectedId ||
                        params.selectedButtonId ||
                        params.selectedRowId ||
                        params.rowId ||
                        params.command ||
                        params.value ||
                        params.action ||
                        params.display_text ||
                        params.displayText ||
                        nativeFlow.name ||
                        null
                    );
                } catch (error) {
                    return (
                        nativeFlow.name ||
                        nativeFlow.messageParamsJson ||
                        null
                    );
                }
            }

            return (
                msg.interactiveResponseMessage.body?.text ||
                msg.interactiveResponseMessage.header?.text ||
                null
            );
        }

        // Native Flow Response مباشرة
        if (msg.nativeFlowResponseMessage) {
            const nativeFlow = msg.nativeFlowResponseMessage;

            try {
                const params = JSON.parse(nativeFlow.paramsJson || '{}');

                return (
                    params.id ||
                    params.button_id ||
                    params.buttonId ||
                    params.selectedId ||
                    params.selectedButtonId ||
                    params.selectedRowId ||
                    params.rowId ||
                    params.command ||
                    params.value ||
                    params.action ||
                    params.display_text ||
                    params.displayText ||
                    nativeFlow.name ||
                    null
                );
            } catch (error) {
                return (
                    nativeFlow.name ||
                    nativeFlow.messageParamsJson ||
                    null
                );
            }
        }

        // Message Context Info
        if (msg.messageContextInfo) {
            return (
                msg.messageContextInfo.selectedButtonId ||
                msg.messageContextInfo.selectedId ||
                msg.messageContextInfo.selectedRowId ||
                msg.messageContextInfo.buttonId ||
                msg.messageContextInfo.rowId ||
                msg.messageContextInfo.interactionId ||
                null
            );
        }

        // الحقول العامة للتفاعلات في إصدارات Baileys المختلفة
        const possibleFields = [
            'selectedButtonId',
            'selectedId',
            'selectedRowId',
            'buttonId',
            'interactionId',
            'rowId',
            'actionId'
        ];

        for (const field of possibleFields) {
            if (msg[field]) {
                return msg[field];
            }
        }

        return null;
    }

    // ==================== نظام الإرسال المحسن ====================
    async sendMessage(jid, content, options = {}) {
        try {
            if (typeof content === 'string') {
                content = { text: content };
            }

            const newOptions = { ...options };

            if (newOptions.quoted && newOptions.quoted.key) {
                newOptions.quoted = {
                    key: newOptions.quoted.key,
                    message: newOptions.quoted.message
                };
            }

            return await this.bot.sendMessage(jid, content, newOptions);

        } catch (error) {
            if (!error.message.includes('Invalid media type')) {
                console.log(chalk.red(`❌ Send message error: ${error.message}`));
            }
            return null;
        }
    }

    async react(message, emoji) {
        try {
            await this.bot.sendMessage(message.key.remoteJid, {
                react: {
                    text: emoji,
                    key: message.key
                }
            });
        } catch (error) {
            console.log(chalk.red(`❌ React error: ${error.message}`));
        }
    }

    // ==================== ✨ نظام الوسائط الفائق ====================
    async downloadMedia(message) {
        try {
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const original = message.message;

            let type = null;
            let mediaMessage = null;

            if (quoted) {
                type = Object.keys(quoted)[0];
                mediaMessage = quoted[type];
            } else if (original) {
                type = Object.keys(original)[0];
                mediaMessage = original[type];
            }

            if (!mediaMessage || !type) {
                console.log(chalk.red('❌ Media message not found.'));
                return null;
            }
            
            const stream = await downloadContentFromMessage(mediaMessage, type.replace('Message', ''));
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            
            console.log(chalk.green(`✅ Media downloaded successfully (${(buffer.length / 1024).toFixed(2)} KB)`));
            return buffer;

        } catch (error) {
            console.log(chalk.red('❌ Media download error:'), error.message);
            return null;
        }
    }

    async sendMedia(jid, buffer, type, options = {}) {
        try {
            let mediaMessage = {};
            
            switch (type) {
                case 'image':
                    mediaMessage = { image: buffer, ...options };
                    break;
                case 'video':
                    mediaMessage = { video: buffer, ...options };
                    break;
                case 'audio':
                    mediaMessage = { audio: buffer, ...options };
                    break;
                case 'document':
                    mediaMessage = { document: buffer, ...options };
                    break;
                case 'sticker':
                    mediaMessage = { sticker: buffer, ...options };
                    break;
            }
            
            return await this.sendMessage(jid, mediaMessage);
        } catch (error) {
            console.log(chalk.red(`❌ Send media error: ${error.message}`));
            return null;
        }
    }

    // ==================== نظام الأزرار والقوائم المحسن ====================
    createButtons(buttons, text = 'اختر من الأزرار:', title = 'SOLO BOT') {
        return {
            text: text,
            footer: 'SOLO BOT - KING',
            title: title,
            buttons: buttons.map(btn => ({
                buttonId: btn.id,
                buttonText: { 
                    displayText: btn.text 
                },
                type: 1
            })),
            headerType: 1
        };
    }

    createList(sections, title = 'القائمة', text = 'اختر من القائمة:') {
        return {
            text: text,
            footer: 'SOLO BOT - KING',
            title: title,
            buttonText: 'عرض الخيارات',
            sections: Array.isArray(sections) ? sections : [sections]
        };
    }

    createSection(title, rows) {
        return {
            title: title,
            rows: rows.map(row => ({
                title: row.title,
                description: row.description || '',
                rowId: row.id || Math.random().toString(36).substring(7)
            }))
        };
    }

    // ==================== نظام المراقبة المحسن ====================
    async startPluginWatcher() {
        try {
            const { default: chokidar } = await import('chokidar');
            
            if (this.watcher) await this.watcher.close();

            this.watcher = chokidar.watch(this.pluginDir, {
                persistent: true,
                ignoreInitial: true,
                atomic: true,
                awaitWriteFinish: { stabilityThreshold: 2000, pollInterval: 100 }
            });

            const handleFileEvent = async (filePath, eventType) => {
                if (this.isReloading || !filePath.endsWith('.js')) return;

                const filename = path.basename(filePath);
                
                try {
                    switch (eventType) {
                        case 'change':
                            console.log(chalk.yellow(`🔄 Plugin changed: ${filename}`));
                            await this.reloadPlugin(filename);
                            break;
                        case 'add':
                            console.log(chalk.green(`📁 New plugin: ${filename}`));
                            await this.loadSinglePlugin(filename);
                            this.showLoadedCommands();
                            break;
                        case 'unlink':
                            console.log(chalk.yellow(`🗑️ Plugin deleted: ${filename}`));
                            await this.unloadPlugin(filename);
                            this.showLoadedCommands();
                            break;
                    }
                } catch (error) {
                    console.log(chalk.red(`❌ Plugin ${eventType} failed for ${filename}:`), error.message);
                }
            };

            this.watcher
                .on('change', (filePath) => handleFileEvent(filePath, 'change'))
                .on('add', (filePath) => handleFileEvent(filePath, 'add'))
                .on('unlink', (filePath) => handleFileEvent(filePath, 'unlink'));

            console.log(chalk.cyan('👀 Plugin watcher V2 started successfully'));

        } catch (error) {
            console.log(chalk.red('❌ Plugin watch error:'), error.message);
        }
    }

    // ==================== ✨ نظام مراقبة الكونفج الجديد ✨ ====================
    async startConfigWatcher() {
        try {
            const { default: chokidar } = await import('chokidar');
            const configPath = path.resolve(process.cwd(), 'config.js');

            if (this.configWatcher) await this.configWatcher.close();

            this.configWatcher = chokidar.watch(configPath, {
                persistent: true,
                ignoreInitial: true,
                awaitWriteFinish: { stabilityThreshold: 1000, pollInterval: 100 }
            });

            this.configWatcher.on('change', async (filePath) => {
                console.log(chalk.yellow('🔄 Config file changed. Reloading configuration...'));
                try {
                    // نستورد الكونفج الجديد ونقوم بتحديثه في كائن البوت الرئيسي
                    const { config: newConfig } = await import(`${pathToFileURL(filePath).href}?v=${Date.now()}`);
                    this.bot.config = newConfig;
                    console.log(chalk.green('✅ Config reloaded successfully!'));
                    
                    // إرسال إشعار للمطور (اختياري)
                    const devJid = this.bot.config.OWNERERROR || (this.bot.config.DEVELOPERS && this.bot.config.DEVELOPERS[0]);

                } catch (error) {
                    console.log(chalk.red('❌ Failed to reload config:'), error.message);
                }
            });

            console.log(chalk.cyan('⚙️ Config watcher started successfully'));

        } catch (error) {
            console.log(chalk.red('❌ Config watch error:'), error.message);
        }
    }

    // =================================================================
    // ✨ نظام مراقبة الملفات الأساسية (Hot Reloading) ✨
    // =================================================================
    async startCoreFileWatcher() {
        try {
            if (this.coreWatcher) await this.coreWatcher.close();

            const { default: chokidar } = await import('chokidar');
            const rootDir = process.cwd();
            
            // المسارات التي سيتم مراقبتها (بدون البلجنات)
            const pathsToWatch = [
                path.join(rootDir, 'handler.js'),
                path.join(rootDir, 'index.js'),
                path.join(rootDir, 'console.js'),
                path.join(rootDir, 'messages.js')
            ];


            this.coreWatcher = chokidar.watch(pathsToWatch, {
                persistent: true,
                ignoreInitial: true,
                atomic: true,
                awaitWriteFinish: { stabilityThreshold: 2000, pollInterval: 100 }
            });

            this.coreWatcher.on('change', async (filePath) => {
                const filename = path.basename(filePath);
                console.log(chalk.magenta(`🚨 Core file (${filename}) changed. Triggering bot restart...`));
                
                // استدعاء دالة إعادة التشغيل في البوت الرئيسي
                if (typeof this.bot.restart === 'function') {
                    await this.bot.restart();
                } else {
                    console.log(chalk.red('  > Restart function not found on bot object. Exiting process...'));
                    process.exit(1);
                }
            });

            console.log(chalk.blueBright('👀 Core file watcher started successfully.'));

        } catch (error) {
            console.log(chalk.red('❌ Core file watch error:'), error.message);
        }
    }


    async reloadPlugin(pluginName) {
        let filename;
        
        for (const [loadedFilename, plugin] of this.plugins.entries()) {
            if (loadedFilename.replace('.js', '') === pluginName || 
                loadedFilename === pluginName ||
                (plugin.name && plugin.name === pluginName)) {
                filename = loadedFilename;
                break;
            }
        }
        
        if (!filename) {
            filename = pluginName.endsWith('.js') ? pluginName : `${pluginName}.js`;
            if (!this.plugins.has(filename)) {
                console.log(chalk.red(`❌ Reload failed: Plugin "${pluginName}" not found.`));
                console.log(chalk.yellow(`📁 Available plugins: ${Array.from(this.plugins.keys()).join(', ')}`));
                return false;
            }
        }

        const plugin = this.plugins.get(filename);
        console.log(chalk.cyan(`🔄 Reloading: ${filename} (${plugin.name})`));

        if (plugin.onUnload) {
            try {
                await plugin.onUnload();
            } catch (error) {
                console.log(chalk.red(`❌ Plugin onUnload failed: ${filename}`), error.message);
            }
        }

        if (plugin.commands && Array.isArray(plugin.commands)) {
            plugin.commands.forEach(cmd => {
                this.commands.delete(cmd.name);
                if (cmd.aliases) {
                    cmd.aliases.forEach(alias => this.aliases.delete(alias));
                }
            });
        } else if (plugin.name) {
            this.commands.delete(plugin.name);
            if (plugin.aliases) {
                plugin.aliases.forEach(alias => this.aliases.delete(alias));
            }
        }

        try {
            await this.loadSinglePlugin(filename);
            console.log(chalk.green(`✅ Successfully reloaded: ${filename}`));
            return true;
        } catch (error) {
            console.log(chalk.red(`❌ Failed to reload: ${filename}`), error.message);
            return false;
        }
    }

    async unloadPlugin(pluginName) {
        if (this.isReloading) return false;
        
        try {
            const plugin = this.plugins.get(pluginName);
            if (!plugin) return false;

            console.log(chalk.yellow(`🔄 Unloading: ${pluginName}`));

            if (plugin.onUnload) {
                try {
                    await plugin.onUnload();
                } catch (error) {
                    console.log(chalk.red(`❌ Plugin onUnload failed: ${pluginName}`), error.message);
                }
            }

            if (plugin.commands) {
                plugin.commands.forEach(cmd => {
                    this.commands.delete(cmd.name);
                    if (cmd.aliases) {
                        cmd.aliases.forEach(alias => {
                            this.aliases.delete(alias);
                        });
                    }
                });
            }

            this.plugins.delete(pluginName);
            console.log(chalk.green(`✅ Unloaded: ${pluginName}`));
            return true;
        } catch (error) {
            console.log(chalk.red(`❌ Unload plugin error: ${pluginName}`), error);
            return false;
        }
    }


    // ==================== نظام مراقبة الأداء ====================
    startPerformanceMonitor() {
        setInterval(() => {
            const memoryUsage = process.memoryUsage();
            const heapUsed = Math.round(memoryUsage.heapUsed / 1024 / 1024);
            const heapTotal = Math.round(memoryUsage.heapTotal / 1024 / 1024);
            
            if (heapUsed > 500) {
                global.gc && global.gc();
            }
        }, 60000);
    }

    // ==================== نظام التنظيف المحسن ====================
    startCleanupCycle() {
        setInterval(() => {
            this.cleanupExpiredData();
        }, 300000);
    }

    cleanupExpiredData() {
        const now = Date.now();
        let cleaned = 0;
        
        for (const [key, timestamp] of this.cooldowns.entries()) {
            if (now - timestamp > 300000) {
                this.cooldowns.delete(key);
                cleaned++;
            }
        }
        
        for (const [key, data] of this.security.spamDetection.entries()) {
            if (now - data.lastMessage > 600000) {
                this.security.spamDetection.delete(key);
                cleaned++;
            }
        }
        
        for (const [key, value] of this.cache.entries()) {
            if (now - value.timestamp > this.cacheTTL) {
                this.cache.delete(key);
                cleaned++;
            }
        }
        
        if (cleaned > 0) {
            console.log(chalk.blue(`🧹 Cleaned ${cleaned} expired entries`));
        }
    }

    // ==================== دوال الاستعلام المحسنة ====================
    getAllPlugins() {
        return Array.from(this.plugins.values());
    }

    getAllCommands() {
        return Array.from(this.commands.values());
    }

    getCommandsByCategory(category) {
        return this.getAllCommands().filter(cmd => cmd.category === category);
    }

    getPlugin(name) {
        return this.plugins.get(name);
    }

    getCommand(name) {
        return this.commands.get(name) || this.commands.get(this.aliases.get(name));
    }

    getStats() {
        const uptime = Date.now() - this.stats.startTime;
        const memory = process.memoryUsage();
        
        return {
            ...this.stats,
            uptime: this.formatUptime(uptime),
            pluginsCount: this.plugins.size,
            commandsCount: this.commands.size,
            memory: Math.round(memory.heapUsed / 1024 / 1024) + 'MB',
            mode: this.bot.config?.MODE || 'public',
            gameSessions: this.gameSessions.size
        };
    }

    formatUptime(ms) {
        const seconds = Math.floor(ms / 1000);
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;

        const parts = [];
        if (days > 0) parts.push(`${days} يوم`);
        if (hours > 0) parts.push(`${hours} ساعة`);
        if (minutes > 0) parts.push(`${minutes} دقيقة`);
        if (secs > 0) parts.push(`${secs} ثانية`);

        return parts.join(' ') || '0 ثانية';
    }

    getCommandUsage() {
        const commands = this.getAllCommands();
        return commands
            .filter(cmd => cmd.usageCount > 0)
            .sort((a, b) => b.usageCount - a.usageCount)
            .slice(0, 10)
            .map(cmd => ({
                name: cmd.name,
                usageCount: cmd.usageCount,
                plugin: cmd.plugin,
                category: cmd.category,
                lastUsed: cmd.lastUsed ? new Date(cmd.lastUsed).toLocaleString() : 'Never'
            }));
    }

    // ==================== نظام إعادة التحميل المحسن ====================
    async reloadAllPlugins() {
        console.log(chalk.yellow('🔄 Manual reload started...'));
        
        this.isReloading = true;
        try {
            const pluginNames = Array.from(this.plugins.keys());
            let successCount = 0;
            
            for (const pluginName of pluginNames) {
                try {
                    await this.unloadPlugin(pluginName);
                    successCount++;
                } catch (error) {
                    console.log(chalk.red(`❌ Failed to unload: ${pluginName}`));
                }
            }
            
            await this.loadPlugins();
            console.log(chalk.green(`✅ Reloaded ${successCount} plugins`));
            return successCount;
            
        } finally {
            this.isReloading = false;
        }
    }

    // ==================== الإغلاق المحسن ====================
    async close() {
        if (this.watcher) {
            await this.watcher.close();
        }
        this.saveData();
        this.isInitialized = false;
        console.log(chalk.yellow('🛑 Handler stopped'));
    }
}

export { Handler };