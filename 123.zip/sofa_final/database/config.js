import fs from 'fs';
import path from 'path';

const DIR = path.join(process.cwd(), 'data');
const FILE = path.join(DIR, 'sofa-db.json');
const digits = (j) => String(j || '').split('@')[0].split(':')[0].replace(/\D/g, '');

let db = { settings: { prefix: '.' }, groups: {}, warns: {}, badwords: {}, knownBots: [], chat: {} };
try { db = { ...db, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) }; } catch {}

let timer = null;
function flushSync() {
    try {
        fs.mkdirSync(DIR, { recursive: true });
        fs.writeFileSync(FILE + '.tmp', JSON.stringify(db));
        fs.renameSync(FILE + '.tmp', FILE);
    } catch {}
}
function save() { clearTimeout(timer); timer = setTimeout(flushSync, 500); }
process.on('exit', flushSync);

const DEFAULTS = { antilink: 'off', antibadword: 'off', antibot: 'off', antispam: 'off', warn_limit: 3 };

export async function getSettings() { return db.settings; }
export async function getGroupSettings(jid) { return { ...DEFAULTS, ...(db.groups[jid] || {}) }; }
export const getGroupSettingsFresh = getGroupSettings;
export async function updateGroupSetting(jid, key, value) {
    db.groups[jid] = { ...(db.groups[jid] || {}), [key]: value };
    save();
}
export async function getWarnLimit(jid) { return (await getGroupSettings(jid)).warn_limit || 3; }
export async function getWarnCount(jid, user) { return db.warns[jid]?.[digits(user)] || 0; }
export async function addWarn(jid, user) {
    const u = digits(user);
    db.warns[jid] = db.warns[jid] || {};
    db.warns[jid][u] = (db.warns[jid][u] || 0) + 1;
    save();
    return db.warns[jid][u];
}
export async function resetWarn(jid, user) {
    if (db.warns[jid]) delete db.warns[jid][digits(user)];
    save();
}
export async function getBadWords(jid) { return db.badwords[jid] || []; }
export async function addBadWord(jid, word) {
    const w = String(word).toLowerCase().trim();
    db.badwords[jid] = db.badwords[jid] || [];
    if (w && !db.badwords[jid].includes(w)) db.badwords[jid].push(w);
    save();
}
export async function removeBadWord(jid, word) {
    const w = String(word).toLowerCase().trim();
    db.badwords[jid] = (db.badwords[jid] || []).filter((x) => x !== w);
    save();
}
export async function getKnownBots() { return db.knownBots; }
export async function addKnownBot(num) {
    const n = digits(num);
    if (n && !db.knownBots.includes(n)) db.knownBots.push(n);
    save();
}
export async function removeKnownBot(num) {
    const n = digits(num);
    db.knownBots = db.knownBots.filter((x) => x !== n);
    save();
}
export async function getConversationHistory(user) { return db.chat[digits(user)] || []; }
export async function addConversationMessage(user, role, content) {
    const u = digits(user);
    db.chat[u] = [...(db.chat[u] || []), { role, content }].slice(-20);
    save();
}
export async function clearConversationHistory(user) { delete db.chat[digits(user)]; save(); }

const normLink = (l) => String(l || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/+$/, '');
export async function getTrustedLinks(jid) { return db.groups[jid]?.trusted_links || []; }
export async function addTrustedLink(jid, link) {
    const n = normLink(link);
    if (!n) return false;
    const list = db.groups[jid]?.trusted_links || [];
    if (!list.includes(n)) list.push(n);
    db.groups[jid] = { ...(db.groups[jid] || {}), trusted_links: list };
    save();
    return true;
}
export async function removeTrustedLink(jid, link) {
    const n = normLink(link);
    const list = db.groups[jid]?.trusted_links || [];
    const next = list.filter((x) => x !== n);
    db.groups[jid] = { ...(db.groups[jid] || {}), trusted_links: next };
    save();
    return next.length !== list.length;
}
export async function setWarnLimit(jid, n) { return updateGroupSetting(jid, 'warn_limit', Number(n)); }
