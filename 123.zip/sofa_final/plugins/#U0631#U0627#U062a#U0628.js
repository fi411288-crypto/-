// 💼 الراتب: كل 5 دقايق تقبض راتب حسب مستواك — SOFA BOT
import { resolveNumber, isRegistered, updateUser, getLevel } from '../lib/economy.js';
import { fmt, bump } from '../lib/shop.js';

const EVERY = 5 * 60 * 1000, BASE = 100, PER_LEVEL = 10, MAX_LEVEL = 40; // الراتب = 100 + 10 × المستوى (حد أقصى 500)

export default [{
    name: 'راتب',
    aliases: ['salary', 'مرتب'],
    category: 'games',
    description: 'اقبض راتبك كل 5 دقايق (بيزيد مع مستواك)',
    cooldown: 2000,
    async run({ sock, m, message, reply, prefix = '.' }) {
        const msg = m || message, number = await resolveNumber(sock, msg);
        if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
        const r = updateUser(number, (u, eco) => {
            const left = EVERY - (Date.now() - (u.salary?.last || 0));
            if (left > 0) return { error: 'wait', left };
            const lvl = getLevel(eco.exp), amt = BASE + Math.min(lvl, MAX_LEVEL) * PER_LEVEL;
            u.salary = { last: Date.now(), count: (u.salary?.count || 0) + 1 };
            eco.coin += amt; bump(u, 'salary');
            return { amt, lvl, total: eco.coin, count: u.salary.count };
        });
        if (r.error === 'wait') { const s = Math.ceil(r.left / 1000); return reply(`⏳ راتبك الجاي بعد *${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}* دقيقة.`); }
        if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ.');
        return reply(`💼 *SOFA • SALARY*\n\n💵 قبضت: \`+${fmt(r.amt)}\` كوين\n📈 مستواك: ${r.lvl}\n💰 رصيدك: \`${fmt(r.total)}\`\n⏱️ الراتب الجاي بعد 5 دقايق`);
    }
}];
