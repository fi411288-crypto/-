import { store, job, sockOf, perms, hhmm, mins } from '../lib/xtools.js';

const db = () => store('autolock', {}).data; // "رقم_البوت:جروب" -> { phone, jid, close, open, state }
const k = (phone, jid) => `${String(phone || 'main').replace(/\D/g, '') || 'main'}:${jid}`;

job('autolock', async () => {
    const now = mins(hhmm());
    for (const e of Object.values(db())) {
        const c = mins(e.close), o = mins(e.open);
        if (c === null || o === null) continue;
        const closed = c <= o ? now >= c && now < o : now >= c || now < o;
        if (e.state === closed || (e.retry && Date.now() < e.retry)) continue;
        const sock = sockOf(e.phone);
        if (!sock) continue;
        try {
            await sock.groupSettingUpdate(e.jid, closed ? 'announcement' : 'not_announcement');
            e.state = closed; e.retry = 0; store('autolock').save();
            await sock.sendMessage(e.jid, { text: closed ? `🔒 *تم قفل الجروب تلقائياً*\nبيتفتح الساعة ${e.open}\n\n> SOFA BOT` : `🔓 *تم فتح الجروب تلقائياً*\nبيتقفل الساعة ${e.close}\n\n> SOFA BOT` });
        } catch { e.retry = Date.now() + 10 * 60000; }
    }
}, 30000);

export default {
    name: 'قفل_تلقائي',
    aliases: ['قفل-تلقائي', 'autolock'],
    description: 'يقفل الجروب ويفتحه في مواعيد تحددها (بتوقيت القاهرة)',
    usage: '.قفل_تلقائي 23:00 07:00 | .قفل_تلقائي ايقاف',
    category: 'admin',
    group: true,
    async run({ sock, message, args, reply, bot, isDeveloper }) {
        const jid = message.key.remoteJid, key = k(bot?.phone, jid);
        const p = await perms({ sock, message, isDeveloper });
        if (!p.isAdmin) return reply('❌ الأمر ده للمشرفين فقط.');
        const a = args.map((x) => x.replace(/[٠-٩]/g, (d) => d.charCodeAt(0) - 1632));
        if (['ايقاف', 'إيقاف', 'الغاء', 'off'].includes(a[0])) {
            delete db()[key]; store('autolock').save();
            return reply('✅ اتلغى القفل التلقائي.');
        }
        const fix = (s) => { const m = /^(\d{1,2})(?::(\d{2}))?$/.exec(s || ''); return m && +m[1] < 24 && +(m[2] || 0) < 60 ? `${String(+m[1]).padStart(2, '0')}:${m[2] || '00'}` : null; };
        const close = fix(a[0]), open = fix(a[1]);
        if (!close || !open) {
            const e = db()[key];
            return reply(`🔒 *القفل التلقائي*\n${e ? `الحالة: شغال ✅\nيقفل: ${e.close} | يفتح: ${e.open}` : 'الحالة: مقفول ❌'}\n\nالتفعيل: .قفل_تلقائي 23:00 07:00\nالإيقاف: .قفل_تلقائي ايقاف\n(بتوقيت القاهرة، والبوت لازم يكون مشرف)`);
        }
        if (!p.isBotAdmin) return reply('❌ لازم البوت يكون مشرف الأول.');
        db()[key] = { phone: String(bot?.phone || 'main').replace(/\D/g, ''), jid, close, open, state: null };
        store('autolock').save();
        return reply(`✅ اتفعّل القفل التلقائي\n🔒 يقفل: ${close}\n🔓 يفتح: ${open}\n\n> SOFA BOT`);
    }
};
