import fetch from 'node-fetch';

const AR = [
    'النجاح مش نهاية، والفشل مش نهاية… الشجاعة إنك تكمل.',
    'اعمل في صمت، وخلي النجاح يعمل الضجة.',
    'كل يوم فرصة جديدة تبدأ من جديد.',
    'أقوى سلاح هو العقل الهادئ.',
    'ما تستناش الفرصة… اصنعها.'
];

export default {
    name: 'اقتباس',
    aliases: ['quote', 'حكمة', 'مقوله'],
    description: 'اقتباس تحفيزي عشوائي',
    category: 'tools',
    async run({ reply, react, text }) {
        await react?.('✨').catch?.(() => {});
        if ((text || '').toLowerCase().includes('en')) {
            try {
                const r = await fetch('https://api.quotable.io/random');
                if (r.ok) {
                    const d = await r.json();
                    return reply(`╭─❏ 「 ✨ Quote 」\n│ "${d.content}"\n│ — ${d.author}\n╰───────────────`);
                }
            } catch {}
        }
        const q = AR[Math.floor(Math.random() * AR.length)];
        return reply(`╭─❏ 「 ✨ اقتباس 」\n│ ${q}\n╰───────────────`);
    }
};
