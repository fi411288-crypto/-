import fs from 'fs';
import { isWelcomeOn, setWelcome, welcomeImage } from '../lib/welcome.js';

const ON = ['تشغيل', 'شغل', 'on', 'تفعيل'];
const OFF = ['ايقاف', 'إيقاف', 'توقيف', 'off', 'قفل'];

export default {
    name: "ترحيب",
    aliases: ["ترحيب-وداع", "welcome"],
    description: "تشغيل أو إيقاف الترحيب والتوديع في الجروب",
    category: "admin",
    group: true,
    admin: true,

    async run({ sock, message, args, reply, prefix }) {
        const jid = message.key.remoteJid;
        const p = prefix || '.';
        const choice = (args[0] || '').trim().toLowerCase();

        if (ON.includes(choice)) {
            setWelcome(jid, true);
            return reply("🟢 تم *تشغيل* الترحيب والتوديع في الجروب.");
        }
        if (OFF.includes(choice)) {
            setWelcome(jid, false);
            return reply("🔴 تم *إيقاف* الترحيب والتوديع في الجروب.");
        }

        const body = `⚙️ *إعدادات الترحيب والتوديع*\n\n📍 الحالة الآن: ${isWelcomeOn(jid) ? '🟢 *شغال*' : '🔴 *متوقف*'}\n\nاختر من الأزرار:`;
        const buttons = [
            { buttonId: `${p}ترحيب ايقاف`, buttonText: { displayText: "🔴 توقيف الترحيب" }, type: 1 },
            { buttonId: `${p}ترحيب تشغيل`, buttonText: { displayText: "🟢 تشغيل الترحيب" }, type: 1 }
        ];
        const footer = "SOFA BOT • Welcome";
        const img = welcomeImage();

        if (img) {
            try {
                await sock.sendMessage(jid, { image: fs.readFileSync(img), caption: body, footer, buttons, headerType: 4 }, { quoted: message });
                return;
            } catch {}
        }
        try {
            await sock.sendMessage(jid, { text: body, footer, buttons, headerType: 1 }, { quoted: message });
        } catch {
            return reply(`${body}\n\n• ${p}ترحيب ايقاف\n• ${p}ترحيب تشغيل`);
        }
    }
};
