import { Sticker, StickerTypes } from 'wa-sticker-formatter';
import { buildMessage } from '../lib/compat.js';

export default {
    name: 'ملصق',
    aliases: ['sticker', 'stiker'],
    description: 'تحويل صورة أو فيديو (حتى 10 ثواني) لملصق',
    category: 'tools',

    async run({ sock, message, reply, prefix }) {
        try {
            buildMessage(message, sock);
            const q = message.quoted || message;
            const mime = q.mimetype || '';
            if (!/image|video|webp/.test(mime)) {
                return reply(`📎 رد على صورة أو فيديو واكتب ${prefix}ملصق`);
            }
            if (/video/.test(mime) && (q.msg?.seconds || 0) > 10) {
                return reply('❌ الفيديو أطول من 10 ثواني.');
            }
            await reply('⏳ ثواني...');
            const media = await q.download();
            if (!media) return reply('❌ تعذر تحميل الوسائط.');
            const sticker = new Sticker(media, { pack: 'SOFA BOT', author: 'SOFA', type: StickerTypes.FULL, quality: 60 });
            await sock.sendMessage(message.key.remoteJid, { sticker: await sticker.toBuffer() }, { quoted: message });
        } catch (e) {
            console.error(e);
            return reply('❌ فشل إنشاء الملصق، جرب تاني.');
        }
    }
};
