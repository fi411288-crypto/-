export default {
  name: 'الردود_الذكية',
  category: 'general',
  description: '💬 ردود تلقائية للتحيات والشكر والوداع والمزاح الخفيف',
  commands: [
    {
      name: 'ردود_البوت',
      aliases: ['الردود', 'smartreplies'],
      category: 'general',
      description: 'عرض حالة الردود التلقائية',
      async run({ reply }) {
        return reply(`💬 *ردود SOFA BOT التلقائية*\n\n✅ التحيات\n✅ الشكر\n✅ الوداع\n✅ صباح/مساء الخير\n✅ مناداة البوت\n✅ مزاح خفيف بدون إساءة جارحة\n\n🤖 الردود تعمل تلقائياً بدون كتابة أمر.`);
      }
    }
  ]
};
