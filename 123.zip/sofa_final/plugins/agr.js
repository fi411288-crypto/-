export default {
    name: 'اجر',
    description: 'عرض مجموعة من الأذكار والأدعية لنيل الأجر والثواب',
    category: 'islamic',

    run: async (context) => {
        const { sock, m } = context;
        const jid = m.key.remoteJid;

        const messages = [
            "💎 *سبحان الله وبحمده، سبحان الله العظيم* 💎",
            "📿 *استغفر الله العظيم واتوب إليه* 📿",
            "✨ *لا حول ولا قوة إلا بالله العلي العظيم* ✨",
            "🌟 *سبحان الله، والحمد لله، ولا إله إلا الله، والله أكبر* 🌟",
            "🌿 *اللهم صلِ وسلم وبارك على نبينا محمد* 🌿",
            "📜 *لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير* 📜"
        ];

        // اختيار ذكر عشوائي من القائمة
        const randomAjar = messages[Math.floor(Math.random() * messages.length)];

        const finalText = `
╭━━━〔 💠 *نيل الأجر* 💠 〕━━━╮

${randomAjar}

🔹 *تذكر:* الدال على الخير كفاعله.
╰━━━━━━━━━━━━━━━╯
> *𝐒𝐎𝐅𝐀 𝐁𝐎𝐓 ⚡*`;

        try {
            // استخدام الطريقة اللي بتمنع الـ TypeError اللي ظهر في PHYSICS
            await sock.sendMessage(jid, { 
                text: finalText 
            }, { quoted: m });
        } catch (error) {
            console.error("خطأ في تنفيذ أمر اجر:", error);
        }
    }
};
