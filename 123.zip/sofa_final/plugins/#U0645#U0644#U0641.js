import fs from 'fs';
import path from 'path';

const pluginsPath = path.join(process.cwd(), 'plugins');
const validName = /^[\w\u0600-\u06FF-]+$/;

const template = (name, category) => `export default {
    name: '${name}',
    category: '${category}',
    run: async ({ reply }) => {
        await reply('✨ تم تنفيذ ${name}');
    }
};
`;

export default {
    name: 'ملف',
    aliases: ['file'],
    description: 'إدارة ملفات الأوامر (اضف / كود / حذف / تغيير)',
    category: 'developer',
    developer: true,

    run: async ({ message, args, reply }) => {
        const action = args[0];
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text;

        const fileOf = (n) => path.join(pluginsPath, `${n}.js`);
        const bad = (n) => !n || !validName.test(n);

        try {
            if (action === 'اضف' || action === 'أضف') {
                const name = args[1];
                const category = args[2] || 'tools';
                if (bad(name)) return reply('❌ اكتب اسم صحيح.');
                const existed = fs.existsSync(fileOf(name));
                fs.writeFileSync(fileOf(name), template(name, category));
                return reply(`${existed ? '🔄 تم استبدال' : '✅ تم إنشاء'} الملف: ${name}.js\n📂 القسم: ${category}`);
            }
            if (action === 'كود') {
                const name = args[1];
                if (!quotedText) return reply('❌ رد على رسالة فيها الكود.');
                if (bad(name)) return reply('❌ اكتب اسم الملف.');
                const existed = fs.existsSync(fileOf(name));
                fs.writeFileSync(fileOf(name), quotedText);
                return reply(`${existed ? '🔄 تم استبدال' : '🚀 تم حفظ'} الكود في: ${name}.js`);
            }
            if (action === 'حذف') {
                const name = args[1];
                if (bad(name)) return reply('❌ اكتب اسم الملف.');
                if (!fs.existsSync(fileOf(name))) return reply('❌ الملف غير موجود.');
                fs.unlinkSync(fileOf(name));
                return reply(`🗑️ تم حذف: ${name}.js`);
            }
            if (action === 'تغيير' || action === 'تغير') {
                const [, oldName, newName] = args;
                if (bad(oldName) || bad(newName)) return reply('❌ الصيغة');
                if (!fs.existsSync(fileOf(oldName))) return reply('❌ الملف القديم غير موجود.');
                if (fs.existsSync(fileOf(newName))) return reply('❌ الاسم الجديد مستخدم.');
                fs.renameSync(fileOf(oldName), fileOf(newName));
                return reply(`🔁 ${oldName}.js ➜ ${newName}.js`);
            }
            return reply('HELP');
        } catch (err) {
            return reply(`❌ حدث خطأ: ${err.message}`);
        }
    }
};
