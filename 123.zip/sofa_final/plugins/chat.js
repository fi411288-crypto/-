import { sendInteractive } from '../lib/sendInteractive.js';
import { smartChat, AiError, SOFA_SYSTEM, clearConversationHistory } from '../lib/sofaAI.js';

export default async (context) => {
    const { client, m, text, prefix } = context;
    const react = (e) => client.sendMessage(m.chat, { react: { text: e, key: m.reactKey } }).catch(() => {});
    const card = (title, body) => sendInteractive(client, m, `╭─❏ 「 ${title}」\n│ ${body}\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀`);

    if (!text) {
        await react('❌');
        return card('Eʀʀᴏʀ', `اكتب رسالتك بعد الأمر.\n│ المحادثة بتتحفظ عشان البوت يفتكر سياقك.\n│ لمسح المحادثة: ${prefix}chat --reset`);
    }

    if (text.toLowerCase().includes('--reset')) {
        await clearConversationHistory(m.sender);
        await react('✅');
        return card('Cʜᴀᴛ Rᴇsᴇᴛ', 'تم مسح تاريخ المحادثة.');
    }

    await react('⌛');
    try {
        const reply = await smartChat({ user: m.sender, text, effort: 'high', max: 6000 });
        await react('✅');
        await card('Cʜᴀᴛ', reply);
    } catch (error) {
        console.error('chat error:', error);
        await react('❌');
        await card('Eʀʀᴏʀ', error instanceof AiError ? error.message : `حصل خطأ: ${error.message}`);
    }
};
