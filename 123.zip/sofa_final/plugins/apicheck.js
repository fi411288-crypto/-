import axios from 'axios';
import fs from 'fs';
import path from 'path';

const UA = { 'User-Agent': 'Mozilla/5.0' };
const get = (url, cfg = {}) => axios.get(url, { timeout: 12000, validateStatus: () => true, headers: UA, ...cfg });

// تصنيف استجابة عامة: ✅ شغال | ⚠️ محجوب/محتاج مفتاح | ❌ واقف
const classify = (r) => {
    if (r.status === 402) return ['❌', 'بقت مدفوعة (402)'];
    if ([401, 403].includes(r.status)) return ['⚠️', `محجوب أو محتاج مفتاح (${r.status})`];
    if (r.status === 429) return ['⚠️', 'حد الطلبات (429)'];
    if (r.status >= 500) return ['❌', `عطل في الخدمة (${r.status})`];
    return ['✅', ''];
};
const hostProbe = (url) => async () => classify(await get(url));

async function nexray() {
    const r = await get('https://api.nexray.web.id/downloader/ytmp3', { params: { url: 'https://youtu.be/dQw4w9WgXcQ' } });
    const bad = classify(r);
    if (bad[0] !== '✅') return bad;
    const d = r.data;
    if (d && typeof d === 'object' && (d.status === true || d.result)) return ['✅', ''];
    if (d && typeof d === 'object') return ['⚠️', `رد بخطأ: ${String(d.message || d.error || 'غير معروف').slice(0, 40)}`];
    return ['❌', 'رد مش JSON (ممكن حماية Cloudflare)'];
}

async function groq() {
    let keys = [];
    try {
        const k = await import('../keys.js');
        keys = k.GROQ_API_KEYS?.length ? k.GROQ_API_KEYS : [k.GROQ_API_KEY].filter(Boolean);
    } catch {}
    if (!keys.length) return ['❌', 'مفيش مفتاح (حطه في keys.local.json)'];
    const r = await get('https://api.groq.com/openai/v1/models', { headers: { Authorization: `Bearer ${keys[0]}` } });
    if (r.status === 401) return ['❌', 'المفتاح غلط أو منتهي'];
    if (r.status !== 200) return classify(r);
    const ids = (r.data?.data || []).map((m) => m.id);
    return ids.includes('openai/gpt-oss-120b') ? ['✅', ''] : ['⚠️', 'الموديل المستخدم مش موجود'];
}

async function pollinations() {
    const r = await get('https://image.pollinations.ai/prompt/test', { params: { width: 64, height: 64 }, responseType: 'arraybuffer' });
    const bad = classify(r);
    if (bad[0] !== '✅') return bad;
    return String(r.headers?.['content-type'] || '').startsWith('image/') ? ['✅', ''] : ['❌', 'رد مش صورة'];
}

async function googleCse() {
    let key, cx;
    try {
        const src = fs.readFileSync(path.join(process.cwd(), 'plugins', 'image.js'), 'utf8');
        key = src.match(/GCSE_KEY\s*=\s*'([^']+)'/)?.[1];
        cx = src.match(/GCSE_CX\s*=\s*'([^']+)'/)?.[1];
    } catch {}
    if (!key || !cx) return ['⚠️', 'مفيش مفتاح بحث'];
    const r = await get('https://www.googleapis.com/customsearch/v1', { params: { q: 'cat', key, cx, searchType: 'image', num: 1 } });
    if (r.status === 200) return ['✅', ''];
    if (r.status === 429 || r.status === 403) return ['❌', 'المفتاح خلص أو اتلغى (محتاج مفتاحك إنت)'];
    return classify(r);
}

const SERVICES = [
    ['Nexray', 'yt ytmp3 اغنيه tikdl tikaudio igdl fbdl alldl bilibili threads snackvideo soundcloud brat', nexray],
    ['Groq (الذكاء الاصطناعي)', 'chat gpt gemini darkgpt', groq],
    ['Pollinations (الصور)', 'ارسم-صورة sora', pollinations],
    ['Blackwave (الفيديو)', 'ارسم-فيديو', hostProbe('https://api-blackwave.vercel.app/api/v1/ai/draw/text2vid?prompt=test')],
    ['Theresav', 'pinterest remini', hostProbe('https://api.theresav.biz.id/')],
    ['Ootaizumi', 'spotify video', hostProbe('https://api.ootaizumi.web.id/')],
    ['Siputzx', 'capcut', hostProbe('https://api.siputzx.my.id/')],
    ['Sidycoders', 'play', hostProbe('https://api.sidycoders.xyz/')],
    ['Apiziaul', 'play (بديل)', hostProbe('https://apiziaul.vercel.app/')],
    ['Privatezia', 'hentai', hostProbe('https://api.privatezia.biz.id/')],
    ['Tiklydown', 'تيك', hostProbe('https://api.tiklydown.eu.org/')],
    ['TikWM', 'تيكتوك', hostProbe('https://www.tikwm.com/')],
    ['Aptoide', 'apk', hostProbe('https://ws75.aptoide.com/')],
    ['Catbox (رفع الصور)', 'remini canvas', hostProbe('https://catbox.moe/')],
    ['بحث صور جوجل', 'image', googleCse],
    ['5sim / SMS-Activate', 'رقم (محتاج مفتاحك)', async () => {
        const [a, b] = await Promise.all([get('https://5sim.net/'), get('https://api.sms-activate.org/')]);
        return classify(a)[0] === '✅' || classify(b)[0] === '✅' ? ['✅', ''] : ['❌', 'الموقعين مش بيردوا'];
    }]
];

export default {
    name: 'apicheck',
    aliases: ['فحص_الخدمات', 'فحصapi'],
    description: 'فحص الخدمات الخارجية اللي الأوامر بتعتمد عليها',
    category: 'developer',
    developer: true,

    async run({ message, sock, reply }) {
        const jid = message.key.remoteJid;
        await sock.sendMessage(jid, { react: { text: '⌛', key: message.key } }).catch(() => {});

        const results = await Promise.all(SERVICES.map(async ([name, cmds, probe]) => {
            try { return [name, cmds, ...(await probe())]; }
            catch (e) { return [name, cmds, '❌', e.code === 'ECONNABORTED' ? 'مفيش رد (timeout)' : (e.code || e.message || 'فشل الاتصال').toString().slice(0, 40)]; }
        }));

        const lines = results.map(([name, cmds, icon, note]) => `${icon} *${name}*${note ? ` — ${note}` : ''}\n    ↳ ${cmds}`);
        const dead = results.filter((r) => r[2] !== '✅');
        const summary = dead.length
            ? `\n\n⚠️ الخدمات اللي محتاجة إصلاح: *${dead.length}* من ${results.length}`
            : `\n\n✅ كل الخدمات شغالة (${results.length})`;
        const notes = '\n\n📌 *مش بتشتغل أصلاً:* canvas وeffects (خدمة البوت الأصلي).\n📌 *shazam:* بيستخدم مفاتيح شخص تاني، الأفضل تعمل حسابك المجاني في ACRCloud.';

        await sock.sendMessage(jid, { react: { text: dead.length ? '⚠️' : '✅', key: message.key } }).catch(() => {});
        return reply(`🔎 *فحص الخدمات*\n\n${lines.join('\n')}${summary}${notes}\n> SOFA BOT`);
    }
};
