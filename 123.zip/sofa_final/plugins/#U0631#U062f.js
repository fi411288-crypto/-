import { store, hook, perms } from '../lib/xtools.js';
import { normAr } from '../lib/community.js';

const ph = (p) => String(p || 'main').replace(/\D/g, '') || 'main';
// الردود منفصلة لكل سيشن (رقم بوت): data.autoreply[رقم_البوت][جروب][كلمة]
const db = (p) => (store('autoreply', {}).data[ph(p)] ||= {});
const last = new Map();

hook('autoreply', async ({ message, text, sock, jid, isCmd, phone }) => {
    if (isCmd || !text || !jid?.endsWith('@g.us')) return;
    const rules = db(phone)[jid];
    if (!rules) return;
    const t = ` ${normAr(text)} `;
    for (const [k, v] of Object.entries(rules)) {
        if (!t.includes(` ${normAr(k)} `)) continue;
        const ck = ph(phone) + jid + k, now = Date.now();
        if (now - (last.get(ck) || 0) < 15000) return;
        last.set(ck, now);
        await sock.sendMessage(jid, { text: v }, { quoted: message });
        return;
    }
});

export default {
    name: 'رد',
    aliases: ['ردود', 'autoreply'],
    description: 'ردود تلقائية بكلمة مفتاحية (مثلاً «السعر» يرد بقائمتك)',
    usage: '.رد اضف كلمة | الرد — .رد حذف كلمة — .رد قائمة',
    category: 'admin',
    group: true,
    async run({ sock, message, text, reply, isDeveloper, bot }) {
        const jid = message.key.remoteJid;
        const [sub, ...rest] = text.trim().split(/\s+/);
        const body = text.trim().slice(sub.length).trim();
        const rules = db(bot?.phone)[jid] || {};
        if (['قائمة', 'قايمة', 'list'].includes(sub)) {
            const e = Object.keys(rules);
            return reply(e.length ? `🤖 *الردود التلقائية*\n\n${e.map((k, i) => `${i + 1}. ${k}`).join('\n')}\n\n> SOFA BOT` : '🤖 مفيش ردود. أضف: .رد اضف كلمة | الرد');
        }
        if (!(await perms({ sock, message, isDeveloper })).isAdmin) return reply('❌ الأمر ده للمشرفين فقط.');
        if (['اضف', 'أضف', 'اضافه', 'add'].includes(sub)) {
            const i = body.indexOf('|');
            const k = body.slice(0, i).trim(), v = body.slice(i + 1).trim();
            if (i < 1 || !k || !v) return reply('📝 الاستخدام: .رد اضف السعر | القائمة بتاعتي...');
            if (Object.keys(rules).length >= 50) return reply('❌ الحد الأقصى 50 رد.');
            (db(bot?.phone)[jid] ||= {})[k] = v.slice(0, 2000);
            store('autoreply').save();
            return reply(`✅ لما حد يكتب «${k}» هرد عليه.`);
        }
        if (['حذف', 'مسح', 'del'].includes(sub)) {
            if (!rules[body]) return reply('❌ الكلمة دي مش موجودة. شوف .رد قائمة');
            delete rules[body];
            store('autoreply').save();
            return reply(`🗑️ اتحذف الرد على «${body}».`);
        }
        return reply('🤖 *الردود التلقائية*\n\n.رد اضف كلمة | الرد\n.رد حذف كلمة\n.رد قائمة');
    }
};
