import fs from 'fs';
import path from 'path';
import { groqChat, MODELS, AiError } from '../lib/groq.js';

// .شرح <اسم الأمر>  ← شرح أي أمر عام بالذكاء الاصطناعي (Groq)
// بيشتغل على أوامر المستخدمين العامة بس. أوامر الأونر (DEV_ONLY_COMMANDS) بترد عليها "أمر غير معروف".

// أوامر مخفية إضافية (سيند/تنفيذ/فحص_جروب أصلاً ownerSession فمتخفية، دي احتياطي)
const EXTRA_HIDDEN = new Set(['cta_url', 'تنفيذ', 'execute', 'exec', 'سيند', 'send_as_admin', 'admin_say', 'فحص_جروب']);

const cache = new Map(); // اسم الأمر -> الشرح (عشان منكررش طلبات الـ API)

const norm = (s) => String(s || '').toLowerCase().trim().replace(/^[.!/#]+/, '');
const variants = (s) => [...new Set([
    s,
    s.replace(/ة/g, 'ه'), s.replace(/ه/g, 'ة'),
    s.replace(/[أإآ]/g, 'ا'),
    s.replace(/ى/g, 'ي'),
    s.replace(/_/g, '-'), s.replace(/-/g, '_')
])];

function isHidden(command, handler) {
    const devOnly = handler?.bot?.config?.DEV_ONLY_COMMANDS || [];
    return devOnly.includes(command.name)
        || EXTRA_HIDDEN.has(command.name)
        || !!command.developer
        || !!command.ownerSession
        || command.permissions?.developer === true;
}

function findCommand(handler, input) {
    for (const v of variants(input)) {
        const c = handler.commands.get(v) || handler.commands.get(handler.aliases.get(v));
        if (c) return c;
    }
    return null;
}

// بنجيب كود الـ plugin (مختصر) عشان الـ AI يشرح اللي بيحصل فعلاً من غير تخمين
function pluginSource(handler, command) {
    try {
        let file = null;
        for (const p of handler.plugins.values()) {
            if (p.name === command.name || p.commands?.some?.((c) => c.name === command.name)) { file = p.filename; break; }
        }
        if (!file) return '';
        let src = fs.readFileSync(path.join(process.cwd(), 'plugins', file), 'utf8');
        src = src.replace(/^import .*$/gm, '')
            .replace(/[A-Za-z0-9_\-]{32,}/g, '***')   // نخفي أي مفاتيح/توكنات
            .replace(/\n{3,}/g, '\n\n');
        return src.slice(0, 3500);
    } catch { return ''; }
}

function fallbackText(command, prefix) {
    const lines = [`📖 *${prefix}${command.name}*`];
    if (command.description) lines.push(`\n${command.description}`);
    if (command.usage) lines.push(`\n📌 الاستخدام: ${command.usage}`);
    if (command.aliases?.length) lines.push(`🔁 أسماء تانية: ${command.aliases.map((a) => prefix + a).join(' ، ')}`);
    return lines.join('\n');
}

async function explain(handler, command, prefix) {
    const notes = [];
    if (command.group) notes.push('بيشتغل في الجروبات بس');
    if (command.private) notes.push('بيشتغل في الخاص بس');
    if (command.admin) notes.push('للأدمنز بس');
    if (command.botAdmin) notes.push('لازم البوت يكون أدمن');

    const info = [
        `اسم الأمر: ${prefix}${command.name}`,
        command.description ? `الوصف: ${command.description}` : '',
        command.usage ? `الاستخدام: ${command.usage}` : '',
        command.aliases?.length ? `أسماء تانية: ${command.aliases.join(', ')}` : '',
        notes.length ? `شروط: ${notes.join(' - ')}` : ''
    ].filter(Boolean).join('\n');

    const src = pluginSource(handler, command);

    const text = await groqChat({
        model: MODELS.fast,
        effort: 'low',
        max: 700,
        temperature: 0.3,
        messages: [
            {
                role: 'system',
                content:
                    'إنت مساعد بوت واتساب. اشرح الأمر للمستخدم بالعربي المصري البسيط وبشكل مختصر (5 أسطر تقريباً كحد أقصى):\n' +
                    '1) بيعمل إيه. 2) طريقة الاستخدام. 3) مثال واحد. 4) أي شرط (جروب/أدمن/رد على رسالة).\n' +
                    'اعتمد بس على البيانات والكود اللي معاك ومتخترعش حاجات مش موجودة. اكتب اسم الأمر بالبريفكس كما هو. ' +
                    'متذكرش مفاتيح أو تفاصيل داخلية للكود. استخدم إيموجي خفيف.'
            },
            { role: 'user', content: `بيانات الأمر:\n${info}\n\nكود الأمر (مختصر):\n${src || '(مش متاح)'}` }
        ]
    });
    return `📖 *${prefix}${command.name}*\n\n${text}`;
}

export default [{
    name: 'شرح',
    aliases: ['explain', 'help_cmd'],
    description: 'شرح أي أمر عام بالذكاء الاصطناعي',
    usage: '.شرح اسم_الأمر',
    category: 'tools',
    async run({ args, reply, react, handler, prefix = '.' }) {
        const input = norm(args[0]);
        if (!input) {
            return reply(`📖 *شرح الأوامر*\n\nالاستخدام: ${prefix}شرح اسم_الأمر\nمثال: ${prefix}شرح قول\n\nلعرض كل الأوامر اكتب ${prefix}اوامر`);
        }

        const command = findCommand(handler, input);
        if (!command || isHidden(command, handler)) {
            return reply(`❌ أمر غير معروف: ${input}\nاكتب ${prefix}اوامر عشان تشوف الأوامر المتاحة.`);
        }

        if (cache.has(command.name)) return reply(cache.get(command.name));

        await react?.('⏳');
        try {
            const out = await explain(handler, command, prefix);
            cache.set(command.name, out);
            await react?.('✅');
            return reply(out);
        } catch (e) {
            await react?.('❌');
            // لو الـ AI وقع (مفتاح/حد مجاني) نرجع الشرح الأساسي من بيانات الأمر
            const base = fallbackText(command, prefix);
            const why = e instanceof AiError ? e.message : 'الذكاء الاصطناعي مش متاح دلوقتي';
            return reply(`${base}\n\n⚠️ ${why}`);
        }
    }
}];
