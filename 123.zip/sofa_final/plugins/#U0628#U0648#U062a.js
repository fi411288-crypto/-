// .بوت ← رد ملكي
import { WA, fancy } from '../lib/theme.js';

export default [{
    name: 'بوت',
    aliases: ['bot'],
    description: 'رد الترحيب',
    category: 'tools',
    ownerSession: true,
    async run({ reply }) {
        return reply(`${WA.top}\n\n👑 *${fancy('SOFA BOT')}* 👑\n🟢 ${fancy('Online')}\n\n_تحت أمرك يا سوفا يافحلي_\n\n${WA.sign}\n${WA.bottom}`);
    }
}];
