// ألعاب الجروب التفاعلية: عاصمه / تاريخ / كت / فكك / ايموجي / سؤال_انمي / فواكه / شخصيه / لعبة / نرد
// كلها بتحسب نقاط (نفس نظام .ترتيب) والإجابة بتتكتب في الشات مباشرة من غير أمر.
// .عاصمه 5  ← 5 جولات ورا بعض | .عاصمه تلميح | .عاصمه تخطي | .عاصمه ايقاف
import { startQuiz, QUIZ_POINTS } from '../lib/quizGames.js';
import { getGroup, addPoints, senderIds, digits, mentionOf } from '../lib/community.js';

const DEFS = [
    { cmd: 'عاصمه', aliases: ['عواصم', 'عاصمة'], file: 'capitals.json', icon: '🌍', title: 'تحدي العواصم', seconds: 30, ask: (q) => q },
    { cmd: 'تاريخ', aliases: ['history'], file: 'history.json', icon: '📜', title: 'تحدي التاريخ', seconds: 40, ask: (q) => q },
    { cmd: 'كت', aliases: ['حيوانات'], file: 'cat.json', icon: '🧠', title: 'معلومات عامة', seconds: 40, ask: (q) => q },
    { cmd: 'فكك', aliases: ['رتب', 'فكك_الكلمة'], file: 'scramble.json', icon: '🔤', title: 'فكك الكلمة', seconds: 35, ask: (q) => `رتّب الحروف دي وكوّن الكلمة الصح:\n\n*${q}*` },
    { cmd: 'ايموجي', aliases: ['emoji', 'إيموجي'], file: 'emoji.json', icon: '😀', title: 'تحدي الإيموجي', seconds: 30, ask: (q) => `الإيموجي ده بيعبّر عن إيه؟ (كلمة واحدة)\n\n${q}` },
    { cmd: 'سؤال_انمي', aliases: ['انمي', 'سؤال-انمي'], file: 'anime.json', icon: '🎌', title: 'تحدي الأنمي', seconds: 45, ask: (q) => q },
    { cmd: 'فواكه', aliases: ['فاكهه', 'خضار'], file: 'fruits.json', icon: '🍉', title: 'فواكه وخضار', seconds: 25, ask: (q) => `إيه اسم ده؟\n\n${q}` },
    { cmd: 'شخصيه', aliases: ['مين_الشخصية'], file: 'characters.json', icon: '🕵️', title: 'مين الشخصية؟', seconds: 45, ask: (q) => `خمّن الشخصية دي:\n\n${q}` },
    { cmd: 'اعلام', aliases: ['علم', 'flags', 'اعلام_الدول'], file: 'flags.json', icon: '🏳️', title: 'تحدي الأعلام', seconds: 25, ask: (q) => `ده علم أنهي دولة؟\n\n${q}` },
    { cmd: 'اسلاميات', aliases: ['دين', 'اسلام', 'islam'], file: 'islamic.json', icon: '🕌', title: 'مسابقة إسلامية', seconds: 40, ask: (q) => q },
    { cmd: 'كوره', aliases: ['رياضه', 'رياضة', 'sports'], file: 'sports.json', icon: '⚽', title: 'تحدي الرياضة', seconds: 35, ask: (q) => q },
    { cmd: 'علوم', aliases: ['علم_وعلوم', 'science'], file: 'science.json', icon: '🔬', title: 'تحدي العلوم', seconds: 40, ask: (q) => q },
    { cmd: 'جغرافيا', aliases: ['جغرافيه', 'جغرافية'], file: 'geography.json', icon: '🗺️', title: 'تحدي الجغرافيا', seconds: 40, ask: (q) => q },
    { cmd: 'امثال', aliases: ['مثل', 'امثله', 'أمثال'], file: 'proverbs.json', icon: '📖', title: 'كمّل المثل', seconds: 35, ask: (q) => q },
    { cmd: 'عكس', aliases: ['اضداد', 'عكسها'], file: 'opposites.json', icon: '🔄', title: 'عكس الكلمة', seconds: 25, ask: (q) => q },
    { cmd: 'انجليزي', aliases: ['english', 'انجلش', 'إنجليزي'], file: 'english.json', icon: '🔤', title: 'تحدي الإنجليزي', seconds: 25, ask: (q) => q },
    { cmd: 'حسبها', aliases: ['رياضيات', 'حساب_سريع', 'math'], file: 'math.json', icon: '🧮', title: 'تحدي الحساب السريع', seconds: 20, ask: (q) => `احسبها بسرعة:\n\n*${q}*` },
    { cmd: 'صح_خطا', aliases: ['صح_ولا_غلط', 'صحخطا', 'truefalse'], file: 'truefalse.json', icon: '✅', title: 'صح ولا غلط؟', seconds: 20, ask: (q) => `${q}\n\n(اكتب: صح  أو  خطأ)` },
    { cmd: 'احجيه', aliases: ['فزوره', 'فوازير', 'احجية'], file: 'riddles.json', icon: '🧩', title: 'فوازير وألغاز', seconds: 45, ask: (q) => q },
    { cmd: 'اسرع', aliases: ['سرعة_كتابة', 'typing'], file: 'typing.json', icon: '⌨️', title: 'سباق الكتابة', seconds: 30, ask: (q) => `اكتب الجملة دي بالظبط بأسرع ما تقدر:\n\n*${q}*` },
    { cmd: 'مصر', aliases: ['معلومات_مصر', 'مصريات'], file: 'egypt.json', icon: '🇪🇬', title: 'مسابقة مصر', seconds: 40, ask: (q) => q },
    { cmd: 'اكلات', aliases: ['اكل', 'مطبخ_العالم', 'طعام'], file: 'food.json', icon: '🍽️', title: 'تحدي الأكلات', seconds: 35, ask: (q) => q },
];

const quiz = DEFS.map((def) => ({
    name: def.cmd,
    aliases: def.aliases,
    description: `${def.title} — أول واحد يجاوب صح ياخد ${QUIZ_POINTS} نقاط`,
    usage: `.${def.cmd} [عدد الجولات] | .${def.cmd} تلميح | .${def.cmd} تخطي | .${def.cmd} ايقاف`,
    category: 'games',
    group: true,
    cooldown: 1000,
    run: (ctx) => startQuiz(ctx, def)
}));

// ───────── لعبة: بتختار لعبة عشوائية ─────────
const random = {
    name: 'لعبة',
    aliases: ['لعبه', 'game', 'العاب', 'ألعاب'],
    description: 'بتختار لعبة أسئلة عشوائية وتبدأها (أو .لعبة قائمة)',
    usage: '.لعبة [عدد الجولات] | .لعبة قائمة',
    category: 'games',
    group: true,
    cooldown: 1000,
    async run(ctx) {
        const { reply, args = [], prefix = '.' } = ctx;
        if (['قائمه', 'قائمة', 'list'].includes(String(args[0] || '').toLowerCase())) {
            const rows = DEFS.map((d) => `${d.icon} ${prefix}${d.cmd} — ${d.title}`).join('\n');
            return reply(`🎮 *الألعاب المتاحة*\n\n${rows}\n🎲 ${prefix}نرد — مبارزة نرد\n🪨 ${prefix}حجر — حجر ورقة مقص ضد البوت\n🔢 ${prefix}تخمين — خمّن الرقم السري\n🤔 ${prefix}هل_تفضل — سؤال للنقاش\n🎯 ${prefix}مين_فينا — اختيار عضو عشوائي\n👁️ ${prefix}عين — خمّن شخصية الأنمي\n\n🔁 زوّد رقم بعد اللعبة لعدد جولات: ${prefix}عاصمه 5\n🎯 ${prefix}لعبة — لعبة عشوائية\n🏆 ${prefix}ترتيب — النقاط`);
        }
        const def = DEFS[Math.floor(Math.random() * DEFS.length)];
        return startQuiz({ ...ctx, args: args.filter((a) => /^\d+$/.test(a)) }, def);
    }
};

// ───────── نرد: مبارزة بين أعضاء الجروب ─────────
const FACE = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
const duels = new Map();
const DUEL_SECONDS = 30;
const roll = () => Math.floor(Math.random() * 6);

const dice = {
    name: 'نرد',
    aliases: ['dice', 'زهر', 'نرد_مبارزة'],
    description: 'مبارزة نرد: كل واحد يرمي مرة والأعلى ياخد نقاط',
    usage: '.نرد',
    category: 'games',
    group: true,
    cooldown: 500,
    async run({ sock, message, reply, bot, prefix = '.' }) {
        const jid = message.key.remoteJid;
        const a = roll(), b = roll(), total = a + b + 2;
        const line = `${FACE[a]} ${FACE[b]} = *${total}*`;
        if (!jid.endsWith('@g.us')) return reply(`🎲 رميت: ${line}`);

        const key = `${bot?.phone || 'main'}:${jid}`;
        const uid = senderIds(message)[0] || digits(message.key.participant);
        const pj = message.key.participant || mentionOf(uid);
        let duel = duels.get(key);

        if (!duel) {
            duel = { rolls: new Map(), sock, jid, phone: bot?.phone };
            duels.set(key, duel);
            duel.rolls.set(uid, { total, a, b, jid: pj });
            duel.timer = setTimeout(() => endDuel(key), DUEL_SECONDS * 1000);
            return reply({
                text: `🎲 *مبارزة نرد بدأت!*\n\n@${digits(uid)} رمى: ${line}\n\n⚔️ اكتب ${prefix}نرد عشان ترمي إنت كمان (مرة واحدة بس)\n⏱️ ${DUEL_SECONDS} ثانية — الأعلى ياخد *${QUIZ_POINTS} نقاط*`,
                mentions: [pj]
            });
        }

        if (duel.rolls.has(uid)) {
            const mine = duel.rolls.get(uid);
            return reply({ text: `✋ @${digits(uid)} إنت رميت قبل كده: ${FACE[mine.a]} ${FACE[mine.b]} = *${mine.total}*`, mentions: [pj] });
        }
        duel.rolls.set(uid, { total, a, b, jid: pj });
        const best = Math.max(...[...duel.rolls.values()].map((r) => r.total));
        return reply({
            text: `🎲 @${digits(uid)} رمى: ${line}${total === best ? '  👑 المتصدر' : ''}\n👥 اللاعبين: ${duel.rolls.size}`,
            mentions: [pj]
        });
    }
};

function endDuel(key) {
    const duel = duels.get(key);
    if (!duel) return;
    duels.delete(key);
    const rows = [...duel.rolls.entries()].sort((x, y) => y[1].total - x[1].total);
    if (rows.length < 2) {
        return duel.sock.sendMessage(duel.jid, { text: '😴 المبارزة انتهت من غير منافس. ماحدش كسب نقاط.' }).catch(() => {});
    }
    const top = rows[0][1].total;
    const winners = rows.filter(([, r]) => r.total === top);
    const { g, save } = getGroup(duel.phone, duel.jid);
    const pts = Math.max(1, Math.floor(QUIZ_POINTS / winners.length));
    winners.forEach(([uid]) => addPoints(g, uid, pts));
    save();
    const table = rows.map(([uid, r], i) => `${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '▫️'} @${digits(uid)} — ${FACE[r.a]} ${FACE[r.b]} = ${r.total}`).join('\n');
    const who = winners.map(([uid]) => `@${digits(uid)}`).join(' و ');
    duel.sock.sendMessage(duel.jid, {
        text: `🏁 *نتيجة مبارزة النرد*\n\n${table}\n\n🎉 ${winners.length > 1 ? 'تعادل بين' : 'الفائز'}: ${who}\n⭐ +${pts} نقطة${winners.length > 1 ? ' لكل واحد' : ''}`,
        mentions: rows.map(([, r]) => r.jid)
    }).catch(() => {});
}

export default [...quiz, random, dice];
