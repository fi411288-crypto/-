import fs from "fs";
import path from "path";

// ملف الأرقام (بيتعمل تلقائياً أول مرة). تقدر تعدله من الواتس بالأوامر تحت أو يدوي.
const FILE = path.join("./data", "zeed_numbers.json");
const DEFAULT_NUMBERS = ["201558394858", "201505938473", "201558475633", "201513847570"];

// 🔒 الناس الوحيدين اللي يقدروا يشغّلوا الأمر ده (أرقام بصيغة دولية من غير +).
// عايز تسمح لحد تاني؟ ضيف رقمه هنا بين علامتين تنصيص وبينهم فاصلة.
const ALLOWED_USERS = ["201018766845"];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clean = (v) => String(v || "").replace(/\D/g, "");
// يشيل @ و :رقم الجهاز من الـ JID قبل ما يطلّع الأرقام
const jidDigits = (j) => clean(String(j || "").split("@")[0].split(":")[0]);

function load() {
    try {
        if (!fs.existsSync(FILE)) save(DEFAULT_NUMBERS);
        const arr = JSON.parse(fs.readFileSync(FILE, "utf8"));
        return [...new Set(arr.map(clean).filter((n) => n.length >= 8 && n.length <= 15))];
    } catch (e) {
        console.error("[زود] فشل قراءة الأرقام:", e.message);
        return [...DEFAULT_NUMBERS];
    }
}

function save(list) {
    fs.mkdirSync(path.dirname(FILE), { recursive: true });
    fs.writeFileSync(FILE, JSON.stringify(list, null, 2));
}

export default {
    name: "زود",
    aliases: ["🌹", "🌌", "👾", "🫯"],
    description: "إضافة قائمة أرقام للجروب (زود | زود <لينك أو ID> | زود ايدي <لينك> | زود اضف/شيل/قائمة)",
    category: "group",

    async run({ sock, message, args, reply, handler }) {
        // الأمر مقفول على ALLOWED_USERS بس (حتى الأرقام المربوطة ملهاش صلاحية)
        const k = message.key || {};
        let senders = [k.participant, k.participantPn, k.participantAlt, k.remoteJidAlt, k.remoteJid]
            .filter((j) => j && !String(j).endsWith("@g.us")).map(jidDigits);
        try { senders.push(...(handler?._senderIds?.(message) || []).map(jidDigits)); } catch {}
        if (message.key?.fromMe) senders.push(jidDigits(sock?.user?.id));
        if (!senders.some((n) => n && ALLOWED_USERS.includes(n))) {
            console.error("[زود] مرفوض، المرسل:", senders.join(", ") || "غير معروف");
            return;
        }

        const here = message.key.remoteJid;
        const inGroup = here.endsWith("@g.us");
        const sub = (args[0] || "").toLowerCase();
        const say = (t) => reply(t);

        // ---- إدارة القائمة ----
        if (["استبدل", "بدل", "set"].includes(sub)) {
            const nums = [...new Set(args.slice(1).join(" ").split(/[,\s]+/).map(clean).filter((n) => n.length >= 8 && n.length <= 15))];
            if (!nums.length) return say("❌ اكتب الأرقام الجديدة:\n.زود استبدل 2010xxxxxxx 2011xxxxxxx");
            save(nums);
            return say(`✅ القائمة بقت ${nums.length} رقم.`);
        }

        if (["اضف", "أضف", "add"].includes(sub)) {
            const nums = args.slice(1).join(" ").split(/[,\s]+/).map(clean).filter((n) => n.length >= 8 && n.length <= 15);
            if (!nums.length) return say("❌ اكتب الرقم بصيغة دولية، مثال:\n.زود اضف 201012345678");
            const list = load();
            const added = nums.filter((n) => !list.includes(n));
            save([...list, ...added]);
            return say(`✅ اتضاف ${added.length} رقم. الإجمالي: ${list.length + added.length}`);
        }

        if (["شيل", "حذف", "remove"].includes(sub)) {
            const nums = args.slice(1).join(" ").split(/[,\s]+/).map(clean).filter(Boolean);
            if (!nums.length) return say("❌ اكتب الرقم اللي عايز تشيله:\n.زود شيل 201012345678");
            const list = load();
            const left = list.filter((n) => !nums.includes(n));
            save(left);
            return say(`✅ اتشال ${list.length - left.length} رقم. المتبقي: ${left.length}`);
        }

        if (["قائمة", "قائمه", "list"].includes(sub)) {
            const list = load();
            return say(list.length ? `📋 الأرقام (${list.length}):\n${list.map((n, i) => `${i + 1}. ${n}`).join("\n")}` : "📋 القائمة فاضية.");
        }

        // ---- تحديد الجروب الهدف: لينك / ID / الجروب الحالي ----
        const idOnly = ["ايدي", "id", "آيدي"].includes(sub);
        const input = (idOnly ? args.slice(1) : args).join(" ");
        const linkMatch = input.match(/chat\.whatsapp\.com\/([A-Za-z0-9]{10,})/i);
        const idMatch = input.match(/(\d+(?:-\d+)?@g\.us)/);

        let target = null;
        let subject = "";
        try {
            if (linkMatch) {
                const info = await sock.groupGetInviteInfo(linkMatch[1]);
                target = info.id;
                subject = info.subject || "";
            } else if (idMatch) {
                target = idMatch[1];
            } else if (inGroup && !idOnly) {
                target = here;
            }
        } catch (e) {
            return say("❌ اللينك مش شغال أو منتهي: " + (e?.message || e));
        }

        if (!target) {
            return say(idOnly || !inGroup
                ? "❌ ابعت لينك الجروب أو الـ ID، مثال:\n.زود https://chat.whatsapp.com/XXXX"
                : "❌ مش قادر أحدد الجروب.");
        }

        // لو طلب الـ ID بس
        if (idOnly) return say(`🆔 ${subject ? subject + "\n" : ""}${target}`);

        // ---- تأكد إن البوت جوه الجروب ----
        try {
            await sock.groupMetadata(target);
        } catch {
            return say("❌ البوت مش عضو في الجروب ده (لازم يكون جواه وأدمن عشان يضيف).");
        }

        // ---- التنفيذ ----
        const numbers = load();
        let ok = 0, invited = 0, failed = 0;
        for (const num of numbers) {
            const jid = `${num}@s.whatsapp.net`;
            try {
                const res = await sock.groupParticipantsUpdate(target, [jid], "add");
                const status = String(res?.[0]?.status ?? "200");
                if (status === "200") ok++;
                else if (status === "403") invited++;
                else { failed++; console.error(`[زود] ${num} رجع status ${status}`); }
            } catch (e) {
                failed++;
                console.error(`[زود] فشلت إضافة ${num}:`, e?.message || e);
            }
            await sleep(1500);
        }

        // صامت جوه الجروب نفسه، وبيرد عليك بملخص لو شغلته من الخاص (أو برا الجروب)
        if (!inGroup || target !== here) {
            await say(`✅ ${subject ? subject + " — " : ""}تمت: ${ok} | خصوصية/دعوة: ${invited} | فشل: ${failed}`);
        }
    }
};