import fetch from 'node-fetch';

export default {
    name: 'سكرين',
    aliases: ['ss', 'screenshot', 'ssweb', 'لقطة'],
    description: 'لقطة شاشة لأي موقع',
    category: 'tools',
    usage: '.سكرين https://google.com',

    async run({ text, reply, sock, m, message, react }) {
        let url = (text || '').trim();
        if (!url) return reply('❌ اكتب رابط الموقع\nمثال: .سكرين https://google.com');
        if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
        await react?.('⏳').catch?.(() => {});
        try {
            const api = `https://api.siputzx.my.id/api/tools/ssweb?url=${encodeURIComponent(url)}&theme=light&device=desktop`;
            let res = await fetch(api);
            if (!res.ok) {
                res = await fetch(`https://image.thum.io/get/full/width/1200/${encodeURIComponent(url)}`);
            }
            if (!res.ok) throw new Error('API status ' + res.status);
            const buf = Buffer.from(await res.arrayBuffer());
            await react?.('✅').catch?.(() => {});
            return sock.sendMessage((m || message).key.remoteJid, {
                image: buf,
                caption: `📸 لقطة شاشة:\n${url}\n> © SOFA VIP`
            }, { quoted: m || message });
        } catch (e) {
            await react?.('❌').catch?.(() => {});
            return reply('❌ فشل التقاط الشاشة: ' + (e.message || e));
        }
    }
};
