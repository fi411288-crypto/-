// ⏰ جدولة رسائل الجروب (يومي أو مرة واحدة) بتوقيت القاهرة — SOFA BOT
import { store, job, sockOf, perms, hhmm, dayIn } from '../lib/xtools.js';

const db = () => (store('schedules', { list: [] }).data.list ||= []);
const ph = (p) => String(p || 'main').replace(/\D/g, '') || 'main';
const MAX = 10;

job('schedules', async () => {
    const now = hhmm(), today = dayIn();
    for (const e of [...db()]) {
        if (e.time !== now || e.last === today) continue;
        const sock = sockOf(e.phone);
        if (!sock) continue;
        try {
            await sock.sendMessage(e.jid, { text: e.text });
            e.last = today;
            if (e.once) db().splice(db().indexOf(e), 1);
            store('schedules').save();
        } catch {}
    }
}, 20000);

export default [{
    name: 'جدولة',
    aliases: ['schedule', 'جدول'],
    category: 'admin',
    group: true,
    description: 'رسالة تتبعت في الجروب في ميعاد محدد (كل يوم أو مرة واحدة)',
    usage: '.جدولة 08:00 صباح الخير | .جدولة مرة 20:30 إعلان | .جدولة قائمة | .جدولة حذف 1',
    cooldown: 2000,
    async run({ sock, message, text, reply, bot, isDeveloper, prefix = '.' }) {
        const p = await perms({ sock, message, isDeveloper });
        if (!p.isAdmin) return reply('❌ الأمر ده للمشرفين فقط.');
        const jid = message.key.remoteJid, phone = ph(bot?.phone);
        const mine = () => db().filter((e) => e.phone === phone && e.jid === jid).sort((a, b) => a.time.localeCompare(b.time));
        const t = String(text || '').trim().replace(/[٠-٩]/g, (d) => d.charCodeAt(0) - 1632);

        if (!t || /^(قائمة|قايمة|list)$/.test(t)) {
            const l = mine();
            return reply(l.length
                ? `⏰ *الرسائل المجدولة*\n\n${l.map((e, i) => `*${i + 1}.* ${e.time} ${e.once ? '(مرة)' : '(يومي)'} — ${e.text.slice(0, 40).replace(/\n/g, ' ')}`).join('\n')}\n\nللحذف: ${prefix}جدولة حذف رقم`
                : `⏰ مفيش رسائل مجدولة.\n\nيومي: ${prefix}جدولة 08:00 صباح الخير\nمرة واحدة: ${prefix}جدولة مرة 20:30 إعلان\n(بتوقيت القاهرة)`);
        }
        const del = /^(حذف|الغاء|إلغاء)\s+(\d+)$/.exec(t);
        if (del) {
            const e = mine()[+del[2] - 1];
            if (!e) return reply('❌ رقم غلط.');
            db().splice(db().indexOf(e), 1); store('schedules').save();
            return reply('🗑️ اتحذفت الرسالة المجدولة.');
        }
        const m = /^(مره|مرة)?\s*(\d{1,2})(?::(\d{2}))?\s+([\s\S]+)$/.exec(t);
        if (!m || +m[2] > 23 || +(m[3] || 0) > 59) return reply(`❌ الصيغة:\n${prefix}جدولة 08:00 صباح الخير\n${prefix}جدولة مرة 20:30 إعلان`);
        if (mine().length >= MAX) return reply(`❌ وصلت للحد الأقصى (${MAX}). احذف واحدة الأول.`);
        const time = `${String(+m[2]).padStart(2, '0')}:${m[3] || '00'}`;
        db().push({ phone, jid, time, once: !!m[1], text: m[4].slice(0, 1500), last: '' });
        store('schedules').save();
        return reply(`✅ اتجدولت!\n🕐 ${time} (بتوقيت القاهرة) — ${m[1] ? 'مرة واحدة' : 'كل يوم'}`);
    }
}];
