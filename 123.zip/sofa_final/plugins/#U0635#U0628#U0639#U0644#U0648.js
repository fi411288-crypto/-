export default {
  name: 'صبعلو',
  description: 'يبعت منشن مع رسالة نصية لشخص معين',
  category: 'ترفيه',
  group: true,

  run: async (context) => {
    const { sock, m } = context;
    const from = m.key.remoteJid;

    try {
      // تحديد الشخص المستهدف (منشن أو ريبلاي)
      let target = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || 
                   m.message?.extendedTextMessage?.contextInfo?.participant;

      if (!target) {
        // رسالة تنبيه لو مفيش منشن
        return await sock.sendMessage(from, { text: 'منشن حد الأول عشان أتصرف 👀' }, { quoted: m });
      }

      // إرسال النص والمنشن فقط بدون صور
      const text = `@${target.split('@')[0]}\n*خد يا معرص* 🖕🏻`;

      await sock.sendMessage(from, {
        text: text,
        mentions: [target]
      }, { quoted: m });

    } catch (e) {
      console.error('Error in صبعلو command:', e);
      await sock.sendMessage(from, { text: 'حصل خطأ في التنفيذ يا برو 🤷‍♂️' }, { quoted: m });
    }
  }
};
