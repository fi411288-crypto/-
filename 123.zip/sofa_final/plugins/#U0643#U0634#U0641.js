import { downloadContentFromMessage } from "@whiskeysockets/baileys";

// ───────────── كشف: يرجّع أي صورة/فيديو/صوت "عرض مرة واحدة" بعد الرد عليها ─────────────

const WRAPPERS = [
    "ephemeralMessage",
    "viewOnceMessage",
    "viewOnceMessageV2",
    "viewOnceMessageV2Extension",
    "documentWithCaptionMessage",
    "editedMessage",
];

// بيفك كل الأغلفة (مؤقتة / عرض مرة واحدة / معدّلة) لحد ما يوصل للمحتوى الحقيقي
function unwrap(msg) {
    let m = msg;
    for (let i = 0; i < 8 && m; i++) {
        let inner = null;
        for (const w of WRAPPERS) {
            if (m[w]?.message) { inner = m[w].message; break; }
        }
        if (!inner) break;
        m = inner;
    }
    return m;
}

// الـ contextInfo ممكن يكون جوه أي نوع رسالة (نص / صورة / ستيكر ...)
function findContext(message) {
    const content = unwrap(message?.message) || {};
    for (const value of Object.values(content)) {
        if (value && typeof value === "object" && value.contextInfo?.quotedMessage) return value.contextInfo;
    }
    return null;
}

const TYPES = [
    ["imageMessage", "image"],
    ["videoMessage", "video"],
    ["ptvMessage", "video"],
    ["audioMessage", "audio"],
];

function findMedia(quoted) {
    const content = unwrap(quoted);
    if (!content) return null;
    for (const [key, type] of TYPES) {
        if (content[key]) return { media: content[key], type, key };
    }
    return null;
}

export default {
    name: "كشف",
    aliases: ["فضح", "readviewonce"],
    description: "كشف محتوى رسائل المشاهدة مرة واحدة",
    usage: ".كشف (رد على الرسالة)",
    category: "media",

    async run({ sock, message, reply }) {
        const chat = message.key.remoteJid;
        const ctx = findContext(message);

        if (!ctx?.quotedMessage) {
            return reply("⚠️ رد على رسالة (عرض مرة واحدة) بالأمر .كشف");
        }

        const found = findMedia(ctx.quotedMessage);
        if (!found) {
            return reply("❌ الرسالة دي مفيهاش صورة أو فيديو أو صوت أقدر أكشفه.");
        }

        const { media, type, key } = found;

        try {
            const stream = await downloadContentFromMessage(media, type === "video" && key === "ptvMessage" ? "video" : type);
            const chunks = [];
            for await (const chunk of stream) chunks.push(chunk);
            const buffer = Buffer.concat(chunks);

            if (!buffer.length) throw new Error("EMPTY");

            const caption = media.caption || "";
            const quotedOpts = { quoted: message };

            if (type === "image") {
                return await sock.sendMessage(chat, { image: buffer, caption, viewOnce: false }, quotedOpts);
            }
            if (type === "video") {
                return await sock.sendMessage(chat, { video: buffer, caption, viewOnce: false }, quotedOpts);
            }
            return await sock.sendMessage(chat, {
                audio: buffer,
                ptt: media.ptt !== false,
                mimetype: media.mimetype || "audio/ogg; codecs=opus",
            }, quotedOpts);
        } catch (err) {
            console.error("[كشف]", err?.message || err);
            return reply("❌ معرفتش أحمّل الوسائط. غالباً اتفتحت قبل كده أو انتهت صلاحيتها، وواتساب بيمسح الميديا بعد المشاهدة.");
        }
    },
};