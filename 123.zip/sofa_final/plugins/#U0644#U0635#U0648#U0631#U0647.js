import ffmpeg from 'fluent-ffmpeg';
import fs from 'fs-extra';
import path from 'path';

export default {
    name: "لصوره",
    description: "تحويل ملصق إلى صورة (باستخدام ffmpeg).",
    category: "tools",

    async run({ message, reply, downloadMedia }) {
        // 1. تحديد مسارات مؤقتة للملفات
        const tempDir = path.join(process.cwd(), 'temp');
        fs.ensureDirSync(tempDir); // التأكد من وجود مجلد temp
        const inputPath = path.join(tempDir, `${Date.now()}.webp`);
        const outputPath = path.join(tempDir, `${Date.now()}.png`);

        try {
            // 2. التحقق من أن الرد كان على ملصق
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quoted || !quoted.stickerMessage) {
                return reply("❌ *خطأ:* يجب الرد على ملصق لتحويله إلى صورة.");
            }

            if (quoted.stickerMessage.isAnimated) {
                return reply("❌ *عذرًا:* لا يمكن تحويل الملصقات المتحركة بهذه الطريقة.");
            }

            // 3. تحميل الملصق
            const stickerBuffer = await downloadMedia(message);
            if (!stickerBuffer) {
                return reply("❌ *فشل تحميل الملصق.*");
            }

            // 4. حفظ الملصق كملف مؤقت
            fs.writeFileSync(inputPath, stickerBuffer);

            // 5. ✨ استخدام ffmpeg للتحويل ✨
            await new Promise((resolve, reject) => {
                ffmpeg(inputPath)
                    .on('error', (err) => {
                        console.error("FFMPEG Error:", err);
                        reject(new Error('فشل التحويل باستخدام ffmpeg. تأكد من تثبيته.'));
                    })
                    .on('end', () => resolve(true))
                    .save(outputPath);
            });

            // 6. إرسال الصورة الناتجة
            await reply({
                image: { url: outputPath },
                caption: "✅ تم تحويل الملصق إلى صورة بنجاح."
            });

        } catch (error) {
            console.error("Error in 'toimg' command:", error);
            await reply(`❌ *حدث خطأ أثناء تحويل الملصق:*\n${error.message}`);
        } finally {
            // 7. ✨ تنظيف الملفات المؤقتة ✨
            // خطوة مهمة جدًا لمنع تراكم الملفات في السيرفر
            if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
            if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
        }
    }
};