import fetch from 'node-fetch';

const FACTS_AR = [
    'عقلك بيستخدم حوالي 20% من طاقة جسمك.',
    'الأخطبوط عنده 3 قلوب.',
    'عسل النحل عمره ما بيفسد.',
    'القلوب بتتولد وبها حوالي 100 ألف ضربة في اليوم.',
    'الضحك بيقلل التوتر وبيزوّد المناعة.'
];
const JOKES_AR = [
    'واحد دخل يمتحن... المراقِب قاله: اكتب اسمك. قاله: مش فاكر الاسم ده في المنهج 😂',
    'ليه الكمبيوتر بارد؟ عشان عنده Windows مفتوحة 🪟',
    'الحمار سأل الأسد: ليه شعرك مش مترتب؟ قاله: أصل مفيش مصفف يقدر يقرب 🦁'
];

export default [
    {
        name: 'حقيقة-عشوائية',
        aliases: ['fact', 'معلومة'],
        description: 'معلومة عشوائية',
        category: 'fun',
        async run({ reply, react }) {
            await react?.('💡').catch?.(() => {});
            try {
                const r = await fetch('https://uselessfacts.jsph.pl/api/v2/facts/random');
                if (r.ok) {
                    const d = await r.json();
                    return reply(`╭─❏ 「 💡 Fact 」\n│ ${d.text}\n╰───────────────`);
                }
            } catch {}
            const f = FACTS_AR[Math.floor(Math.random() * FACTS_AR.length)];
            return reply(`╭─❏ 「 💡 معلومة 」\n│ ${f}\n╰───────────────`);
        }
    },
    {
        name: 'نكتة',
        aliases: ['joke', 'نكت'],
        description: 'نكتة عشوائية',
        category: 'fun',
        async run({ reply, react }) {
            await react?.('😂').catch?.(() => {});
            try {
                const r = await fetch('https://official-joke-api.appspot.com/random_joke');
                if (r.ok) {
                    const d = await r.json();
                    return reply(`╭─❏ 「 😂 Joke 」\n│ ${d.setup}\n│ ${d.punchline}\n╰───────────────`);
                }
            } catch {}
            const j = JOKES_AR[Math.floor(Math.random() * JOKES_AR.length)];
            return reply(`╭─❏ 「 😂 نكتة 」\n│ ${j}\n╰───────────────`);
        }
    }
];
