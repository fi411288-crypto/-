// 🔨 مزاد SOFA: مرة في اليوم، عناصر افتراضية بالكوين. العناصر النادرة LIMITED بتنزل مرة واحدة بس — SOFA BOT
// .ابدا_المزاد (من رقم المطور 201018766845 بس) ← بيتبعت لكل جروبات الأرقام المربوطة (ماعدا أرقام المطور)
import { resolveNumber, isRegistered } from '../lib/economy.js';
import { fmt, toEnDigits } from '../lib/shop.js';
import { job } from '../lib/xtools.js';
import { castToGroups } from '../lib/cast.js';
import { isDevSender, AUCTION_STARTER } from '../lib/devAuth.js';
import { load, startAuction, placeBid, endAuction, itemTitle, minNext, leftText, vaultOf } from '../lib/auction.js';

const board = (a, prefix = '.') =>
    `🔨 *SOFA • AUCTION* 🔨\n\n🎁 *العنصر:* ${itemTitle(a.item)}\n` +
    `💰 *${a.bid ? 'أعلى مزايدة' : 'سعر البداية'}:* \`${fmt(a.bid || a.start)}\` كوين\n` +
    (a.leader ? `👑 *المتصدر:* ${a.leaderName}\n` : '') +
    `📈 *أقل مزايدة جاية:* \`${fmt(minNext(a))}\`\n👥 *عدد المزايدات:* ${a.bids}\n⏳ *باقي:* ${leftText(a.endsAt - Date.now())}\n\n` +
    `للمزايدة اكتب: *${prefix}زايد ${minNext(a)}*`;

const parseAmount = (t) => {
    const m = /^(\d+(?:\.\d+)?)\s*(k|ك|m|م)?$/i.exec(toEnDigits(String(t || '')).replace(/[,٬]/g, '').trim());
    if (!m) return 0;
    const mul = /k|ك/i.test(m[2] || '') ? 1e3 : /m|م/i.test(m[2] || '') ? 1e6 : 1;
    return Math.floor(parseFloat(m[1]) * mul);
};

// إنهاء المزاد تلقائياً (بيشتغل كل 10 ثواني ويكمّل حتى بعد ريستارت)
job('auction-end', async () => {
    const a = load().active;
    if (!a || Date.now() < a.endsAt) return;
    const r = endAuction();
    if (!r) return;
    const text = r.sold
        ? `🔨 *SOFA • AUCTION — خلص المزاد!* 🔨\n\n🎁 ${itemTitle(r.item)}\n🏆 الفايز: *${r.auction.leaderName}* (@${r.auction.leader})\n💰 بسعر: \`${fmt(r.auction.bid)}\` كوين\n\n🎉 مبروك! العنصر اتضاف لخزنته (.خزنتي)${r.item.limited ? '\n💎 العنصر ده LIMITED ومش هينزل تاني أبداً!' : ''}\n\n⏰ المزاد الجاي بكرة بإذن الله`
        : `🔨 *SOFA • AUCTION — خلص المزاد!* 🔨\n\n🎁 ${itemTitle(r.item)}\n😔 محدش زايد عليه ومشي من غير ما يتباع.\n\n⏰ المزاد الجاي بكرة بإذن الله`;
    await castToGroups(text).catch((e) => console.log('[auction] cast failed:', e.message));
}, 10000);

export default [
    {
        name: 'ابدا_المزاد',
        aliases: ['ابدأ_المزاد', 'ابدا-المزاد', 'ابدأ-المزاد', 'startauction'],
        category: 'dev',
        description: 'للمطور (201018766845): يبدأ مزاد اليوم ويتبعت لكل الجروبات. اختياري: عدد الدقايق',
        usage: '.ابدا_المزاد [دقايق]',
        async run(ctx) {
            const { reply, args } = ctx;
            if (!(await isDevSender(ctx, [AUCTION_STARTER]))) return reply('❌ الأمر ده لرقم المطور بس.');
            const r = startAuction(parseInt(toEnDigits(args[0] || ''), 10) || undefined);
            if (!r.ok) return reply(r.error === 'active' ? '⏳ في مزاد شغال دلوقتي بالفعل.' : '📅 مزاد النهارده اتعمل قبل كده — المزاد مرة واحدة في اليوم.');
            await reply(`✅ بدأ المزاد (${r.minutes} دقيقة): ${itemTitle(r.auction.item)}\n📣 جاري الإرسال لكل الجروبات... هبعتلك التقرير.`);
            const t = await castToGroups(
                `🔨 *SOFA • مزاد اليوم!* 🔨\n\n🎁 *العنصر:* ${itemTitle(r.auction.item)}\n💰 *سعر البداية:* \`${fmt(r.auction.start)}\` كوين\n⏳ *المدة:* ${leftText(r.auction.endsAt - Date.now())}\n\n` +
                `${r.auction.item.limited ? '💎 *عنصر LIMITED — بينزل مرة واحدة بس وبعدها مش هيتكرر!*\n\n' : ''}` +
                `للمزايدة اكتب: *.زايد ${r.auction.start}*\nلمتابعة المزاد: *.مزاد*\n(لازم تكون مسجّل: .تسجيل — والمزايدة بالكوين بس)`
            );
            return reply(`📣 *تقرير إرسال المزاد*\n✅ اتبعت: ${t.sent}\n⏭️ اتخطى: ${t.skipped}\n❌ فشل: ${t.failed}\n📱 أرقام: ${t.sessions}`);
        }
    },
    {
        name: 'مزاد',
        aliases: ['المزاد', 'auction'],
        category: 'games',
        description: 'يعرض المزاد الشغال دلوقتي',
        cooldown: 3000,
        async run({ reply, prefix = '.' }) {
            const s = load();
            if (!s.active) return reply('🔨 مفيش مزاد شغال دلوقتي. المزاد بينزل مرة في اليوم — خليك متابع!');
            return reply(board(s.active, prefix));
        }
    },
    {
        name: 'زايد',
        aliases: ['مزايدة', 'مزايده', 'bid'],
        category: 'games',
        description: 'زايد في المزاد: .زايد <المبلغ> (بيقبل 50k / 2m)',
        usage: '.زايد 50000',
        cooldown: 2000,
        async run({ sock, m, message, args, reply, prefix = '.' }) {
            const number = await resolveNumber(sock, m || message);
            if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
            const s = load();
            if (!s.active) return reply('🔨 مفيش مزاد شغال دلوقتي.');
            const amount = parseAmount(args[0]);
            if (!amount) return reply(`❌ اكتب المبلغ: *${prefix}زايد ${minNext(s.active)}*`);
            const r = placeBid(number, amount);
            if (!r.ok) {
                if (r.error === 'low') return reply(`❌ المزايدة قليلة! أقل مبلغ دلوقتي: \`${fmt(r.min)}\``);
                if (r.error === 'funds') return reply(`❌ رصيدك مش كفاية! معاك \`${fmt(r.have)}\` كوين.`);
                return reply('🔨 المزاد خلص أو حصل خطأ.');
            }
            const a = r.auction;
            return reply({
                text: `✅ *مزايدة ناجحة!*\n\n🎁 ${itemTitle(a.item)}\n👑 المتصدر: @${number}\n💰 \`${fmt(a.bid)}\` كوين (اتحجزت من رصيدك: \`${fmt(r.coins)}\` متبقي)\n⏳ باقي: ${leftText(a.endsAt - Date.now())}${r.extended ? '\n⚡ اتمدد المزاد دقيقة (مزايدة في آخر لحظة)' : ''}` +
                    (r.outbid ? `\n\n📢 @${r.outbid} اتزايد عليك! اكتب *${prefix}زايد ${minNext(a)}*` : ''),
                mentions: [`${number}@s.whatsapp.net`, ...(r.outbid ? [`${r.outbid}@s.whatsapp.net`] : [])]
            });
        }
    },
    {
        name: 'خزنتي',
        aliases: ['خزنة', 'vault'],
        category: 'games',
        description: 'العناصر اللي كسبتها من المزاد',
        cooldown: 3000,
        async run({ sock, m, message, reply, prefix = '.' }) {
            const number = await resolveNumber(sock, m || message);
            if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
            const items = vaultOf(number);
            if (!items.length) return reply('🗄️ خزنتك فاضية. اكسب عناصر من *.مزاد*');
            return reply(`🗄️ *SOFA • VAULT*\n\n${items.map((i, n) => `${n + 1}. ${i.name} — \`${fmt(i.paid)}\``).join('\n')}\n\n📦 العدد: ${items.length}`);
        }
    }
];
