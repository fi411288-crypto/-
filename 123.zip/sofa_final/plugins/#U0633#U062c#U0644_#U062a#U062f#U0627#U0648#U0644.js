// 📜 سجل التداول — تاريخ عمليات بيع وشراء الأسهم — SOFA BOT
// لازم تضيف سطرين في اسهم.js عشان العمليات تتسجّل (موجودين في الرسالة)
import { resolveNumber, isRegistered, getUser } from '../lib/economy.js';
import { fmt, displayName } from '../lib/shop.js';

const when = (t) => new Date(t).toLocaleString('en-GB', { timeZone: 'Africa/Cairo', hour12: false, day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

export default [{
    name: 'سجل-تداول',
    aliases: ['سجل_تداول', 'تداولاتي', 'trades', 'سجل-الاسهم'],
    category: 'games',
    description: 'تاريخ عمليات بيع وشراء الأسهم بتاعتك',
    usage: '.سجل-تداول [العدد]',
    cooldown: 3000,
    async run({ sock, m, message, args, reply, prefix = '.' }) {
        const msg = m || message;
        const number = await resolveNumber(sock, msg);
        if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);

        const u = getUser(number);
        const trades = Array.isArray(u?.trades) ? u.trades : [];
        if (!trades.length) return reply(`📭 مفيش عمليات تداول متسجّلة لسه.\nابدأ بـ *${prefix}اسهم شراء 100*`);

        const count = Math.min(20, Math.max(1, parseInt(args[0], 10) || 10));
        const last = trades.slice(-count).reverse();
        const sells = trades.filter((t) => t.side === 'sell');
        const realized = sells.reduce((s, t) => s + (Number(t.pl) || 0), 0);
        const wins = sells.filter((t) => (t.pl || 0) > 0).length;

        const lines = last.map((t) => t.side === 'buy'
            ? `🟢 شراء ${fmt(t.qty)} × ${Number(t.price).toFixed(2)} = \`${fmt(t.total)}\`\n   🕒 ${when(t.at)}`
            : `🔴 بيع ${fmt(t.qty)} × ${Number(t.price).toFixed(2)} = \`${fmt(t.total)}\` ${t.pl >= 0 ? '▲' : '▼'} ${fmt(Math.abs(t.pl || 0))}\n   🕒 ${when(t.at)}`);

        return reply(
            `📜 *SOFA • TRADE LOG*\n👤 ${displayName(u)}\n\n${lines.join('\n')}\n\n` +
            `📊 إجمالي العمليات: *${trades.length}*\n${realized >= 0 ? '🟢 ربح محقق' : '🔴 خسارة محققة'}: \`${fmt(Math.abs(Math.round(realized)))}\`\n` +
            (sells.length ? `🎯 صفقات رابحة: ${wins}/${sells.length}` : '')
        );
    }
}];
