// 🌧️ مطر كوين: ارمي فلوس في الجروب وأول ناس يكتبوا .التقط ياخدوها — SOFA BOT
import { resolveNumber, isRegistered, updateUser } from '../lib/economy.js';
import { fmt, toEnDigits } from '../lib/shop.js';

const TTL = 60000, MIN = 100, MAX = 1000000;
const rains = new Map(); // jid -> state
const credit = (n, c) => updateUser(n, (u, eco) => { eco.coin += c; });

function end(jid, st, sock) {
    if (rains.get(jid) !== st) return;
    clearTimeout(st.timer); rains.delete(jid);
    const left = st.amount - st.share * st.claimed.size;
    if (st.paid && left > 0) credit(st.payer, left);
    sock.sendMessage(jid, { text: `🌤️ *خلص المطر!* اتلقط ${st.claimed.size}/${st.count}${st.paid && left > 0 ? `\n↩️ اتردّ \`${fmt(left)}\` للي رماه` : ''}` }).catch(() => {});
}

export default [
    {
        name: 'مطر',
        aliases: ['rain', 'مطر_كوين'],
        category: 'games',
        group: true,
        description: 'ارمي كوين في الجروب وأول ناس يلتقطوه (من رصيدك، والمطور ببلاش)',
        usage: '.مطر 5000 [عدد الناس]',
        cooldown: 5000,
        async run({ sock, m, message, args, reply, isDeveloper, prefix = '.' }) {
            const msg = m || message, jid = msg.key.remoteJid;
            const payer = await resolveNumber(sock, msg);
            if (!payer || !isRegistered(payer)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
            if (rains.has(jid)) return reply('🌧️ فيه مطر شغال في الجروب، استنى يخلص.');
            const nums = args.map(toEnDigits).filter((a) => /^\d{1,9}$/.test(a)).map(Number);
            const amount = nums[0], count = Math.max(1, Math.min(20, nums[1] || 5));
            if (!amount || amount < MIN || amount > MAX) return reply(`❌ اكتب مبلغ من ${fmt(MIN)} لـ ${fmt(MAX)}:\n*${prefix}مطر 5000 5*`);
            if (Math.floor(amount / count) < 1) return reply('❌ المبلغ صغير على العدد ده.');
            const paid = !isDeveloper;
            if (paid) {
                const r = updateUser(payer, (u, eco) => { if (eco.coin < amount) return { error: 'funds', have: eco.coin }; eco.coin -= amount; });
                if (r.error) return reply(`❌ رصيدك مش كفاية! معاك: \`${fmt(r.have)}\``);
            }
            const st = { amount, count, share: Math.floor(amount / count), claimed: new Set(), payer, paid };
            rains.set(jid, st);
            st.timer = setTimeout(() => end(jid, st, sock), TTL);
            return reply(`🌧️ *SOFA • RAIN*\n\n💰 اترمى \`${fmt(amount)}\` كوين!\n🎯 أول *${count}* يكتبوا *${prefix}التقط* ياخدوا \`${fmt(st.share)}\` كل واحد\n⏳ معاكم دقيقة!`);
        }
    },
    {
        name: 'التقط',
        aliases: ['catch', 'التقاط'],
        category: 'games',
        group: true,
        description: 'التقط من المطر الشغال',
        cooldown: 1000,
        async run({ sock, m, message, reply, prefix = '.' }) {
            const msg = m || message, jid = msg.key.remoteJid, st = rains.get(jid);
            if (!st) return reply('☀️ مفيش مطر دلوقتي.');
            const n = await resolveNumber(sock, msg);
            if (!n || !isRegistered(n)) return reply(`❌ لازم تسجّل الأول: *${prefix}تسجيل*`);
            if (st.claimed.has(n)) return reply('ℹ️ أنت لقطت بالفعل.');
            if (st.paid && n === st.payer) return reply('😅 مينفعش تلقط مطرك.');
            if (st.claimed.size >= st.count) return reply('😢 اتلقط كله.');
            st.claimed.add(n); credit(n, st.share);
            await reply(`✅ لقطت \`${fmt(st.share)}\` كوين! (${st.claimed.size}/${st.count})`);
            if (st.claimed.size >= st.count) end(jid, st, sock);
        }
    }
];
