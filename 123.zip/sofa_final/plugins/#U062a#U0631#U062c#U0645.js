import axios from 'axios';
import { quotedOf, reactor, groqChat, MODELS } from '../lib/groq.js';

// اللغات المدعومة: الاسم بالعربي أو الرمز -> رمز جوجل
const LANGS = {
    ar: 'ar', عربي: 'ar', عربية: 'ar', en: 'en', انجليزي: 'en', إنجليزي: 'en', انجليزية: 'en',
    fr: 'fr', فرنسي: 'fr', de: 'de', الماني: 'de', ألماني: 'de', es: 'es', اسباني: 'es', إسباني: 'es',
    it: 'it', ايطالي: 'it', إيطالي: 'it', tr: 'tr', تركي: 'tr', ru: 'ru', روسي: 'ru',
    zh: 'zh-CN', صيني: 'zh-CN', ja: 'ja', ياباني: 'ja', ko: 'ko', كوري: 'ko', hi: 'hi', هندي: 'hi',
    fa: 'fa', فارسي: 'fa', pt: 'pt', برتغالي: 'pt', id: 'id', اندونيسي: 'id', ur: 'ur', اردو: 'ur',
    he: 'iw', عبري: 'iw', el: 'el', يوناني: 'el', nl: 'nl', هولندي: 'nl'
};
const NAMES = {
    ar: 'العربية', en: 'الإنجليزية', fr: 'الفرنسية', de: 'الألمانية', es: 'الإسبانية', it: 'الإيطالية', tr: 'التركية',
    ru: 'الروسية', 'zh-CN': 'الصينية', ja: 'اليابانية', ko: 'الكورية', hi: 'الهندية', fa: 'الفارسية', pt: 'البرتغالية',
    id: 'الإندونيسية', ur: 'الأردية', iw: 'العبرية', el: 'اليونانية', nl: 'الهولندية', 'zh-TW': 'الصينية', 'zh': 'الصينية'
};
const nameOf = (c) => (c ? NAMES[c] || c : 'تلقائي');

// تقسيم النص الطويل لأجزاء (رابط جوجل محدود الطول)
function chunks(text, size = 1200) {
    const out = [];
    let rest = text;
    while (rest.length > size) {
        let cut = rest.lastIndexOf('\n', size);
        if (cut < size / 2) cut = rest.lastIndexOf(' ', size);
        if (cut < size / 2) cut = size;
        out.push(rest.slice(0, cut));
        rest = rest.slice(cut);
    }
    out.push(rest);
    return out;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const UA = { 'User-Agent': 'Mozilla/5.0' };

// مصادر الترجمة بالترتيب: لو واحد اتحجب (429) أو فشل، بنجرب اللي بعده
const PROVIDERS = [
    ['google', async (t, tl) => {
        const call = () => axios.get('https://translate.googleapis.com/translate_a/single', {
            params: { client: 'gtx', sl: 'auto', tl, dt: 't', q: t }, timeout: 15000, headers: UA
        });
        let r;
        try { r = await call(); }
        catch (e) {
            if (e.response?.status !== 429) throw e;
            await sleep(1500); // محاولة تانية بعد ثانية ونص
            r = await call();
        }
        const segs = r.data?.[0];
        if (!Array.isArray(segs)) throw new Error('رد غير متوقع');
        return { text: segs.map((x) => x?.[0] || '').join(''), from: r.data?.[2] };
    }],
    ['google2', async (t, tl) => {
        const r = await axios.get('https://clients5.google.com/translate_a/t', {
            params: { client: 'dict-chrome-ex', sl: 'auto', tl, q: t }, timeout: 15000, headers: UA
        });
        const d = r.data;
        if (d?.sentences) return { text: d.sentences.map((x) => x.trans || '').join(''), from: d.src };
        if (Array.isArray(d)) {
            const first = Array.isArray(d[0]) ? d[0][0] : d[0];
            if (typeof first === 'string') return { text: first, from: d[0]?.[1] };
        }
        throw new Error('رد غير متوقع');
    }],
    ['mymemory', async (t, tl) => {
        const src = /[\u0600-\u06FF]/.test(t) ? 'ar' : 'Autodetect';
        const to = tl === 'zh-CN' ? 'zh' : tl;
        let out = '';
        // الخدمة دي بتقبل ~500 حرف في الطلب الواحد
        for (let i = 0; i < t.length; i += 450) {
            const r = await axios.get('https://api.mymemory.translated.net/get', {
                params: { q: t.slice(i, i + 450), langpair: `${src}|${to}` }, timeout: 15000
            });
            const tr = r.data?.responseData?.translatedText;
            if (!tr || r.data?.responseStatus === 403 || r.data?.responseStatus === 429) throw new Error('رفض الخدمة');
            out += tr;
        }
        return { text: out, from: src === 'ar' ? 'ar' : null };
    }],
    ['groq', async (t, tl) => {
        const out = await groqChat({
            model: MODELS.fast, effort: 'low', max: 2048,
            messages: [
                { role: 'system', content: `Translate the user's text to the language with ISO code "${tl}". Output only the translation, nothing else.` },
                { role: 'user', content: t }
            ]
        });
        return { text: out, from: null };
    }]
];

async function translate(text, target) {
    let from = null;
    let result = '';
    const dead = new Set();   // مصادر فشلت قبل كده، منرجعش لها
    const errors = [];
    for (const part of chunks(text)) {
        let done = false;
        for (const [name, fn] of PROVIDERS) {
            if (dead.has(name)) continue;
            try {
                const r = await fn(part, target);
                if (!r.text?.trim()) throw new Error('نتيجة فاضية');
                result += r.text;
                from = from || r.from;
                done = true;
                break;
            } catch (e) {
                dead.add(name);
                errors.push(`${name}: ${e.response?.status || String(e.message).slice(0, 30)}`);
            }
        }
        if (!done) throw new Error(`كل المصادر فشلت (${errors.join(' | ')})`);
    }
    return { text: result.trim(), from };
}

export default {
    name: 'ترجم',
    aliases: ['ترجمة', 'ترجمه', 'translate', 'tr'],
    description: 'ترجمة نص بترجمة جوجل (من غير مفتاح)',
    category: 'tools',

    async run({ sock, message, args, reply, prefix }) {
        const q = quotedOf(sock, message);
        const list = [...args];

        // أول كلمة ممكن تكون اسم اللغة المطلوبة
        let target = null;
        if (list.length && LANGS[list[0].toLowerCase()]) target = LANGS[list.shift().toLowerCase()];

        let text = list.join(' ').trim();
        if (!text && q?.text) text = q.text.trim();
        if (!text) {
            return reply(`🌐 *الترجمة*\n\n• ${prefix}ترجم مرحبا بالعالم\n• ${prefix}ترجم فرنسي كيف حالك\n• أو رد على رسالة واكتب ${prefix}ترجم\n\nاللغات: عربي، انجليزي، فرنسي، الماني، اسباني، ايطالي، تركي، روسي، صيني، ياباني، كوري، هندي، فارسي، برتغالي، اندونيسي، اردو، عبري، يوناني، هولندي`);
        }

        // من غير لغة محددة: عربي -> إنجليزي، وأي لغة تانية -> عربي
        if (!target) target = /[\u0600-\u06FF]/.test(text) ? 'en' : 'ar';

        const react = reactor(sock, message);
        await react('⌛');
        try {
            const { text: out, from } = await translate(text, target);
            await react('✅');
            return reply(`🌐 *ترجمة* (${nameOf(from)} ➜ ${nameOf(target)})\n\n${out}\n\n> SOFA BOT`);
        } catch (e) {
            await react('❌');
            return reply(`❌ فشلت الترجمة: ${e.message}`);
        }
    }
};
