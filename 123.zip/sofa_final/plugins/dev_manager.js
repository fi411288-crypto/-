import { developerManager, config } from '../config.js';

const digits = (v) => String(v || '').replace(/\D/g, '');
const format = (n) => `@${n}`;

function getTarget(m, args) {
    const mentioned = m?.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (mentioned[0]) return digits(mentioned[0]);

    const quoted = m?.message?.extendedTextMessage?.contextInfo?.participant;
    if (quoted) return digits(quoted);

    const raw = args?.[0] || '';
    const n = digits(raw);
    return n.length >= 8 ? n : null;
}

export default {
    name: 'dev_manager',
    category: 'dev',
    description: 'إضافة وحذف وإظهار المطورين الدائمين',
    commands: [
        {
            name: 'اضف_مطور',
            aliases: ['اضف_مطور', 'ضيف_مطور', 'adddev', 'adddeveloper'],
            category: 'dev',
            developer: true,
            ownerOnly: true,
            description: 'إضافة مطور جديد للرقم المحدد',
            run: async ({ m, args, reply }) => {
                const target = getTarget(m, args);
                if (!target) return reply(`❌ الاستخدام الصحيح:\n.اضف_مطور 201xxxxxxxxx\nأو اعمل منشن للشخص ثم اكتب .اضف_مطور`);

                const result = developerManager.add(target);
                if (result.reason === 'owner') return reply('👑 هذا الرقم هو المالك الأساسي بالفعل.');
                if (result.reason === 'exists') return reply(`⚠️ ${format(target)} مطور بالفعل.`);
                if (!result.ok) return reply('❌ رقم غير صالح.');

                return reply(`✅ تم إضافة المطور بنجاح.\n👨‍💻 المطور: ${format(target)}\n🔐 الصلاحية: مطور كامل`);
            }
        },
        {
            name: 'حذف_مطور',
            aliases: ['شيل_مطور', 'احذف_مطور', 'deldev', 'remove_developer'],
            category: 'dev',
            developer: true,
            ownerOnly: true,
            description: 'حذف مطور من القائمة',
            run: async ({ m, args, reply }) => {
                const target = getTarget(m, args);
                if (!target) return reply(`❌ الاستخدام الصحيح:\n.حذف_مطور 201xxxxxxxxx\nأو اعمل منشن للمطور ثم اكتب .حذف_مطور`);

                const result = developerManager.remove(target);
                if (result.reason === 'owner') return reply('❌ لا يمكن حذف المالك الأساسي من قائمة المطورين.');
                if (result.reason === 'missing') return reply(`⚠️ ${format(target)} ليس مطورًا مسجلاً.`);
                if (!result.ok) return reply('❌ رقم غير صالح.');

                return reply(`✅ تم حذف المطور.\n👨‍💻 الرقم: ${format(target)}`);
            }
        },
        {
            name: 'المطورين',
            aliases: ['مطورين', 'قائمة_المطورين', 'developers', 'devs'],
            category: 'dev',
            developer: true,
            ownerOnly: true,
            description: 'عرض جميع المطورين المسجلين',
            run: async ({ reply }) => {
                const owners = (config.OWNER_NUMBERS || [config.OWNER_NUMBER]).map(digits).filter(Boolean);
                const developers = developerManager.list();
                const lines = [
                    ...owners.map((n, i) => `${i + 1}. 👑 ${format(n)} — مالك`),
                    ...developers.map((n, i) => `${owners.length + i + 1}. 👨‍💻 ${format(n)} — مطور`)
                ];
                return reply(`╭━━━〔 👑 المالكون والمطورون 〕━━━╮\n${lines.join('\n') || 'لا يوجد مطورون مضافون حالياً.'}\n╰━━━━━━━━━━━━━━━━━━╯`);
            }
        }
    ]
};
