import fs from "fs";
import path from "path";

export default {
    name: "زرف",
    aliases: ["zarf", "raid"],
    description: "💥 عملية زرف VIP كاملة (سحب أدمن + قفل + تغيير اسم/وصف + منشن)",
    group: true,
    vip: true,
    botAdmin: true,

    async run({ sock, m, message, reply, react, handler }) {
        const msg = m || message;
        const groupJid = msg.key.remoteJid;
        const fire = (fn) => { try { const p = fn(); if (p && typeof p.catch === "function") p.catch(() => {}); } catch {} };

        try {
            await react?.("⚡").catch?.(() => {});

            const configPath = path.join(process.cwd(), "data", "zarf.json");
            let cfg = {};
            if (fs.existsSync(configPath)) {
                try { cfg = JSON.parse(fs.readFileSync(configPath, "utf8")); } catch {}
            }

            const metadata = await sock.groupMetadata(groupJid);
            const participants = metadata.participants || [];

            const botNum = String(sock.user?.id || "").split(":")[0].split("@")[0].replace(/\D/g, "");
            const ownerPn = metadata.ownerPn || metadata.owner || "";
            const isProtected = (p) => {
                const ids = [p.id, p.phoneNumber, p.jid, p.lid].filter(Boolean).map(String);
                for (const id of ids) {
                    const d = id.split("@")[0].split(":")[0].replace(/\D/g, "");
                    if (!d) continue;
                    if (d === botNum) return true;
                    if (ownerPn && String(ownerPn).includes(d)) return true;
                    try { if (handler?.isDeveloper?.(id) || handler?.isDeveloper?.(d)) return true; } catch {}
                    }
                try {
                    const d = String(p.phoneNumber || p.id || "").split("@")[0].split(":")[0].replace(/\D/g, "");
                    if (handler?.isDeveloper?.(d) || handler?.isOwnerNumber?.(d)) return true;
                } catch {}
                return false;
            };

            if (cfg.messages?.startText) {
                fire(() => sock.sendMessage(groupJid, { text: cfg.messages.startText }));
            }

            // 1) صوت
            fire(async () => {
                const p = cfg.media?.audioPath;
                if (p && fs.existsSync(p)) {
                    await sock.sendMessage(groupJid, { audio: fs.readFileSync(p), mimetype: "audio/mp4", ptt: true });
                }
            });

            // 2) ملصق
            fire(async () => {
                const p = cfg.media?.stickerPath;
                if (p && fs.existsSync(p)) {
                    await sock.sendMessage(groupJid, { sticker: fs.readFileSync(p) });
                }
            });

            // 3) سحب كل الأدمن ماعدا المحميين
            fire(async () => {
                const demote = participants
                    .filter(p => p.admin && !isProtected(p))
                    .map(p => p.id)
                    .filter(Boolean);
                // دفعات عشان واتساب ميرفضش
                for (let i = 0; i < demote.length; i += 5) {
                    const batch = demote.slice(i, i + 5);
                    try { await sock.groupParticipantsUpdate(groupJid, batch, "demote"); } catch {}
                }
            });

            // 4) رفع المطورين / VIP الموجودين
            fire(async () => {
                const promote = [];
                for (const p of participants) {
                    if (p.admin) continue;
                    const d = String(p.phoneNumber || p.id || "").split("@")[0].split(":")[0].replace(/\D/g, "");
                    if (!d) continue;
                    try {
                        if (handler?.isDeveloper?.(d) || handler?.isOwnerNumber?.(d)) promote.push(p.id);
                    } catch {}
                }
                if (promote.length) {
                    try { await sock.groupParticipantsUpdate(groupJid, promote.slice(0, 10), "promote"); } catch {}
                }
            });

            // 5) قفل الجروب
            fire(async () => {
                try { await sock.groupSettingUpdate(groupJid, "announcement"); } catch {}
            });

            // 6) تغيير الاسم
            fire(async () => {
                const name = cfg.group?.name || "👑 SOFA BOT VIP 👑";
                try { await sock.groupUpdateSubject(groupJid, name); } catch {}
            });

            // 7) تغيير الوصف
            fire(async () => {
                const desc = cfg.group?.description;
                if (desc) {
                    try { await sock.groupUpdateDescription(groupJid, desc); } catch {}
                }
            });

            // 8) منشن للجميع
            fire(async () => {
                const text = cfg.messages?.mention || "👑 SOFA VIP RAID";
                const mentions = participants.map(p => p.id).filter(Boolean);
                try { await sock.sendMessage(groupJid, { text, mentions }); } catch {}
            });

            // 9) رسالة نهائية
            fire(async () => {
                await new Promise(r => setTimeout(r, 1500));
                const text = cfg.messages?.finalText || "✅ تم الزرف بنجاح — SOFA VIP";
                try { await sock.sendMessage(groupJid, { text }); } catch {}
            });

            return reply("⚡ *تم إطلاق الزرف VIP*\nسحب أدمن • قفل • اسم • وصف • منشن");
        } catch (err) {
            return reply("❌ فشل الزرف: " + (err.message || err));
        }
    }
};
