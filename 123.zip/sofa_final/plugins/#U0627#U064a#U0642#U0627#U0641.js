export default {
    name: "ايقاف",
    desc: "ايقاف تشغيل البوت فوراً",
    category: "developer",
    developer: true,
    
    async run({ message, handler }) {
        await handler.sendMessage(message.key.remoteJid, {
            text: '🔄 *جاري ايقاف تشغيل 𝐘𝐔𝐓𝐀 𝐁𝐎𝐓...*' 
        }, { quoted: message });

        setTimeout(() => {
            process.exit(1); 
        }, 3000);
    }
};
