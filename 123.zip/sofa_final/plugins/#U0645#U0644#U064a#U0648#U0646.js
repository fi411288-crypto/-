// SOFA MILLION — من سيربح المليون (نفس الشكل والرسائل والجوايز بتاعة النسخة الأصلية، متحوّل لـ SOFA BOT)
// الأزرار: sock.sendButtonV2 (الموجود في البوت) | الجوايز كوين/XP في data/economy.json
import axios from 'axios';
import { resolveNumber, isRegistered, addRewards as ecoAddRewards } from '../lib/economy.js';
import { getGroup, addPoints, ECO_RATE } from '../lib/community.js';

const TIMEOUT = 60000;
const QUESTIONS_API_URL = "https://gist.githubusercontent.com/Dx-Tea/19102ea14b19d7ef685128e6186a277d/raw/867b4da16f68253f67ca184f77ce5295d1da4029/By-shanks";
const EYE_API_URL = "https://gist.githubusercontent.com/Kyutaka101/4e01c190b7d67225ad7a86d388eeedf6/raw/67f0de059cea4b965a3f3bf211c12fc9c48043e5/gistfile1.txt";
const BTN_CMD = 'مليون_رد';

const FALLBACK_QUESTIONS = [
    { q: "ما هي عاصمة فرنسا؟", a: "باريس", opts: ["باريس", "لندن", "روما"] },
    { q: "من هو أول خلفاء المسلمين؟", a: "أبو بكر الصديق", opts: ["أبو بكر الصديق", "عمر بن الخطاب", "عثمان بن عفان"] },
    { q: "كم عدد سور القرآن الكريم؟", a: "114", opts: ["114", "113", "115"] },
    { q: "ما هو أكبر كوكب في المجموعة الشمسية؟", a: "المشتري", opts: ["المشتري", "زحل", "المريخ"] },
    { q: "في أي سنة أقيمت غزوة بدر؟", a: "2 هجريا", opts: ["2 هجريا", "3 هجريا", "1 هجريا"] },
    { q: "ما هي عاصمة مصر؟", a: "القاهرة", opts: ["القاهرة", "الإسكندرية", "الجيزة"] },
    { q: "ما هو النبي الذي ابتلعه الحوت؟", a: "يونس", opts: ["يونس", "موسى", "عيسى"] },
    { q: "كم عدد ركعات صلاة الفجر؟", a: "ركعتان", opts: ["ركعتان", "أربع ركعات", "ثلاث ركعات"] }
];

const PRIZE_TABLE = {
    1:  { xp: 300, coins: 5000 },
    2:  { xp: 350, coins: 10000 },
    3:  { xp: 400, coins: 15000 },
    4:  { xp: 450, coins: 20000 },
    5:  { xp: 500, coins: 25000 },
    6:  { xp: 550, coins: 30000 },
    7:  { xp: 600, coins: 35000 },
    8:  { xp: 650, coins: 40000 },
    9:  { xp: 700, coins: 45000 },
    10: { xp: 750, coins: 50000 },
    11: { xp: 800, coins: 55000 },
    12: { xp: 850, coins: 60000 },
    13: { xp: 900, coins: 65000 },
    14: { xp: 950, coins: 70000 },
    15: { xp: 1000, coins: 475000 }
};

const games = new Map();

/* ───────── مساعدات الهوية (رقم حقيقي حتى مع LID) ───────── */
const digits = (j) => String(j || '').split('@')[0].split(':')[0].replace(/\D/g, '');
const chatOf = (m) => m.key.remoteJid;
const sendersOf = (m) => [m.key.participant, m.key.participantAlt, m.key.participantPn, m.key.fromMe ? null : m.key.remoteJid]
    .map(digits).filter(Boolean);
const getSenderId = (m) => m.key.participant || m.key.participantPn || m.key.remoteJid;

/* ───────── الجوايز: بتتسجل في نظام الاقتصاد المشترك (lib/economy.js) ───────── */
async function addRewards(sock, number, xpReward, coinReward, game) {
    try {
        const r = ecoAddRewards(number, xpReward, coinReward);
        // نفس الفوز يتحسب نقاط في الجروب (بدون ما XP يتضاعف)
        if (r.success && game?.chat?.endsWith('@g.us') && xpReward > 0) {
            try {
                const { g, save } = getGroup(String(sock.user?.id || '').split('@')[0].split(':')[0], game.chat);
                addPoints(g, String(game.owner).split('@')[0].split(':')[0].replace(/\D/g, ''), Math.max(1, Math.round(xpReward / ECO_RATE)), false);
                save();
            } catch {}
        }
        if (!r.success) console.error('[MILLION] reward not saved for', number);
        return r;
    } catch (error) {
        console.error("[SOFA MILLION REWARD ERROR]", error);
        return { success: false };
    }
}

async function getImageThumbnail() {
    try {
        const res = await axios.get(EYE_API_URL, { timeout: 8000 });
        const items = res.data;
        if (Array.isArray(items) && items.length > 0) {
            const randomItem = items[Math.floor(Math.random() * items.length)];
            return randomItem.img;
        }
    } catch (_) {}
    return "https://upload.satoru.click/files/9ef506.jpg";
}

async function react(sock, m, emoji) {
    try { await sock.sendMessage(chatOf(m), { react: { text: emoji, key: m.key } }); } catch {}
}

async function sendText(sock, m, text) {
    await sock.sendMessage(chatOf(m), { text }, { quoted: m });
}

const norm = (s) => String(s || "").toLowerCase().replace(/[؟?!.,،؛:ـ]/g, "").replace(/\s+/g, " ").trim();

async function fetchQuestions() {
    try {
        const res = await axios.get(QUESTIONS_API_URL, { timeout: 8000 });
        if (Array.isArray(res.data) && res.data.length > 0) {
            const seen = new Set();
            const questions = res.data
                .map(item => ({
                    q: String(item.question || item.q || "").trim(),
                    a: String(item.response || item.a || "").trim(),
                    opts: item.options || item.opts || [item.response || item.a]
                }))
                .filter(item => {
                    if (!item.q || !item.a) return false;
                    const n = norm(item.q);
                    if (seen.has(n)) return false;
                    seen.add(n);
                    return true;
                });
            if (questions.length > 0) return questions;
        }
    } catch (_) {}
    return FALLBACK_QUESTIONS;
}

function shuffle(array) {
    const result = [...array];
    for (let i = result.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
}

function getNextQuestion(game) {
    if (!Array.isArray(game.src) || game.src.length === 0) return null;
    const usedQuestions = game.usedQuestions || new Set();
    const availableQuestions = game.src.filter(item => { const n = norm(item.q); return n && !usedQuestions.has(n); });
    if (availableQuestions.length === 0) return null;
    const item = availableQuestions[Math.floor(Math.random() * availableQuestions.length)];
    usedQuestions.add(norm(item.q));
    game.usedQuestions = usedQuestions;
    return item;
}

// 3 اختيارات: لو السؤال مفيهوش اختيارات غلط كفاية بنسحبها من إجابات أسئلة تانية (بدل "خيار خاطئ")
function buildOptions(game, item) {
    const correct = String(item.a || "").trim();
    let wrong = (item.opts || []).map(o => String(o).trim()).filter(o => o && o.toLowerCase() !== correct.toLowerCase());
    if (wrong.length < 2) {
        const pool = [...new Set(game.src.map(x => String(x.a || "").trim()).filter(a => a && a.toLowerCase() !== correct.toLowerCase() && !wrong.includes(a)))];
        wrong = wrong.concat(shuffle(pool));
    }
    while (wrong.length < 2) wrong.push("خيار خاطئ");
    const two = shuffle(wrong).slice(0, 2);
    return { correct, options: shuffle([correct, two[0], two[1]]) };
}

/* ───────── إرسال السؤال بالأزرار ───────── */
async function sendMillionQuestion(sock, m, chatId, game, prefix) {
    const { level, question, options, accumulatedCoins } = game;
    const prize = PRIZE_TABLE[level] || { xp: 300, coins: 5000 };

    const body =
        `🌌 *من سيربح المليون* 💰\n\n` +
        `📈 *المستوى:* \`${level} / 15\`\n` +
        `💰 *المتراكم معك حتى الآن:* \`${accumulatedCoins.toLocaleString()} كوين\`\n` +
        `💎 *جائزة هذا السؤال:* \`${prize.coins.toLocaleString()} كوين\` | \`+${prize.xp} XP\`\n\n` +
        `❓ *السؤال:*\n*${question}*\n\n` +
        `⏳ *الوقت المتاح:* 60 ثانية\n\n` +
        `👇 *اختر إجابتك من الأزرار أدناه:*`;

    game.token = String(Date.now());
    const buttons = options.map((o, i) => ({ text: `💡 ${o}`, id: `${prefix}${BTN_CMD} ${i} ${game.token}` }));

    let thumb;
    try { thumb = await getImageThumbnail(); } catch {}

    try {
        if (typeof sock.sendButtonV2 === 'function') {
            const r = await sock.sendButtonV2(chatId, body, buttons, { footer: "🌌 SOFA BOT", thumbnail: thumb });
            if (r) return r;
        }
    } catch {}
    try {
        return await sock.sendMessage(chatId, {
            text: body, footer: "🌌 SOFA BOT", headerType: 1,
            buttons: buttons.map(b => ({ buttonId: b.id, buttonText: { displayText: b.text }, type: 1 }))
        }, { quoted: m });
    } catch {}
    // لو الأزرار مش مدعومة خالص: نفس الأسئلة كأرقام
    return sock.sendMessage(chatId, { text: `${body}\n\n${buttons.map((b, i) => `${b.text} ← ${prefix}${BTN_CMD} ${i} ${game.token}`).join('\n')}` }, { quoted: m });
}

function armTimer(sock, m, chatId, game, correctAnswer, longText) {
    game.timer = setTimeout(async () => {
        const activeGame = games.get(chatId);
        if (activeGame !== game) return;
        games.delete(chatId);
        try {
            if (game.accumulatedCoins > 0) await addRewards(sock, game.ownerJid, game.accumulatedXp, game.accumulatedCoins, game);
            await sendText(sock, m, longText
                ? `🌌 *SOFA • MILLION*\n\n⏳ *انتهى الوقت!*\n🎯 الإجابة الصحيحة: *${correctAnswer}*\n\n💰 إجمالي ما جمعته وخرجت به:\n+${game.accumulatedCoins.toLocaleString()} كوين | +${game.accumulatedXp.toLocaleString()} XP`
                : `🌌 *SOFA • MILLION*\n\n⏳ *انتهى الوقت!* الإجابة الصحيحة كانت: *${correctAnswer}*\n\n💰 ما جمعته وخرجت به:\n+${game.accumulatedCoins.toLocaleString()} كوين | +${game.accumulatedXp.toLocaleString()} XP`);
        } catch {}
    }, TIMEOUT);
}

async function createGame(sock, m, prefix, ownerNumber) {
    const chatId = chatOf(m);

    if (games.has(chatId)) {
        return sendText(sock, m, "🌌 *SOFA • MILLION*\n\n⌛ توجد لعبة نشطة بالفعل في هذا الشات.");
    }

    const src = await fetchQuestions();
    const game = {
        chat: chatId, owner: getSenderId(m), ownerJid: ownerNumber, ownerIds: sendersOf(m),
        level: 1, correctAnswer: "", options: [], question: "",
        accumulatedXp: 0, accumulatedCoins: 0, timer: null, src, usedQuestions: new Set(), token: ""
    };

    const item = getNextQuestion(game);
    if (!item) return sendText(sock, m, "🌌 *SOFA • MILLION*\n\n❌ لا توجد أسئلة متاحة لبدء اللعبة.");

    const { correct, options } = buildOptions(game, item);
    game.correctAnswer = correct;
    game.options = options;
    game.question = String(item.q || "").trim();

    games.set(chatId, game);
    try {
        await sendMillionQuestion(sock, m, chatId, game, prefix);
    } catch (error) {
        games.delete(chatId);
        throw error;
    }
    armTimer(sock, m, chatId, game, correct, true);
}

async function handleAnswer(sock, m, chatId, optionIndex, token, prefix) {
    const game = games.get(chatId);

    if (!game) return sendText(sock, m, "🌌 *SOFA • MILLION*\n\n❌ لا توجد لعبة نشطة الآن.");

    if (!sendersOf(m).some(id => game.ownerIds.includes(id))) {
        await react(sock, m, "⚠️");
        return sendText(sock, m, "❌ *هذه ليست لعبتك! انتظر حتى تنتهي لعبة صاحبها.*");
    }

    if (token && token !== game.token) return react(sock, m, "⌛"); // زر قديم من سؤال سابق

    const selectedAnswer = game.options[optionIndex];
    if (selectedAnswer === undefined) return;

    if (selectedAnswer.toLowerCase() === game.correctAnswer.toLowerCase()) {
        clearTimeout(game.timer);

        const currentPrize = PRIZE_TABLE[game.level] || { xp: 300, coins: 5000 };
        game.accumulatedXp += currentPrize.xp;
        game.accumulatedCoins += currentPrize.coins;
        game.level++;

        if (game.level > 15) {
            games.delete(chatId);
            await addRewards(sock, game.ownerJid, game.accumulatedXp, game.accumulatedCoins, game);
            await react(sock, m, "🏆");
            return sendText(sock, m, `🌌 *SOFA • MILLION* 🏆\n\n🎊 *ألف مبروك! فزت بالمليون الكبرى وتخطيت كل المراحل!* 🎊\n\n💰 إجمالي الكوينات المضافة: +${game.accumulatedCoins.toLocaleString()} كوين | +${game.accumulatedXp.toLocaleString()} XP`);
        }

        const item = getNextQuestion(game);
        if (!item) {
            games.delete(chatId);
            if (game.accumulatedCoins > 0) await addRewards(sock, game.ownerJid, game.accumulatedXp, game.accumulatedCoins, game);
            await react(sock, m, "🏆");
            return sendText(sock, m, `🌌 *SOFA • MILLION*\n\n🏆 *انتهت الأسئلة المتاحة!*\n\n💰 إجمالي الكوينات التي جمعتها: +${game.accumulatedCoins.toLocaleString()} كوين\n⚡ إجمالي XP: +${game.accumulatedXp.toLocaleString()} XP`);
        }

        const { correct, options } = buildOptions(game, item);
        game.correctAnswer = correct;
        game.options = options;
        game.question = String(item.q || "").trim();

        await react(sock, m, "✅");
        await sendText(sock, m, `✅ *إجابة صحيحة! (+${currentPrize.coins.toLocaleString()} كوين)*\nجاري إرسال السؤال التالي...`);
        await sendMillionQuestion(sock, m, chatId, game, prefix);
        armTimer(sock, m, chatId, game, correct, false);
        return;
    }

    clearTimeout(game.timer);
    games.delete(chatId);

    const totalCoins = game.accumulatedCoins;
    const totalXp = game.accumulatedXp;
    if (totalCoins > 0) await addRewards(sock, game.ownerJid, totalXp, totalCoins, game);

    await react(sock, m, "❌");
    return sendText(
        sock, m,
        `🌌 *SOFA • MILLION* ❌\n\n` +
        `❌ *إجابة خاطئة للأسف!*\n\n` +
        `🎯 *الإجابة الصحيحة:*\n➜ ${game.correctAnswer}\n\n` +
        (totalCoins > 0 ? `🎁 انتهت اللعبة، وخرجت بكل الأموال التي جمعتها حتى الآن:\n💰 +${totalCoins.toLocaleString()} كوين\n⚡ +${totalXp.toLocaleString()} XP` : `💔 خسرت من أول سؤال ولم تجمع أي رصيد.`)
    );
}

export default [
    {
        name: "المليون",
        aliases: ["million", "من_سيربح_المليون"],
        category: "games",
        description: "SOFA Million Game Buttons Lib Integration",
        cooldown: 1000,
        async run({ sock, message, prefix = '.' }) {
            try {
                await react(sock, message, "💰");
                const number = await resolveNumber(sock, message);
                if (!number || !isRegistered(number)) {
                    await react(sock, message, "🔒");
                    return await sendText(sock, message, `🌌 *SOFA • MILLION*\n\n🔒 *لازم تسجّل الأول عشان تلعب وتاخد الجوايز!*\n\n✍️ اكتب: *${prefix}تسجيل*`);
                }
                return await createGame(sock, message, prefix, number);
            } catch (error) {
                console.error("[SOFA MILLION ERROR]", error);
                try { await sendText(sock, message, "🌌 *SOFA • MILLION*\n\n❌ حدث خطأ أثناء تشغيل اللعبة."); } catch {}
                await react(sock, message, "❌");
            }
        }
    },
    {
        // أمر داخلي بتشغّله أزرار الإجابة (مش بيظهر في القوائم)
        name: BTN_CMD,
        aliases: [],
        category: "hidden",
        description: "internal: Million answer button",
        cooldown: 300,
        async run({ sock, message, args, prefix = '.' }) {
            try {
                const idx = parseInt(args[0], 10);
                if (![0, 1, 2].includes(idx)) return;
                return await handleAnswer(sock, message, chatOf(message), idx, args[1] || "", prefix);
            } catch (error) {
                console.error("[SOFA MILLION ANSWER ERROR]", error);
            }
        }
    }
];
