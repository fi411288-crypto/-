import fetch from 'node-fetch';

export default {
    name: 'emojimix',
    aliases: ['خلط-ايموجي', 'emix', 'مزج'],
    description: 'دمج إيموجيين في ملصق',
    category: 'media',
    usage: '.emojimix 😍+🔥',

    async run({ text, reply, sock, m, message, react }) {
        const raw = (text || '').trim().replace(/\s+/g, '');
        const parts = raw.split(/[+|/]/).filter(Boolean);
        if (parts.length < 2) return reply('❌ استخدم: .emojimix 😍+🔥');
        const [a, b] = parts;
        await react?.('⏳').catch?.(() => {});
        try {
            const url = `https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuZQYF_7vvblLxkloO_a2IgBKbR4&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(a)}_${encodeURIComponent(b)}`;
            // fallback API
            const api = `https://api.lolhuman.xyz/api/emojimix/${encodeURIComponent(a)}${encodeURIComponent(b)}?apikey=GataDios`;
            let res = await fetch(api);
            if (!res.ok) {
                res = await fetch(`https://api.dreaded.site/api/maker/emojimix?emoji1=${encodeURIComponent(a)}&emoji2=${encodeURIComponent(b)}`);
            }
            if (!res.ok) throw new Error('تعذر الدمج');
            const buf = Buffer.from(await res.arrayBuffer());
            await react?.('✅').catch?.(() => {});
            return sock.sendMessage((m || message).key.remoteJid, { sticker: buf }, { quoted: m || message });
        } catch (e) {
            await react?.('❌').catch?.(() => {});
            return reply('❌ فشل الدمج: جرب إيموجيز تانيين');
        }
    }
};
