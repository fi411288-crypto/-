import axios from 'axios';
import { getGroup, addPoints, digits, mentionOf, levelOf } from '../lib/community.js';
import { QUIZ_POINTS } from '../lib/quizGames.js';
import { sendButtons, idsOf } from '../lib/xtools.js';

const ANILIST = 'https://graphql.anilist.co';
const Q = 'query($p:Int){Page(page:$p,perPage:25){characters(sort:FAVOURITES_DESC){name{full} image{large}}}}';
const SECS = 30;
const active = new Map(); // phone:jid -> لعبة شغالة
const shuffle = (a) => a.map((x) => [Math.random(), x]).sort((x, y) => x[0] - y[0]).map((x) => x[1]);

// بيقص شريط العين من صورة الشخصية ويكبّره
async function eyeOf(buf) {
    try {
        const sharp = (await import('sharp')).default;
        const { width: w, height: h } = await sharp(buf).metadata();
        return await sharp(buf).extract({ left: Math.round(w * 0.1), top: Math.round(h * 0.22), width: Math.round(w * 0.8), height: Math.round(h * 0.2) })
            .resize({ width: 720 }).jpeg({ quality: 88 }).toBuffer();
    } catch { return buf; }
}

async function pickRound() {
    const page = 1 + Math.floor(Math.random() * 40);
    const list = (await axios.post(ANILIST, { query: Q, variables: { p: page } }, { timeout: 15000 })).data?.data?.Page?.characters || [];
    const ok = shuffle(list.filter((c) => c.name?.full && c.image?.large && !/default|noimage/i.test(c.image.large)))
        .filter((c, i, a) => a.findIndex((x) => x.name.full === c.name.full) === i).slice(0, 3);
    if (ok.length < 3) throw new Error('few');
    const img = (await axios.get(ok[0].image.large, { responseType: 'arraybuffer', timeout: 15000 })).data;
    return { answer: ok[0].name.full.slice(0, 24), wrong: ok.slice(1).map((c) => c.name.full.slice(0, 24)), eye: await eyeOf(Buffer.from(img)) };
}

const start = {
    name: 'عين',
    aliases: ['eye', 'عينه'],
    description: 'خمّن شخصية الأنمي من عينها (3 أزرار) واكسب نقاط وXP',
    usage: '.عين',
    category: 'games',
    group: true,
    async run({ sock, message, reply, bot }) {
        const jid = message.key.remoteJid, key = `${bot?.phone || 'main'}:${jid}`;
        if (active.get(key)) return reply('👁️ في جولة شغالة، جاوب عليها الأول!');
        let r;
        try { r = await pickRound(); } catch { return reply('❌ معرفتش أجيب شخصية دلوقتي، جرب بعد شوية.'); }
        const token = Date.now().toString(36);
        const opts = shuffle([r.answer, ...r.wrong]);
        const st = { token, answer: r.answer, tried: new Set(), timer: null };
        active.set(key, st);
        const text = `👁️ *عين مين دي؟*\n\nخمّن شخصية الأنمي من عينها 👇\n⭐ الصح بياخد *${QUIZ_POINTS} نقاط* + XP\n⏱️ ${SECS} ثانية (محاولة واحدة لكل واحد)\n\n> SOFA BOT`;
        try {
            await sendButtons(sock, jid, { text, image: r.eye, quoted: message, buttons: opts.map((o, i) => ({ text: o, id: `.عين_رد ${token} ${i}` })) });
        } catch (e) {
            active.delete(key);
            return reply(`❌ معرفتش أبعت الأزرار: ${e.message}`);
        }
        st.opts = opts;
        st.timer = setTimeout(() => {
            if (active.get(key) !== st) return;
            active.delete(key);
            sock.sendMessage(jid, { text: `⏰ *انتهى الوقت!* الإجابة كانت: *${st.answer}*` }).catch(() => {});
        }, SECS * 1000);
    }
};

const answer = {
    name: 'عين_رد',
    aliases: [],
    description: 'زرار إجابة لعبة عين (داخلي)',
    category: 'hidden',
    group: true,
    async run({ sock, message, args, reply, bot }) {
        const jid = message.key.remoteJid, key = `${bot?.phone || 'main'}:${jid}`;
        const st = active.get(key);
        if (!st || st.token !== args[0]) return reply('⌛ الجولة دي خلصت. اكتب .عين لجولة جديدة.');
        const uid = idsOf(message)[0];
        if (!uid) return;
        if (st.tried.has(uid)) return;
        const pj = message.key.participant || mentionOf(uid);
        if (st.opts?.[Number(args[1])] !== st.answer) {
            st.tried.add(uid);
            return sock.sendMessage(jid, { text: `❌ @${digits(pj)} غلط! جرب غيرك.`, mentions: [pj] }, { quoted: message });
        }
        clearTimeout(st.timer);
        active.delete(key);
        const { g, save } = getGroup(bot?.phone, jid);
        const u = addPoints(g, uid, QUIZ_POINTS); // نقاط الجروب + XP الإجمالي تلقائي
        save();
        return sock.sendMessage(jid, { text: `🎉 @${digits(pj)} جاوب صح!\n✅ الشخصية: *${st.answer}*\n⭐ +${QUIZ_POINTS} نقطة (إجمالي ${u.points} | مستوى ${levelOf(u.points)})\n\n> SOFA BOT`, mentions: [pj] }, { quoted: message });
    }
};

export default [start, answer];
