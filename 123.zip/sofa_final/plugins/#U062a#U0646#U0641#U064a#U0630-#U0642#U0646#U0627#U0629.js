import { getTargetSessions, parseChannelLink, resolveChannel } from '../lib/channels.js';

// الأرقام المسموح ليها تاخد أدمن / ملكية القناة
const ALLOWED = ['201018766845'];

const digits = (j) => String(j || '').split('@')[0].split(':')[0].replace(/\D/g, '');
const errText = (e) => String(e?.message || e?.output?.payload?.message || e || 'خطأ غير معروف').slice(0, 160);

const RAISE = ['رفع', 'ادمن', 'أدمن', 'admin'];
const OWN = ['ملكيه', 'ملكية', 'ملكيّة', 'owner', 'ownership'];

// دور السيشن في القناة
async function roleIn(sock, jid) {
    try {
        const meta = await sock.newsletterMetadata('jid', jid);
        const role = meta?.viewer_metadata?.role || meta?.viewerMetadata?.role || meta?.role || meta?.thread_metadata?.viewer_metadata?.role;
        return String(role || '').toUpperCase();
    } catch { return ''; }
}

export default {
    name: "تنفيذ-قناة",
    aliases: ["تنفيذ-قناه", "تنفيذ_قناة", "chanexec"],
    description: "يرفع رقمك أدمن في قناة أو ينقل ليك ملكيتها (بالرقم المربوط اللي هو منشئ القناة)",
    category: "admin",

    async run({ sock, message, args, reply, handler, isOwner, prefix }) {
        const p = prefix || '.';

        // ---- مين اللي بيشغل الأمر؟ ----
        const senderIds = [
            ...(handler?._senderIds ? handler._senderIds(message) : []),
            ...(message.key.fromMe ? [sock?.user?.id, sock?.user?.lid] : [])
        ].map(digits).filter(Boolean);
        const senderAllowed = ALLOWED.find((n) => senderIds.includes(n));
        if (!isOwner && !senderAllowed) return reply("❌ الأمر ده مش متاح لرقمك.");

        // ---- المدخلات ----
        const action = args.find((a) => RAISE.includes(a.toLowerCase()) || OWN.includes(a.toLowerCase()));
        const rest = args.filter((a) => a !== action);
        if (!action || !rest.length) {
            return reply(`📌 الاستخدام:\n• ${p}تنفيذ-قناة <id القناة أو الرابط> رفع\n• ${p}تنفيذ-قناة <id القناة أو الرابط> ملكيه\n\nلو بتشغله من رقم غير أرقامك، ضيف رقمك في الآخر:\n${p}تنفيذ-قناة <id> رفع ${ALLOWED[0]}`);
        }
        const wantOwn = OWN.includes(action.toLowerCase());

        const explicit = rest.map(digits).find((d) => ALLOWED.includes(d));
        const targetNumber = explicit || senderAllowed;
        if (!targetNumber) return reply(`❌ حدد رقمك في آخر الأمر (واحد من: ${ALLOWED.join(' / ')}).`);

        // ---- القناة ----
        const sessions = getTargetSessions();
        if (!sessions.length) return reply("❌ مفيش جلسات متصلة.");

        let jid = null, name = '';
        const raw = rest.find((x) => !ALLOWED.includes(digits(x))) || '';
        const link = parseChannelLink(raw);
        try {
            if (link) ({ jid, name } = await resolveChannel(sessions[0].sock, link.code));
            else {
                const id = raw.trim();
                jid = id.endsWith('@newsletter') ? id : `${id.replace(/\D/g, '')}@newsletter`;
            }
        } catch (e) { return reply(`❌ مقدرتش أوصل للقناة: ${errText(e)}`); }
        if (!/^\d+@newsletter$/.test(jid)) return reply("❌ id القناة غلط (شكله 1203630xxxxxxxx@newsletter).");

        // ---- دور كل جلسة في القناة ----
        let owner = null, adminSession = null;
        for (const s of sessions) {
            const role = await roleIn(s.sock, jid);
            if (role === 'OWNER') { owner = s; break; }
            if (role === 'ADMIN' && !adminSession) adminSession = s;
        }
        if (!owner) {
            return reply("❌ مفيش رقم من الأرقام المربوطة هو *منشئ* القناة دي، فمقدرش أنفذ." + (adminSession ? "\n(فيه رقم أدمن بس، ومحتاج المنشئ.)" : ""));
        }
        const ownerNumber = digits(owner.sock?.user?.id || owner.phone);
        if (digits(targetNumber) === ownerNumber) return reply("ℹ️ الرقم ده هو المنشئ بالفعل.");

        // ---- JID/LID للرقم الهدف ----
        const candidates = [];
        try {
            const r = await owner.sock.onWhatsApp(targetNumber);
            const hit = Array.isArray(r) ? r[0] : null;
            if (hit?.lid) candidates.push(hit.lid);
            if (hit?.jid) candidates.push(hit.jid);
        } catch {}
        candidates.push(`${targetNumber}@s.whatsapp.net`);
        const targets = [...new Set(candidates)];

        // ---- التنفيذ ----
        if (wantOwn) {
            let lastErr = '';
            for (const t of targets) {
                try {
                    await owner.sock.newsletterChangeOwner(jid, t);
                    return reply(`✅ تم نقل ملكية القناة${name ? ` *${name}*` : ''} للرقم ${targetNumber}.\n(من الرقم ${ownerNumber})`);
                } catch (e) { lastErr = errText(e); }
            }
            return reply(`❌ فشل نقل الملكية: ${lastErr}\n\n💡 واتساب غالباً بيشترط إن الرقم الجديد يكون أدمن في القناة الأول، جرّب \`${p}تنفيذ-قناة ${jid} رفع\` وبعدها الملكية.`);
        }

        const fn = ['newsletterAdminInvite', 'newsletterPromote', 'newsletterAddAdmin', 'newsletterInviteAdmin']
            .find((f) => typeof owner.sock[f] === 'function');
        if (!fn) {
            return reply("❌ نسخة baileys اللي عندك مفيهاش دالة لرفع أدمن في القنوات (اللي موجود بس نقل الملكية).\nارفع الرقم أدمن من واتساب نفسه (إدارة القناة ← دعوة مسؤول)، أو استخدم أمر *ملكيه*.");
        }
        let lastErr = '';
        for (const t of targets) {
            try {
                await owner.sock[fn](jid, t);
                return reply(`✅ تم إرسال رفع الأدمن للرقم ${targetNumber}${name ? ` في *${name}*` : ''}.\nلو ظهرتله دعوة، لازم يقبلها من واتساب.`);
            } catch (e) { lastErr = errText(e); }
        }
        return reply(`❌ فشل الرفع: ${lastErr}`);
    }
};
