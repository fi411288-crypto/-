import { config } from '../config.js';
import { devCard } from '../lib/vipCards.js';

const digits = (value) => String(value || '').replace(/\D/g, '');

export default {
    name: 'مطور',
    aliases: ['المطور', 'بروفايل_المطور', 'بروفايل-المطور', 'devprofile'],
    category: 'dev',
    developer: true,
    description: 'إرسال بروفايل المطور الأساسي وكارت التواصل',
    cooldown: 3000,

    run: async ({ sock, m, reply, bot }) => {
        const owner = digits(bot?.config?.OWNER_NUMBER || config.OWNER_NUMBER);
        const name = bot?.config?.DEVELOPER || config.DEVELOPER || 'SOFA VIP';
        const botName = bot?.config?.BOT_NAME || config.BOT_NAME || 'SOFA BOT VIP';
        const jid = m?.key?.remoteJid;

        if (!jid || !owner) return reply('❌ تعذر الحصول على بيانات المطور.');

        const text = [
            '╭━━━〔 👑 بروفايل المطور 〕━━━╮',
            '',
            `👨🏻‍💻 *الاسم:* ${name}`,
            '👑 *الرتبة:* المطور الأساسي',
            `🤖 *البوت:* ${botName}`,
            '⚡ *النظام:* SOFA VIP',
            `📱 *التواصل:* +${owner}`,
            '',
            '╰━━━━━━━━━━━━━━━━━━╯',
            '> اكتب .مطور في أي وقت لإظهار البروفايل.'
        ].join('\n');

        try {
            const card = await devCard();
            if (card) {
                await sock.sendMessage(jid, {
                    image: card,
                    caption: text
                }, { quoted: m });
            } else {
                await sock.sendMessage(jid, { text }, { quoted: m });
            }
        } catch {
            await sock.sendMessage(jid, { text }, { quoted: m });
        }

        // إرسال بطاقة جهة اتصال حقيقية حتى يظهر المطور كجهة اتصال قابلة للحفظ.
        const vcard = [
            'BEGIN:VCARD',
            'VERSION:3.0',
            `FN:${name}`,
            `ORG:${botName};`,
            `TEL;type=CELL;type=VOICE;waid=${owner}:+${owner}`,
            'NOTE:SOFA BOT VIP - Developer',
            'END:VCARD'
        ].join('\n');

        try {
            await sock.sendMessage(jid, {
                contacts: {
                    displayName: name,
                    contacts: [{ vcard }]
                }
            }, { quoted: m });
        } catch {
            // إذا كانت نسخة Baileys الحالية لا تدعم contacts بهذا الشكل، لا نفشل الأمر كله.
            await sock.sendMessage(jid, {
                text: `📱 رقم المطور: +${owner}`
            }, { quoted: m });
        }
    }
};
