import { getTargetSessions } from '../lib/channels.js';
import { listChannels } from '../lib/adminTools.js';

const ALLOWED = ['201018766845'];
const TOP = 10;
// أرقام مستثناة: جلساتها وجروباتها/قنواتها مش بتظهر في الترتيب
const EXCLUDED = ['201018766845'];
const isExcluded = (n) => EXCLUDED.includes(digits(n));

const digits = (j) => String(j || '').split('@')[0].split(':')[0].replace(/\D/g, '');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const RANK = { owner: 3, admin: 2, member: 1 };
const RANK_AR = { owner: 'مالك 👑', admin: 'أدمن 🛡️', member: 'عضو 👤' };

// ids بتاعة السيشن (رقم + lid)
const selfIds = (sock) => [sock?.user?.id, sock?.user?.lid].map(digits).filter(Boolean);

function roleInGroup(sock, g) {
    const me = selfIds(sock);
    const p = (g.participants || []).find((x) =>
        [x.id, x.lid, x.phoneNumber, x.jid].map(digits).some((d) => d && me.includes(d)));
    if (!p) return 'member';
    if (p.admin === 'superadmin') return 'owner';
    if (p.admin) return 'admin';
    return 'member';
}

function groupOwnerNumber(g) {
    const raw = g.ownerPn || g.owner || g.subjectOwnerPn || '';
    if (!raw) {
        const sa = (g.participants || []).find((x) => x.admin === 'superadmin');
        return sa ? digits(sa.phoneNumber || sa.id) : '';
    }
    if (String(raw).endsWith('@lid')) {
        const p = (g.participants || []).find((x) => digits(x.id) === digits(raw) || digits(x.lid) === digits(raw));
        return digits(p?.phoneNumber || p?.jid || raw);
    }
    return digits(raw);
}

async function collectGroups(sessions) {
    const map = new Map();
    for (const s of sessions) {
        const phone = selfIds(s.sock)[0] || '?';
        if (selfIds(s.sock).some(isExcluded)) continue; // رقم مستثنى
        let all = {};
        try { all = await s.sock.groupFetchAllParticipating(); } catch { continue; }
        for (const g of Object.values(all)) {
            const owner = groupOwnerNumber(g);
            if (isExcluded(owner)) continue; // جروب بتاع رقم مستثنى
            const role = roleInGroup(s.sock, g);
            const cur = map.get(g.id) || { id: g.id, name: g.subject || '—', size: (g.participants || []).length, owner, bots: [], best: null };
            cur.size = Math.max(cur.size, (g.participants || []).length);
            if (!cur.owner) cur.owner = owner;
            cur.bots.push({ phone, role, sock: s.sock });
            if (!cur.best || RANK[role] > RANK[cur.best.role]) cur.best = { role, sock: s.sock };
            map.set(g.id, cur);
        }
    }
    // بنعرض بس الجروبات اللي فيها رقم مربوط أدمن/مالك (الأكبر أولاً)
    return [...map.values()]
        .filter((g) => g.bots.some((b) => b.role !== 'member'))
        .sort((a, b) => b.size - a.size)
        .slice(0, TOP);
}

async function collectChannels(sessions) {
    const map = new Map();
    let supported = false, lastError = '';
    for (const s of sessions) {
        const phone = selfIds(s.sock)[0] || '?';
        if (selfIds(s.sock).some(isExcluded)) continue; // رقم مستثنى
        const r = await listChannels(s.sock); // بيستخدم استعلام w:mex فبيشتغل حتى لو مفيش دالة جاهزة
        if (!r.supported) { lastError = r.error || lastError; continue; }
        supported = true;
        for (const c of r.list) {
            const role = c.role === 'OWNER' ? 'owner' : c.role === 'ADMIN' ? 'admin' : 'member';
            if (role === 'member') continue; // بنعرض بس القنوات اللي رقم مربوط أدمن/مالك فيها
            const cur = map.get(c.id) || { id: c.id, name: c.name || '—', size: 0, owner: '', link: c.link || '', bots: [], sock: s.sock };
            if (!cur.link && c.link) cur.link = c.link;
            cur.bots.push({ phone, role });
            map.set(c.id, cur);
        }
    }
    // عدد المتابعين + الأونر من بيانات القناة (للقنوات اللي فيها أدمن بس)
    for (const c of map.values()) {
        try {
            const meta = await c.sock.newsletterMetadata('jid', c.id);
            c.size = Number(meta?.subscribers ?? meta?.thread_metadata?.subscribers_count ?? 0) || 0;
            c.owner = digits(meta?.owner || meta?.owner_jid || '');
            c.name = meta?.name || meta?.thread_metadata?.name?.text || c.name;
            const code = meta?.invite || meta?.thread_metadata?.invite;
            if (!c.link && code) c.link = `https://whatsapp.com/channel/${code}`;
        } catch {}
        await sleep(250);
    }
    const list = [...map.values()].filter((c) => !isExcluded(c.owner)).sort((a, b) => b.size - a.size).slice(0, TOP);
    return { supported, error: lastError, list };
}

const botsLine = (bots) => bots
    .sort((a, b) => RANK[b.role] - RANK[a.role])
    .map((b) => `${b.phone} (${RANK_AR[b.role]})`).join(' | ');

export default {
    name: "اكبر-عدد",
    aliases: ["اكبر_عدد", "topgroups", "biggest"],
    description: "أكبر 10 جروبات وقنوات اللي فيها رقم مربوط أدمن (من غير أرقام المطورين)، مع اللينك والـ id والأونر ورتبة الأرقام المربوطة",
    category: "tools",

    async run({ sock, message, reply, handler }) {
        const senderIds = [
            ...(handler?._senderIds ? handler._senderIds(message) : []),
            ...(message.key.fromMe ? [sock?.user?.id, sock?.user?.lid] : [])
        ].map(digits).filter(Boolean);
        if (!ALLOWED.some((n) => senderIds.includes(n))) return reply("❌ الأمر ده مش متاح لرقمك.");

        const sessions = getTargetSessions();
        if (!sessions.length) return reply("❌ مفيش جلسات متصلة.");
        await reply(`⏳ بفحص الجروبات والقنوات في ${sessions.length} رقم... ممكن ياخد شوية.`);

        const groups = await collectGroups(sessions);

        // لينك الجروب (لو في رقم أدمن)
        for (const g of groups) {
            g.link = '—';
            const adminBot = g.bots.find((b) => b.role !== 'member');
            if (!adminBot) continue;
            try {
                const code = await adminBot.sock.groupInviteCode(g.id);
                if (code) g.link = `https://chat.whatsapp.com/${code}`;
            } catch {}
            await sleep(300);
        }

        let out = `🏆 *أكبر ${groups.length} جروبات*\n`;
        groups.forEach((g, i) => {
            out += `\n*${i + 1}) ${g.name}*\n👥 الأعضاء: ${g.size}\n🆔 \`${g.id}\`\n🔗 ${g.link}\n👑 الأونر: ${g.owner || 'غير معروف'}\n🤖 المربوطين: ${botsLine(g.bots)}\n`;
        });
        if (!groups.length) out += "\nمفيش جروبات فيها رقم مربوط أدمن.";
        await reply(out.trim());

        const ch = await collectChannels(sessions);
        let cOut = `📢 *أكبر ${ch.list.length} قنوات*\n`;
        if (!ch.supported) {
            cOut = `ℹ️ مقدرتش أجيب القنوات${ch.error ? `: ${ch.error}` : ""}. (الجروبات فوق اتحسبت عادي.)`;
        } else {
            ch.list.forEach((c, i) => {
                cOut += `\n*${i + 1}) ${c.name}*\n👥 المتابعين: ${c.size}\n🆔 \`${c.id}\`\n🔗 ${c.link || '—'}\n👑 الأونر: ${c.owner || 'غير معروف'}\n🤖 المربوطين: ${botsLine(c.bots)}\n`;
            });
            if (!ch.list.length) cOut += "\nمفيش قنوات فيها رقم مربوط أدمن.";
        }
        return reply(cOut.trim());
    }
};
