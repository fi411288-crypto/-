import axios from 'axios';

const API = 'https://api.jikan.moe/v4';
const CACHE_TTL = 6 * 60 * 60 * 1000;
const SEARCH_TTL = 15 * 60 * 1000;

const cache = new Map();
let seasonCache = { at: 0, data: null };

function clean(value = '') {
    return String(value).replace(/[<>]/g, '').trim();
}

function pickTitle(a) {
    return a?.title || a?.title_english || a?.title_japanese || 'بدون اسم';
}

function short(text, max = 420) {
    const s = clean(text || 'لا يوجد وصف متاح.').replace(/\s+/g, ' ');
    return s.length > max ? s.slice(0, max - 1) + '…' : s;
}

function score(v) {
    return v == null ? 'غير متاح' : Number(v).toFixed(2);
}

function formatAnime(a, i = 0) {
    const title = pickTitle(a);
    const type = a.type || 'غير محدد';
    const eps = a.episodes ?? '?';
    const status = a.status || 'غير محدد';
    const scoreText = score(a.score);
    return `${i ? `${i}. ` : ''}🎬 *${title}*\n` +
        `   🎭 ${type} | 📺 الحلقات: ${eps} | ⭐ ${scoreText}\n` +
        `   📌 ${status}`;
}

async function get(url, params = {}) {
    const res = await axios.get(`${API}${url}`, {
        params,
        timeout: 15000,
        headers: { 'User-Agent': 'SOFA-BOT Anime Center/1.0' }
    });
    return res.data;
}

async function searchAnime(query) {
    const key = `search:${query.toLowerCase()}`;
    const old = cache.get(key);
    if (old && Date.now() - old.at < SEARCH_TTL) return old.data;
    const data = await get('/anime', { q: query, limit: 8, sfw: true, order_by: 'score', sort: 'desc' });
    cache.set(key, { at: Date.now(), data: data?.data || [] });
    return data?.data || [];
}

async function getAnime(id) {
    const key = `anime:${id}`;
    const old = cache.get(key);
    if (old && Date.now() - old.at < CACHE_TTL) return old.data;
    const data = await get(`/anime/${id}/full`);
    cache.set(key, { at: Date.now(), data: data?.data || null });
    return data?.data || null;
}

async function getAnimeCharacters(id) {
    const data = await get(`/anime/${id}/characters`);
    return Array.isArray(data?.data) ? data.data : [];
}

async function getSeason() {
    if (seasonCache.data && Date.now() - seasonCache.at < CACHE_TTL) return seasonCache.data;
    const data = await get('/seasons/now', { limit: 24, sfw: true });
    seasonCache = { at: Date.now(), data: data?.data || [] };
    return seasonCache.data;
}

async function getUpcoming() {
    const data = await get('/seasons/upcoming', { limit: 20, sfw: true });
    return data?.data || [];
}

function streamingLinks(a) {
    const links = Array.isArray(a?.streaming) ? a.streaming : [];
    const unique = [];
    const seen = new Set();
    for (const x of links) {
        if (!x?.url || seen.has(x.url)) continue;
        seen.add(x.url);
        unique.push({ name: x.name || 'مشاهدة', url: x.url });
    }
    return unique.slice(0, 5);
}

function watchBlock(a) {
    const links = streamingLinks(a);
    if (!links.length) {
        return '📺 *المشاهدة:* لا يوجد رابط مشاهدة رسمي متاح في بيانات المصدر حاليًا.\n' +
               'ℹ️ استخدم صفحة المعلومات للعثور على المنصة الرسمية المتاحة في بلدك.';
    }
    return '📺 *روابط المشاهدة الرسمية المتاحة:*\n' +
        links.map((x, i) => `${i + 1}. ${x.name}: ${x.url}`).join('\n');
}

function help() {
    return `╭━━━〔 🎌 مركز الأنمي 〕━━━╮
│ .انمي <اسم>
│ 🔎 البحث عن أنمي ومعلوماته وروابط المشاهدة الرسمية إن توفرت.
│
│ .انمي_الموسم
│ 📅 أنميات الموسم الحالي.
│
│ .انمي_قادم
│ 🚀 الأعمال القادمة.
│
│ .تحديثات_الانمي
│ 🆕 تحديث البيانات من المصدر.
│
│ .انمي_معلومات <ID>
│ 📚 معلومات تفصيلية عن أنمي محدد.
│
│ .شخصيات_انمي <اسم أو ID>
│ 🎭 صور وأسماء شخصيات الأنمي.
╰━━━━━━━━━━━━━━━━━━━━╯
⚡ يتم تحديث البيانات تلقائيًا كل 6 ساعات.`;
}

const plugin = {
    name: 'anime_center',
    category: 'anime',
    description: 'مركز أنمي للبحث والمواسم والتحديثات وروابط المشاهدة الرسمية',
    commands: [
        {
            name: 'انمي',
            aliases: ['anime', 'انمي_بحث', 'بحث_انمي'],
            category: 'anime',
            cooldown: 4000,
            description: 'البحث عن الأنمي',
            run: async ({ text, args, reply }) => {
                const q = clean(text || args?.join(' ') || '');
                if (!q) return reply(help());
                try {
                    const results = await searchAnime(q);
                    if (!results.length) return reply('❌ لم أجد أنمي بهذا الاسم.');
                    const lines = results.map((a, i) => formatAnime(a, i + 1));
                    return reply(`╭━━━〔 🔎 نتائج الأنمي 〕━━━╮\n${lines.join('\n\n')}\n╰━━━━━━━━━━━━━━━━━━━━╯\n\n💡 للحصول على التفاصيل: .انمي_معلومات <ID>\n🆔 IDs: ${results.map(a => a.mal_id).join('، ')}`);
                } catch (e) {
                    return reply(`❌ تعذر جلب بيانات الأنمي الآن.\n${e?.response?.status ? `HTTP ${e.response.status}` : 'تحقق من اتصال الإنترنت.'}`);
                }
            }
        },
        {
            name: 'انمي_معلومات',
            aliases: ['animeinfo', 'معلومات_انمي'],
            category: 'anime',
            cooldown: 5000,
            description: 'معلومات كاملة وروابط مشاهدة رسمية',
            run: async ({ text, args, reply }) => {
                const id = Number(clean(text || args?.[0] || ''));
                if (!Number.isInteger(id) || id < 1) return reply('❌ الاستخدام: .انمي_معلومات <ID>');
                try {
                    const a = await getAnime(id);
                    if (!a) return reply('❌ الأنمي غير موجود.');
                    const title = pickTitle(a);
                    const genres = (a.genres || []).map(x => x.name).join('، ') || 'غير متاح';
                    const studios = (a.studios || []).map(x => x.name).join('، ') || 'غير متاح';
                    const body = `╭━━━〔 🎌 ${title} 〕━━━╮
│ 🆔 ID: ${a.mal_id}
│ ⭐ التقييم: ${score(a.score)}
│ 📺 الحلقات: ${a.episodes ?? '?'}
│ 🎞️ النوع: ${a.type || 'غير متاح'}
│ 📌 الحالة: ${a.status || 'غير متاح'}
│ 🗓️ البداية: ${a.aired?.from ? new Date(a.aired.from).toLocaleDateString('ar-EG') : 'غير متاح'}
│ 🏷️ التصنيف: ${genres}
│ 🏢 الاستوديو: ${studios}
│
│ 📝 ${short(a.synopsis)}
╰━━━━━━━━━━━━━━━━━━━━╯

${watchBlock(a)}

🔗 صفحة المعلومات: ${a.url || 'غير متاح'}`;
                    return reply(body);
                } catch (e) {
                    return reply('❌ تعذر جلب التفاصيل الآن، حاول مرة أخرى بعد قليل.');
                }
            }
        },
        {
            name: 'شخصيات_انمي',
            aliases: ['شخصيات', 'animecharacters', 'انمي_شخصيات'],
            category: 'anime',
            cooldown: 6000,
            description: 'عرض صور وأسماء شخصيات أنمي محدد',
            run: async ({ sock, m, text, args, reply }) => {
                const query = clean(text || args?.join(' ') || '');
                if (!query) return reply('🎌 الاستخدام: .شخصيات_انمي <اسم الأنمي أو ID>\\nمثال: .شخصيات_انمي Naruto');
                try {
                    let animeId = Number(query);
                    let animeTitle = query;
                    if (!Number.isInteger(animeId) || animeId < 1) {
                        const found = await searchAnime(query);
                        if (!found.length) return reply('❌ لم أجد الأنمي بهذا الاسم.');
                        animeId = found[0].mal_id;
                        animeTitle = pickTitle(found[0]);
                    } else {
                        const info = await getAnime(animeId);
                        if (!info) return reply('❌ رقم الأنمي غير موجود.');
                        animeTitle = pickTitle(info);
                    }

                    const characters = await getAnimeCharacters(animeId);
                    if (!characters.length) return reply('❌ لا توجد شخصيات متاحة لهذا الأنمي حالياً.');
                    await reply(`🎌 *شخصيات ${animeTitle}*\\nسيتم إرسال أول ${Math.min(6, characters.length)} شخصيات بالصور.`);
                    let sent = 0;
                    for (const item of characters.slice(0, 6)) {
                        const character = item?.character;
                        const imageUrl = character?.images?.jpg?.image_url || character?.images?.webp?.image_url;
                        if (!imageUrl) continue;
                        try {
                            const image = await axios.get(imageUrl, { responseType: 'arraybuffer', timeout: 12000 });
                            const caption = `🎭 *${clean(character.name || 'شخصية بدون اسم')}*\\n⭐ الدور: ${clean(item.role || 'غير محدد')}\\n🔗 ${character.url || ''}`;
                            await sock.sendMessage(m.key.remoteJid, { image: Buffer.from(image.data), caption }, { quoted: m });
                            sent++;
                        } catch {}
                    }
                    if (!sent) return reply('❌ تعذر تحميل صور الشخصيات حالياً. حاول مرة أخرى لاحقاً.');
                } catch (e) {
                    console.error('[anime characters]', e?.message || e);
                    return reply('❌ تعذر جلب شخصيات الأنمي الآن. حاول مرة أخرى بعد قليل.');
                }
            }
        },
        {
            name: 'انمي_الموسم',
            aliases: ['الموسم_الانمي', 'seasonanime', 'انمي_جديد'],
            category: 'anime',
            cooldown: 5000,
            description: 'أنميات الموسم الحالي',
            run: async ({ reply }) => {
                try {
                    const list = await getSeason();
                    if (!list.length) return reply('❌ لا توجد بيانات للموسم حاليًا.');
                    const lines = list.slice(0, 20).map((a, i) => formatAnime(a, i + 1));
                    return reply(`╭━━━〔 📅 أنمي الموسم 〕━━━╮\n${lines.join('\n\n')}\n╰━━━━━━━━━━━━━━━━━━━━╯\n\n🆔 استخدم ID مع .انمي_معلومات للحصول على روابط المشاهدة الرسمية إن توفرت.\n♻️ آخر تحديث للبيانات: ${new Date(seasonCache.at).toLocaleString('ar-EG')}`);
                } catch (e) {
                    return reply('❌ تعذر تحديث قائمة الموسم الآن.');
                }
            }
        },
        {
            name: 'انمي_قادم',
            aliases: ['انمي_القادم', 'upcominganime'],
            category: 'anime',
            cooldown: 5000,
            description: 'الأعمال القادمة',
            run: async ({ reply }) => {
                try {
                    const list = await getUpcoming();
                    const lines = list.slice(0, 18).map((a, i) => formatAnime(a, i + 1));
                    return reply(`╭━━━〔 🚀 أنمي قادم 〕━━━╮\n${lines.join('\n\n')}\n╰━━━━━━━━━━━━━━━━━━━━╯`);
                } catch {
                    return reply('❌ تعذر جلب الأعمال القادمة الآن.');
                }
            }
        },
        {
            name: 'تحديثات_الانمي',
            aliases: ['تحديث_الانمي', 'animeupdates'],
            category: 'anime',
            cooldown: 3000,
            description: 'تحديث ذاكرة مركز الأنمي',
            run: async ({ reply }) => {
                try {
                    seasonCache = { at: 0, data: null };
                    cache.clear();
                    const list = await getSeason();
                    return reply(`✅ تم تحديث مركز الأنمي بنجاح.\n📚 تم تحميل ${list.length} عملًا من الموسم الحالي.\n🕐 ${new Date(seasonCache.at).toLocaleString('ar-EG')}`);
                } catch {
                    return reply('❌ فشل التحديث. تحقق من اتصال الإنترنت وحاول لاحقًا.');
                }
            }
        },
        {
            name: 'قسم_الانمي',
            aliases: ['الانمي', 'animehelp'],
            category: 'anime',
            description: 'قائمة أوامر مركز الأنمي',
            run: async ({ reply }) => reply(help())
        }
    ],
    onLoad: async () => {
        // تحديث ذاكرة الموسم تلقائيًا كل 6 ساعات، بدون إزعاج المجموعات برسائل تلقائية.
        try { await getSeason(); } catch {}
        setInterval(async () => {
            try { await getSeason(); } catch {}
        }, CACHE_TTL);
    }
};

export default plugin;
