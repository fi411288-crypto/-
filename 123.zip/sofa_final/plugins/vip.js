import { isVip, addVip, removeVip, listVips, vipStatus } from '../lib/vip.js';

const box = (title, lines) =>
    `╭─❏ 「 ${title} 」\n│\n${lines.map((l) => `│ ${l}`).join('\n')}\n╰───────────────\n> © 𝐒𝐎𝐅𝐀 𝐕𝐈𝐏`;

export default {
    name: 'vip',
    aliases: ['في اي بي', 'عضوية', 'premium', 'فيب'],
    description: '👑 نظام VIP — عرض الحالة / إدارة الأعضاء',
    category: 'vip',
    usage: '.vip | .vip add <رقم> [أيام] | .vip del <رقم> | .vip list',

    async run({ sock, m, message, text, reply, react, handler, prefix, isOwner, isDeveloper }) {
        const msg = m || message;
        const args = (text || '').trim().split(/\s+/).filter(Boolean);
        const sub = (args[0] || '').toLowerCase();

        const senderRaw = msg?.key?.participant || msg?.key?.participantPn || msg?.key?.remoteJid || '';
        const sender = String(senderRaw).split('@')[0].split(':')[0].replace(/\D/g, '');

        const ownerOk = !!(isOwner || isDeveloper || handler?.isOwnerNumber?.(sender) || handler?.isDeveloper?.(sender));

        const doReply = async (t) => {
            if (typeof reply === 'function') return reply(t);
            return sock.sendMessage(msg.key.remoteJid, { text: t }, { quoted: msg });
        };

        // بدون أوامر فرعية = عرض حالة المستخدم
        if (!sub || sub === 'status' || sub === 'حالة' || sub === 'me') {
            const st = vipStatus(sender);
            if (st.isVip) {
                const left = st.permanent ? 'مدى الحياة ∞' : `${st.daysLeft} يوم`;
                return doReply(box('👑 VIP STATUS', [
                    'أنت *VIP* ✨',
                    '',
                    `📅 المدة المتبقية: ${left}`,
                    '🔓 عندك صلاحية الأوامر الحصرية',
                    '',
                    'الأوامر الخاصة:',
                    '• .warmgpt  — ذكاء دافئ',
                    '• .زرف / .فنش / .سحب / .تصفيه',
                    '',
                    'استمتع يا ملك 👑'
                ]));
            }
            return doReply(box('💎 SOFA VIP', [
                'أنت *مش مشترك* حالياً.',
                '',
                'مميزات الـ VIP:',
                '• 🌸 WarmGPT — ذكاء دافئ وذكي',
                '• 💥 أوامر الزرف الحصرية',
                '• 🎨 كروت وتصميمات مميزة',
                '• ⚡ أولوية في الردود',
                '• 🔓 أوامر مخفية',
                '',
                'للتواصل مع المطور للاشتراك.'
            ]));
        }

        if (!ownerOk) {
            return doReply('❌ إدارة الـ VIP للمالك فقط');
        }

        if (sub === 'add' || sub === 'اضف' || sub === 'أضف' || sub === '+') {
            const num = (args[1] || '').replace(/\D/g, '');
            let days = parseInt(args[2], 10);
            const permanent = args.includes('دائم') || args.includes('permanent') || args.includes('∞') || days === 0;
            if (!num || num.length < 8) {
                return doReply(box('استخدام', [
                    `${prefix}vip add <رقم> [أيام]`,
                    `${prefix}vip add <رقم> دائم`,
                    '',
                    'مثال:',
                    `${prefix}vip add 2010xxxxxxx 30`,
                    `${prefix}vip add 2010xxxxxxx دائم`
                ]));
            }
            if (!permanent && (!days || days < 1)) days = 30;
            const r = addVip(num, { days: permanent ? 0 : days, permanent, addedBy: sender });
            if (r.ok) {
                try { await react?.('👑'); } catch {}
                return doReply(box('✅ تم الإضافة', [
                    `📱 الرقم: ${num}`,
                    `⏳ المدة: ${permanent ? 'دائم ∞' : days + ' يوم'}`,
                    '',
                    'مبروك العضوية الجديدة 👑'
                ]));
            }
            return doReply('❌ ' + (r.msg || 'فشل'));
        }

        if (sub === 'del' || sub === 'remove' || sub === 'حذف' || sub === 'شيل' || sub === '-') {
            const num = (args[1] || '').replace(/\D/g, '');
            if (!num) return doReply(`استخدام: ${prefix}vip del <رقم>`);
            const r = removeVip(num);
            return doReply(r.ok ? `✅ تم إزالة VIP من ${num}` : '❌ ' + (r.msg || 'مش موجود'));
        }

        if (sub === 'list' || sub === 'قائمة' || sub === 'ليست' || sub === 'ls') {
            const list = listVips().filter(v => v.active);
            if (!list.length) return doReply('لا يوجد أعضاء VIP حالياً');
            const lines = list.map((v, i) =>
                `${i + 1}. ${v.number} — ${v.permanent ? '∞ دائم' : (v.days || '?') + ' يوم'}`
            );
            return doReply(box(`👑 قائمة VIP (${list.length})`, lines));
        }

        if (sub === 'check' || sub === 'فحص') {
            const num = (args[1] || '').replace(/\D/g, '') || sender;
            const st = vipStatus(num);
            if (!st.isVip) return doReply(`❌ ${num} مش VIP`);
            return doReply(box('فحص VIP', [
                `📱 ${num}`,
                `✅ VIP نشط`,
                `⏳ ${st.permanent ? 'دائم ∞' : st.daysLeft + ' يوم متبقي'}`
            ]));
        }

        return doReply(box('👑 أوامر VIP', [
            `${prefix}vip — حالة عضويتك`,
            `${prefix}vip add <رقم> [أيام]`,
            `${prefix}vip add <رقم> دائم`,
            `${prefix}vip del <رقم>`,
            `${prefix}vip list`,
            `${prefix}vip check <رقم>`
        ]));
    }
};
