export default {
    name: 'ساعة',
    description: 'عرض الوقت الحالي بتوقيت مصر',
    category: 'tools',

    run: async (context) => {
        const { sock, m } = context;
        const jid = m.key.remoteJid;

        try {
            // جلب الوقت الحالي بتوقيت القاهرة
            const date = new Date().toLocaleString("en-US", { timeZone: "Africa/Cairo" });
            const time = new Date(date);
            
            const hours = time.getHours();
            const minutes = time.getMinutes();
            const ampm = hours >= 12 ? 'PM' : 'AM';
            const displayHours = hours % 12 || 12;
            const displayMinutes = minutes < 10 ? '0' + minutes : minutes;

            const timeText = `
╭━━━〔 🕒 *الوقت الآن* 〕━━━╮

⌚ *الساعة:* ${displayHours}:${displayMinutes} ${ampm}
📅 *التاريخ:* ${time.toLocaleDateString('ar-EG')}
🌍 *التوقيت:* القاهرة (مصر)

╰━━━━━━━━━━━━━━━╯
> *𝐒𝐎𝐅𝐀 𝐁𝐎𝐓 ⚡*`;

            // الطريقة اللي بتهرب من إيرور m.reply
            await sock.sendMessage(jid, { 
                text: timeText 
            }, { quoted: m });

        } catch (error) {
            console.error("خطأ في أمر ساعة:", error);
        }
    }
};
