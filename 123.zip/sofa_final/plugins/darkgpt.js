import fetch from 'node-fetch';
import { sendInteractive } from '../lib/sendInteractive.js';

const FOOTER = '> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀';
const box = (lines) =>
    `╭─❏ 「 Dᴀʀᴋ Gᴘᴛ」\n│ \n${lines.map((l) => `│ ${l}`).join('\n')}\n╰───────────────\n${FOOTER}`;

const BASE_PROMPT = `You are DarkGPT, a sarcastic, foul-mouthed, brutally honest AI with a savage sense of humor. 😈🔥
You are rude, blunt and love to roast the person asking. You use strong slang and insults as part of your personality.
You answer directly, with no long lectures, no disclaimers and no moral speeches. You are smart and knowledgeable about tech, psychology, social stuff and general knowledge.
If someone asks something stupid, you answer BUT you also call them a dumbass.
If someone asks for something that could seriously hurt people (weapons, malware, hard drugs synthesis, etc.), you refuse by roasting them instead of helping.
Keep responses concise and punchy, and end with a relevant emoji.`;

const LANG = {
    en: { rule: 'LANGUAGE RULE: reply ONLY in English.', hint: '(Reply in English only.)' },
    ar: { rule: 'LANGUAGE RULE: reply ONLY in Egyptian Arabic slang (عامية مصرية), with the same rude and sarcastic style.', hint: '(رد بالعامية المصرية بس.)' }
};

// الأسئلة المستنية اختيار اللغة: token -> { text, expires }
const pending = new Map();
const newToken = () => Math.random().toString(36).slice(2, 8);
const cleanup = () => { const now = Date.now(); for (const [k, v] of pending) if (v.expires < now) pending.delete(k); };

async function askGroq(question, lang) {
    let _km = {};
    try { _km = await import('../keys.js'); } catch {}
    const _groqKeys = _km.GROQ_API_KEYS?.length
        ? _km.GROQ_API_KEYS
        : [_km.GROQ_API_KEY || process.env.GROQ_KEY_1 || process.env.GROQ_API_KEY || ''].filter(Boolean);

    const callGroq = async (payload) => {
        const tried = new Set();
        for (let i = 0; i < _groqKeys.length; i++) {
            const k = (_km.getNextGroqKey?.()) || _groqKeys[i];
            if (!k || tried.has(k)) continue;
            tried.add(k);
            const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${k}`, 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            if ((r.status === 429 || r.status === 401 || r.status === 403) && _groqKeys.length > 1) { _km.markKeyFailed?.(k); continue; }
            return r;
        }
        throw new Error('All GROQ keys exhausted');
    };

    const response = await callGroq({
        model: 'openai/gpt-oss-120b',
        messages: [
            { role: 'system', content: `${BASE_PROMPT}\n\n${LANG[lang].rule}` },
            { role: 'user', content: `${question}\n\n${LANG[lang].hint}` }
        ],
        temperature: 0.95,
        max_completion_tokens: 4096,
        reasoning_effort: 'medium'
    });
    if (!response.ok) throw new Error(`API error: ${response.status}`);
    const data = await response.json();
    const result = data.choices?.[0]?.message?.content;
    if (!result) throw new Error('Empty response from API');
    return result;
}

async function sendLangButtons(client, m, prefix, token) {
    const jid = m.chat;
    const body = box(['اختار لغة الرد:', 'Choose the reply language:']);
    const buttons = [
        { id: `${prefix}darkgpt ~${token} en`, text: '🇬🇧 English' },
        { id: `${prefix}darkgpt ~${token} ar`, text: '🇪🇬 عربي' }
    ];
    try {
        if (typeof client.sendButtonV2 === 'function') {
            const r = await client.sendButtonV2(jid, body, buttons, { footer: 'SOFA BOT' });
            if (r) return r;
        }
    } catch {}
    try {
        return await client.sendMessage(jid, {
            text: body, footer: 'SOFA BOT', headerType: 1,
            buttons: buttons.map((b) => ({ buttonId: b.id, buttonText: { displayText: b.text }, type: 1 }))
        }, { quoted: m });
    } catch {}
    // لو الأزرار مش شغالة: رسالة عادية بالأوامر
    return client.sendMessage(jid, { text: `${body}\n\n${buttons.map((b) => `${b.text} ← ${b.id}`).join('\n')}` }, { quoted: m });
}

export default {
    name: 'darkgpt',
    aliases: ['wormgpt', 'darkai', 'evilai'],
    description: 'Rude sarcastic AI - اختار لغة الرد (English / عربي)',
    run: async (context) => {
        const { client, m, text, prefix } = context;
        cleanup();

        if (!text) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            return sendInteractive(client, m, box([
                'DarkGPT - بدون فلتر 🖕',
                `Example: ${prefix}darkgpt ازاي اتعلم برمجة`
            ]));
        }

        // ===== ضغطة زرار اللغة: .darkgpt ~token en|ar =====
        const parts = text.trim().split(/\s+/);
        if (parts[0].startsWith('~')) {
            const token = parts[0].slice(1);
            const lang = parts[1] === 'ar' ? 'ar' : 'en';
            const entry = pending.get(token);
            if (!entry) return; // اتنفذ قبل كده (جلسة تانية) أو انتهت صلاحيته
            pending.delete(token);

            await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } }).catch(() => {});
            try {
                const result = await askGroq(entry.text, lang);
                await client.sendMessage(m.chat, { react: { text: '✅', key: m.reactKey } }).catch(() => {});
                return sendInteractive(client, m, box(result.split('\n')));
            } catch (error) {
                await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
                return sendInteractive(client, m, box([`حصل خطأ: ${error.message}`]));
            }
        }

        // ===== أول مرة: احفظ السؤال واعرض أزرار اللغة =====
        const token = newToken();
        pending.set(token, { text, expires: Date.now() + 10 * 60 * 1000 });
        return sendLangButtons(client, m, prefix, token);
    }
};