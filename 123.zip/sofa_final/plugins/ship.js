export default {
    name: 'شيب',
    aliases: ['ship', 'حب', 'نسبة'],
    description: 'نسبة توافق بين شخصين',
    category: 'fun',
    usage: '.شيب @شخص1 @شخص2',

    async run({ text, reply, m, message }) {
        const msg = m || message;
        const mentions = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        let a = '', b = '';
        if (mentions.length >= 2) {
            a = '@' + mentions[0].split('@')[0];
            b = '@' + mentions[1].split('@')[0];
        } else if (mentions.length === 1) {
            a = 'أنت';
            b = '@' + mentions[0].split('@')[0];
        } else {
            const parts = (text || '').trim().split(/\s+/).filter(Boolean);
            if (parts.length >= 2) { a = parts[0]; b = parts[1]; }
            else return reply('❌ منشن شخصين أو اكتب اسمين\nمثال: .شيب محمد سارة');
        }
        const pct = Math.floor(Math.random() * 101);
        let bar = '█'.repeat(Math.round(pct / 10)) + '░'.repeat(10 - Math.round(pct / 10));
        let msgLine = pct > 80 ? 'حب قوي أوي 💘' : pct > 50 ? 'في أمل 💕' : pct > 25 ? 'صداقة أحسن 🤝' : 'بعيد شوية 😅';
        return reply(`╭─❏ 「 💘 SHIP 」\n│ ${a} ❤️ ${b}\n│ [${bar}] ${pct}%\n│ ${msgLine}\n╰───────────────`, mentions.length ? { /* mentions handled by reply if supported */ } : undefined);
    }
};
