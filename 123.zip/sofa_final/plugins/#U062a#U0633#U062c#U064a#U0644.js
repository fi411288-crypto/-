// تسجيل المستخدمين + عرض الرصيد + ترتيب الأغنياء
import { resolveNumber, isRegistered, registerUser, getUser, getLevel, topUsers, START_COINS } from '../lib/economy.js';
import { displayName } from '../lib/shop.js';

const fmt = (n) => Number(n || 0).toLocaleString();

export default [
    {
        name: 'تسجيل',
        aliases: ['register', 'سجل'],
        category: 'games',
        description: 'تسجيل حسابك في اقتصاد البوت (لازم قبل ما تلعب المليون)',
        cooldown: 2000,
        async run({ sock, m, message, reply, prefix = '.' }) {
            const msg = m || message;
            const number = await resolveNumber(sock, msg);
            if (!number) return reply('❌ مقدرتش أحدد رقمك. جرب تبعت الأمر تاني.');
            if (isRegistered(number)) return reply(`✅ *أنت مسجّل بالفعل!*\nاكتب *${prefix}رصيدي* لعرض حسابك.`);
            const r = registerUser(number, msg.pushName || number);
            if (!r.ok) return reply('❌ حصل خطأ أثناء حفظ التسجيل، حاول تاني.');
            return reply(
                `🌌 *SOFA • REGISTER* ✅\n\n` +
                `🎉 *تم تسجيلك بنجاح يا ${r.user.name}!*\n\n` +
                `🎁 هدية التسجيل: \`${fmt(START_COINS)} كوين\`\n` +
                `🎮 تقدر دلوقتي تلعب *${prefix}المليون*`
            );
        }
    },
    {
        name: 'رصيدي',
        aliases: ['balance', 'bal', 'حسابي'],
        category: 'games',
        description: 'يعرض رصيدك من الكوين والـ XP',
        cooldown: 2000,
        async run({ sock, m, message, reply, prefix = '.' }) {
            const msg = m || message;
            const number = await resolveNumber(sock, msg);
            const user = number && isRegistered(number) ? getUser(number) : null;
            if (!user) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
            const coin = Number(user.economy?.coin || 0), exp = Number(user.economy?.exp || 0);
            return reply(
                `🌌 *SOFA • PROFILE*\n\n` +
                `👤 *الاسم:* ${displayName(user)}\n` +
                `💰 *الكوين:* \`${fmt(coin)}\`\n` +
                `⚡ *XP:* \`${fmt(exp)}\`\n` +
                `📈 *المستوى:* \`${getLevel(exp)}\``
            );
        }
    },
    {
        name: 'الاغنياء',
        aliases: ['top', 'توب_كوين'],
        category: 'games',
        description: 'ترتيب أغنى 10 لاعبين',
        cooldown: 3000,
        async run({ reply }) {
            const list = topUsers(10);
            if (!list.length) return reply('📭 مفيش لاعبين مسجّلين لسه.');
            const medals = ['🥇', '🥈', '🥉'];
            return reply(`🌌 *SOFA • TOP COINS*\n\n` + list.map((u, i) => `${medals[i] || `*${i + 1}.*`} ${u.name} — \`${fmt(u.coin)}\` 💰`).join('\n'));
        }
    }
];
