import { aiCommand } from '../lib/aiCmd.js';
import { MODELS } from '../lib/groq.js';

export default aiCommand({
    name: 'صحح',
    aliases: ['تصحيح', 'correct', 'fix'],
    description: 'تصحيح الإملاء وتحسين صياغة الكلام بالعربي والإنجليزي',
    usage: '.صحح النص (أو رد على رسالة)',
    system: 'صحح الإملاء والنحو وحسّن صياغة النص اللي هيجيلك بنفس لغته (عربي أو إنجليزي) من غير ما تغير المعنى أو اللهجة بشكل كبير. ' +
        'اكتب بالشكل ده بالظبط:\n✅ *النص المصحح:*\n<النص المصحح>\n\n✏️ *التعديلات:*\n- <غلط> ← <صح> (اكتب أهم 5 تعديلات بس، ولو مفيش أخطاء قول "النص سليم")',
    model: MODELS.fast,
    effort: 'low',
    max: 1500,
    temperature: 0.2,
    emptyHelp: '✏️ {p}صحح النص هنا\nأو رد على رسالة واكتب {p}صحح',
    wrap: (t) => `${t}\n\n> SOFA BOT`
});
