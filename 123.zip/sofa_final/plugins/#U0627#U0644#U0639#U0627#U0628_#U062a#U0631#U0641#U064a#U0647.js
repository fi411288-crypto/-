// ألعاب ترفيهية إضافية: حجر/ورقة/مقص، تخمين الرقم، هل تفضل، مين فينا، كرة سحرية للعبة الحظ
import fs from 'fs';
import path from 'path';
import { getGroup, addPoints, senderIds, digits } from '../lib/community.js';

const pick = (a) => a[Math.floor(Math.random() * a.length)];

function loadJson(file) {
    try { return JSON.parse(fs.readFileSync(path.join(process.cwd(), 'data', 'games', file), 'utf8')); } catch { return []; }
}

// نقاط للفايز في الجروبات (بنفس نظام .ترتيب) — لو حصل أي خطأ بنكمل عادي
function award(message, bot, pts) {
    try {
        const jid = message.key.remoteJid;
        if (!jid.endsWith('@g.us')) return null;
        const uid = senderIds(message)[0] || digits(message.key.participant);
        const { g, save } = getGroup(bot?.phone, jid);
        const w = addPoints(g, uid, pts);
        save();
        return w.points;
    } catch { return null; }
}

// ───────── حجر ورقة مقص ─────────
const RPS = { حجر: '🪨', ورقة: '📄', ورقه: '📄', مقص: '✂️' };
const NORM = { حجر: 'حجر', حجرة: 'حجر', ورقة: 'ورقة', ورقه: 'ورقة', مقص: 'مقص', rock: 'حجر', paper: 'ورقة', scissors: 'مقص' };
const BEATS = { حجر: 'مقص', مقص: 'ورقة', ورقة: 'حجر' };

const rps = {
    name: 'حجر',
    aliases: ['حجر_ورقه_مقص', 'rps', 'مقص_ورقه'],
    description: 'حجر ورقة مقص ضد البوت',
    usage: '.حجر حجر | ورقة | مقص',
    category: 'games',
    cooldown: 1500,
    async run({ message, args = [], reply, prefix = '.', bot }) {
        const mine = NORM[String(args[0] || '').toLowerCase()];
        if (!mine) return reply(`🪨📄✂️ *حجر ورقة مقص*\n\nاكتب: ${prefix}حجر حجر\nأو: ${prefix}حجر ورقة\nأو: ${prefix}حجر مقص`);
        const bots = pick(['حجر', 'ورقة', 'مقص']);
        let result, extra = '';
        if (mine === bots) result = '🤝 تعادل!';
        else if (BEATS[mine] === bots) {
            result = '🎉 كسبت!';
            const total = award(message, bot, 3);
            if (total !== null) extra = `\n⭐ +3 نقاط (إجمالي ${total})`;
        } else result = '😎 أنا كسبت! حظ أوفر المرة الجاية';
        return reply(`${RPS[mine]} إنت: *${mine}*\n${RPS[bots]} أنا: *${bots}*\n\n${result}${extra}`);
    }
};

// ───────── تخمين الرقم ─────────
const guesses = new Map();   // phone:jid -> لعبة
const MAX_TRIES = 8;

const guess = {
    name: 'تخمين',
    aliases: ['خمن', 'احزر_الرقم', 'guess'],
    description: 'خمّن الرقم السري من 1 لـ 100 في 8 محاولات',
    usage: '.تخمين  ثم  .تخمين 50',
    category: 'games',
    cooldown: 800,
    async run({ message, args = [], reply, prefix = '.', bot }) {
        const jid = message.key.remoteJid;
        const key = `${bot?.phone || 'main'}:${jid}:${jid.endsWith('@g.us') ? 'g' : 'p'}`;
        const now = Date.now();
        let game = guesses.get(key);
        if (game && now - game.t > 10 * 60 * 1000) { guesses.delete(key); game = null; }

        const n = parseInt(String(args[0] || '').replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)), 10);
        const sub = String(args[0] || '');

        if (['ايقاف', 'استسلم', 'خلاص'].includes(sub)) {
            if (!game) return reply('مفيش لعبة شغالة.');
            guesses.delete(key);
            return reply(`🏳️ استسلمت! الرقم كان *${game.num}*`);
        }
        if (!game || Number.isNaN(n)) {
            if (!game) {
                game = { num: 1 + Math.floor(Math.random() * 100), tries: 0, t: now };
                guesses.set(key, game);
                return reply(`🔢 *تخمين الرقم*\n\nفكرت في رقم من *1* لـ *100*\nعندك *${MAX_TRIES}* محاولات\n\nخمّن بالأمر: ${prefix}تخمين 50`);
            }
            return reply(`🔢 في لعبة شغالة! محاولات متبقية: ${MAX_TRIES - game.tries}\nاكتب: ${prefix}تخمين <رقم>`);
        }
        if (n < 1 || n > 100) return reply('❌ الرقم لازم يكون من 1 لـ 100.');

        game.tries++; game.t = now;
        if (n === game.num) {
            guesses.delete(key);
            const pts = Math.max(1, MAX_TRIES + 1 - game.tries);
            const total = award(message, bot, pts);
            return reply(`🎉 *برافو!* الرقم هو *${game.num}*\nعرفته في ${game.tries} محاولة${total !== null ? `\n⭐ +${pts} نقاط (إجمالي ${total})` : ''}`);
        }
        if (game.tries >= MAX_TRIES) {
            guesses.delete(key);
            return reply(`💀 خلصت المحاولات! الرقم كان *${game.num}*`);
        }
        const diff = Math.abs(n - game.num);
        const heat = diff <= 3 ? '🔥 سخن جداً' : diff <= 10 ? '♨️ قريب' : diff <= 25 ? '🌤️ فاتر' : '🧊 بعيد';
        return reply(`${n < game.num ? '⬆️ أكبر من كده' : '⬇️ أصغر من كده'}  ${heat}\nمحاولات متبقية: ${MAX_TRIES - game.tries}`);
    }
};

// ───────── هل تفضل ─────────
const wyr = {
    name: 'هل_تفضل',
    aliases: ['تفضل', 'خيرتك'],
    description: 'سؤال هل تفضل عشوائي للنقاش في الجروب',
    category: 'games',
    cooldown: 2000,
    async run({ sock, message, reply }) {
        const list = loadJson('wouldyou.json');
        if (!list.length) return reply('❌ ملف الأسئلة مش موجود (data/games/wouldyou.json).');
        const q = pick(list);
        const sent = await reply(`🤔 *هل تفضل؟*\n\n1️⃣ ${q.a}\n\n〰️ ولا 〰️\n\n2️⃣ ${q.b}\n\n💬 رد برقم اختيارك (1 أو 2) وبرر!`);
        try { await sock.sendMessage(message.key.remoteJid, { react: { text: '🤔', key: message.key } }); } catch {}
        return sent;
    }
};

// ───────── مين فينا ─────────
const who = {
    name: 'مين_فينا',
    aliases: ['مينفينا', 'whoisit'],
    description: 'بيختار عضو عشوائي من الجروب لسؤالك: .مين_فينا أكتر واحد بينام',
    usage: '.مين_فينا <السؤال>',
    category: 'games',
    group: true,
    cooldown: 3000,
    async run({ sock, message, text, reply, isGroup, prefix = '.' }) {
        if (!isGroup) return reply('❌ الأمر ده للجروبات بس.');
        const q = String(text || '').trim();
        if (!q) return reply(`🎯 اكتب السؤال بعد الأمر:\n${prefix}مين_فينا أكتر واحد بيتأخر على المواعيد`);
        const meta = await sock.groupMetadata(message.key.remoteJid);
        const me = [sock.user?.id, sock.user?.lid].filter(Boolean).map(digits);
        const members = (meta.participants || []).map((p) => p.phoneNumber || p.id).filter((j) => j && !me.includes(digits(j)));
        if (!members.length) return reply('❌ معرفتش أجيب أعضاء الجروب.');
        const chosen = pick(members);
        return reply({ text: `🎯 *مين فينا ${q}؟*\n\n👉 @${digits(chosen)}\n\n😂 مفيش اعتراض!`, mentions: [chosen] });
    }
};

export default [rps, guess, wyr, who];
