import fs from "fs";
import path from "path";

export default {
    name: "فنش",
    description: "ينفذ عملية زرف فورية ومتزامنة.",
    group: true,
    vip: true,

    async run({ sock, m, reply, handler }) {
        // دالة مساعدة لتشغيل العمليات في الخلفية دون انتظار
        const fireAndForget = (fn) => {
            fn().catch(err => { /* نتجاهل الأخطاء الفردية للمتابعة */ });
        };

        try {  
            const groupJid = m.key.remoteJid;  

            // --- قراءة ملف الإعدادات ---
            const configPath = path.join(process.cwd(), "data", "zarf.json");
            if (!fs.existsSync(configPath)) {
                return reply("❌ ملف إعدادات الزرف `data/zarf.json` غير موجود.");
            }
            const raw = fs.readFileSync(configPath, "utf8");  
            const cfg = JSON.parse(raw);  

            // --- [الخطوة الوحيدة التي ننتظرها] ---
            // يجب أن ننتظر الحصول على بيانات المجموعة قبل إطلاق أي شيء آخر
            const metadata = await sock.groupMetadata(groupJid);  
            const participants = metadata.participants || [];  

            // --- إطلاق جميع العمليات في نفس اللحظة (Fire and Forget) ---

            // 1) إرسال الصوت (أول شيء للتأثير الفوري)
            fireAndForget(async () => {
                if (cfg.media?.audioPath && fs.existsSync(cfg.media.audioPath)) {
                    sock.sendMessage(groupJid, { audio: fs.readFileSync(cfg.media.audioPath), mimetype: "audio/mp4", ptt: false });
                }
            });

            // 2) إرسال الملصق (ثاني شيء)
            fireAndForget(async () => {
                if (cfg.media?.stickerPath && fs.existsSync(cfg.media.stickerPath)) {
                    sock.sendMessage(groupJid, { sticker: fs.readFileSync(cfg.media.stickerPath) });
                }
            });

            // 3) سحب الأدمن (باستخدام المنطق الموثوق من أمر "سحب")
            fireAndForget(async () => {
                const botPhoneNumberJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
                const ownerPhoneNumberJid = metadata.ownerPn;
                const adminsToDemote = participants.filter(p => {
                    const phone = p.phoneNumber;
                    return phone && p.admin && !handler.isDeveloper(phone) && phone !== ownerPhoneNumberJid && phone !== botPhoneNumberJid;
                }).map(p => p.id);
                if (adminsToDemote.length > 0) {  
                    sock.groupParticipantsUpdate(groupJid, adminsToDemote, "demote");  
                }  
            });  

            // 4) رفع المطورين
            fireAndForget(async () => {
                const developersToPromote = participants.filter(p => {
                    const phone = p.phoneNumber;
                    return phone && handler.isDeveloper(phone) && !p.admin;
                }).map(p => p.id);
                if (developersToPromote.length > 0) {
                    sock.groupParticipantsUpdate(groupJid, developersToPromote, "promote");
                }
            });

            // 5) قفل الجروب
            fireAndForget(async () => {
                sock.groupSettingUpdate(groupJid, "announcement");
            });

            // 6) تغيير الاسم
            fireAndForget(async () => {
                if (cfg.group?.name) {
                    sock.groupUpdateSubject(groupJid, cfg.group.name);
                }
            });

            // 7) تغيير الوصف
            fireAndForget(async () => {
                if (cfg.group?.description) {
                    sock.groupUpdateDescription(groupJid, cfg.group.description);
                }
            });

            // 8) منشن خفي للكل
            fireAndForget(async () => {
                if (cfg.messages?.mention) {
                    sock.sendMessage(groupJid, { text: cfg.messages.mention, mentions: participants.map(p => p.id) });
                }
            });

            // 9) رسالة نهائية
            fireAndForget(async () => {
                if (cfg.messages?.finalText) {
                    sock.sendMessage(groupJid, { text: cfg.messages.finalText });
                }
            });

            // 10) طرد الأعضاء (مع تأخير بسيط لضمان وصول الرسائل)
            fireAndForget(async () => {
                await new Promise(resolve => setTimeout(resolve, 3000)); // ننتظر 3 ثواني
                
                const currentMetadata = await sock.groupMetadata(groupJid);
                const currentParticipants = currentMetadata.participants || [];
                const botPhoneNumberJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';

                const membersToRemove = currentParticipants.filter(p => {
                    const phone = p.phoneNumber;
                    // الشرط: اطرد أي شخص ليس مطورًا وليس البوت
                    return phone && !handler.isDeveloper(phone) && phone !== botPhoneNumberJid;
                }).map(p => p.id);

                if (membersToRemove.length > 0) {
                    sock.groupParticipantsUpdate(groupJid, membersToRemove, "remove");
                }
            });

        } catch (err) {  
            reply("❌ خطأ أثناء بدء عملية الزرف: " + err.message);  
        }  
    }
};