// .توثيق +212 627-896021  ← يفحص الرقم: مسجّل على واتساب ولا لأ (+ النبذة، حساب تجاري، الصورة، الدولة)
const COOLDOWN_MS = 10 * 1000;
const MAX_NUMBERS = 3;
const cd = new Map();

// كود الدولة -> [الاسم, العلم] (بنطابق أطول كود أول)
const C = {
    20: ['مصر', '🇪🇬'], 212: ['المغرب', '🇲🇦'], 213: ['الجزائر', '🇩🇿'], 216: ['تونس', '🇹🇳'], 218: ['ليبيا', '🇱🇾'],
    249: ['السودان', '🇸🇩'], 253: ['جيبوتي', '🇩🇯'], 252: ['الصومال', '🇸🇴'], 222: ['موريتانيا', '🇲🇷'],
    961: ['لبنان', '🇱🇧'], 962: ['الأردن', '🇯🇴'], 963: ['سوريا', '🇸🇾'], 964: ['العراق', '🇮🇶'], 965: ['الكويت', '🇰🇼'],
    966: ['السعودية', '🇸🇦'], 967: ['اليمن', '🇾🇪'], 968: ['عُمان', '🇴🇲'], 970: ['فلسطين', '🇵🇸'], 971: ['الإمارات', '🇦🇪'],
    973: ['البحرين', '🇧🇭'], 974: ['قطر', '🇶🇦'], 90: ['تركيا', '🇹🇷'], 98: ['إيران', '🇮🇷'], 92: ['باكستان', '🇵🇰'],
    91: ['الهند', '🇮🇳'], 880: ['بنجلاديش', '🇧🇩'], 62: ['إندونيسيا', '🇮🇩'], 60: ['ماليزيا', '🇲🇾'], 63: ['الفلبين', '🇵🇭'],
    44: ['بريطانيا', '🇬🇧'], 33: ['فرنسا', '🇫🇷'], 49: ['ألمانيا', '🇩🇪'], 39: ['إيطاليا', '🇮🇹'], 34: ['إسبانيا', '🇪🇸'],
    31: ['هولندا', '🇳🇱'], 32: ['بلجيكا', '🇧🇪'], 41: ['سويسرا', '🇨🇭'], 46: ['السويد', '🇸🇪'], 7: ['روسيا', '🇷🇺'],
    380: ['أوكرانيا', '🇺🇦'], 1: ['أمريكا/كندا', '🇺🇸'], 52: ['المكسيك', '🇲🇽'], 55: ['البرازيل', '🇧🇷'], 54: ['الأرجنتين', '🇦🇷'],
    234: ['نيجيريا', '🇳🇬'], 27: ['جنوب أفريقيا', '🇿🇦'], 254: ['كينيا', '🇰🇪'], 251: ['إثيوبيا', '🇪🇹'], 233: ['غانا', '🇬🇭'],
    221: ['السنغال', '🇸🇳'], 225: ['كوت ديفوار', '🇨🇮'], 86: ['الصين', '🇨🇳'], 81: ['اليابان', '🇯🇵'], 82: ['كوريا الجنوبية', '🇰🇷'],
    61: ['أستراليا', '🇦🇺'], 65: ['سنغافورة', '🇸🇬'], 66: ['تايلاند', '🇹🇭'], 84: ['فيتنام', '🇻🇳']
};
function country(n) {
    for (let l = 3; l >= 1; l--) { const c = C[n.slice(0, l)]; if (c) return c; }
    return ['غير معروفة', '🌐'];
}
const fmtPhone = (n) => { const [, f] = country(n); return `+${n}`; };

async function check(sock, n) {
    const jid = `${n}@s.whatsapp.net`;
    const r = { n, exists: false };
    try {
        const res = await sock.onWhatsApp(jid);
        const hit = Array.isArray(res) ? res.find((x) => x?.exists) : null;
        r.exists = !!hit;
        r.jid = hit?.jid || jid;
    } catch (e) { r.error = String(e?.message || e).slice(0, 60); return r; }
    if (!r.exists) return r;

    const safe = async (fn) => { try { return await fn(); } catch { return null; } };
    const [about, pic, biz] = await Promise.all([
        safe(async () => { const s = await sock.fetchStatus(r.jid); const x = Array.isArray(s) ? s[0] : s; return x?.status?.status ?? x?.status ?? null; }),
        safe(() => sock.profilePictureUrl(r.jid, 'image')),
        safe(() => sock.getBusinessProfile(r.jid))
    ]);
    r.about = typeof about === 'string' && about.trim() ? about.trim().slice(0, 120) : null;
    r.pic = pic || null;
    r.business = biz?.description || biz?.category || biz?.wid ? biz : null;
    return r;
}

function card(r) {
    const [name, flag] = country(r.n);
    const head = '╭━━━━━━━〔 🛡️ *فحص الرقم* 〕━━━━━━━╮';
    const foot = '╰━━━━━━━━━━━━━━━━━━━━━━━╯';
    const L = [head, '', `  📱 *الرقم*  ⟫  \`+${r.n}\``, `  ${flag} *الدولة*  ⟫  ${name}`, ''];
    if (r.error) {
        L.push(`  ⚠️ *الحالة*  ⟫  تعذّر الفحص`, `  ℹ️ ${r.error}`);
    } else if (r.exists) {
        L.push('  ✅ *الحالة*  ⟫  *شغّال ومسجّل على واتساب*', '  ─────────────');
        L.push(`  💼 *نوع الحساب*  ⟫  ${r.business ? 'تجاري (Business)' : 'شخصي'}`);
        if (r.business?.category) L.push(`  🏷️ *النشاط*  ⟫  ${String(r.business.category).slice(0, 40)}`);
        L.push(`  🖼️ *الصورة*  ⟫  ${r.pic ? 'موجودة' : 'مخفية / مفيش'}`);
        L.push(`  💬 *النبذة*  ⟫  ${r.about ? `_${r.about}_` : 'مفيش / مخفية'}`);
    } else {
        L.push('  ❌ *الحالة*  ⟫  *غير مسجّل أو محظور*', '  ─────────────',
            '  ℹ️ واتساب بيرجّع نفس النتيجة للرقم المحظور والرقم اللي ملوش حساب، فمقدرش أفرّق بينهم.');
    }
    L.push('', foot, '> ✦ SOFA BOT ✦');
    return L.join('\n');
}

export default {
    name: 'توثيق',
    aliases: ['فحص', 'check', 'verify'],
    description: 'فحص رقم واتساب: .توثيق +212 627-896021',
    category: 'tools',

    async run({ sock, message, args, reply, prefix = '.' }) {
        const jid = message.key.remoteJid;
        const who = message.key.participant || jid;
        const left = COOLDOWN_MS - (Date.now() - (cd.get(who) || 0));
        if (left > 0) return reply(`⏳ استنى ${Math.ceil(left / 1000)} ثانية.`);

        // نقسّم على الفاصلة/السطر عشان أكتر من رقم، ومسافات وشرطات جوه الرقم الواحد بتتشال
        const raw = args.join(' ');
        const nums = [...new Set(
            raw.split(/[,،\n]+/).map((x) => x.replace(/\D/g, '').replace(/^00/, '')).filter(Boolean)
        )];
        if (!nums.length) return reply(`🛡️ *فحص الرقم*\n\nاكتب الرقم مع كود الدولة:\n*${prefix}توثيق +212 627-896021*`);
        if (nums.length > MAX_NUMBERS) return reply(`❌ أقصى عدد ${MAX_NUMBERS} أرقام في المرة.`);
        const bad = nums.find((n) => n.length < 8 || n.length > 15);
        if (bad) return reply(`❌ الرقم *${bad}* غير صالح. اكتبه مع كود الدولة.`);

        cd.set(who, Date.now());
        await sock.sendMessage(jid, { react: { text: '🔎', key: message.key } }).catch(() => {});

        for (const n of nums) {
            const r = await check(sock, n);
            const text = card(r);
            if (r.pic) {
                try { await sock.sendMessage(jid, { image: { url: r.pic }, caption: text }, { quoted: message }); continue; } catch {}
            }
            await sock.sendMessage(jid, { text }, { quoted: message });
            if (nums.length > 1) await new Promise((res) => setTimeout(res, 1200));
        }
        await sock.sendMessage(jid, { react: { text: '✅', key: message.key } }).catch(() => {});
    }
};
