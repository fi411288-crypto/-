// 🚪 سجل الطرد: مين اتطرد ومين طرده ومتى (بيلقط أي طرد حتى من خارج البوت) — SOFA BOT
import { store, job, perms, digits } from '../lib/xtools.js';

const db = () => store('kicklog', {}).data;
const attached = (globalThis.__kickLogSocks ||= new WeakSet());
const idOf = (p) => (typeof p === 'string' ? p : p?.id || p?.phoneNumber || '');

job('kicklog-attach', async () => {
    for (const s of global.bot?.sessions?.values?.() || []) {
        const sock = s?.sock;
        if (!sock?.ev || attached.has(sock)) continue;
        attached.add(sock);
        sock.ev.on('group-participants.update', (e) => {
            try {
                if (e?.action !== 'remove' || !e.author || !e.id) return;
                const by = idOf(e.author);
                const me = [sock.user?.id, sock.user?.lid].filter(Boolean).map(digits);
                for (const u of (e.participants || []).map(idOf).filter(Boolean)) {
                    if (digits(u) === digits(by)) continue; // خرج بنفسه
                    const l = (db()[e.id] ||= []);
                    l.push({ t: Date.now(), user: u, by, bot: me.includes(digits(by)) });
                    if (l.length > 200) l.splice(0, l.length - 200);
                }
                store('kicklog').save();
            } catch {}
        });
    }
}, 15000);

export default [{
    name: 'سجل_طرد',
    aliases: ['سجل-طرد', 'kicklog', 'المطرودين'],
    category: 'admin',
    group: true,
    description: 'آخر من اتطردوا من الجروب ومين طردهم ومتى',
    usage: '.سجل_طرد [عدد] | .سجل_طرد مسح',
    cooldown: 3000,
    async run({ sock, message, args, reply, isDeveloper }) {
        const p = await perms({ sock, message, isDeveloper });
        if (!p.isAdmin) return reply('❌ الأمر ده للمشرفين فقط.');
        const jid = message.key.remoteJid;
        if (['مسح', 'clear'].includes(args[0])) { delete db()[jid]; store('kicklog').save(); return reply('🗑️ اتمسح السجل.'); }
        const n = Math.max(1, Math.min(20, parseInt(String(args[0] || '10').replace(/[٠-٩]/g, (d) => d.charCodeAt(0) - 1632), 10) || 10));
        const l = (db()[jid] || []).slice(-n).reverse();
        if (!l.length) return reply('📭 مفيش حد اتطرد من وقت ما السجل اشتغل.');
        const when = (t) => new Date(t).toLocaleString('ar-EG', { timeZone: 'Africa/Cairo', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
        const lines = l.map((e, i) => `*${i + 1}.* @${digits(e.user)}\n   👮 ${e.bot ? '🤖 البوت' : '@' + digits(e.by)} • 🕐 ${when(e.t)}`);
        return reply({ text: `🚪 *سجل الطرد* (آخر ${l.length})\n\n${lines.join('\n')}\n\n> SOFA BOT`, mentions: l.flatMap((e) => (e.bot ? [e.user] : [e.user, e.by])) });
    }
}];
