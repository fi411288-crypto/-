// ملف: plugins/تيك.js

import axios from "axios";

export default {
    name: "تيك",
    aliases: ["tiktok", "tt"],
    description: "بحث عن فيديو تيك توك وإرساله.",
    category: "download",

    async run({ sock, message, reply, text }) {
        if (!text) {
            return reply("🎵 اكتب كلمة للبحث في تيك توك.\nمثال:\n.تيك ايديت انمي");
        }

        try {
            await reply(`🔎 جاري البحث عن "${text}" ...`);

            const apiUrl = `https://api.tiklydown.eu.org/api/search?keywords=${encodeURIComponent(text)}`;

            const response = await axios.get(apiUrl);

            if (!response.data || !response.data.data || response.data.data.length === 0) {
                return reply("❌ لم يتم العثور على فيديوهات.");
            }

            const videos = response.data.data;

            // اختيار فيديو عشوائي
            const random = videos[Math.floor(Math.random() * videos.length)];

            if (!random.play) {
                return reply("❌ لم أستطع استخراج رابط الفيديو.");
            }

            const caption = `
🎬 العنوان: ${random.title || 'بدون عنوان'}
👤 الناشر: ${random.author?.nickname || 'غير معروف'}
❤️ الإعجابات: ${random.play_count || 0}
`.trim();

            await sock.sendMessage(
                message.key.remoteJid,
                {
                    video: { url: random.play },
                    caption
                },
                { quoted: message }
            );

        } catch (err) {
            console.error("Error:", err);
            return reply(`❌ خطأ: ${err.message}`);
        }
    }
};