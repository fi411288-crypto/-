// 💸 تحويل كوين + هدية + ترتيب الأثرياء (كارت ذهبي) — SOFA BOT
import { isRegistered, getUser, transferCoins, topUsers } from '../lib/economy.js';
import { topCard } from '../lib/goldcards.js';
import { targetJid } from '../lib/xtools.js';
import { fmt, compact, numberOfJid, toEnDigits, displayName, questBump } from '../lib/shop.js';
import { resolveNumber } from '../lib/economy.js';

const FEE = 0.05, GIFT_MAX = 50000, MIN = 10;

async function send({ sock, msg, args, reply, prefix, fee, max, label }) {
    const from = await resolveNumber(sock, msg);
    if (!from || !isRegistered(from)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
    const target = targetJid(msg);
    if (!target) return reply(`❌ اعمل منشن للعضو أو رد على رسالته:\n*${prefix}${label} @العضو 1000*`);
    const raw = args.map(toEnDigits).find((a) => /^\d{1,9}$/.test(a) && !String(a).startsWith('@'));
    const amount = parseInt(raw || '', 10);
    if (!amount || amount < MIN) return reply(`❌ اكتب مبلغ صح (الحد الأدنى ${MIN}).`);
    if (max && amount > max) return reply(`❌ الحد الأقصى للهدية الواحدة ${fmt(max)}.`);
    const to = await numberOfJid(sock, target);
    if (!to) return reply('❌ مقدرتش أحدد رقم العضو.');
    if (to === from) return reply('😅 مينفعش تحوّل لنفسك.');
    if (!isRegistered(to)) return reply('❌ العضو ده مش مسجّل في البوت (لازم يكتب .تسجيل).');
    const r = transferCoins(from, to, amount, fee);
    if (r.error === 'funds') return reply(`❌ رصيدك مش كفاية!\n💰 معاك: \`${fmt(r.have)}\`\n📤 المطلوب: \`${fmt(r.need)}\`${fee ? ` (شامل رسوم ${fee * 100}%)` : ''}`);
    if (!r.ok) return reply('❌ حصل خطأ أثناء التحويل.');
    questBump(from, 'send');
    return { r, amount, target, to };
}

export default [
    {
        name: 'تحويل_كوين',
        aliases: ['تحويل-كوين', 'transfer', 'حول'],
        category: 'games',
        description: 'تحويل كوين لعضو (رسوم 5%)',
        usage: '.تحويل_كوين @العضو 1000',
        cooldown: 4000,
        group: true,
        async run({ sock, m, message, args, reply, prefix = '.' }) {
            const msg = m || message;
            const x = await send({ sock, msg, args, reply, prefix, fee: FEE, label: 'تحويل_كوين' });
            if (!x?.r) return;
            return reply({
                text: `💸 *SOFA • TRANSFER*\n\n✅ اتحوّل \`${fmt(x.amount)}\` كوين إلى @${x.to}\n🧾 الرسوم: \`${fmt(x.r.fee)}\`\n💼 رصيدك: \`${fmt(x.r.from)}\``,
                mentions: [x.target]
            });
        }
    },
    {
        name: 'هدية',
        aliases: ['gift', 'اهدي'],
        category: 'games',
        description: 'إهداء كوين لعضو بدون رسوم (حتى 50,000)',
        usage: '.هدية @العضو 1000',
        cooldown: 4000,
        group: true,
        async run({ sock, m, message, args, reply, prefix = '.' }) {
            const msg = m || message;
            const x = await send({ sock, msg, args, reply, prefix, fee: 0, max: GIFT_MAX, label: 'هدية' });
            if (!x?.r) return;
            return reply({
                text: `🎁 *SOFA • GIFT*\n\n🎉 @${x.to} استلم هدية \`${fmt(x.amount)}\` كوين من ${displayName(getUser(await resolveNumber(sock, msg)) || { name: 'صديق' })}!\n💼 رصيدك: \`${fmt(x.r.from)}\``,
                mentions: [x.target]
            });
        }
    },
    {
        name: 'ثروة',
        aliases: ['اثرياء', 'الاثرياء', 'wealth', 'richest'],
        category: 'games',
        description: 'كارت ذهبي لأغنى 10 أعضاء',
        cooldown: 5000,
        async run({ reply }) {
            const list = topUsers(10);
            if (!list.length) return reply('📭 مفيش لاعبين مسجّلين لسه.');
            const rows = list.map((u) => ({ name: u.name, points: compact(u.coin), sub: 'COINS' }));
            const txt = list.map((u, i) => `${['🥇', '🥈', '🥉'][i] || `*${i + 1}.*`} ${u.name} — \`${fmt(u.coin)}\` 💰`).join('\n');
            const img = await topCard({ group: 'RICHEST', rows, unit: 'COIN' });
            if (!img) return reply(`💰 *أغنى 10 أعضاء*\n\n${txt}\n\n> SOFA BOT`);
            return reply({ image: img, caption: `💰 *أغنى 10 أعضاء*\n\n> SOFA BOT` });
        }
    }
];
