import { getAdminFlags } from '../lib/compat.js';

export default {
    name: 'لينك',
    aliases: ['رابط_المجموعة', 'grouplink'],
    description: 'يرسل رابط دعوة المجموعة الحالية',
    category: 'group',

    async run({ sock, message, reply, isGroup }) {
        if (!isGroup) return reply('❌ الأمر ده للمجموعات فقط.');
        try {
            const jid = message.key.remoteJid;
            const metadata = await sock.groupMetadata(jid);
            const { isBotAdmin } = getAdminFlags(sock, message, metadata);
            if (!isBotAdmin) return reply('❌ لازم أكون مشرف في المجموعة عشان أجيب الرابط.');
            const code = await sock.groupInviteCode(jid);
            return reply(`🔗 رابط المجموعة:\nhttps://chat.whatsapp.com/${code}`);
        } catch (e) {
            return reply(`❌ حدث خطأ: ${e.message}`);
        }
    }
};
