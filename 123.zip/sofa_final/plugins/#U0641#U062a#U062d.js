import { getAdminFlags } from '../lib/compat.js';

// فتح المجموعة — للمشرفين فقط. أي عضو عادي بيستخدمه بيطلعله: "هذا الأمر للمشرفين فقط"
export default {
    name: 'فتح',
    aliases: ['unlock', 'open', 'opengroup'],
    description: 'فتح دردشة المجموعة للكل (للمشرفين فقط)',
    category: 'group',

    async run({ sock, message, reply, isGroup, isDeveloper }) {
        if (!isGroup) return reply('❌ الأمر ده للمجموعات فقط.');
        try {
            const jid = message.key.remoteJid;
            const metadata = await sock.groupMetadata(jid);
            const { isAdmin, isBotAdmin } = getAdminFlags(sock, message, metadata);
            if (!isAdmin && !isDeveloper) return reply('❌ هذا الأمر للمشرفين فقط');
            if (!isBotAdmin) return reply('❌ لازم أكون مشرف في المجموعة عشان أنفذ الأمر ده.');
            await sock.groupSettingUpdate(jid, 'not_announcement');
            return reply('✅ تم فتح المجموعة، الكل يقدر يرسل رسائل.');
        } catch (e) {
            return reply(`❌ حدث خطأ: ${e.message}`);
        }
    }
};
