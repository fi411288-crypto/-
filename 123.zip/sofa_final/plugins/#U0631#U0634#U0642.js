import { parseChannelLink, getTargetSessions, resolveChannel, sleep, rand, errText } from '../lib/channels.js';

// .رشق ❤️ https://whatsapp.com/channel/<كود>/<رقم الرسالة>
// كل الأرقام المربوطة (المتصلة) بتعمل رياكشن على رسالة القناة.
// لو كتبت أكتر من إيموجي (.رشق ❤️ 🔥 👍) كل رقم بيختار واحد عشوائي.
export default {
    name: 'رشق',
    aliases: ['react_all'],
    description: 'كل الأرقام المربوطة تعمل رياكشن على رسالة في قناة: .رشق ❤️ <لينك الرسالة>',
    usage: '.رشق ❤️ https://whatsapp.com/channel/xxxx/123',
    category: 'tools',
    developer: true,
    run: async (context) => {
        const { client, m, text } = context;
        const send = (t) => client.sendMessage(m.chat, { text: t }, { quoted: m });
        const react = (e) => client.sendMessage(m.chat, { react: { text: e, key: m.reactKey } }).catch(() => {});

        const link = parseChannelLink(text);
        const emojis = String(text || '').replace(/https?:\/\/\S+/gi, '').trim().split(/\s+/).filter(Boolean);

        if (!link || !link.messageId || !emojis.length) {
            await react('❌');
            return send('╭─❏ 「 رشق 」\n│ الاستخدام:\n│ .رشق ❤️ https://whatsapp.com/channel/كود/رقم_الرسالة\n│\n│ لازم لينك *رسالة* جوه القناة\n│ (اضغط مطولاً على الرسالة ← نسخ الرابط)\n╰───────────────');
        }

        const sessions = getTargetSessions(context);
        if (!sessions.length) { await react('❌'); return send('❌ مفيش أرقام متصلة دلوقتي.'); }

        await react('⌛');
        let jid, name;
        try {
            ({ jid, name } = await resolveChannel(sessions[0].sock, link.code));
        } catch (e) {
            await react('❌');
            return send(`❌ مقدرتش أوصل للقناة: ${errText(e)}`);
        }

        let ok = 0;
        const fails = [];
        for (const s of sessions) {
            const emoji = emojis[rand(0, emojis.length - 1)];
            try {
                if (typeof s.sock.newsletterReactMessage === 'function') {
                    await s.sock.newsletterReactMessage(jid, link.messageId, emoji);
                } else {
                    await s.sock.sendMessage(jid, { react: { text: emoji, key: { remoteJid: jid, id: link.messageId, fromMe: false } } });
                }
                ok++;
            } catch (e) {
                fails.push(`${s.phone}: ${errText(e)}`);
            }
            await sleep(rand(400, 1200)); // فاصل بسيط بين الأرقام عشان ميتحسبش سبام
        }

        await react(ok ? '✅' : '❌');
        let msg = `╭─❏ 「 رشق 」\n│ القناة: ${name || link.code}\n│ ✅ نجح: ${ok} رقم\n│ ❌ فشل: ${fails.length} رقم\n╰───────────────`;
        if (fails.length) msg += `\n\n${fails.slice(0, 10).map((f) => `• ${f}`).join('\n')}`;
        return send(msg);
    }
};
