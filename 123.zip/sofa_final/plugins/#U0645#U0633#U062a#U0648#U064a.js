import { getGroup, levelOf, levelStart, weekKey, weekPoints } from '../lib/community.js';
import { topCard } from '../lib/goldcards.js';
import { idsOf, findUser, targetJid, digits } from '../lib/xtools.js';

const bar = (cur, total) => { const n = Math.max(0, Math.min(10, Math.round((cur / Math.max(1, total)) * 10))); return '▰'.repeat(n) + '▱'.repeat(10 - n); };

const level = {
    name: 'مستوى',
    aliases: ['level', 'xp', 'رتبتي', 'مستواي'],
    description: 'مستواك ونقاط XP في الجروب',
    usage: '.مستوى [منشن/رد]',
    category: 'tools',
    group: true,
    async run({ message, reply, bot }) {
        const { g } = getGroup(bot?.phone, message.key.remoteJid);
        const t = targetJid(message);
        const hit = findUser(g, t ? [digits(t)] : idsOf(message));
        if (!hit) return reply('📊 لسه معندوش نقاط. اتكلم في الجروب أو جاوب ألغاز (.لغز) وهتبدأ تجمع XP!');
        const [id, u] = hit;
        const lvl = levelOf(u.points), from = levelStart(lvl), to = levelStart(lvl + 1);
        const rank = Object.values(g.users).filter((x) => x.points > u.points).length + 1;
        const who = u.jid || `${id}@s.whatsapp.net`;
        return reply({
            text: `👑 *مستوى @${digits(who)}*\n\n🏅 المستوى: *${lvl}*\n⭐ XP: *${u.points}*\n${bar(u.points - from, to - from)} ${u.points}/${to}\n📅 نقاط الأسبوع: ${weekPoints(u, weekKey())}\n🏆 ترتيبك: ${rank} من ${Object.keys(g.users).length}\n💬 رسائلك: ${u.msgs}\n\n> SOFA BOT`,
            mentions: [who]
        });
    }
};

const top = {
    name: 'توب',
    aliases: ['top', 'متصدرين'],
    description: 'كارت ذهبي لأعلى 10 أعضاء XP في الجروب',
    usage: '.توب | .توب اسبوع',
    category: 'tools',
    group: true,
    async run({ sock, message, args, reply, bot }) {
        const jid = message.key.remoteJid;
        const { g } = getGroup(bot?.phone, jid);
        const wk = ['اسبوع', 'الاسبوع', 'week'].includes((args[0] || '').toLowerCase());
        const rows = Object.entries(g.users)
            .map(([id, u]) => ({ name: u.name || digits(u.jid || id), points: wk ? weekPoints(u) : u.points, level: levelOf(u.points) }))
            .filter((r) => r.points > 0).sort((a, b) => b.points - a.points).slice(0, 10);
        if (!rows.length) return reply('📊 لسه مفيش نقاط في الجروب.');
        let group = 'LEADERBOARD';
        try { group = (await sock.groupMetadata(jid)).subject || group; } catch {}
        const img = await topCard({ group: wk ? `${group} • WEEK` : group, rows });
        const txt = rows.map((r, i) => `${['🥇', '🥈', '🥉'][i] || `*${i + 1}.*`} ${r.name} — ${r.points} XP (مستوى ${r.level})`).join('\n');
        if (!img) return reply(`🏆 *أعلى 10 ${wk ? 'الأسبوع' : ''}*\n\n${txt}\n\n> SOFA BOT`);
        return reply({ image: img, caption: `🏆 *أعلى 10 ${wk ? 'الأسبوع' : 'أعضاء'}*\n\n> SOFA BOT` });
    }
};

export default [level, top];
