// 🕵️ المحقق: قضية خيالية وأدلة بتظهر بالتدريج — أول واحد يتهم الجاني الصح ياخد 50,000 كوين — SOFA BOT
import { resolveNumber, isRegistered, addRewards } from '../lib/economy.js';
import { CASES, REWARD } from '../lib/detective.js';
import { fmt, toEnDigits } from '../lib/shop.js';

const STEP = 40_000;        // دليل جديد كل 40 ثانية
const AFTER_LAST = 60_000;  // مهلة بعد آخر دليل
const games = new Map();    // groupJid -> game
let lastCase = -1;

const sus = (c) => c.suspects.map((s, i) => `*${i + 1}.* ${s}`).join('\n');
const clueList = (g) => g.c.clues.slice(0, g.shown).map((t, i) => `🔎 ${i === 0 ? 'الواقعة' : `دليل ${i}`}: ${t}`).join('\n');

function finish(jid, g, text, mentions = []) {
    clearTimeout(g.timer); games.delete(jid);
    return g.sock.sendMessage(jid, { text, mentions }).catch(() => {});
}

function schedule(jid, g) {
    g.timer = setTimeout(() => {
        if (games.get(jid) !== g) return;
        if (g.shown < g.c.clues.length) {
            g.shown++;
            const last = g.shown === g.c.clues.length;
            g.sock.sendMessage(jid, { text: `🕵️ *دليل جديد!*\n\n🔎 دليل ${g.shown - 1}: ${g.c.clues[g.shown - 1]}\n\n${last ? '⏰ ده آخر دليل — قدامكم دقيقة!' : ''}\nللاتهام: *.اتهم <رقم>*` }).catch(() => {});
            schedule(jid, g);
        } else {
            finish(jid, g, `⌛ *خلص الوقت ومحدش كشف الجاني!*\n\n🔓 الجاني كان: *${g.c.suspects[g.c.culprit - 1]}*\n${g.c.reveal}`);
        }
    }, g.shown < g.c.clues.length ? STEP : AFTER_LAST);
    g.timer.unref?.();
}

export default [
    {
        name: 'المحقق',
        aliases: ['detective', 'قضية', 'محقق'],
        category: 'games',
        description: 'لعبة تحقيق: اكتشف الجاني من الأدلة وخد 50,000 كوين',
        cooldown: 3000,
        async run({ sock, message, m, isGroup, reply, prefix = '.' }) {
            const msg = m || message, jid = msg.key.remoteJid;
            if (!isGroup) return reply('❌ لعبة المحقق للجروبات بس.');
            const cur = games.get(jid);
            if (cur) return reply(`🕵️ *في قضية شغالة!*\n\n📁 ${cur.c.title}\n\n${clueList(cur)}\n\n👥 *المشتبهين:*\n${sus(cur.c)}\n\nللاتهام: *${prefix}اتهم <رقم>*`);
            let i; do { i = Math.floor(Math.random() * CASES.length); } while (CASES.length > 1 && i === lastCase);
            lastCase = i;
            const g = { c: CASES[i], shown: 1, guessed: new Set(), sock, timer: null };
            games.set(jid, g); schedule(jid, g);
            return reply(
                `🕵️ *SOFA • DETECTIVE*\n\n📁 *القضية:* ${g.c.title}\n${g.c.story}\n\n${clueList(g)}\n\n👥 *المشتبهين:*\n${sus(g.c)}\n\n` +
                `⏱️ دليل جديد كل 40 ثانية\n🎁 أول واحد يكشف الجاني ياخد *${fmt(REWARD)}* كوين\n⚠️ كل واحد له اتهام واحد بس!\n\nللاتهام: *${prefix}اتهم <رقم>*`
            );
        }
    },
    {
        name: 'اتهم',
        aliases: ['اتهام', 'accuse'],
        category: 'games',
        description: 'اتهم مشتبه في لعبة المحقق: .اتهم <رقم>',
        cooldown: 1500,
        async run({ sock, message, m, args, isGroup, reply, prefix = '.' }) {
            const msg = m || message, jid = msg.key.remoteJid;
            if (!isGroup) return reply('❌ لعبة المحقق للجروبات بس.');
            const g = games.get(jid);
            if (!g) return reply(`❌ مفيش قضية شغالة. ابدأ واحدة بـ *${prefix}المحقق*`);
            const number = await resolveNumber(sock, msg);
            if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
            const n = parseInt(toEnDigits(args[0] || ''), 10);
            if (!n || n < 1 || n > g.c.suspects.length) return reply(`❌ اكتب رقم المشتبه من 1 لـ ${g.c.suspects.length}\nمثال: *${prefix}اتهم 2*`);
            if (g.guessed.has(number)) return reply('⛔ اتهمت قبل كده! كل واحد له اتهام واحد بس.');
            g.guessed.add(number);
            if (n !== g.c.culprit) return reply(`❌ *${g.c.suspects[n - 1]}* مش هو الجاني! اتهامك راح.`);
            const r = addRewards(number, 100, REWARD);
            return finish(jid, g, `🎉 *مبروك! كشفت الجاني!*\n\n🕵️ @${number} اتهم صح\n🔓 الجاني: *${g.c.suspects[g.c.culprit - 1]}*\n${g.c.reveal}\n\n🎁 \`+${fmt(REWARD)}\` كوين${r.success ? `\n💼 رصيده: \`${fmt(r.newCoins)}\`` : ''}\n\n🏁 القضية اتقفلت — ابدأوا قضية جديدة بـ .المحقق`, [`${number}@s.whatsapp.net`]);
        }
    }
];
