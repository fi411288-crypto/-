import { getSession, ownerNumber, digits } from '../lib/adminTools.js';

// .سيند الرسالة ← رد على رسالة في جروب، البوت بيشوف مين الأدمن ويبعت الرسالة من جهته
// مثال: .سيند السلام عليكم ورحمة الله (بيبعتها من حساب الأدمن الموجود في الجروب)
export default [{
    name: 'سيند',
    aliases: ['send_as_admin', 'admin_say'],
    description: 'بعت رسالة من الأدمن الموجود في الجروب (بدل الرفع أدمن)',
    category: 'owner',
    ownerSession: true,
    async run({ m, sock, args, text, reply }) {
        const msg = String(text || '').trim();
        if (!msg) return reply('الاستخدام: .سيند الرسالة (في رد على جروب)');

        const groupJid = m.chat;
        if (!String(groupJid).includes('@g.us')) {
            return reply('❌ هذا الأمر للجروبات فقط');
        }

        try {
            // اجلب معلومات الجروب
            const meta = await sock.groupMetadata(groupJid);
            
            // ابحث عن أول أدمن متصل (من الأرقام المربوطة)
            let adminSession = null;
            let adminPhone = null;
            
            const linkedPhones = global.bot?.sessionOwners ? [...global.bot.sessionOwners.keys()] : [];
            
            for (const phone of linkedPhones) {
                const s = global.bot?.sessions?.get(phone);
                if (!s?.isConnected || !s.sock) continue;

                try {
                    const participant = meta.participants.find((p) => {
                        const pPhone = p.phoneNumber ? digits(p.phoneNumber) : digits(p.id);
                        return pPhone === phone;
                    });

                    const isAdmin = participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
                    const isOwner = meta.owner && digits(meta.owner) === phone;

                    if (isAdmin || isOwner) {
                        adminSession = s;
                        adminPhone = phone;
                        break;
                    }
                } catch {}
            }

            if (!adminSession) {
                return reply('❌ مفيش رقم أدمن متصل في الجروب');
            }

            // بعت الرسالة من جهة الأدمن
            await adminSession.sock.sendMessage(groupJid, { text: msg });
            return reply(`✅ تم البعث من: ${adminPhone}\n\nالرسالة: "${msg}"`);
        } catch (error) {
            return reply(`❌ فشل: ${error.message}`);
        }
    }
}];
