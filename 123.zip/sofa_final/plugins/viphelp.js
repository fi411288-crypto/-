export default {
    name: 'viphelp',
    aliases: ['مساعدة-vip', 'vip-help', 'اوامر-vip'],
    description: '👑 دليل أوامر VIP و WarmGPT',
    category: 'vip',

    async run({ reply, prefix }) {
        const p = prefix || '.';
        return reply(`╭─❏ 「 👑 VIP + WarmGPT 」
│
│ 🌸 *WarmGPT*
│ • ${p}warmgpt سؤالك
│ • ${p}دافي سؤالك
│ • ${p}حنون سؤالك
│   ← رد دافئ بالعربي مباشرة
│   ← للإنجليزي: ${p}warmgpt en your question
│
│ 👑 *إدارة VIP* (للمالك)
│ • ${p}vip — حالتك
│ • ${p}vip add رقم [أيام|دائم]
│ • ${p}vip del رقم
│ • ${p}vip list
│ • ${p}vip check رقم
│
│ 💥 *أوامر حصرية VIP*
│ • ${p}زرف — زرف كامل للجروب
│ • ${p}فنش
│ • ${p}سحب
│ • ${p}تصفيه
│
│ ⚙️ *أدمن*
│ • ${p}ادمن — قائمة الأدمن
│
╰───────────────
> © SOFA BOT VIP`);
    }
};
