import { addBan, listBans } from '../lib/bans.js';
import { digits, isLinkedSender, protectedNumbers, extractTargets } from '../lib/banTargets.js';

export default {
    name: "بان",
    aliases: ["حظر", "ban"],
    description: "يحظر مستخدم من استخدام البوت (منشن / رد / رقم / tg:ID)",
    category: "admin",

    async run({ sock, message, args, reply, handler, prefix }) {
        if (!isLinkedSender(handler, message)) return reply("❌ الأمر ده للأرقام المربوطة بالبوت بس.");
        const p = prefix || '.';

        const t = await extractTargets({ sock, message, args });
        if (!t.wa.length && !t.tg.length) {
            const l = listBans();
            return reply(`🚫 *المحظورين من البوت*\n\n📱 واتساب: ${l.wa.length ? l.wa.join(' ، ') : 'لا يوجد'}\n✈️ تليجرام: ${l.tg.length ? l.tg.join(' ، ') : 'لا يوجد'}\n\n📌 الاستخدام:\n• ${p}بان (رد أو منشن)\n• ${p}بان 2010xxxxxxx\n• ${p}بان tg:123456789\nولفك الحظر: ${p}فك-بان`);
        }

        const own = new Set([...protectedNumbers(), ...selfIds(sock)]);
        const done = [];
        for (const n of t.wa) { if (own.has(n)) continue; if (addBan('wa', n)) done.push(n); }
        for (const n of t.tg) { if (addBan('tg', n)) done.push(`tg:${n}`); }

        if (!done.length) return reply("ℹ️ مفيش جديد يتحظر (الأرقام يا إما محظورة بالفعل يا إما محمية).");
        return reply(`🚫 تم حظر:\n${done.map((d) => `• ${d}`).join('\n')}\n\nمش هيقدروا يستخدموا البوت.`);
    }
};

function selfIds(sock) {
    return [sock?.user?.id, sock?.user?.lid].map(digits).filter(Boolean);
}
