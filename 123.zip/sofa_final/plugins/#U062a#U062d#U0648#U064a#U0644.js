export default {
    name: "تحويل",
    description: "تحويل الملصق إلى صورة",
    developer: false,
    async run({ message, reply, handler, sock }) {
        try {
            // لازم يكون رد على ملصق
            const quoted = message.message?.extendedTextMessage?.contextInfo;
            const mime = quoted?.quotedMessage?.stickerMessage?.mimetype;

            if (!mime) {
                return reply("⚠️ رُد على *ملصق* لتحويله لصورة");
            }

            // تنزيل البيانات عبر الهاندلر
            const buffer = await handler.downloadMedia({
                message: quoted.quotedMessage
            });

            if (!buffer) return reply("❌ فشل تنزيل الملصق (الهاندلر لم يرجع بيانات).");

            // إرسال كصورة
            await sock.sendMessage(message.key.remoteJid, {
                image: buffer,
                caption: "✅ تم تحويل الملصق إلى صورة"
            }, { quoted: message });

        } catch (err) {
            reply("❌ خطأ: " + err.message);
        }
    }
};