import { digits, ownerNumber } from '../lib/adminTools.js';

// .مين  ← الأرقام المربوطة وحالتها (خفيف: بيقرا من الذاكرة بس، من غير قراءة ملفات)
export default [{
    name: 'مين',
    aliases: ['linked'],
    description: 'عرض الأرقام المربوطة وعددها',
    category: 'owner',
    ownerSession: true,
    async run({ reply }) {
        const bot = global.bot;
        const phones = [...new Set([...(bot?.sessionOwners?.keys?.() || [])].map(digits).filter(Boolean))];
        if (!phones.length) return reply('❌ مفيش أرقام مربوطة.');

        const owner = ownerNumber();
        let online = 0;
        const lines = phones.slice(0, 200).map((p, i) => {
            const ok = !!bot?.sessions?.get?.(p)?.isConnected;
            if (ok) online++;
            return `${i + 1}. ${p} ${ok ? '🟢' : '🔴'}${p === owner ? ' 👑' : ''}`;
        });
        const more = phones.length > 200 ? `\n… و ${phones.length - 200} تانيين` : '';
        const mem = Math.round(process.memoryUsage().heapUsed / 1048576);
        return reply(`📋 *الأرقام المربوطة*\n\n${lines.join('\n')}${more}\n\n🔢 العدد: ${phones.length}\n🟢 متصل: ${online} | 🔴 مش متصل: ${phones.length - online}\n🧠 الذاكرة: ${mem}MB`);
    }
}];
