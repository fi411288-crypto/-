import fetch from 'node-fetch';

export default {
    name: 'كلمات',
    aliases: ['lyrics', 'ليركس', 'كلمات-اغنيه'],
    description: 'جلب كلمات أغنية',
    category: 'music',
    usage: '.كلمات اسم الأغنية',

    async run({ text, reply, react }) {
        const q = (text || '').trim();
        if (!q) return reply('❌ اكتب اسم الأغنية\nمثال: .كلمات shape of you');
        await react?.('⏳').catch?.(() => {});
        try {
            // lyrics.ovh
            let artist = '', title = q;
            if (q.includes('-')) {
                const sp = q.split('-').map(s => s.trim());
                artist = sp[0]; title = sp.slice(1).join('-').trim();
            }
            let url = artist
                ? `https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`
                : `https://some-random-api.com/lyrics?title=${encodeURIComponent(q)}`;
            let res = await fetch(url);
            let lyrics = '';
            if (res.ok) {
                const d = await res.json();
                lyrics = d.lyrics || d.plainLyrics || '';
                if (!artist && d.author) artist = d.author;
                if (d.title) title = d.title;
            }
            if (!lyrics) {
                // try search style
                res = await fetch(`https://lyrist.vercel.app/api/${encodeURIComponent(q)}`);
                if (res.ok) {
                    const d = await res.json();
                    lyrics = d.lyrics || '';
                    artist = d.artist || artist;
                    title = d.title || title;
                }
            }
            if (!lyrics) {
                await react?.('❌').catch?.(() => {});
                return reply('❌ ملقتش كلمات للأغنية دي');
            }
            await react?.('✅').catch?.(() => {});
            const head = `🎵 *${title}*${artist ? ' — ' + artist : ''}\n\n`;
            const body = lyrics.length > 3500 ? lyrics.slice(0, 3500) + '...' : lyrics;
            return reply(head + body);
        } catch (e) {
            await react?.('❌').catch?.(() => {});
            return reply('❌ خطأ: ' + (e.message || e));
        }
    }
};
