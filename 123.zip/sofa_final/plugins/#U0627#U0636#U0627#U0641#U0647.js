import fs from "fs";
import path from "path";
import os from "os";
import { execFileSync } from "child_process";
import { downloadContentFromMessage } from "@whiskeysockets/baileys";

const PLUGINS = () => path.join(process.cwd(), "plugins");

// توحيد الأسماء: يشيل النقطة والـ .js ويوحد ة/ه وأ/ا وي/ى ويتجاهل - _ والمسافات
const norm = (s) => String(s || "").trim().toLowerCase()
    .replace(/^[.!#/]+/, "").replace(/(\.js)+$/i, "")
    .replace(/[ً-ٟـ]/g, "")
    .replace(/[أإآ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه")
    .replace(/[\s_\-]+/g, "");

const listFiles = () => fs.readdirSync(PLUGINS()).filter((f) => f.endsWith(".js"));

// يلاقي ملف الأمر: بالاسم / بأسماء الملفات / بالأوامر المسجلة في البوت
function findPluginFile(handler, input) {
    const want = norm(input);
    if (!want) return null;
    const files = listFiles();
    const byFile = files.find((f) => norm(f) === want);
    if (byFile) return byFile;
    for (const p of handler?.plugins?.values?.() || []) {
        const names = [p.name, ...(p.aliases || []), ...(p.commands || []).flatMap((c) => [c.name, ...(c.aliases || [])])];
        if (names.some((n) => norm(n) === want) && p.filename && files.includes(p.filename)) return p.filename;
    }
    return null;
}

function similar(input) {
    const want = norm(input);
    return listFiles().filter((f) => want && norm(f).includes(want)).slice(0, 6);
}

const unwrap = (m) => {
    let x = m;
    for (let i = 0; i < 5 && x; i++) {
        const inner = x.ephemeralMessage?.message || x.viewOnceMessage?.message || x.documentWithCaptionMessage?.message;
        if (!inner) break;
        x = inner;
    }
    return x;
};

// الكود من الرد: نص عادي أو ملف .js مرفق
async function quotedCode(message) {
    const root = unwrap(message.message) || {};
    const ctx = Object.values(root).find((v) => v && typeof v === "object" && v.contextInfo?.quotedMessage)?.contextInfo;
    const q = unwrap(ctx?.quotedMessage);
    if (!q) return { error: "❌ رُد على رسالة فيها الكود (نص أو ملف .js)." };

    let code = q.conversation || q.extendedTextMessage?.text || "";
    if (!code && q.documentMessage) {
        const stream = await downloadContentFromMessage(q.documentMessage, "document");
        const chunks = [];
        for await (const c of stream) chunks.push(c);
        code = Buffer.concat(chunks).toString("utf8");
    }
    code = String(code).replace(/^﻿/, "").trim();
    // لو الكود جوه ``` ``` نشيلها
    code = code.replace(/^```[a-zA-Z]*\s*\n?/, "").replace(/\n?```\s*$/, "").trim();
    if (!code) return { error: "❌ الرسالة اللي رديت عليها مفيهاش كود." };
    return { code };
}

// يفحص الكود (syntax) قبل ما نكتبه عشان ميبوظش البوت
function syntaxError(code) {
    const tmp = path.join(os.tmpdir(), `chk_${Date.now()}.mjs`);
    try {
        fs.writeFileSync(tmp, code);
        execFileSync(process.execPath, ["--check", tmp], { stdio: "pipe" });
        return null;
    } catch (e) {
        return String(e.stderr || e.message || e).split("\n").filter(Boolean).slice(0, 4).join("\n");
    } finally {
        try { fs.unlinkSync(tmp); } catch {}
    }
}

function backup(file) {
    const dir = path.join(process.cwd(), "data", "plugin_backups");
    fs.mkdirSync(dir, { recursive: true });
    fs.copyFileSync(path.join(PLUGINS(), file), path.join(dir, `${file}.${Date.now()}.bak`));
}

export default {
    name: "اضافه",
    aliases: ["اضافة", "addcmd"],
    description: "إنشاء أمر جديد في plugins من كود في الرد",
    usage: ".اضافه اسم_الملف (رد على رسالة فيها الكود)",
    developer: true,

    async run({ message, reply, args }) {
        try {
            const raw = args.join(" ").trim().replace(/^[.!#/]+/, "").replace(/(\.js)+$/i, "");
            if (!raw) return reply("❌ حدد اسم الأمر.\nمثال: .اضافه سمسم (وارد على رسالة الكود)");
            if (/[\\/]|\.\./.test(raw)) return reply("❌ اسم غير صالح.");

            const exists = listFiles().find((f) => norm(f) === norm(raw));
            if (exists) return reply(`❌ في ملف بالاسم ده بالفعل: ${exists}\nلو عايز تعدله استخدم .تعديل ${raw}`);

            const { code, error } = await quotedCode(message);
            if (error) return reply(error);

            const bad = syntaxError(code);
            if (bad) return reply(`❌ الكود فيه خطأ كتابة ومش هتضيفه:\n${bad}`);

            fs.writeFileSync(path.join(PLUGINS(), `${raw}.js`), code);
            return reply(`✅ تم إنشاء الملف: plugins/${raw}.js\nالبوت هيحمّله لوحده، ولو معملش ريستارت.`);
        } catch (err) {
            return reply("❌ خطأ: " + err.message);
        }
    }
};
