import fetch from 'node-fetch';

const FOOTER = '> © 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀 𝐕𝐈𝐏';
const box = (lines) =>
    `╭─❏ 「 🌸 Wᴀʀᴍ Gᴘᴛ 」\n│\n${lines.map((l) => `│ ${l}`).join('\n')}\n╰───────────────\n${FOOTER}`;

const BASE_PROMPT = `You are WarmGPT, a warm, kind, emotionally intelligent, and supportive AI companion. 🌸✨
You speak with genuine care, empathy and gentle humor. You make people feel heard and valued.
You give thoughtful, encouraging, and practical answers. You never judge or roast the user.
You are knowledgeable, calm, and always try to lift the user's mood when they seem down.
Keep responses clear, warm, and not too long. End with a soft positive emoji when appropriate.
If the user asks something harmful, gently redirect them with care instead of helping.`;

const LANG = {
    en: { rule: 'LANGUAGE RULE: reply ONLY in warm, friendly English.', hint: '(Reply in warm English.)' },
    ar: { rule: 'LANGUAGE RULE: reply ONLY in soft Egyptian Arabic (عامية مصرية حنونة ولطيفة), with the same warm supportive style.', hint: '(رد بالعامية المصرية الحنونة.)' }
};

async function askGroq(question, lang = 'ar') {
    let _km = {};
    try { _km = await import('../keys.js'); } catch {}
    const _groqKeys = _km.GROQ_API_KEYS?.length
        ? _km.GROQ_API_KEYS
        : [_km.GROQ_API_KEY || process.env.GROQ_KEY_1 || process.env.GROQ_API_KEY || ''].filter(Boolean);

    if (!_groqKeys.length) throw new Error('مفيش مفتاح GROQ. حط GROQ_KEY_1 في البيئة أو keys.js');

    const callGroq = async (payload) => {
        const tried = new Set();
        for (let i = 0; i < _groqKeys.length; i++) {
            const k = (_km.getNextGroqKey?.()) || _groqKeys[i];
            if (!k || tried.has(k)) continue;
            tried.add(k);
            const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${k}`, 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            if ((r.status === 429 || r.status === 401 || r.status === 403) && _groqKeys.length > 1) {
                _km.markKeyFailed?.(k);
                continue;
            }
            return r;
        }
        throw new Error('كل مفاتيح GROQ خلصت');
    };

    const L = LANG[lang] || LANG.ar;
    const response = await callGroq({
        model: 'openai/gpt-oss-120b',
        messages: [
            { role: 'system', content: `${BASE_PROMPT}\n\n${L.rule}` },
            { role: 'user', content: `${question}\n\n${L.hint}` }
        ],
        temperature: 0.75,
        max_completion_tokens: 4096,
        reasoning_effort: 'medium'
    });
    if (!response.ok) {
        const errText = await response.text().catch(() => '');
        throw new Error(`API error: ${response.status} ${errText.slice(0, 120)}`);
    }
    const data = await response.json();
    const result = data.choices?.[0]?.message?.content;
    if (!result) throw new Error('الرد فاضي من الـ API');
    return result;
}

function detectLang(text) {
    const t = String(text || '').trim().toLowerCase();
    // أول كلمة لغة اختيارية: en / eng / english / ar / عربي ...
    if (/^(en|eng|english|انجليزي|إنجليزي)\b/.test(t)) return { lang: 'en', rest: t.replace(/^(en|eng|english|انجليزي|إنجليزي)\s*/i, '').trim() };
    if (/^(ar|arab|arabic|عربي|عربى)\b/.test(t)) return { lang: 'ar', rest: t.replace(/^(ar|arab|arabic|عربي|عربى)\s*/i, '').trim() };
    return { lang: 'ar', rest: String(text || '').trim() }; // افتراضي عربي
}

export default {
    name: 'warmgpt',
    aliases: ['warm', 'دافي', 'ودود', 'حنون', 'ورمجبت'],
    description: '🌸 WarmGPT — ذكاء اصطناعي دافئ ولطيف (VIP فقط)',
    category: 'ai',
    vip: true,
    usage: '.warmgpt <سؤالك>',

    async run({ sock, m, message, text, reply, react, prefix }) {
        const msg = m || message;
        const jid = msg?.key?.remoteJid;
        const doReact = async (emoji) => {
            try {
                if (typeof react === 'function') await react(emoji);
                else if (sock && msg?.key) await sock.sendMessage(jid, { react: { text: emoji, key: msg.key } });
            } catch {}
        };
        const send = async (t) => {
            if (typeof reply === 'function') return reply(t);
            return sock.sendMessage(jid, { text: t }, { quoted: msg });
        };

        const raw = (text || '').trim();

        if (!raw) {
            await doReact('❌');
            return send(box([
                'اكتب سؤالك بعد الأمر يا قلبي 🌸',
                '',
                'مثال:',
                `${prefix || '.'}warmgpt أنا حاسس بإحباط`,
                `${prefix || '.'}warmgpt en how are you`,
                '',
                'الافتراضي: عربي 🇪🇬',
                'للإنجليزي: ابدأ بـ en'
            ]));
        }

        // تنظيف أي \ قبل ~ لو المستخدم نسخ غلط
        const cleaned = raw.replace(/\\~/g, '~').replace(/^~\S+\s*(ar|en)\s*/i, '').trim() || raw;
        const { lang, rest } = detectLang(cleaned);
        const question = rest || cleaned;

        if (!question) {
            await doReact('❌');
            return send(box(['اكتب السؤال بعد الأمر 🌸']));
        }

        await doReact('⌛');
        try {
            const answer = await askGroq(question, lang);
            await doReact('🌸');
            if (answer.length > 3500) {
                const chunks = answer.match(/[\s\S]{1,3400}/g) || [answer];
                for (const c of chunks) await send(box([c]));
                return;
            }
            return send(box([answer]));
        } catch (e) {
            await doReact('❌');
            return send(box(['حصل خطأ: ' + (e.message || e)]));
        }
    }
};
