// 📣 للمطور: كل الأرقام المربوطة تبعت رابطين القناتين في كل جروباتها — SOFA BOT
// رقم المطور 201018766845 مش بيبعتوا أي حاجة لأي حد.
import { castToGroups } from '../lib/cast.js';
import { TG_CHANNEL_URL, WA_CHANNEL_URL, TASK_REWARD } from '../lib/tgTasks.js';
import { fmt } from '../lib/shop.js';
import { isDevSender } from '../lib/devAuth.js';

let running = false;

const BODY =
    `🎁 *مهام SOFA BOT — اكسب ${fmt(TASK_REWARD * 2)} كوين!*\n\n` +
    `📢 قناة التليجرام:\n${TG_CHANNEL_URL}\n\n` +
    `💬 قناة الواتساب:\n${WA_CHANNEL_URL}\n\n` +
    `تابع القناتين ✅ وادخل بوت التليجرام واضغط (🎁 المهام) ← (تحقق) واستلم ${fmt(TASK_REWARD)} كوين عن كل قناة.`;

export default [{
    name: 'اذاعه-مهام',
    aliases: ['اذاعة-مهام', 'اذاعه_مهام', 'اذاعة_مهام', 'إذاعه-مهام', 'taskcast'],
    description: 'اذاعة رابطين القناتين من كل الأرقام المربوطة لكل جروباتها',
    category: 'dev',
    async run(ctx) {
        const { reply } = ctx;
        if (!(await isDevSender(ctx))) return reply('❌ الأمر ده للمطور فقط.');
        if (running) return reply('⏳ في إذاعة شغالة دلوقتي، استنى تخلص.');
        running = true;
        try {
            await reply('📣 بدأت إذاعة المهام من الأرقام المربوطة... (هبعتلك التقرير لما تخلص)');
            const t = await castToGroups(BODY);
            if (!t.sessions) return reply('❌ مفيش أرقام مربوطة متصلة دلوقتي.');
            const lines = t.results.map((r) => r.error ? `• ${r.phone}: ❌ ${r.error}` : `• ${r.phone}: ✅ ${r.sent} | ⏭️ ${r.skipped} | ❌ ${r.failed}`);
            await reply(`📣 *تقرير إذاعة المهام*\n\n${lines.join('\n')}\n\n✅ اتبعت: ${t.sent}\n⏭️ اتخطى (جروب مقفول): ${t.skipped}\n❌ فشل: ${t.failed}`);
        } finally { running = false; }
    }
}];
