import { downloadContentFromMessage } from '@whiskeysockets/baileys';

export default {
    name: 'لصورة',
    aliases: ['toimg', 'toimage', 'تحويل-صورة'],
    description: 'تحويل ملصق إلى صورة (رد على الملصق)',
    category: 'tools',

    async run({ sock, m, message, reply, react }) {
        const msg = m || message;
        const q = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!q?.stickerMessage) return reply('❌ رد على ملصق');
        await react?.('⏳').catch?.(() => {});
        try {
            const stream = await downloadContentFromMessage(q.stickerMessage, 'sticker');
            const chunks = [];
            for await (const c of stream) chunks.push(c);
            const buf = Buffer.concat(chunks);
            await react?.('✅').catch?.(() => {});
            return sock.sendMessage(msg.key.remoteJid, { image: buf, caption: '🖼️ تم التحويل' }, { quoted: msg });
        } catch (e) {
            await react?.('❌').catch?.(() => {});
            return reply('❌ فشل التحويل: ' + (e.message || e));
        }
    }
};
