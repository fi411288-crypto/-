import { jidDecode } from "@whiskeysockets/baileys";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export default {
  name: 'بوم',
  category: 'admin',
  group: true,
  admin: true,
  vip: true,
  category: 'wars',
  run: async (context) => {
    const { sock, m } = context;
    const jid = m.key.remoteJid;
    const botJid = (jidDecode(sock.user.id)?.user || sock.user.id.split("@")[0]) + "@s.whatsapp.net";

    await sock.sendMessage(jid, { text: "*⌛️ حدد ثواني الانفجار (1-60)⏳️*" }, { quoted: m });

    const listener = async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message || msg.key.remoteJid !== jid) return;
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
        const count = parseInt(text.trim());
        if (isNaN(count) || count < 1 || count > 60) return;

        sock.ev.off("messages.upsert", listener);
        for (let i = count; i >= 0; i--) {
            await sleep(1000);
            await sock.sendMessage(jid, { text: `*${i} 💣*` });
        }

        const meta = await sock.groupMetadata(jid);
        const toKick = meta.participants.filter(p => p.id !== botJid && !p.admin).map(p => p.id);
        if (toKick.length > 0) {
            await sock.groupParticipantsUpdate(jid, toKick, 'remove');
            await sock.sendMessage(jid, { text: '💥 *تمت الإبادة!*' });
        }
    };
    sock.ev.on("messages.upsert", listener);
  }
};
