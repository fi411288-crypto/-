import { makeNsfwCommand } from '../lib/nsfw.js';
// ملاحظة: المسار هنا نفس مسار anal زي ما كان في الكود اللي بعتّه. غيّره لمسار boobs لو لقيت واحد شغال
export default makeNsfwCommand({ name: 'boobs', aliases: ['tits'], title: 'Boobs', emoji: '🍒', endpoint: 'https://prexzyapis.com/nsfw/anal', usage: '.boobs أو .tits' });
