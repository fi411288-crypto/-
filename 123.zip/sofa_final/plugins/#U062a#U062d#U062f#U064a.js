// ⚔️ تحدي: مبارزة بين اتنين على كوين بأسئلة من ألعاب data/games (أحسن 2 من 3) — SOFA BOT
import fs from 'fs';
import path from 'path';
import { hook, targetJid, digits } from '../lib/xtools.js';
import { normAr } from '../lib/community.js';
import { resolveNumber, isRegistered, updateUser } from '../lib/economy.js';
import { fmt, numberOfJid, toEnDigits, questBump } from '../lib/shop.js';

const DIR = path.join(process.cwd(), 'data', 'games');
const ROUNDS = 3, TIME = 25000, ASK_TTL = 60000, MIN = 50, MAX = 100000, DEF = 100, FEE = 0.05;
const duels = new Map(); // jid -> state
const cache = [];

function pick() {
    if (!cache.length) {
        try {
            for (const f of fs.readdirSync(DIR).filter((x) => x.endsWith('.json'))) {
                const arr = JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8'));
                if (Array.isArray(arr)) cache.push(...arr.filter((x) => x?.question && x?.response).map((x) => ({ q: String(x.question), a: [x.response, ...(Array.isArray(x.alt) ? x.alt : x.alt ? [x.alt] : [])].map(String) })));
            }
        } catch {}
    }
    return cache[Math.floor(Math.random() * cache.length)] || null;
}
const ok = (n, a) => n === a || (a.length >= 3 && n.includes(a) && n.length <= a.length + 12);
const tag = (j) => `@${digits(j)}`;
const send = (st, content) => st.sock.sendMessage(st.jid, content).catch(() => {});
const credit = (num, coin) => updateUser(num, (u, eco) => { eco.coin += coin; });

function ask(st) {
    const q = pick();
    if (!q) { refund(st); return send(st, { text: '❌ مفيش أسئلة في data/games. اتلغى التحدي واتردت الكوينات.' }); }
    st.round++;
    st.answers = q.a.map(normAr).filter(Boolean);
    st.shown = q.a[0];
    send(st, { text: `⚔️ *الجولة ${st.round}/${ROUNDS}*\n\n❓ ${q.q}\n\n✍️ أول واحد يكتب الإجابة صح ياخد النقطة (${TIME / 1000} ثانية)` });
    st.timer = setTimeout(() => {
        if (duels.get(st.jid) !== st) return;
        st.answers = [];
        send(st, { text: `⌛ الوقت خلص! الإجابة كانت: *${st.shown}*` });
        next(st);
    }, TIME);
}
function next(st) {
    if (st.score.a === 2 || st.score.b === 2 || st.round >= ROUNDS) return setTimeout(() => settle(st), 1500);
    setTimeout(() => duels.get(st.jid) === st && ask(st), 2500);
}
function refund(st) { clearTimeout(st.timer); duels.delete(st.jid); credit(st.a.num, st.amount); credit(st.b.num, st.amount); }
function settle(st) {
    if (duels.get(st.jid) !== st) return;
    clearTimeout(st.timer); duels.delete(st.jid);
    const { a, b, score } = st;
    if (score.a === score.b) {
        credit(a.num, st.amount); credit(b.num, st.amount);
        return send(st, { text: `🤝 *تعادل ${score.a}-${score.b}!*\nاتردّت الكوينات للاتنين.`, mentions: [a.jid, b.jid] });
    }
    const w = score.a > score.b ? a : b, prize = Math.floor(st.amount * 2 * (1 - FEE));
    updateUser(w.num, (u, eco) => { eco.coin += prize; eco.exp += 50; });
    send(st, { text: `🏆 *الفايز: ${tag(w.jid)}*\n📊 النتيجة: ${score.a}-${score.b}\n💰 الجايزة: \`${fmt(prize)}\` كوين (+50 XP)\n\n> SOFA BOT`, mentions: [a.jid, b.jid] });
}

hook('duel', async ({ message, text, sock, jid, isCmd }) => {
    const st = duels.get(jid);
    if (!st || st.stage !== 'play' || !st.answers.length || isCmd || !text) return;
    const n = normAr(text);
    if (!st.answers.some((a) => ok(n, a))) return;
    const num = await resolveNumber(sock, message);
    const side = num === st.a.num ? 'a' : num === st.b.num ? 'b' : null;
    if (!side || !st.answers.length) return;
    st.answers = []; clearTimeout(st.timer);
    st.score[side]++;
    send(st, { text: `✅ ${tag(st[side].jid)} جاوب صح! النتيجة ${st.score.a}-${st.score.b}`, mentions: [st[side].jid] });
    next(st);
});

const gate = async (sock, msg, reply, prefix) => {
    const n = await resolveNumber(sock, msg);
    if (!n || !isRegistered(n)) { reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`); return null; }
    return n;
};

export default [
    {
        name: 'تحدي',
        aliases: ['duel', 'تحدى'],
        category: 'games',
        group: true,
        description: 'تحدي عضو على كوين بأسئلة (أحسن 2 من 3)',
        usage: '.تحدي @العضو 500',
        cooldown: 3000,
        async run({ sock, m, message, args, reply, prefix = '.' }) {
            const msg = m || message, jid = msg.key.remoteJid;
            const from = await gate(sock, msg, reply, prefix);
            if (!from) return;
            if (duels.has(jid)) return reply('⏳ فيه تحدي شغال في الجروب، استنى يخلص.');
            const target = targetJid(msg);
            if (!target) return reply(`❌ اعمل منشن للعضو أو رد على رسالته:\n*${prefix}تحدي @العضو 500*`);
            const to = await numberOfJid(sock, target);
            if (!to || to === from) return reply('😅 مينفعش تتحدى نفسك.');
            if (!isRegistered(to)) return reply('❌ العضو ده مش مسجّل في البوت (.تسجيل).');
            const amount = parseInt(args.map(toEnDigits).find((x) => /^\d{1,9}$/.test(x)) || DEF, 10);
            if (amount < MIN || amount > MAX) return reply(`❌ المبلغ من ${fmt(MIN)} لـ ${fmt(MAX)}.`);
            const st = { jid, sock, stage: 'ask', amount, a: { num: from, jid: msg.key.participant || msg.key.remoteJid }, b: { num: to, jid: target }, round: 0, score: { a: 0, b: 0 }, answers: [] };
            duels.set(jid, st);
            st.timer = setTimeout(() => { if (duels.get(jid) === st && st.stage === 'ask') { duels.delete(jid); send(st, { text: '⌛ التحدي اتلغى (محدش رد).' }); } }, ASK_TTL);
            return reply({ text: `⚔️ *SOFA • DUEL*\n\n${tag(st.a.jid)} بيتحداك يا ${tag(target)}!\n💰 الرهان: \`${fmt(amount)}\` كوين من كل واحد\n🏆 الفايز ياخد \`${fmt(Math.floor(amount * 2 * (1 - FEE)))}\`\n\n✅ *${prefix}قبول*   ❌ *${prefix}رفض*\n(معاك دقيقة)`, mentions: [st.a.jid, target] });
        }
    },
    {
        name: 'قبول',
        aliases: ['accept'],
        category: 'games',
        group: true,
        description: 'قبول تحدي موجّه ليك',
        cooldown: 2000,
        async run({ sock, m, message, reply, prefix = '.' }) {
            const msg = m || message, jid = msg.key.remoteJid, st = duels.get(jid);
            if (!st || st.stage !== 'ask') return reply('ℹ️ مفيش تحدي مستني ردك.');
            const me = await gate(sock, msg, reply, prefix);
            if (!me) return;
            if (me !== st.b.num) return reply('❌ التحدي ده مش ليك.');
            clearTimeout(st.timer);
            const ra = updateUser(st.a.num, (u, eco) => { if (eco.coin < st.amount) return { error: 'funds' }; eco.coin -= st.amount; });
            if (!ra.ok) { duels.delete(jid); return reply('❌ المتحدي مش معاه رصيد كفاية. اتلغى التحدي.'); }
            const rb = updateUser(st.b.num, (u, eco) => { if (eco.coin < st.amount) return { error: 'funds' }; eco.coin -= st.amount; });
            if (!rb.ok) { duels.delete(jid); credit(st.a.num, st.amount); return reply('❌ رصيدك مش كفاية للتحدي. اتلغى.'); }
            st.stage = 'play';
            questBump(st.a.num, 'duel'); questBump(st.b.num, 'duel');
            await reply({ text: `🔥 *بدأ التحدي!*\n${tag(st.a.jid)} ⚔️ ${tag(st.b.jid)}\n💰 على \`${fmt(st.amount * 2)}\` كوين — أحسن 2 من ${ROUNDS}`, mentions: [st.a.jid, st.b.jid] });
            setTimeout(() => duels.get(jid) === st && ask(st), 2500);
        }
    },
    {
        name: 'رفض',
        aliases: ['decline'],
        category: 'games',
        group: true,
        description: 'رفض تحدي (أو المتحدي يلغيه قبل القبول)',
        cooldown: 2000,
        async run({ sock, m, message, reply }) {
            const msg = m || message, jid = msg.key.remoteJid, st = duels.get(jid);
            if (!st || st.stage !== 'ask') return reply('ℹ️ مفيش تحدي مستني ردك.');
            const me = await resolveNumber(sock, msg);
            if (me !== st.b.num && me !== st.a.num) return reply('❌ التحدي ده مش ليك.');
            clearTimeout(st.timer); duels.delete(jid);
            return reply(me === st.a.num ? '🚫 المتحدي لغى التحدي.' : '🚫 تم رفض التحدي.');
        }
    }
];
