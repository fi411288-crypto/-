export default {
  name: 'فحص_الاوامر',
  category: 'dev',
  developer: true,
  aliases: ['فحص-الاوامر', 'commandcheck', 'commandaudit'],
  description: 'فحص الأوامر المسجلة ومطابقتها مع القائمة',
  run: async ({ client, m, bot }) => {
    const handler = bot?.handler || global.bot?.handler;
    if (!handler?.commands) {
      return client.sendMessage(m.chat, { text: '❌ لا يمكن الوصول إلى نظام الأوامر الآن.' }, { quoted: m });
    }
    const count = handler.commands.size;
    const plugins = handler.plugins?.size || 0;
    const aliases = handler.aliases?.size || 0;
    const lines = [
      '╭─❏ 「 SOFA COMMAND AUDIT 」',
      `│ ✅ أوامر مسجلة: ${count}`,
      `│ 📦 Plugins محملة: ${plugins}`,
      `│ 🔗 Aliases: ${aliases}`,
      '│',
      '│ القائمة تعتمد الآن على الأوامر المسجلة فعليًا.',
      '╰───────────────'
    ];
    return client.sendMessage(m.chat, { text: lines.join('\n') }, { quoted: m });
  }
};
