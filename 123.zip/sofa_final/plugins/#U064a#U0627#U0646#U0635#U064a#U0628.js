// 🎟️ اليانصيب — سحب يومي مجاني + سحب جماعي بتذاكر افتراضية — SOFA BOT
// .يانصيب          → حالة السحب
// .يانصيب مجاني    → سحبة مجانية كل يوم
// .يانصيب شراء 3   → اشتري تذاكر (السحب الكبير كل 24 ساعة)
import { resolveNumber, isRegistered, updateUser, getUser, addRewards } from '../lib/economy.js';
import { cairoDay } from '../lib/community.js';
import { store, job } from '../lib/xtools.js';
import { fmt, toEnDigits } from '../lib/shop.js';

const DAY = 864e5;
const TICKET = 500;        // سعر التذكرة
const MAX_TICKETS = 20;    // أقصى تذاكر للشخص في الجولة
const PAYOUT = 0.9;        // 90% من الصندوق للفايز (10% بيتحرق)
// [احتمال %, الجايزة] — السحبة المجانية
const FREE = [[50, 0], [25, 200], [14, 500], [8, 1000], [2.7, 3000], [0.3, 15000]];

const lot = () => {
    const s = store('lottery', {});
    const d = s.data;
    d.round ||= 1; d.pot ||= 0; d.tickets ||= {}; d.endsAt ||= Date.now() + DAY;
    return { s, d };
};
const left = (t) => {
    const ms = Math.max(0, t - Date.now());
    return `${Math.floor(ms / 36e5)} ساعة و ${Math.floor((ms % 36e5) / 6e4)} دقيقة`;
};

// السحب الكبير: كل ما الوقت يخلص (لازم لاعبين اتنين على الأقل وإلا بيتمدّد 24 ساعة)
job('lottery-draw', async () => {
    const { s, d } = lot();
    if (Date.now() < d.endsAt) return;
    const entries = Object.entries(d.tickets);
    if (entries.length < 2) { d.endsAt = Date.now() + DAY; s.save(); return; }
    const total = entries.reduce((a, [, n]) => a + n, 0);
    let roll = Math.random() * total, winner = entries[0][0];
    for (const [num, n] of entries) { roll -= n; if (roll <= 0) { winner = num; break; } }
    const payout = Math.floor(d.pot * PAYOUT);
    addRewards(winner, 0, payout);
    updateUser(winner, (u) => { u.lotteryWins = (u.lotteryWins || 0) + 1; });
    d.last = { round: d.round, winner, name: getUser(winner)?.name || winner, payout, players: entries.length, tickets: total, at: Date.now() };
    d.round++; d.pot = 0; d.tickets = {}; d.endsAt = Date.now() + DAY;
    s.save();
}, 60000);

export default [{
    name: 'يانصيب',
    aliases: ['lottery', 'لوتري', 'سحب'],
    category: 'games',
    description: 'يانصيب: سحبة مجانية يومياً أو تذاكر للسحب الكبير',
    usage: '.يانصيب | .يانصيب مجاني | .يانصيب شراء 3',
    cooldown: 3000,
    async run({ sock, m, message, args, reply, prefix = '.' }) {
        const msg = m || message;
        const number = await resolveNumber(sock, msg);
        if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);

        const sub = (args[0] || '').toLowerCase();

        // ───── سحبة مجانية ─────
        if (['مجاني', 'مجانا', 'free'].includes(sub)) {
            const today = cairoDay();
            const sum = FREE.reduce((a, [p]) => a + p, 0);
            let roll = Math.random() * sum, prize = 0;
            for (const [p, c] of FREE) { roll -= p; if (roll <= 0) { prize = c; break; } }
            const r = updateUser(number, (u, eco) => {
                if (u.lotteryFree === today) return { error: 'used' };
                u.lotteryFree = today;
                eco.coin += prize;
                return { coin: eco.coin };
            });
            if (r.error === 'used') return reply('⏳ استخدمت سحبتك المجانية النهارده، ارجع بكرة 🎟️');
            if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ، حاول تاني.');
            return reply(`🎟️ *SOFA • FREE DRAW*\n\n` + (prize ? `🎉 كسبت \`${fmt(prize)}\` كوين!` : '😅 الحظ مش معاك المرة دي، جرّب بكرة.') + `\n💼 رصيدك: \`${fmt(r.coin)}\``);
        }

        // ───── شراء تذاكر ─────
        if (['شراء', 'اشتري', 'تذكرة', 'تذاكر', 'buy'].includes(sub)) {
            const qty = Math.max(1, parseInt(toEnDigits(args[1] || '1'), 10) || 1);
            const { s, d } = lot();
            const have = d.tickets[number] || 0;
            if (have + qty > MAX_TICKETS) return reply(`❌ أقصى عدد تذاكر ليك في الجولة *${MAX_TICKETS}* (معاك ${have}).`);
            const cost = qty * TICKET;
            const r = updateUser(number, (u, eco) => {
                if (eco.coin < cost) return { error: 'funds', have: eco.coin };
                eco.coin -= cost;
                return { coin: eco.coin };
            });
            if (r.error === 'funds') return reply(`❌ رصيدك مش كفاية!\n💰 معاك: \`${fmt(r.have)}\`\n📤 المطلوب: \`${fmt(cost)}\``);
            if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ، حاول تاني.');
            d.tickets[number] = have + qty; d.pot += cost; s.save();
            const total = Object.values(d.tickets).reduce((a, n) => a + n, 0);
            return reply(`🎟️ *SOFA • LOTTERY*\n\n✅ اشتريت *${qty}* تذكرة بـ \`${fmt(cost)}\`\n🎫 تذاكرك: *${d.tickets[number]}* من ${total} (فرصتك ${((d.tickets[number] / total) * 100).toFixed(1)}%)\n💰 الصندوق: \`${fmt(d.pot)}\`\n⏳ السحب بعد: ${left(d.endsAt)}\n💼 رصيدك: \`${fmt(r.coin)}\``);
        }

        // ───── الحالة ─────
        const { d } = lot();
        const mine = d.tickets[number] || 0;
        const total = Object.values(d.tickets).reduce((a, n) => a + n, 0);
        const players = Object.keys(d.tickets).length;
        const freeUsed = getUser(number)?.lotteryFree === cairoDay();
        return reply(
            `🎟️ *SOFA • LOTTERY*\n\n🏆 الجولة رقم *${d.round}*\n💰 الصندوق: \`${fmt(d.pot)}\` (الفايز ياخد ${PAYOUT * 100}%)\n` +
            `👥 لاعبين: ${players} • 🎫 تذاكر: ${total}\n🎫 تذاكرك: *${mine}*${total && mine ? ` (${((mine / total) * 100).toFixed(1)}%)` : ''}\n⏳ السحب بعد: ${left(d.endsAt)}\n` +
            (players < 2 ? '⚠️ لازم لاعبين اتنين على الأقل وإلا السحب بيتأجل.\n' : '') +
            (d.last ? `\n🥇 آخر فايز: *${d.last.name}* — \`${fmt(d.last.payout)}\`\n` : '') +
            `\n🎁 السحبة المجانية: ${freeUsed ? '✅ استخدمتها النهارده' : `*${prefix}يانصيب مجاني*`}\n🛒 تذكرة بـ \`${fmt(TICKET)}\`: *${prefix}يانصيب شراء 3*`
        );
    }
}];
