import { getGroup, cairoDay, digits, mentionOf } from '../lib/community.js';
import { getMetadata } from '../lib/compat.js';
import { hook } from '../lib/xtools.js';

// عدّاد رسائل كل عضو لكل يوم (بيتخزن جوه بيانات الجروب، آخر 8 أيام)
hook('report', ({ g, uid }) => {
    const ud = (g.ud ||= {}), d = cairoDay();
    (ud[d] ||= {})[uid] = (ud[d][uid] || 0) + 1;
    const old = cairoDay(Date.now() - 8 * 864e5);
    for (const k of Object.keys(ud)) if (k < old) delete ud[k];
});

const sumDays = (g, n) => {
    const t = {};
    for (let i = 0; i < n; i++) for (const [u, c] of Object.entries(g.ud?.[cairoDay(Date.now() - i * 864e5)] || {})) t[u] = (t[u] || 0) + c;
    return t;
};

export default {
    name: 'تقرير',
    aliases: ['report', 'تقارير'],
    description: 'إحصائيات الجروب: أنشط الأعضاء وعدد الرسائل النهاردة',
    usage: '.تقرير',
    category: 'tools',
    group: true,
    async run({ sock, message, reply, bot }) {
        const jid = message.key.remoteJid;
        const { g } = getGroup(bot?.phone, jid);
        let members = '؟', name = 'الجروب';
        try { const m = await getMetadata(sock, jid); members = m.participants.length; name = m.subject || name; } catch {}
        const today = g.days[cairoDay()] || 0, yest = g.days[cairoDay(Date.now() - 864e5)] || 0;
        let week = 0; for (let i = 0; i < 7; i++) week += g.days[cairoDay(Date.now() - i * 864e5)] || 0;
        const mentions = [];
        const rank = (obj) => Object.entries(obj).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([id, n], i) => {
            const u = g.users[id], j = u?.jid || mentionOf(id); mentions.push(j);
            return `${['🥇', '🥈', '🥉'][i] || `${i + 1}.`} @${digits(j)} — ${n}`;
        });
        const td = rank(sumDays(g, 1)), wk = rank(sumDays(g, 7));
        const cmds = Object.entries(g.cmds).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([c, n]) => `${c} (${n})`).join('، ');
        return reply({
            text: `📊 *تقرير ${name}*\n\n👥 الأعضاء: *${members}*\n💬 رسائل النهاردة: *${today}* | أمس: ${yest}\n📅 آخر 7 أيام: *${week}*\n🧮 الإجمالي: ${g.msgs}\n⚙️ أوامر مستخدمة: ${g.cmdTotal}${cmds ? `\n🔥 أكتر أوامر: ${cmds}` : ''}\n\n🗣️ *أنشط اليوم:*\n${td.join('\n') || '— لسه'}\n\n🏆 *أنشط الأسبوع:*\n${wk.join('\n') || '— لسه (الأرقام بتبدأ من أول تركيب الأمر)'}\n\n> SOFA BOT`,
            mentions
        });
    }
};
