// 🤝 دعوة: ابعت لينكك لصحابك — كل واحد يربط رقمه بالبوت تاخد 2000 كوين — SOFA BOT
import { resolveNumber, isRegistered } from '../lib/economy.js';
import { inviteCount, REF_REWARD } from '../lib/referral.js';
import { fmt } from '../lib/shop.js';

export default [{
    name: 'دعوة',
    aliases: ['دعوه', 'invite', 'ref'],
    category: 'games',
    description: 'لينك دعوة خاص بيك — 2000 كوين لكل صديق يربط رقمه',
    cooldown: 3000,
    async run({ sock, m, message, reply, prefix = '.' }) {
        const number = await resolveNumber(sock, m || message);
        if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
        const botName = global.bot?.telegram?.botUsername || 'Sofa48755_Bot';
        const n = inviteCount(number);
        return reply(
            `🤝 *SOFA • INVITE*\n\n` +
            `ابعت اللينك ده لصحابك:\nhttps://t.me/${botName}?start=ref_${number}\n\n` +
            `🎁 كل صديق يدخل من لينكك ويربط رقمه = \`+${fmt(REF_REWARD)}\` كوين ليك\n` +
            `👥 دعواتك الناجحة: \`${n}\`\n💰 كسبت من الدعوات: \`${fmt(n * REF_REWARD)}\`\n\n> SOFA BOT`
        );
    }
}];
