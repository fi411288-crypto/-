import { groqChat, MODELS, imageOf, reactor, AiError } from '../lib/groq.js';

const SYSTEM = 'إنت خبير في تحليل الصور. اشرح محتوى الصورة بالتفصيل بالعربي بلهجة بسيطة: إيه اللي فيها، الأشخاص/الأشياء، الألوان، أي نص مكتوب (انقله كما هو)، والمكان أو السياق لو واضح. ' +
    'لو الصورة سكرين شوت لتطبيق أو خطأ، اشرح اللي ظاهر واقترح الحل. لو المستخدم طلب حاجة معينة جاوب عليها هي. متخمنش هوية أشخاص حقيقيين من وشوشهم.';

export default {
    name: 'حلل-صورة',
    aliases: ['حلل_صورة', 'تحليل', 'analyze'],
    description: 'تبعت صورة أو سكرين شوت والبوت يشرح محتواها',
    usage: '.حلل-صورة (رد على صورة أو ابعتها بالكابشن)',
    category: 'ai',
    async run({ sock, message, text, reply, prefix }) {
        const react = reactor(sock, message);
        let image;
        try { image = await imageOf(sock, message); }
        catch (e) { return reply(`❌ ${e.message}`); }
        if (!image) return reply(`🖼️ رد على صورة واكتب ${prefix}حلل-صورة\nأو ابعت الصورة وفي الكابشن ${prefix}حلل-صورة\nتقدر تزود طلب: ${prefix}حلل-صورة اقرأ النص اللي فيها`);

        await react('⌛');
        try {
            const out = await groqChat({
                model: MODELS.vision, max: 1800,
                messages: [
                    { role: 'system', content: SYSTEM },
                    { role: 'user', content: [
                        { type: 'text', text: (text || '').trim() || 'حلل الصورة دي واشرح محتواها.' },
                        { type: 'image_url', image_url: { url: image } }
                    ] }
                ]
            });
            await react('✅');
            return reply(`🖼️ *تحليل الصورة*\n\n${out}\n\n> SOFA BOT`);
        } catch (e) {
            await react('❌');
            return reply(`❌ ${e instanceof AiError ? e.message : 'حصل خطأ: ' + e.message}`);
        }
    }
};
