// ================== Luxury Bomb Game ==================

let bombGames = {};

export default {
    name: "قنبله",
    description: "𝐒𝐎𝐅𝐀 Bomb Game",
    async run({ sock, message, reply }) {

        const groupJid = message.key.remoteJid;

        // إذا في لعبة شغالة بالفعل للجروب
        if (bombGames[groupJid]) {
            return reply("⚠️ في لعبة شغالة بالفعل في الجروب!");
        }

        const metadata = await sock.groupMetadata(groupJid);
        let players = metadata.participants
            .map(p => p.id)
            .filter(id => id !== sock.user.id);

        if (players.length < 2)
            return reply("🚫 محتاجين عضوين على الأقل!");

        // إنشاء حالة اللعبة
        bombGames[groupJid] = {
            players,
            currentPlayer: null,
            timeout: null,
            paused: false
        };

        const game = bombGames[groupJid];

        const randomPlayer = () =>
            game.players[Math.floor(Math.random() * game.players.length)];

        const endGame = async (winner = null) => {
            clearTimeout(game.timeout);

            if (winner) {
                await sock.sendMessage(groupJid, {
                    text:
`╭─── 💎 𝐒𝐎𝐅𝐀 𝐁𝐎𝐓 𝗕𝗢𝗠𝗕 💎 ───╮
🏆 الفائز النهائي:
➤ @${winner.split('@')[0]}
╰────────────────────╯`,
                    mentions: [winner]
                });
            }

            delete bombGames[groupJid];
        };

        const explode = async () => {
            if (game.paused) return; // إذا اللعبة متوقفة ما انفجرش

            const loser = game.currentPlayer;

            await sock.sendMessage(groupJid, {
                text:
`╭─── 💣 𝗕𝗢𝗠𝗕 𝗘𝗫𝗣𝗟𝗢𝗗𝗘𝗗 💣 ───╮
💥 انفجرت على:
➤ @${loser.split('@')[0]}
❌ خرج من اللعبة
╰────────────────────╯`,
                mentions: [loser]
            });

            game.players = game.players.filter(p => p !== loser);

            if (game.players.length === 1) {
                return endGame(game.players[0]);
            }

            startRound();
        };

        const startRound = async () => {
            if (game.paused) return; // ما تبدأش لو اللعبة متوقفة

            game.currentPlayer = randomPlayer();

            await sock.sendMessage(groupJid, {
                text:
`╭─── 💎 𝐒𝐎𝐅𝐀 𝐁𝐎𝐓 𝗕𝗢𝗠𝗕 💎 ───╮
💣 القنبلة مع:
➤ @${game.currentPlayer.split('@')[0]}
⚡ حولها بسرعة قبل الانفجار!
👥 المتبقين: ${game.players.length}
╰────────────────────╯`,
                mentions: [game.currentPlayer]
            });

            const time = (Math.floor(Math.random() * 26) + 5) * 1000; // 5-30 ثانية عشوائي
            game.timeout = setTimeout(explode, time);
        };

        // Listener واحد فقط
        if (!global.bombListenerAdded) {
            global.bombListenerAdded = true;

            sock.ev.on("messages.upsert", async (m) => {
                const msg = m.messages[0];
                if (!msg?.message) return;

                const jid = msg.key.remoteJid;
                const game = bombGames[jid];
                if (!game) return;

                const sender = msg.key.participant || msg.key.remoteJid;
                const text =
                    msg.message?.conversation ||
                    msg.message?.extendedTextMessage?.text;

                // -------------------- أمر وقف --------------------
                if (text === ".وقف") {
                    clearTimeout(game.timeout);
                    game.paused = true;
                    await sock.sendMessage(jid, {
                        text: "🛑 تم إيقاف لعبة القنبلة"
                    });
                    return;
                }

                // -------------------- أمر رجع --------------------
                if (text === ".رجع") {
                    if (!game.paused) return;
                    game.paused = false;
                    await sock.sendMessage(jid, {
                        text: "▶️ اللعبة عادت من حيث توقفت!"
                    });
                    startRound();
                    return;
                }

                if (sender !== game.currentPlayer) return;

                const mentions =
                    msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;

                if (!mentions?.length) return;

                const target = mentions[0];
                if (!game.players.includes(target)) return;

                game.currentPlayer = target;

                await sock.sendMessage(jid, {
                    text:
`💣 القنبلة اتحولت إلى:
➤ @${target.split('@')[0]} ⚡`,
                    mentions: [target]
                });

                clearTimeout(game.timeout);
                const time = (Math.floor(Math.random() * 26) + 5) * 1000;
                game.timeout = setTimeout(explode, time);
            });
        }

        // -------------------- رسالة البداية + القواعد --------------------
        await sock.sendMessage(groupJid, {
            text:
`╭─ 💎 𝐒𝐎𝐅𝐀 𝐁𝐎𝐓 𝗕𝗢𝗠𝗕 𝗚𝗔𝗠𝗘 💎───╮

⏳ ستبدأ اللعبة خلال 5 ثواني...

📜 قواعد اللعبة:

➊ تذهب القنبلة في البداية لشخص عشوائي.
➋ تنفجر بعد مدة عشوائية من 5 إلى 30 ثانية.
➌ لنقل القنبلة من معك إلى شخص آخر:
   قم بعمل منشن له فقط ⚡
➍ إذا انفجرت القنبلة معك ❌
   تخرج من اللعبة فورًا.
➎ تستمر اللعبة حتى يتبقى لاعب واحد فقط 🏆

🩸 استعدوا... 

╰────────────────────────╯`
        });

        setTimeout(startRound, 5000);
    }
};