import { delay } from "@whiskeysockets/baileys";
import chalk from "chalk";

const activeGames = new Map();
let isListenerAttached = false;

// دالة مساعدة لتنظيف الـ JID
const normalizeJID = (jid) => {
    if (!jid) return "";
    let clean = jid.split(':')[0];
    return clean.includes('@s.whatsapp.net') ? `${clean}@s.whatsapp.net` : (clean.includes('@lid') ? clean : `${clean}@s.whatsapp.net`);
};

class TicTacToe {
    constructor(p1Data, p2Data) {
        this.board = Array(9).fill(null);
        this.playersData = {
            '❎': { ...p1Data, mark: '❎' },
            '⭕': { ...p2Data, mark: '⭕' }
        };
        this.turn = '❎';
        this.winner = null;
    }
    isTurn(incomingID) {
        const currentPlayer = this.playersData[this.turn];
        return currentPlayer.pn === normalizeJID(incomingID);
    }
    identifyPlayer(incomingID) {
        const normalized = normalizeJID(incomingID);
        if (this.playersData['❎'].pn === normalized) return this.playersData['❎'];
        if (this.playersData['⭕'].pn === normalized) return this.playersData['⭕'];
        return null;
    }
    play(index) {
        if (this.winner || this.board[index] !== null) return false;
        this.board[index] = this.turn;
        this.checkWinner();
        if (!this.winner) {
            this.turn = this.turn === '❎' ? '⭕' : '❎';
        }
        return true;
    }
    checkWinner() {
        const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
        for (const [a, b, c] of wins) {
            if (this.board[a] && this.board[a] === this.board[b] && this.board[a] === this.board[c]) {
                this.winner = this.board[a];
                return;
            }
        }
        if (this.board.every(cell => cell !== null)) this.winner = 'draw';
    }
    botMove() {
        const available = this.board.map((v, i) => v === null ? i : null).filter(v => v !== null);
        if (available.length === 0 || this.winner) return;
        const randomMove = available[Math.floor(Math.random() * available.length)];
        this.play(randomMove);
    }
}

async function sendBoard(sock, jid, game, quotedMsg) {
    const nums = {0:'1️⃣',1:'2️⃣',2:'3️⃣',3:'4️⃣',4:'5️⃣',5:'6️⃣',6:'7️⃣',7:'8️⃣',8:'9️⃣'};
    const boardDisplay = game.board.map((v, i) => v ? v : nums[i]);
    
    let text = `🎮 *لعبة XO - SOFA BOT*\n\n`;
    text += `❎ : @${game.playersData['❎'].pn.split('@')[0]}\n`;
    text += `⭕ : ${game.playersData['⭕'].pn === 'BOT' ? '🤖 البوت' : '@' + game.playersData['⭕'].pn.split('@')[0]}\n\n`;
    text += `${boardDisplay[0]} ${boardDisplay[1]} ${boardDisplay[2]}\n${boardDisplay[3]} ${boardDisplay[4]} ${boardDisplay[5]}\n${boardDisplay[6]} ${boardDisplay[7]} ${boardDisplay[8]}\n\n`;

    if (game.winner) {
        text += game.winner === 'draw' ? `🤝 *تعادل!*` : `🏆 *الفائز:* ${game.winner === '❎' ? '❎' : '⭕'}`;
        activeGames.delete(jid);
    } else {
        text += `⏳ دور: ${game.turn}\n🏳 اكتب *استسلام* للانسحاب.`;
    }

    const mentions = [game.playersData['❎'].pn, game.playersData['⭕'].pn].filter(id => id !== 'BOT');
    await sock.sendMessage(jid, { text, mentions }, { quoted: quotedMsg });
}

export default {
    name: "اكس",
    category: "games",
    description: "لعبة XO الكلاسيكية",
    run: async (context) => {
        const { sock, m, args } = context;
        const jid = m.key.remoteJid;

        // دالة رد احتياطية عشان متضربش Error
        const reply = async (text) => {
            return await sock.sendMessage(jid, { text }, { quoted: m });
        };

        if (!isListenerAttached) {
            sock.ev.on('messages.upsert', async ({ messages }) => {
                const msg = messages[0];
                if (!msg.message || msg.key.fromMe) return;
                const chatId = msg.key.remoteJid;
                const game = activeGames.get(chatId);
                if (!game) return;

                const body = (msg.message?.conversation || msg.message?.extendedTextMessage?.text || "").trim();
                const senderID = normalizeJID(msg.key.participant || msg.key.remoteJid);

                if (body === "استسلام" && game.identifyPlayer(senderID)) {
                    await sock.sendMessage(chatId, { text: "🏳 تم إنهاء اللعبة بالانسحاب." });
                    activeGames.delete(chatId);
                    return;
                }

                if (/^[1-9]$/.test(body)) {
                    const player = game.identifyPlayer(senderID);
                    if (!player || !game.isTurn(senderID)) return;

                    let moveIndex = parseInt(body) - 1;
                    if (game.play(moveIndex)) {
                        await sendBoard(sock, chatId, game, msg);
                        
                        // لو الدور على البوت وهو لسه مفيش فائز
                        if (!game.winner && game.playersData[game.turn].pn === "BOT") {
                            await delay(1500);
                            game.botMove();
                            await sendBoard(sock, chatId, game, msg);
                        }
                    }
                }
            });
            isListenerAttached = true;
        }

        if (activeGames.has(jid)) return reply("⚠️ فيه لعبة شغالة أصلاً!");

        const p1Data = { pn: normalizeJID(m.key.participant || jid) };
        let p2Data = (args[0] === "بوت") ? { pn: "BOT" } : null;

        if (!p2Data) {
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            if (mentioned) p2Data = { pn: normalizeJID(mentioned) };
        }

        if (!p2Data) return reply("📌 منشن حد تلعب معاه أو اكتب: .اكس بوت");
        if (p2Data.pn === p1Data.pn) return reply("❌ ما ينفعش تلعب ضد نفسك يا دمج!");

        const game = new TicTacToe(p1Data, p2Data);
        activeGames.set(jid, game);
        await sendBoard(sock, jid, game, m);
    }
};
