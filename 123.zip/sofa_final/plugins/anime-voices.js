import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { generateRealisticAnimeVoice, realisticTTSAvailable } from '../lib/realisticAnimeTTS.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const VOICES_DIR = path.join(__dirname, '..', 'media', 'anime-voices');

// مكتبة أسماء كبيرة قابلة للتوسعة. المقاطع الصوتية الفعلية لا تُضمَّن داخل البوت؛
// ضع المقاطع التي تملك حق استخدامها داخل media/anime-voices.
const VOICES = [
  ['لوفي',['luffy','لوفي','مونكي دي لوفي','monkeydluffy']], ['زورو',['zoro','زورو','roronoazoro']], ['نامي',['nami','نامي']], ['سانجي',['sanji','سانجي']], ['أوسوب',['usopp','اوسوب','أوسوب']], ['تشوبر',['chopper','تشوبر']], ['روبن',['robin','روبين']], ['فرانكي',['franky','فرانكي']], ['بروك',['brook','بروك']], ['جينبي',['jinbe','جينبي']], ['شانكس',['shanks','شانكس']], ['إيس',['ace','ايس','إيس']], ['سابو',['sabo','سابو']], ['ترافالغار لو',['law','ترافالغار لو','ترافلغار لو']], ['دوفلامينغو',['doflamingo','دوفلامينغو']], ['كايدو',['kaido','كايدو']], ['بيغ مام',['bigmom','big mom','بيغ مام']], ['تيتش',['teach','blackbeard','بلاكبيرد','تيتش']], ['وايتبيرد',['whitebeard','اللحية البيضاء','وايتبيرد']],
  ['غوكو',['goku','غوكو','جوكو','جوجو','سون غوكو']], ['فيجيتا',['vegeta','فيجيتا']], ['غوهان',['gohan','غوهان']], ['ترانكس',['trunks','ترانكس']], ['بيكولو',['piccolo','بيكولو']], ['فريزا',['frieza','فريزا']], ['سيل',['cell','سيل']], ['ماجين بو',['majinbu','majin boo','ماجين بو']], ['برولي',['broly','برولي']], ['بيروس',['beerus','بيروس']], ['ويس',['whis','ويس']],
  ['ناروتو',['naruto','ناروتو','ناروتو اوزوماكي']], ['ساسكي',['sasuke','ساسكي']], ['ساكورا',['sakura','ساكورا']], ['كاكاشي',['kakashi','كاكاشي']], ['إيتاتشي',['itachi','ايتاتشي','إيتاتشي']], ['مادارا',['madara','مادارا']], ['أوبيتو',['obito','أوبيتو','اوبيتو']], ['ميناتو',['minato','ميناتو']], ['جيرايا',['jiraiya','جيرايا']], ['أوروتشيمارو',['orochimaru','أوروتشيمارو']], ['تسونادي',['tsunade','تسونادي']], ['غارا',['gaara','غارا']], ['باين',['pain','باين']], ['كونان',['konan','كونان']], ['شيكامارو',['shikamaru','شيكامارو']], ['إينو',['ino','إينو']], ['روك لي',['rocklee','rock lee','روك لي']], ['نيجي',['neji','نيجي']], ['هيناتا',['hinata','هيناتا']], ['كِبا',['kiba','كيبا']], ['كايلر بي',['killerbee','killer b','كيلر بي']],
  ['تانجيرو',['tanjiro','تانجيرو']], ['نيزوكو',['nezuko','نيزوكو']], ['زينيتسو',['zenitsu','زينيتسو']], ['إينوسكي',['inosuke','اينوسكي','إينوسكي']], ['غيو',['giyu','غيو']], ['شينوبو',['shinobu','شينوبو']], ['رينغوكو',['rengoku','رينغوكو']], ['موزان',['muzan','موزان']], ['أكازا',['akaza','أكازا']], ['توميوكا',['tomioka','توميوكا']], ['ميتسوري',['mitsuri','ميتسوري']], ['مويشيرو',['muichiro','مويشيرو']], ['سانيمي',['sanemi','سانيمي']], ['أوباناي',['obanai','أوباناي']], ['غيومي',['gyomei','غيومي']], ['تينغن',['tengen','تينغن']],
  ['ليفاي',['levi','ليفاي']], ['إيرين',['eren','ايرين','إيرين']], ['ميكاسا',['mikasa','ميكاسا']], ['أرمين',['armin','أرمين']], ['هانجي',['hange','هانجي']], ['إروين',['erwin','إروين']], ['راينر',['reiner','راينر']], ['آني',['annie','آني']], ['زيك',['zeke','زيك']], ['جان',['jean','جان']], ['كوني',['connie','كوني']],
  ['غوجو',['gojo','غوجو']], ['سوكونا',['sukuna','سوكونا']], ['يوجي',['yuji','يوجي']], ['ميغومي',['megumi','ميغومي']], ['نوبارا',['nobara','نوبارا']], ['ماكي',['maki','ماكي']], ['توجي',['toji','توجي']], ['كينجاكو',['kenjaku','كينجاكو']], ['نانامي',['nanami','نانامي']], ['يوتـا',['yuta','يوتا']],
  ['غون',['gon','غون']], ['كيلوا',['killua','كيلوا']], ['كورابيكا',['kurapika','كورابيكا']], ['ليوريو',['leorio','ليوريو']], ['هيسوكا',['hisoka','هيسوكا']], ['إيلومي',['illumi','إيلومي']], ['ميرويم',['meruem','ميرويم']], ['نِتيرو',['netero','نيتيرو']],
  ['ديكو',['deku','ديكو','midoriya','ميدوريا']], ['باكوجو',['bakugo','باكوجو']], ['تودوروكي',['todoroki','تودوروكي']], ['أوراراكا',['uraraka','أوراراكا']], ['إيدا',['iida','إيدا']], ['أيزاوا',['aizawa','أيزاوا']], ['إنديفر',['endeavor','إنديفر']], ['هوكس',['hawks','هوكس']], ['تومورا',['tomura','تومورا']], ['أول مايت',['allmight','all might','اول مايت']],
  ['إدوارد إلريك',['edward','edwardelric','إدوارد','إدوارد إلريك']], ['ألفونس إلريك',['alphonse','alphonseelric','ألفونس']], ['روي موستانغ',['roy','roymustang','روي موستانغ']], ['وينري',['winry','وينري']], ['سكار',['scar','سكار']],
  ['ميلوداس',['meliodas','ميلوداس']], ['إسكانور',['escanor','إسكانور']], ['بان',['ban','بان']], ['كينغ',['king','كينغ']], ['ديان',['diane','ديان']], ['إليزابيث',['elizabeth','إليزابيث']], ['ميرلين',['merlin','ميرلين']], ['غوثر',['gowther','غوثر']],
  ['إينوياشا',['inuyasha','إينوياشا']], ['كاكاشي هاتاكي',['hatakekakashi','كاكاشي هاتاكي']], ['أوكابي',['okabe','أوكابي']], ['كوريسو',['kurisu','كوريسو']], ['سايتاما',['saitama','سايتاما']], ['جينوس',['genos','جينوس']], ['غارو',['garou','غارو']], ['موب',['mob','موب']], ['ريغن',['reigen','ريغن']], ['سينكو',['senku','سينكو']], ['تايجو',['taiju','تايجو']], ['إيشيغامي',['ishigami','إيشيغامي']], ['كاغويا',['kaguya','كاغويا']], ['ليفاي',['leviackerman','ليفاي أكرمان']], ['جوتارو',['jotaro','جوتارو']], ['ديو',['dio','ديو']], ['جوزيف',['joseph','جوزيف']], ['غينتاما',['gintama','غينتاما']], ['غينتوكي',['gintoki','غينتوكي']], ['أكيتو',['akito','أكيتو']], ['شينرا',['shinra','شينرا']], ['آستا',['asta','آستا']], ['يونو',['yuno','يونو']], ['إيرزا',['erza','إيرزا']], ['ناتسو',['natsu','ناتسو']], ['غراي',['gray','غراي']], ['لوسي',['lucy','لوسي']], ['إسكانور',['escanor','إسكانور']]
];

const normalize = (s = '') => String(s).toLowerCase().trim()
  .replace(/[ًٌٍَُِّْـ]/g, '')
  .replace(/[إأآٱ]/g, 'ا')
  .replace(/[ى]/g, 'ي')
  .replace(/ة/g, 'ه')
  .replace(/[ؤ]/g, 'و')
  .replace(/[ئ]/g, 'ي')
  .replace(/[ _\-–—.,!?؟!؛:()\[\]{}'"`]+/g, '');

function findVoice(query) {
  const q = normalize(query);
  if (!q) return null;
  // جرّب الأسماء الأطول أولاً حتى تعمل الأسماء متعددة الكلمات مثل «ترافالغار لو».
  const matches = [];
  for (const voice of VOICES) {
    const [name, aliases] = voice;
    for (const a of [name, ...aliases]) {
      const na = normalize(a);
      if (na === q) matches.push([na.length, voice]);
    }
  }
  matches.sort((a, b) => b[0] - a[0]);
  return matches[0]?.[1] || null;
}

function indexedClip(index) {
  if (!fs.existsSync(VOICES_DIR)) return null;
  const wanted = String(index + 1).padStart(3, '0');
  const file = fs.readdirSync(VOICES_DIR).find(f =>
    new RegExp(`^${wanted}_character_${wanted}\\.(ogg|opus|mp3|m4a|wav)$`, 'i').test(f)
  );
  return file ? path.join(VOICES_DIR, file) : null;
}

function clipForVoice(voice) {
  const index = VOICES.indexOf(voice);
  if (index < 0) return [];
  const indexed = indexedClip(index);
  if (indexed) return [indexed];
  const [name, aliases] = voice;
  return filesFor([name, ...aliases]);
}

function filesFor(keys) {
  if (!fs.existsSync(VOICES_DIR)) return [];
  const list = Array.isArray(keys) ? keys : [keys];
  const wanted = new Set(list.map(normalize));
  return fs.readdirSync(VOICES_DIR)
    .filter(f => /\.(ogg|opus|mp3|m4a|wav)$/i.test(f))
    .filter(f => wanted.has(normalize(path.parse(f).name)))
    .map(f => path.join(VOICES_DIR, f));
}

function allClips() {
  if (!fs.existsSync(VOICES_DIR)) return [];
  return fs.readdirSync(VOICES_DIR).filter(f => /\.(ogg|opus|mp3|m4a|wav)$/i.test(f));
}

async function sendClip({ sock, m }, file, title) {
  const ext = path.extname(file).toLowerCase();
  const mimetype = ext === '.ogg' || ext === '.opus' ? 'audio/ogg; codecs=opus' : ext === '.mp3' ? 'audio/mpeg' : 'audio/mp4';
  const audio = fs.readFileSync(file);
  return sock.sendMessage(m.key.remoteJid, { audio, mimetype, ptt: true, fileName: `${title}${ext}` }, { quoted: m });
}

export default {
  name: 'صوت_انمي',
  aliases: ['صوت-انمي','انمي_صوت','animevoice','animevoices','صوت_شخصية','صوت_شخصيه','صوت_انمي_واقعي','صوت_واقعي'],
  description: 'مكتبة واسعة لأسماء شخصيات الأنمي وتشغيل المقاطع المحلية المتاحة',
  category: 'audio',
  usage: '.صوت_انمي لوفي | .صوت_انمي لوفي مرحباً يا أصدقاء | .اصوات',

  async run({ text, reply, sock, m }) {
    const q = String(text || '').trim().replace(/^[.,!?؟!؛:]+|[.,!?؟!؛:]+$/g, '').trim();

    if (!q || /^(قائمة|اصوات|الأصوات|الاصوات|اصوات_الانمي|الانمي_صوت|list)$/i.test(q)) {
      const lines = VOICES.map(([name, aliases], i) => {
        const ok = Boolean(indexedClip(i)) || [name, ...aliases].some(a => allClips().some(f => normalize(path.parse(f).name) === normalize(a)));
        return `${String(i + 1).padStart(3, '0')} ${ok ? '🎙️' : '⚪'} ${name}`;
      });
      const ready = lines.filter(x => x.includes('🎙️')).length;
      return reply(`╭━━━〔 🎌 مكتبة أصوات الأنمي 〕━━━╮\n┃ 👤 الشخصيات المسجلة: ${VOICES.length}\n┃ 🎙️ المقاطع الموجودة فعلياً: ${ready}\n┃\n${lines.join('\n')}\n┃\n┃ 📌 استخدم: .صوت_انمي <الشخصية>\n┃ 📂 المقاطع: media/anime-voices/\n┃ 🎙️ = يوجد مقطع محلي\n┃ ⚪ = الاسم مدعوم لكن المقطع غير مضاف\n╰━━━━━━━━━━━━━━━━━━━━━━╯`);
    }

    const tokens = q.split(/\s+/);
    let resolved = null;
    let consumed = 0;
    for (let count = tokens.length; count >= 1; count--) {
      const candidate = tokens.slice(0, count).join(' ');
      const found = findVoice(candidate);
      if (found) {
        resolved = found;
        consumed = count;
        break;
      }
    }
    if (!resolved) return reply(`❌ لم أجد هذه الشخصية في المكتبة.\n\nاكتب *.اصوات* لعرض القائمة.`);

    const [name, aliases] = resolved;
    const textForTTS = tokens.slice(consumed).join(' ').trim();

    // الوضع الواقعي: يحوّل النص إلى صوت طبيعي عبر مزود TTS عند ضبط المفتاح والـVoice ID.
    // لا يحاول تقليد صوت ممثل أو تسجيل أصلي؛ استخدم Voice أصلياً تملك حق استخدامه.
    if (textForTTS && realisticTTSAvailable()) {
      try {
        const file = await generateRealisticAnimeVoice({ character: name, text: textForTTS });
        const audio = fs.readFileSync(file);
        return sock.sendMessage(m.key.remoteJid, {
          audio,
          mimetype: 'audio/mpeg',
          ptt: true,
          fileName: `${name}-realistic.mp3`
        }, { quoted: m });
      } catch (e) {
        console.error('[anime-voices] realistic TTS:', e?.message || e);
      }
    }

    const files = clipForVoice(resolved);
    if (!files.length) {
      if (textForTTS && !realisticTTSAvailable()) {
        return reply(`⚠️ لم يتم إعداد مزود TTS الخارجي، ولا يوجد مقطع محلي للشخصية *${name}*.`);
      }
      return reply(`⚪ *${name}* موجودة في القائمة، لكن لا يوجد لها مقطع صوتي محلي.`);
    }

    // إذا لم يكن TTS الخارجي مضبوطاً، استخدم المقطع المحلي المرفق بدلاً من إظهار خطأ.
    return sendClip({ sock, m }, files[Math.floor(Math.random() * files.length)], name);
  }
};
