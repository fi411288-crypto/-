import { groqChat, MODELS, quotedOf, imageOf, reactor, AiError } from '../lib/groq.js';

const SYSTEM = 'أنت مدرس خبير. حل المسألة خطوة بخطوة بالعربية وبشكل منظم وواضح. اكتب المعادلات كنص عادي من غير LaTeX (مثل x^2 و sqrt(x) و 3/4). اختم بسطر أخير بالشكل: ✅ الناتج: ... وخلي الشرح مناسب للقراءة على الموبايل.';

export default {
    name: 'حل',
    aliases: ['solve'],
    description: 'حل مسألة (رياضيات، فيزياء، واجبات) بالخطوات — نص أو صورة',
    category: 'ai',

    async run({ sock, message, text, reply, prefix }) {
        const react = reactor(sock, message);
        const q = (text || '').trim() || quotedOf(sock, message)?.text?.trim() || '';

        let image = null;
        try { image = await imageOf(sock, message); }
        catch (e) { return reply(`❌ ${e.message}`); }

        if (!q && !image) {
            return reply(`🧮 اكتب المسألة: ${prefix}حل 2x + 5 = 17\n🖼️ أو رد على صورة المسألة واكتب ${prefix}حل`);
        }

        await react('⌛');
        try {
            const answer = image
                ? await groqChat({
                    model: MODELS.vision, max: 3000,
                    messages: [
                        { role: 'system', content: SYSTEM },
                        { role: 'user', content: [
                            { type: 'text', text: q || 'حل المسألة اللي في الصورة.' },
                            { type: 'image_url', image_url: { url: image } }
                        ] }
                    ]
                })
                : await groqChat({
                    effort: 'medium', max: 3000,
                    messages: [{ role: 'system', content: SYSTEM }, { role: 'user', content: q }]
                });
            await react('✅');
            return reply(`🧮 *الحل:*\n\n${answer}\n\n> SOFA BOT`);
        } catch (e) {
            await react('❌');
            return reply(`❌ ${e instanceof AiError ? e.message : 'حصل خطأ: ' + e.message}`);
        }
    }
};
