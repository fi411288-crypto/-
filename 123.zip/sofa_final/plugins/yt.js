import { ytCommand } from '../lib/youtube.js';

export default {
    name: 'yt',
    aliases: ['youtube'],
    description: 'تحميل من يوتيوب: .yt <رابط أو اسم> [mp3|mp4]',
    category: 'downloader',
    run: (ctx) => {
        const parts = (ctx.text || '').trim().split(/\s+/);
        const last = (parts[parts.length - 1] || '').toLowerCase();
        const isVideo = last === 'mp4';
        if (last === 'mp3' || last === 'mp4') parts.pop();
        return ytCommand({ ...ctx, text: parts.join(' ') }, isVideo ? 'video' : 'audio', 'yt');
    }
};
