import axios from 'axios';

async function translateToArabic(text) {
    // 1) ترجمة جوجل
    try {
        const r = await axios.get('https://translate.googleapis.com/translate_a/single', {
            params: { client: 'gtx', sl: 'en', tl: 'ar', dt: 't', q: text },
            timeout: 15000
        });
        const parts = r.data?.[0];
        if (Array.isArray(parts)) {
            const out = parts.map((p) => p?.[0] || '').join('').trim();
            if (out) return out;
        }
    } catch {}
    // 2) احتياطي: MyMemory
    const r = await axios.get('https://api.mymemory.translated.net/get', {
        params: { q: text, langpair: 'en|ar' },
        timeout: 15000
    });
    const out = String(r.data?.responseData?.translatedText || '').trim();
    if (!out) throw new Error('Translation result is empty');
    return out;
}

const makeRun = (isArabic) => async ({ reply, react }) => {
    const title = isArabic ? 'نصيحة' : 'Aᴅᴠɪᴄᴇ';
    await react('⌛').catch(() => {});

    try {
        const res = await axios.get('https://api.adviceslip.com/advice', {
            timeout: 8000,
            responseType: 'text',
            headers: { 'Cache-Control': 'no-cache' },
            params: { timestamp: Date.now() }
        });
        const data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
        const advice = data?.slip?.advice;
        if (!advice) throw new Error('Advice API returned no advice');

        const output = isArabic ? await translateToArabic(advice) : advice;

        await react('✅').catch(() => {});
        return reply(
            `╭─❏ 「 ${title} 」\n` +
            `│\n` +
            `│ 💡 ${output}\n` +
            `╰───────────────\n` +
            `> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀`
        );
    } catch (error) {
        console.error('[ADVICE ERROR]', error.message);
        await react('❌').catch(() => {});
        const errorText = isArabic
            ? 'معرفتش أجيب النصيحة أو أترجمها دلوقتي، جرّب كمان شوية.'
            : 'My advice? Try again later.';
        return reply(
            `╭─❏ 「 ${title} 」\n` +
            `│\n` +
            `│ ${errorText}\n` +
            `╰───────────────\n` +
            `> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀`
        );
    }
};

// كل صيغة أمر مسجّلة باسمها مباشرة (من غير الاعتماد على alias)
export default [
    {
        name: 'advice',
        aliases: ['tip', 'lifetip', 'suggest'],
        description: 'Get random life advice in English',
        category: 'fun',
        run: makeRun(false)
    },
    {
        name: 'نصيحه',
        aliases: [],
        description: 'نصيحة عشوائية بالعربي',
        category: 'fun',
        run: makeRun(true)
    },
    {
        name: 'نصيحة',
        aliases: [],
        description: 'نصيحة عشوائية بالعربي',
        category: 'fun',
        run: makeRun(true)
    }
];
