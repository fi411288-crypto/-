export default {
    name: 'منشن',
    aliases: ['tagall', 'م', 'هيدن', 'mention'],
    description: 'منشن جميع أعضاء الجروب',
    category: 'admin',
    group: true,
    admin: true,

    async run({ sock, m, message, text, reply }) {
        const msg = m || message;
        const jid = msg.key.remoteJid;
        try {
            const meta = await sock.groupMetadata(jid);
            const members = (meta.participants || []).map(p => p.id).filter(Boolean);
            if (!members.length) return reply('❌ مفيش أعضاء');
            const body = (text || '').trim() || '📢 منشن جماعي';
            // تقسيم لو العدد كبير
            const chunk = 400;
            for (let i = 0; i < members.length; i += chunk) {
                const part = members.slice(i, i + chunk);
                const lines = part.map((id, idx) => `${i + idx + 1}. @${id.split('@')[0]}`).join('\n');
                await sock.sendMessage(jid, {
                    text: `╭─❏ 「 📢 منشن 」\n│ ${body}\n│\n${lines}\n╰───────────────`,
                    mentions: part
                }, { quoted: msg });
            }
        } catch (e) {
            return reply('❌ فشل المنشن: ' + e.message);
        }
    }
};
