// 🏅 إنجازاتي — إنجازات العضو ومكافآتها (بتتسلّم تلقائي أول ما تتحقق) — SOFA BOT
import { resolveNumber, isRegistered, updateUser, getLevel } from '../lib/economy.js';
import { fmt, displayName } from '../lib/shop.js';

const propsCount = (u) => Object.values(u.inv?.props || {}).reduce((a, n) => a + n, 0);

// prog: بترجّع [الحالي, المطلوب]
const LIST = [
    { id: 'daily7',   name: '🔥 أسبوع نار',     desc: 'سلسلة يومي 7 أيام',         coin: 3000,   xp: 100, prog: (u) => [u.daily?.best || 0, 7] },
    { id: 'daily30',  name: '🌋 شهر كامل',      desc: 'سلسلة يومي 30 يوم',         coin: 25000,  xp: 500, prog: (u) => [u.daily?.best || 0, 30] },
    { id: 'rich100k', name: '💰 صاحب ثروة',     desc: 'رصيد 100,000 كوين',         coin: 5000,   xp: 150, prog: (u, e) => [e.coin, 100000] },
    { id: 'rich1m',   name: '💎 مليونير',       desc: 'رصيد 1,000,000 كوين',       coin: 50000,  xp: 600, prog: (u, e) => [e.coin, 1000000] },
    { id: 'lvl5',     name: '⚡ صاعد',          desc: 'توصل المستوى 5',            coin: 3000,   xp: 0,   prog: (u, e) => [getLevel(e.exp), 5] },
    { id: 'lvl10',    name: '🚀 محترف',         desc: 'توصل المستوى 10',           coin: 10000,  xp: 0,   prog: (u, e) => [getLevel(e.exp), 10] },
    { id: 'owner',    name: '🏠 مالك',          desc: 'تشتري أول عقار/سيارة',      coin: 2000,   xp: 100, prog: (u) => [propsCount(u), 1] },
    { id: 'tycoon',   name: '🏰 إمبراطور عقارات', desc: 'تملك 5 عقارات',           coin: 15000,  xp: 300, prog: (u) => [propsCount(u), 5] },
    { id: 'style',    name: '🎨 أنيق',          desc: 'تشتري لقب وإطار',           coin: 2500,   xp: 100, prog: (u) => [(u.inv?.titles?.length ? 1 : 0) + (u.inv?.frames?.length ? 1 : 0), 2] },
    { id: 'trader',   name: '📈 متداول',        desc: '10 عمليات تداول أسهم',      coin: 4000,   xp: 150, prog: (u) => [u.trades?.length || 0, 10] },
    { id: 'banker',   name: '🏦 مدّخر',         desc: 'إيداع 100,000 في البنك',    coin: 5000,   xp: 150, prog: (u) => [u.bank?.amount || 0, 100000] },
    { id: 'debt',     name: '🤝 ملتزم',         desc: 'تسدّد قرض بالكامل',         coin: 1500,   xp: 50,  prog: (u) => [u.loansPaid || 0, 1] },
    { id: 'lucky',    name: '🍀 محظوظ',         desc: 'تكسب اليانصيب الكبير',      coin: 10000,  xp: 300, prog: (u) => [u.lotteryWins || 0, 1] }
];

const bar = (c, t) => { const f = Math.min(10, Math.floor((Math.min(c, t) / t) * 10)); return '▰'.repeat(f) + '▱'.repeat(10 - f); };

export default [{
    name: 'إنجازاتي',
    aliases: ['انجازاتي', 'إنجازات', 'انجازات', 'achievements', 'ach'],
    category: 'games',
    description: 'إنجازاتك ومكافآتها',
    cooldown: 3000,
    async run({ sock, m, message, reply, prefix = '.' }) {
        const msg = m || message;
        const number = await resolveNumber(sock, msg);
        if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);

        const r = updateUser(number, (u, eco) => {
            const done = (u.ach ||= {});
            const fresh = [];
            for (const a of LIST) {
                const [c, t] = a.prog(u, eco);
                if (c >= t && !done[a.id]) { done[a.id] = Date.now(); eco.coin += a.coin; eco.exp += a.xp; fresh.push(a); }
            }
            const rows = LIST.map((a) => { const [c, t] = a.prog(u, eco); return { a, c, t, ok: !!done[a.id] }; });
            return { fresh, rows, name: displayName(u) };
        });
        if (!r.ok) return reply('❌ حصل خطأ، حاول تاني.');

        const got = r.rows.filter((x) => x.ok).length;
        const lines = r.rows.map(({ a, c, t, ok }) => ok
            ? `✅ *${a.name}* — ${a.desc}`
            : `⬜ ${a.name} — ${a.desc}\n   ${bar(c, t)} ${fmt(Math.min(c, t))}/${fmt(t)} • 🎁 ${fmt(a.coin)}`);
        const bonus = r.fresh.length
            ? `\n🎉 *إنجازات جديدة اتفتحت:*\n` + r.fresh.map((a) => `• ${a.name}: +${fmt(a.coin)} كوين${a.xp ? ` +${a.xp} XP` : ''}`).join('\n') + '\n'
            : '';
        return reply(`🏅 *SOFA • ACHIEVEMENTS*\n👤 ${r.name}\n📊 ${got}/${LIST.length}\n${bonus}\n${lines.join('\n')}`);
    }
}];
