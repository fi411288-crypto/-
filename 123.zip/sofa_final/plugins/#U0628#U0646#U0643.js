// 🏦 البنك: فلوسك فيه آمنة من السرقة وبتكبر 1% كل يوم — SOFA BOT
import { resolveNumber, isRegistered, updateUser } from '../lib/economy.js';
import { fmt, bankOf, bump, toEnDigits, BANK_CAP, BANK_RATE } from '../lib/shop.js';

const IN = ['ايداع', 'إيداع', 'ودع', 'deposit'], OUT = ['سحب', 'اسحب', 'withdraw'];

export default [{
    name: 'بنك',
    aliases: ['bank', 'البنك'],
    category: 'games',
    description: 'ايداع وسحب — الفلوس في البنك محدش يسرقها وبتزيد 1% يومياً',
    usage: '.بنك | .بنك ايداع 1000 | .بنك سحب كله',
    cooldown: 2500,
    async run({ sock, m, message, args, reply, prefix = '.' }) {
        const msg = m || message, number = await resolveNumber(sock, msg);
        if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
        const act = IN.includes(args[0]) ? 'in' : OUT.includes(args[0]) ? 'out' : null;
        const a = toEnDigits(args[1] || ''), all = ['كله', 'الكل', 'all'].includes(a), n = parseInt(a, 10);
        if (act && !all && !(n > 0)) return reply(`❌ اكتب المبلغ: *${prefix}بنك ${args[0]} 1000* أو "كله"`);
        const r = updateUser(number, (u, eco) => {
            const b = bankOf(u);
            if (act === 'in') {
                const amt = all ? Math.min(eco.coin, BANK_CAP - b.amount) : n;
                if (amt <= 0) return { error: 'zero' };
                if (amt > eco.coin) return { error: 'funds', have: eco.coin };
                if (b.amount + amt > BANK_CAP) return { error: 'cap', room: BANK_CAP - b.amount };
                if (b.amount === 0) b.last = Date.now();
                eco.coin -= amt; b.amount += amt; bump(u, 'bank');
                return { done: `🏦 اتودّع \`${fmt(amt)}\` في البنك`, bank: b.amount, coin: eco.coin };
            }
            if (act === 'out') {
                const amt = all ? b.amount : n;
                if (amt <= 0) return { error: 'zero' };
                if (amt > b.amount) return { error: 'bank', have: b.amount };
                b.amount -= amt; eco.coin += amt;
                return { done: `💵 سحبت \`${fmt(amt)}\` من البنك`, bank: b.amount, coin: eco.coin };
            }
            return { bank: b.amount, coin: eco.coin };
        });
        if (r.error === 'funds') return reply(`❌ رصيدك اللي في إيدك مش كفاية! معاك: \`${fmt(r.have)}\``);
        if (r.error === 'bank') return reply(`❌ اللي في البنك بس: \`${fmt(r.have)}\``);
        if (r.error === 'cap') return reply(`❌ الحد الأقصى للبنك ${fmt(BANK_CAP)}. المتاح: \`${fmt(r.room)}\``);
        if (r.error === 'zero') return reply('❌ مفيش مبلغ يتنقل.');
        if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ.');
        return reply(`🌌 *SOFA • BANK*\n\n${r.done ? r.done + '\n\n' : ''}🏦 البنك: \`${fmt(r.bank)}\`\n👛 في إيدك: \`${fmt(r.coin)}\`\n📈 فايدة ${BANK_RATE * 100}% كل يوم (حد أقصى ${fmt(BANK_CAP)})\n\n*${prefix}بنك ايداع 1000* | *${prefix}بنك سحب 1000*`);
    }
}];
