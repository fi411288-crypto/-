// .تنصيب            ← يربط رقمك (اللي بعتّ منه الأمر) بالبوت
// .تنصيب 2012xxxxxxxx ← يربط الرقم ده (الكود بيجيلك هنا في الشات، مش على خاصه)
// نفس نظام التليجرام: كود ربط حقيقي + كارت VIP + خطوات الربط، ورقم واحد = جلسة واحدة.
import { proto, generateWAMessageFromContent, prepareWAMessageMedia } from '@whiskeysockets/baileys';
import { resolveNumber } from '../lib/economy.js';
import { pairCard } from '../lib/vipCards.js';

const COOLDOWN_MS = 60 * 1000;         // كولداون كل شخص بين طلبين
const CODE_LIFETIME_MS = 3 * 60 * 1000; // مدة صلاحية الكود قبل ما نقفل الجلسة المعلّقة
const MAX_PER_HOUR = 3;                 // أقصى عدد أكواد لنفس الرقم في الساعة (عشان محدش يضايق رقم)
const LINE = '━━━━━━━━━━━━━━';

const userCd = new Map();      // طالب الأمر -> وقت آخر طلب
const phoneTries = new Map();  // الرقم -> [أوقات طلب الكود]
const digits = (j) => String(j || '').split('@')[0].split(':')[0].replace(/\D/g, '');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fmtCode = (c) => { const x = String(c || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); return x.length === 8 ? `${x.slice(0, 4)}-${x.slice(4)}` : x; };

// أكتر من جلسة بتستقبل نفس الرسالة (لو أكتر من رقم مربوط في الجروب): واحدة بس تنفّذ
const seen = (globalThis.__tansebSeen ||= new Set());
function firstToHandle(message) {
    const k = `${message.key?.remoteJid}|${message.key?.id}`;
    if (seen.has(k)) return false;
    seen.add(k);
    if (seen.size > 300) seen.delete(seen.values().next().value);
    return true;
}

// الرقم الحقيقي للمرسل (لو واتساب مخبيه ومش قادرين نوصله بنطلب منه يكتبه)
async function senderPhone(sock, message) {
    const key = message.key || {};
    const n = await resolveNumber(sock, message);
    const lidRaw = [key.participant, key.remoteJid].find((j) => String(j || '').includes('@lid'));
    if (!n || (lidRaw && n === digits(lidRaw))) return { id: n, phone: '' };
    return { id: n, phone: n };
}

async function sendCodeCard(sock, jid, quoted, { text, card, code }) {
    const IM = proto.Message.InteractiveMessage;
    const media = card ? await prepareWAMessageMedia({ image: card }, { upload: sock.waUploadToServer }) : null;
    const im = IM.fromObject({
        body: IM.Body.fromObject({ text }),
        footer: IM.Footer.fromObject({ text: 'SOFA BOT' }),
        header: media
            ? IM.Header.fromObject({ title: '', hasMediaAttachment: true, imageMessage: media.imageMessage })
            : IM.Header.fromObject({ title: '', hasMediaAttachment: false }),
        nativeFlowMessage: IM.NativeFlowMessage.fromObject({
            buttons: [{ name: 'cta_copy', buttonParamsJson: JSON.stringify({ display_text: '📋 نسخ الكود', copy_code: String(code).replace(/-/g, '') }) }]
        })
    });
    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: { messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 }, interactiveMessage: im } }
    }, { userJid: sock.user?.id, quoted });
    await sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
}

export default {
    name: 'تنصيب',
    aliases: ['install', 'ربط', 'تركيب'],
    description: 'ربط رقمك بالبوت: .تنصيب  أو  .تنصيب 2012xxxxxxxx',
    category: 'tools',

    async run({ sock, message, args, reply, prefix = '.' }) {
        if (!firstToHandle(message)) return;
        const bot = global.bot;
        if (!bot?.createWhatsAppSession) return reply('❌ نظام التنصيب مش متاح دلوقتي.');

        // التنصيب مسموح من جلسة البوت الأساسي فقط، وليس من أي جلسة فرعية.
        const mainNumber = digits(bot?.config?.BOT_NUMBER);
        const currentBotNumber = digits(sock?.user?.id);
        if (!mainNumber || currentBotNumber !== mainNumber) {
            return reply('⛔ أمر التنصيب متاح من البوت الأساسي فقط. البوتات الفرعية لا يمكنها تنصيب جلسات جديدة.');
        }

        const jid = message.key.remoteJid;
        const react = (e) => sock.sendMessage(jid, { react: { text: e, key: message.key } }).catch(() => {});

        // ===== مين الطالب + الرقم المطلوب =====
        const me = await senderPhone(sock, message);
        const requester = me.id || jid;
        const typed = digits(args.join(''));
        const phone = typed || me.phone;
        if (!phone) return reply(`📱 اكتب رقمك مع كود الدولة:\n*${prefix}تنصيب 201xxxxxxxxx*`);
        if (phone.length < 8 || phone.length > 15) return reply(`❌ رقم غير صالح. اكتبه مع كود الدولة، مثال:\n*${prefix}تنصيب 201018766845*`);

        // ===== كولداون الطالب =====
        const left = COOLDOWN_MS - (Date.now() - (userCd.get(requester) || 0));
        if (left > 0) return reply(`⏳ استنى *${Math.ceil(left / 1000)}* ثانية قبل ما تطلب تاني.`);

        // ===== رقم واحد = جلسة واحدة =====
        const ownerKey = `wa:${requester}`;
        const myPhone = bot.getPhoneByTelegramId?.(ownerKey);
        if (myPhone && myPhone !== phone) {
            return reply(`⚠️ *عندك رقم مربوط بالفعل*\n${LINE}\n📱 +${myPhone}\n\nكل شخص ليه رقم واحد بس.`);
        }
        const existing = bot.sessions?.get(phone);
        const owner = bot.sessionOwners?.get(phone);
        if (existing?.isConnected) return reply(`🟢 *الرقم ده مربوط ومتصل بالفعل*\n📱 +${phone}`);
        if (owner && owner !== ownerKey) return reply(`⚠️ *الرقم ده مربوط بحساب تاني*\n📱 +${phone}`);
        // كود لسه صالح؟ منبعتش كود جديد (ده بيمنع إزعاج صاحب الرقم بإشعارات متكررة)
        if (existing && !existing.isConnected && existing.pairingCode && Date.now() - existing.startTime < CODE_LIFETIME_MS) {
            const wait = Math.ceil((CODE_LIFETIME_MS - (Date.now() - existing.startTime)) / 1000);
            return reply(`⏳ في كود لسه صالح للرقم ده. استنى *${wait}* ثانية لو الكود انتهى وأطلب من جديد.`);
        }
        // حد أقصى لعدد الأكواد لنفس الرقم في الساعة
        const hour = (phoneTries.get(phone) || []).filter((t) => Date.now() - t < 3600_000);
        if (hour.length >= MAX_PER_HOUR) return reply(`🚫 اتطلب أكتر من ${MAX_PER_HOUR} أكواد للرقم ده في الساعة الأخيرة. حاول بعد شوية.`);

        userCd.set(requester, Date.now());
        hour.push(Date.now());
        phoneTries.set(phone, hour);

        await react('⏳');
        await reply(`⏳ *جاري إنشاء جلسة واتساب...*\nممكن ياخد لحد 30 ثانية.`);

        let result;
        try {
            result = await bot.createWhatsAppSession(phone, ownerKey);
        } catch (e) {
            await react('❌');
            return reply(`❌ *فشل الاتصال*\n${LINE}\n${String(e.message || e).slice(0, 120)}\n\nجرّب تاني بعد شوية.`);
        }
        if (result?.connected) {
            await react('✅');
            return reply(`🟢 *الحساب متصل بنجاح*\n${LINE}\n📱 +${phone}`);
        }
        if (!result?.pairingCode) {
            await react('❌');
            return reply('❌ مقدرتش أجيب كود الربط، جرّب تاني.');
        }

        const code = fmtCode(result.pairingCode);
        const text =
            `🔐 *كود الربط جاهز*\n${LINE}\n📱 *الرقم:* +${phone}\n\n🔑 *الكود:* \`${code}\`\n_(اضغط «نسخ الكود» تحت)_\n${LINE}\n` +
            `*طريقة الربط:*\n1️⃣ افتح واتساب\n2️⃣ الأجهزة المرتبطة\n3️⃣ ربط جهاز\n4️⃣ الربط برقم الهاتف بدلاً من ذلك\n5️⃣ اكتب الكود\n\n` +
            `⏱ الكود صالح لدقائق قليلة، وهبلغك أول ما الاتصال يتم.`;

        // الكود بيتبعت هنا في الشات (مش على خاص صاحب الرقم) — كارت VIP + زرار نسخ، ولو فشل نص عادي
        let card = null;
        try { card = await pairCard({ code, phone: `+${phone}` }); } catch {}
        try {
            await sendCodeCard(sock, jid, message, { text, card, code });
        } catch {
            try {
                if (card) await sock.sendMessage(jid, { image: card, caption: text }, { quoted: message });
                else await sock.sendMessage(jid, { text }, { quoted: message });
            } catch (e) { return reply(text); }
        }
        await react('🔑');

        // نراقب الاتصال: لو اتربط نبلّغ، ولو الكود خلص من غير ربط نقفل الجلسة المعلّقة عشان الرقم ميتقفلش
        (async () => {
            const until = Date.now() + CODE_LIFETIME_MS + 30_000;
            while (Date.now() < until) {
                await sleep(3000);
                const s = bot.sessions?.get(phone);
                if (s?.isConnected) {
                    await sock.sendMessage(jid, { text: `✅ *تم ربط +${phone} بنجاح!*\n🤖 البوت شغال على الرقم ده دلوقتي.` }, { quoted: message }).catch(() => {});
                    return;
                }
                if (!s) return; // اتلغت من مكان تاني
            }
            try {
                const s = bot.sessions?.get(phone);
                if (s && !s.isConnected && bot.sessionOwners?.get(phone) === ownerKey) {
                    await bot.removeSession(phone, false);
                    await sock.sendMessage(jid, { text: `⌛ انتهى الكود للرقم +${phone} من غير ربط. اكتب *${prefix}تنصيب* تاني لو لسه عايز.` }, { quoted: message }).catch(() => {});
                }
            } catch {}
        })();
    }
};
