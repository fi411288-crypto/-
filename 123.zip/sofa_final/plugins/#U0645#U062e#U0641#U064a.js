export default {
name: "م",
description: "منشن كل أعضاء الجروب بكلمة مخفية. سواء كتبت بعد الأمر أو عملت ريبلاي.",
usage: ".م <النص> أو ريبلاي على رسالة",
group: true,

async run({ sock, message, reply }) {
try {
const from = message.key.remoteJid;
if (!from.endsWith("@g.us"))
return reply("الأمر ده يشتغل جوه الجروبات بس.");

let displayText = "";  

  // لو عملت ريبلاي على رسالة ناخد نصها  
  if (message.message?.extendedTextMessage?.contextInfo?.quotedMessage) {  
    const quoted = message.message.extendedTextMessage.contextInfo.quotedMessage;  
    displayText =   
      quoted.conversation ||   
      quoted.extendedTextMessage?.text ||   
      "";  
  } else {  
    // لو مكتوب بعد .م ناخد النص بعد الأمر  
    const fullText =  
      message.message?.conversation ||  
      message.message?.extendedTextMessage?.text ||  
      "";  

    if (!fullText.startsWith(".م"))  
      return;  

    displayText = fullText.slice(2).trim();  
  }  

  if (!displayText)  
    return reply("مفيش نص لأرساله. اكتب بعد الأمر أو اعمل ريبلاي على رسالة.");  

  // جلب أعضاء الجروب  
  const meta = await sock.groupMetadata(from);  
  let participants = meta.participants.map(p => p.id);  

  // استبعاد البوت  
  const botJid = sock.user.id;  
  participants = participants.filter(jid => jid && jid !== botJid);  

  if (!participants.length)  
    return reply("مافيش أعضاء لأمنشنهم.");  

  // إرسال الرسالة بالتنسيق الأصلي + منشن مخفي  
  await sock.sendMessage(from, {  
    text: displayText,  
    mentions: participants  
  });  

} catch (err) {  
  console.error("Mention Error:", err);  
  reply("حصل خطأ وأنا بحاول أعمل المنشن المخفي.");  
}

}
};