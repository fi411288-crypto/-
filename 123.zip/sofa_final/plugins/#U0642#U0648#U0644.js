import { exec } from 'child_process';
import { promisify } from 'util';
import fetch from 'node-fetch';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const execAsync = promisify(exec);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TMP_DIR = path.join(__dirname, '..', 'data', 'tmp_audio');

async function generateAudio(text) {
    try {
        await fs.ensureDir(TMP_DIR);
        const timestamp = Date.now();
        const mp3File = path.join(TMP_DIR, `${timestamp}.mp3`);
        const oggFile = path.join(TMP_DIR, `${timestamp}.ogg`);
        
        // جلب الصوت من Google Translate API
        const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=ar&client=gtx&prev=input`;
        const response = await fetch(url, {
            method: 'GET',
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
            timeout: 30000
        });
        
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const buffer = await response.buffer();
        await fs.writeFile(mp3File, buffer);

        // تحويل MP3 إلى OGG (Opus) بـ ffmpeg
        try {
            await execAsync(`ffmpeg -i "${mp3File}" -acodec libopus -b:a 32k "${oggFile}" -y -loglevel error`);
            await fs.remove(mp3File);
            return oggFile;
        } catch (ffErr) {
            // لو ffmpeg مش موجود: استخدم MP3 مباشرة
            console.warn('⚠️ ffmpeg not available, using MP3');
            return mp3File;
        }
    } catch (e) {
        throw new Error(`فشل توليد الصوت: ${e.message}`);
    }
}

export default [{
    name: 'قول',
    aliases: ['say', 'speak', 'tts'],
    description: 'تحويل نص لصوت',
    category: 'tools',
    async run(context) {
        const { client, m, text } = context;

        if (!text) {
            return client.sendMessage(m.chat, { text: `الاستخدام:\n.قول النص هنا` }, { quoted: m });
        }

        await client.sendMessage(m.chat, { react: { text: '⏳', key: m.reactKey } }).catch(() => {});
        try {
            const filePath = await generateAudio(text);
            const buffer = await fs.readFile(filePath);
            
            // بعت كـ PTT (voice message)
            await client.sendMessage(m.chat, { 
                audio: buffer, 
                ptt: true, 
                mimetype: 'audio/ogg; codecs=opus' 
            }, { quoted: m });
            
            await fs.remove(filePath).catch(() => {});
            return client.sendMessage(m.chat, { react: { text: '✅', key: m.reactKey } }).catch(() => {});
        } catch (error) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            return client.sendMessage(m.chat, { text: `❌ خطأ: ${error.message}` }, { quoted: m });
        }
    }
}];