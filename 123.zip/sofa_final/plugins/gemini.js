import { sendInteractive } from '../lib/sendInteractive.js';
import { smartChat, AiError, SOFA_SYSTEM } from '../lib/sofaAI.js';

const GEMINI = () => `${SOFA_SYSTEM()}\n\nتقمّص أسلوب Gemini: شامل ودقيق ومنظم، وقدّم زوايا متعددة للمواضيع المعقدة.`;

export default async (context) => {
    const { client, m, text, prefix } = context;
    const react = (e) => client.sendMessage(m.chat, { react: { text: e, key: m.reactKey } }).catch(() => {});
    const card = (title, body) => sendInteractive(client, m, `╭─❏ 「 ${title}」\n│ ${body}\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀`);

    if (!text) {
        await react('❌');
        return card('Eʀʀᴏʀ', `اكتب سؤالك بعد الأمر. مثال: ${prefix}gemini ما هو الذكاء الاصطناعي؟`);
    }

    await react('⌛');
    try {
        const reply = await smartChat({ user: m.sender, text, remember: false, effort: 'high', max: 6000, system: GEMINI() });
        await react('✅');
        await card('Gᴇᴍɪɴɪ Rᴇsᴘᴏɴsᴇ', reply);
    } catch (error) {
        console.error('gemini error:', error);
        await react('❌');
        await card('Eʀʀᴏʀ', error instanceof AiError ? error.message : `حصل خطأ: ${error.message}`);
    }
};
