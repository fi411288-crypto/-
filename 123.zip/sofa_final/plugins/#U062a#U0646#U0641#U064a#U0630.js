import { readLinkedPhones, getSession, ownerNumber, digits, connectedSessions, rankInGroup, RANK_AR } from '../lib/adminTools.js';
import { sendButtons } from '../lib/xtools.js';

const RAISE = ['رفع', 'raise'];
const LOWER = ['خفض', 'lower'];

export default [{
    name: 'تنفيذ',
    aliases: ['execute', 'exec'],
    description: 'تنفيذ أي أمر في جروب (الحالي أو بالـ id) + رفع/خفض الأونر',
    usage: '.تنفيذ ق | .تنفيذ زود | .تنفيذ id_جروب زود | .تنفيذ id_جروب رفع',
    category: 'owner',
    ownerSession: true,
    async run({ args, reply, message, sock, bot }) {
        const current = message.key.remoteJid;
        let rest = [...args];

        // الجروب: لو أول كلمة id جروب نستخدمه، غير كده الجروب الحالي
        let groupJid = current.endsWith('@g.us') ? current : null;
        if (rest[0] && String(rest[0]).includes('@g.us')) groupJid = rest.shift();

        // رقم مختار من الأزرار: #2012xxxxxxxx (بيتحط في آخر الأمر)
        let forced = null;
        const fi = rest.findIndex((a) => /^#\d{6,}$/.test(String(a)));
        if (fi !== -1) forced = digits(rest.splice(fi, 1)[0]);

        const pfx = bot?.config?.PREFIX || '.';
        // بيجمع الأرقام المربوطة (ماعدا الأونر) اللي جوه الجروب ورتبتها
        const collect = async () => {
            const out = [];
            for (const s of connectedSessions({ excludeOwner: true })) {
                try {
                    const meta = await s.sock.groupMetadata(groupJid);
                    out.push({ s, phone: digits(s.sock.user?.id), rank: rankInGroup(meta, s.sock) });
                } catch {}
            }
            const ORD = { owner: 0, admin: 1, member: 2 };
            return out.sort((a, b) => ORD[a.rank] - ORD[b.rank]);
        };
        // دايماً يعرض أزرار (حتى لو رقم واحد) بالأرقام، واللي تختاره هو اللي ينفّذ. بيرجّع الرقم المختار أو null (يعني اتعرضت أزرار / مفيش)
        const pick = async (cands, { adminOnly }) => {
            if (forced) {
                const c = cands.find((x) => x.phone === forced);
                if (!c) { await reply(`❌ الرقم ${forced} مش متصل أو مش في الجروب ده.`); return 'MENU'; }
                if (adminOnly && c.rank === 'member') { await reply(`❌ الرقم ${forced} مش أدمن في الجروب ده.`); return 'MENU'; }
                return c;
            }
            const admins = cands.filter((x) => x.rank !== 'member');
            const pool = adminOnly ? admins : (admins.length ? admins : cands);
            if (!pool.length) return null;
            const shown = pool.slice(0, 20);
            const cmdText = `${pfx}تنفيذ ${groupJid} ${rest.join(' ')}`;
            await sendButtons(sock, current, {
                text: `👥 *اختار الرقم اللي هينفّذ*\n\n⚙️ الأمر: \`${rest.join(' ')}\`\n🆔 الجروب: ${groupJid}\n\nمتاح ${pool.length} ${pool.length === 1 ? 'رقم مربوط' : 'أرقام مربوطة'} للتنفيذ، اختار:`,
                buttons: shown.map((x) => ({ text: `${x.phone} ${x.rank === 'owner' ? '👑' : x.rank === 'admin' ? '🛡️' : '👤'}`, id: `${cmdText} #${x.phone}` })),
                quoted: message,
                pickTitle: 'اختار الرقم'
            }).catch((e) => reply('❌ مقدرتش أعرض الأزرار: ' + String(e.message || e).slice(0, 80)));
            return 'MENU';
        };

        const name = String(rest[0] || '').trim();
        if (!name) {
            return reply('الاستخدام:\n.تنفيذ ق  (في الجروب ده)\n.تنفيذ id_جروب زود\n.تنفيذ id_جروب رفع\n.تنفيذ id_جروب خفض');
        }
        if (!groupJid) return reply('❌ اكتب id الجروب: .تنفيذ id_جروب الأمر');

        const lower = name.toLowerCase();

        // ───────── رفع / خفض الأونر عن طريق رقم مربوط أدمن ─────────
        if (RAISE.includes(lower) || LOWER.includes(lower)) {
            const isRaise = RAISE.includes(lower);

            // منع أي عضو أو جلسة فرعية من ترقية نفسها/المالك عبر أمر التنفيذ.
            // طلب الرفع يجب أن يصدر من أدمن حقيقي في نفس الجروب.
            if (isRaise) {
                let requesterIsAdmin = false;
                try {
                    const meta = await sock.groupMetadata(groupJid);
                    const senderJid = message.key?.participant || message.key?.remoteJid;
                    const senderDigits = digits(senderJid);
                    const requester = (meta.participants || []).find((p) =>
                        digits(p.id) === senderDigits || digits(p.phoneNumber) === senderDigits
                    );
                    requesterIsAdmin = requester?.admin === 'admin' || requester?.admin === 'superadmin';
                } catch {}
                if (!requesterIsAdmin) {
                    return reply('⛔ لا يمكن تنفيذ الرفع إلا بطلب من أدمن الجروب نفسه. اطلب من أحد الأدمنز ترقيتك.');
                }
            }

            const targetJid = `${ownerNumber()}@s.whatsapp.net`;
            const cands = await collect();
            if (!cands.length) return reply('❌ مفيش أرقام مربوطة متصلة في الجروب ده');
            const chosen = await pick(cands, { adminOnly: true });
            if (chosen === 'MENU') return;
            if (!chosen) return reply('❌ لا يوجد رقم أدمن أو مالك في هذا الجروب من الأرقام المربوطة');
            const adminSession = chosen.s, adminPhone = chosen.phone;

            try {
                await adminSession.sock.groupParticipantsUpdate(groupJid, [targetJid], isRaise ? 'promote' : 'demote');
                return reply(`${isRaise ? '✅ تم رفعك أدمن' : '✅ تم خفضك من الأدمن'}\n(من خلال: ${adminPhone})`);
            } catch (e) {
                return reply(`❌ فشل: ${String(e.message || e).slice(0, 80)}`);
            }
        }

        // ───────── تنفيذ أي أمر تاني داخل الجروب ─────────
        if (['تنفيذ', 'execute', 'exec'].includes(lower)) return reply('❌ مينفعش تنفذ تنفيذ جوه تنفيذ');

        const prefix = bot?.config?.PREFIX || '.';
        const ownerJid = `${ownerNumber()}@s.whatsapp.net`;

        // ───── نختار رقم مربوط (مش الأونر) جوه الجروب ده: لو أكتر من أدمن بنعرض أزرار ─────
        const candidates = await collect();
        if (!candidates.length) return reply('❌ مفيش رقم مربوط متصل وعضو في الجروب ده.');
        const chosen = await pick(candidates.filter((c) => c.s.handler), { adminOnly: false });
        if (chosen === 'MENU') return;
        if (!chosen) return reply('❌ مفيش رقم مربوط متصل وعضو في الجروب ده.');
        const { s: exec, rank } = chosen;
        const execPhone = digits(exec.sock.user?.id);
        const execHandler = exec.handler;
        const execCmd = execHandler.commands.get(lower) || execHandler.commands.get(execHandler.aliases.get(lower));
        if (!execCmd) return reply(`❌ الرقم ${execPhone} معندوش أمر اسمه "${name}"`);

        // زود بيطلّع ملخص لما يتشغّل من برا الجروب الهدف، فنشغّله من "شات الأونر" ونديله الـ id ونمنع إرسال الملخص ونعرضه هنا
        const isZeed = execCmd.name === 'زود';
        const remote = isZeed ? ownerJid : groupJid;
        const text = isZeed ? `${prefix}${rest.join(' ')} ${groupJid}` : prefix + rest.join(' ');

        // رسالة وهمية جاية من الأونر (مش fromMe) عشان الرقم المربوط يعتبرها من صاحب الأمر
        const fake = {
            key: { remoteJid: remote, fromMe: false, id: 'SOFA' + Date.now().toString(36).toUpperCase(), participant: ownerJid },
            message: { conversation: text },
            messageTimestamp: Math.floor(Date.now() / 1000),
            pushName: 'SOFA'
        };

        // نلتقط ردود الأمر + سجل الكونسول بتاعه
        const sent = [], logged = [];
        const textOf = (c) => typeof c === 'string' ? c : (c?.text || c?.caption || (c?.react ? `[تفاعل ${c.react.text}]` : '[ميديا]'));
        const eh = exec.handler, es = exec.sock;
        const origH = eh.sendMessage.bind(eh);
        const origS = es.sendMessage.bind(es);
        const origErr = console.error, origLog = console.log;
        const hold = (jid) => isZeed && jid === ownerJid; // ملخص زود: منبعتوش من الرقم المربوط
        eh.sendMessage = async (jid, c, o) => { sent.push(textOf(c)); return hold(jid) ? null : origH(jid, c, o); };
        es.sendMessage = async (jid, c, o) => { sent.push(textOf(c)); return hold(jid) ? null : origS(jid, c, o); };
        const grab = (fn) => (...a) => { const l = a.map(String).join(' '); if (/^\[/.test(l)) logged.push(l); fn(...a); };
        console.error = grab(origErr);
        console.log = grab(origLog);

        let found = true;
        try {
            found = await eh.handlePrefixCommand(fake, text, ownerJid, true, true);
        } catch (e) {
            sent.push('❌ ' + String(e.message || e));
        } finally {
            eh.sendMessage = origH;
            es.sendMessage = origS;
            console.error = origErr;
            console.log = origLog;
        }

        const who = `${execPhone} (${RANK_AR[rank] || rank})`;
        const errors = sent.filter((t) => /^(❌|⚠️)/.test(String(t)));
        const logTail = logged.length ? `\n📝 سجل:\n${logged.slice(0, 3).map((l) => l.slice(0, 120)).join('\n')}` : '';
        const shown = sent.filter((t) => !/^\[تفاعل/.test(String(t))).slice(0, 3).map((t) => String(t).slice(0, 200)).join('\n');

        // لو الأمر صامت وإنت جوه جروب: الحالة تتبعت لشات الأونر (رسالة لنفسك) عشان ميبانش حاجة في الجروب
        const notify = (t) => (current.endsWith('@g.us') && !sent.length)
            ? sock.sendMessage(ownerJid, { text: t }).catch(() => {})
            : reply(t);

        if (!found) return reply(`⚠️ الرقم ${who} رفض الأمر (صلاحيات أو كولداون).`);
        if (errors.length) return reply(`❌ نفّذ ${who} بس الأمر رجّع خطأ:\n${errors.slice(0, 2).join('\n')}${logTail}`);
        if (!sent.length) return notify(`✅ اتنفذ ${prefix}${execCmd.name} بواسطة ${who}\n(الأمر بيشتغل بصمت ومبعتش رد)${logTail}`);
        return reply(`✅ اتنفذ ${prefix}${execCmd.name} بواسطة ${who}\n${shown}${logTail}`);
    }
}];