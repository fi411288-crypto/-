// 📊 للمطور: إحصائيات مهام المتابعة والدعوات — SOFA BOT
import { taskStats, TASK_REWARD } from '../lib/tgTasks.js';
import { fmt } from '../lib/shop.js';
import { isDevSender } from '../lib/devAuth.js';
import fs from 'fs';
import path from 'path';

export default [{
    name: 'احصاء-مهام',
    aliases: ['إحصاء-مهام', 'احصاء_مهام', 'إحصاء_مهام', 'taskstats'],
    category: 'dev',
    description: 'للمطور: إحصائيات مهام المتابعة والدعوات',
    cooldown: 3000,
    async run(ctx) {
        const { reply } = ctx;
        if (!(await isDevSender(ctx))) return reply('❌ الأمر ده للمطور فقط.');
        const s = taskStats();
        let refs = 0;
        try { refs = Object.keys(JSON.parse(fs.readFileSync(path.join(process.cwd(), 'data', 'referrals.json'), 'utf8')).rewarded || {}).length; } catch {}
        return reply(
            `📊 *SOFA • TASKS STATS*\n\n` +
            `👥 أرقام شاركت: \`${fmt(s.users)}\`\n📢 خلّصوا مهمة التليجرام: \`${fmt(s.tg)}\`\n💬 خلّصوا مهمة الواتساب: \`${fmt(s.wa)}\`\n🏆 خلّصوا الاتنين: \`${fmt(s.both)}\`\n` +
            `💰 كوين اتصرفت (مهام): \`${fmt(s.paid)}\`  (${fmt(TASK_REWARD)} للمهمة)\n\n🤝 دعوات ناجحة: \`${fmt(refs)}\`\n\n> SOFA BOT`
        );
    }
}];
