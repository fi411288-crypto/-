import { store, perms, idsOf, sendButtons, digits } from '../lib/xtools.js';

const polls = () => store('polls', {}).data;
const NUM = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

function render(p, closed) {
    const counts = p.opts.map((_, i) => Object.values(p.votes).filter((v) => v === i).length);
    const total = counts.reduce((a, b) => a + b, 0);
    const lines = p.opts.map((o, i) => {
        const pct = total ? Math.round((counts[i] / total) * 100) : 0;
        return `${NUM[i]} *${o}*\n    ${'▰'.repeat(Math.round(pct / 10))}${'▱'.repeat(10 - Math.round(pct / 10))} ${counts[i]} (${pct}%)`;
    });
    return `📊 *${p.q}*\n\n${lines.join('\n\n')}\n\n👥 إجمالي الأصوات: *${total}*\n${closed ? '🔒 التصويت انتهى' : '👇 اختار من الأزرار (تقدر تغيّر صوتك)'}\n\n> SOFA BOT`;
}

async function publish(sock, p, quoted) {
    if (p.key) sock.sendMessage(p.jid, { delete: p.key }).catch(() => {});
    const buttons = p.opts.map((o, i) => ({ text: `${i + 1}. ${o}`, id: `.صوت ${p.id} ${i}` }));
    try { p.key = await sendButtons(sock, p.jid, { text: render(p), buttons, quoted, pickTitle: 'صوّت' }); }
    catch (e) {
        const m = await sock.sendMessage(p.jid, { text: `${render(p)}\n\nللتصويت اكتب: .صوت ${p.id} رقم_الخيار` }, { quoted });
        p.key = m?.key;
    }
    store('polls').save();
}

const create = {
    name: 'تصويت',
    aliases: ['استفتاء', 'poll'],
    description: 'استفتاء بأزرار والنتيجة بتتحدّث لوحدها',
    usage: '.تصويت السؤال | خيار1 | خيار2 | ... (2 إلى 10) — .تصويت انهاء',
    category: 'admin',
    group: true,
    async run({ sock, message, text, reply, isDeveloper }) {
        const jid = message.key.remoteJid;
        if (!(await perms({ sock, message, isDeveloper })).isAdmin) return reply('❌ الأمر ده للمشرفين فقط.');
        if (/^(انهاء|إنهاء|انهي|stop|end)$/i.test(text.trim())) {
            const p = Object.values(polls()).filter((x) => x.jid === jid && !x.closed).sort((a, b) => b.at - a.at)[0];
            if (!p) return reply('❌ مفيش تصويت شغال في الجروب.');
            p.closed = true;
            if (p.key) sock.sendMessage(jid, { delete: p.key }).catch(() => {});
            store('polls').save();
            return reply(render(p, true));
        }
        const parts = text.split('|').map((s) => s.trim()).filter(Boolean);
        if (parts.length < 3 || parts.length > 11) return reply('📊 الاستخدام:\n.تصويت السؤال | خيار1 | خيار2 | خيار3\n(من 2 لـ 10 خيارات)\nلإنهاء التصويت: .تصويت انهاء');
        const [q, ...opts] = parts;
        const id = Date.now().toString(36);
        const d = polls();
        for (const [k, v] of Object.entries(d)) if (Date.now() - v.at > 30 * 864e5) delete d[k];
        d[id] = { id, jid, q: q.slice(0, 200), opts: opts.map((o) => o.slice(0, 60)), votes: {}, at: Date.now(), key: null, closed: false };
        await publish(sock, d[id], message);
    }
};

const vote = {
    name: 'صوت',
    aliases: ['vote'],
    description: 'زرار التصويت (داخلي)',
    category: 'hidden',
    group: true,
    async run({ sock, message, args, reply }) {
        const p = polls()[args[0]];
        if (!p || p.jid !== message.key.remoteJid) return reply('❌ التصويت ده مش موجود.');
        if (p.closed) return reply('🔒 التصويت ده انتهى.');
        let i = Number(args[1]);
        if (!Number.isInteger(i)) return;
        if (i >= p.opts.length && i <= p.opts.length && !p.opts[i]) i -= 1; // لو كتب الرقم من 1
        if (!p.opts[i]) return reply('❌ خيار غلط.');
        const uid = idsOf(message)[0];
        if (!uid) return;
        if (p.votes[uid] === i) return;
        p.votes[uid] = i;
        p.chain = (p.chain || Promise.resolve()).then(() => publish(sock, p, message)).catch(() => {});
    }
};

export default [create, vote];
