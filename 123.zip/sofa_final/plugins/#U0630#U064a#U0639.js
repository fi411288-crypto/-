import { isAllowedSender } from '../lib/banTargets.js';

export default {
    name: "ذيع",
    aliases: ["بث-تليجرام", "broadcast"],
    description: "يبعت رسالة لكل مستخدمي بوت تليجرام",
    category: "admin",

    async run({ sock, message, args, reply, handler, prefix }) {
        if (!isAllowedSender(handler, message, sock)) return reply("❌ الأمر ده مش متاح لرقمك.");

        const text = args.join(' ').trim();
        if (!text) return reply(`📌 الاستخدام: ${prefix || '.'}ذيع الرسالة اللي عايز تبعتها\nمثال: ${prefix || '.'}ذيع البوت شغال`);

        const tg = global.bot?.telegram;
        if (!tg?.telegram) return reply("❌ بوت تليجرام مش شغال دلوقتي.");

        await reply(`⏳ جاري الإرسال لـ ${tg.totalUserIds().size} مستخدم تليجرام...`);
        const r = await tg.broadcast(text);
        return reply(`📢 *تمت الإذاعة*\n\n✅ وصلت: ${r.sent}\n🚫 حاظرين البوت: ${r.blocked}\n⏭️ متخطيين (حظر/محظور): ${r.skipped}\n⚠️ فشلت: ${r.failed}\n👥 الإجمالي: ${r.total}`);
    }
};
