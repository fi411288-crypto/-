// .بوت ← رد بـ "تحت أمرك يا سوفا يافحلي"
export default [{
    name: 'بوت',
    aliases: ['bot'],
    description: 'رد الترحيب',
    category: 'tools',
    ownerSession: true,
    async run({ reply }) {
        return reply('تحت أمرك يا سوفا يافحلي 👑');
    }
}];