// 🎟️ أكواد الهدايا: المطور بيعمل الكود (مبلغ + عدد الناس) والأعضاء بياخدوه بـ .خدش — SOFA BOT
import { resolveNumber, isRegistered, updateUser } from '../lib/economy.js';
import { store } from '../lib/xtools.js';
import { fmt, toEnDigits } from '../lib/shop.js';

const db = () => store('codes', {}).data;
const save = () => store('codes').save();
const key = (c) => String(c || '').trim().toUpperCase();
const valid = (c) => /^[A-Z0-9_\u0600-\u06FF]{3,20}$/.test(c);
const dev = (isDeveloper, reply) => (isDeveloper ? true : (reply('❌ الأمر ده للمطور فقط.'), false));

export default [
    {
        name: 'خدش',
        aliases: ['redeem', 'كود'],
        category: 'games',
        description: 'استلم هدية من كود (كود واحد لكل عضو)',
        usage: '.خدش CODE',
        cooldown: 3000,
        async run({ sock, m, message, args, reply, prefix = '.' }) {
            const msg = m || message, number = await resolveNumber(sock, msg);
            if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
            const k = key(args[0]);
            if (!k) return reply(`❌ اكتب الكود: *${prefix}خدش CODE*`);
            const c = db()[k];
            if (!c) return reply('❌ الكود غلط أو منتهي.');
            if (c.used.includes(number)) return reply('ℹ️ أنت استخدمت الكود ده قبل كده.');
            if (c.used.length >= c.max) return reply('😢 الكود خلص! كل الأماكن اتاخدت.');
            const r = updateUser(number, (u, eco) => { eco.coin += c.amount; return { total: eco.coin }; });
            if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ.');
            c.used.push(number); save();
            return reply(`🎟️ *SOFA • CODE*\n\n✅ استلمت \`${fmt(c.amount)}\` كوين!\n💰 رصيدك: \`${fmt(r.total)}\`\n👥 باقي ${c.max - c.used.length} مكان على الكود`);
        }
    },
    {
        name: 'انشاء_كود',
        aliases: ['كود_جديد', 'newcode'],
        category: 'dev',
        description: 'للمطور: إنشاء كود هدية (المبلغ وعدد الأشخاص)',
        usage: '.انشاء_كود RAMADAN 5000 50',
        cooldown: 1500,
        async run({ args, reply, isDeveloper, prefix = '.' }) {
            if (!dev(isDeveloper, reply)) return;
            const k = key(args[0]), amount = parseInt(toEnDigits(args[1] || ''), 10), max = parseInt(toEnDigits(args[2] || '1'), 10);
            if (!valid(k) || !(amount > 0) || !(max > 0)) return reply(`❌ الصيغة:\n*${prefix}انشاء_كود الكود المبلغ عدد_الأشخاص*\nمثال: *${prefix}انشاء_كود RAMADAN 5000 50*\n(الكود 3-20 حرف/رقم)`);
            if (amount > 10000000 || max > 10000) return reply('❌ المبلغ حد أقصى 10,000,000 والأشخاص 10,000.');
            if (db()[k]) return reply('❌ الكود موجود بالفعل. احذفه الأول بـ .حذف_كود');
            db()[k] = { amount, max, used: [], at: Date.now() }; save();
            return reply(`✅ *اتعمل الكود!*\n\n🎟️ \`${k}\`\n💰 \`${fmt(amount)}\` كوين لكل واحد\n👥 أول *${max}* شخص\n\nقول للناس يكتبوا: *${prefix}خدش ${k}*`);
        }
    },
    {
        name: 'حذف_كود',
        aliases: ['delcode'],
        category: 'dev',
        description: 'للمطور: حذف كود',
        cooldown: 1500,
        async run({ args, reply, isDeveloper }) {
            if (!dev(isDeveloper, reply)) return;
            const k = key(args[0]);
            if (!db()[k]) return reply('❌ الكود مش موجود.');
            delete db()[k]; save(); return reply('🗑️ اتحذف الكود.');
        }
    },
    {
        name: 'اكواد',
        aliases: ['codes'],
        category: 'dev',
        description: 'للمطور: عرض الأكواد واستخدامها',
        cooldown: 1500,
        async run({ reply, isDeveloper }) {
            if (!dev(isDeveloper, reply)) return;
            const l = Object.entries(db());
            return reply(l.length ? `🎟️ *الأكواد*\n\n${l.map(([k, c]) => `• \`${k}\` — ${fmt(c.amount)} كوين — ${c.used.length}/${c.max}`).join('\n')}` : '📭 مفيش أكواد.');
        }
    }
];
