import { getAdminFlags } from '../lib/compat.js';
import { getTrustedLinks, addTrustedLink } from '../database/config.js';

const fmt = (msg) => `╭─❏ 「 TRUSTLINK」\n│ ${msg}\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀`;

export default {
    name: 'trustlink',
    aliases: ['trustedlinks'],
    description: 'السماح برابط معين رغم تفعيل antilink (أو عرض الروابط المسموحة)',
    category: 'group',

    async run({ sock, message, args, reply, isGroup, isDeveloper, prefix }) {
        if (!isGroup) return reply(fmt('Groups only.'));
        const jid = message.key.remoteJid;
        const meta = await sock.groupMetadata(jid);
        const { isAdmin } = getAdminFlags(sock, message, meta);
        if (!isAdmin && !isDeveloper) return reply(fmt('Admins only.'));

        const link = args.join(' ').trim();
        if (!link) {
            const list = await getTrustedLinks(jid);
            return reply(fmt(`Trusted links: *${list.length}*\n${list.map((l) => `│ • ${l}`).join('\n') || '│ (none)'}\n│ \n│ Usage: ${prefix}trustlink <link>\n│ Remove: ${prefix}untrustlink <link>`));
        }
        if (!(await addTrustedLink(jid, link))) return reply(fmt('Invalid link.'));
        return reply(fmt(`✅ Link trusted. Antilink will ignore it:\n│ ${link}`));
    }
};
