  import { makeCanvas } from '../lib/toxicApi.js';
    import { getSettings } from '../database/config.js';
import { sendInteractive } from '../lib/sendInteractive.js';

  const CANVAS_TYPES = [
      'spotify', 'youtube', 'google', 'tiktok', 'duckduckgo', 'brave', 'applemusic',
      'soundcloud', 'pinterest', 'playstore', 'happymod', 'apkpure', 'unsplash',
      'wallpaper', 'wattpad', 'weather', 'sticker', 'lyrics', 'shazam', 'web', 'image',
  ];

  export default {
      name: 'canvas',
      aliases: ['canvascard', 'spotifycard', 'youtubecard', 'tiktokcard'],
      description: 'Generate themed canvas cards from an image',
      category: 'Editing',
      run: async (context) => {
          const { client, m, text: argText } = context;
        await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });
          const settings = await getSettings();
          const prefix = settings.prefix || '.';

          const quoted = m.quoted ? m.quoted : null;
          const mime = quoted?.mimetype || '';
          const args = String(argText || '').trim();

          const typesList = CANVAS_TYPES.map(t => `│ • ${t}`).join('\n');
          const usageMsg = `╭─❏ 「 Cᴀɴᴠᴀs Cᴀʀᴅ」
│ Reply to an image to use this.\n│ \n│ *Usage:*\n│ ${prefix}canvas Title | type | text | watermark\n│ \n│ *Example:*\n│ ${prefix}canvas Blinding Lights | spotify | The Weeknd | SOFA\n│ ${prefix}canvas My Video | youtube | Subscribe Now | BOT\n│ \n│ *Available Types (${CANVAS_TYPES.length}):*\n${typesList}\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀`;

          if (!quoted || !/image/.test(mime)) {
              await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
              return client.sendMessage(m.chat, { text: usageMsg });
          }

          const parts = args.split('|').map(s => s.trim());
          const title = parts[0] || 'Unknown Title';
          const rawType = (parts[1] || 'spotify').toLowerCase();
          const type = CANVAS_TYPES.includes(rawType) ? rawType : 'spotify';
          const text = parts[2] || '';
          const watermark = parts[3] || 'SOFA';

          if (parts[1] && !CANVAS_TYPES.includes(rawType)) {
              return sendInteractive(client, m, `╭─❏ 「 Eʀʀᴏʀ」
│ Invalid type: *${parts[1]}*\n│ \n│ Valid types:\n${typesList}\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀`);
          }

          await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });

          try {
              const media = await quoted.download();
              const cardBuf = await makeCanvas(media, title, type, text, watermark);

              await client.sendMessage(m.chat, { react: { text: '✅', key: m.reactKey } });
              await client.sendMessage(m.chat, {
                  image: cardBuf,
                  caption: `╭─❏ 「 Cᴀɴᴠᴀs Cᴀʀᴅ」
│ *Type:* ${type}\n│ *Title:* ${title}\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀`
              });
          } catch (err) {
              await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } });
              await sendInteractive(client, m, `╭─❏ 「 Eʀʀᴏʀ」
│ Canvas generation failed: ${String(err?.message || err).slice(0, 80)}\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀`);
          }
      }
  };
  