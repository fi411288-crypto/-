import { isPrivateOnly, setPrivateOnly } from '../lib/privateMode.js';

const ON = ['تشغيل', 'شغل', 'تفعيل', 'on', '1'];
const OFF = ['ايقاف', 'إيقاف', 'توقيف', 'الغاء', 'إلغاء', 'off', '0'];

export default {
    name: 'خاص',
    aliases: ['private', 'privateonly', 'خاص-فقط'],
    description: 'تشغيل/إيقاف وضع الخاص فقط (البوت يشتغل في الخاص ويتجاهل الجروبات) — للمطور فقط',
    category: 'developer',

    async run({ sock, args, reply, isDeveloper, prefix }) {
        if (!isDeveloper) return reply('❌ هذا الأمر للمطور فقط.');
        const p = prefix || '.';
        const choice = (args[0] || '').trim().toLowerCase();

        if (ON.includes(choice)) {
            setPrivateOnly(sock, true);
            return reply(`🔒 تم تشغيل *وضع الخاص فقط*.\nالبوت هيشتغل في الشات الخاص بس، وهيتجاهل كل الجروبات (أوامر وردود وترحيب).\n\nللرجوع اكتب: ${p}خاص ايقاف (تقدر تكتبه في أي جروب).`);
        }
        if (OFF.includes(choice)) {
            setPrivateOnly(sock, false);
            return reply('🔓 تم إيقاف *وضع الخاص فقط*.\nالبوت رجع يشتغل في الخاص والجروبات.');
        }
        return reply(`⚙️ *وضع الخاص فقط*\nالحالة الآن: ${isPrivateOnly(sock) ? '🟢 شغال (الجروبات متجاهلة)' : '🔴 متوقف (يشتغل في كل مكان)'}\n\n• ${p}خاص تشغيل\n• ${p}خاص ايقاف`);
    }
};
