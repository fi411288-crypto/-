import { ytCommand } from '../lib/youtube.js';

export default {
    name: 'اغنيه',
    aliases: ['اغنية', 'song'],
    description: 'تحميل أغنية من يوتيوب بالاسم',
    category: 'downloader',
    run: (ctx) => ytCommand(ctx, 'audio', 'اغنيه')
};
