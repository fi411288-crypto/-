// .فحص_قنوات ← بيعرض دوال القنوات المتاحة في نسخة baileys (للأونر بس، من جلسته)
export default [{
    name: 'فحص_قنوات',
    description: 'عرض دوال القنوات المتاحة في baileys',
    category: 'owner',
    ownerSession: true,
    async run({ sock, reply }) {
        const names = Object.keys(sock).filter((k) => /newsletter|channel/i.test(k) && typeof sock[k] === 'function').sort();
        return reply(names.length ? `📢 دوال القنوات المتاحة:\n\n${names.join('\n')}` : '❌ مفيش أي دوال قنوات.');
    }
}];
