export default {
  name: 'اختراق',
  description: 'مزاح: تم اختراقك بنجاح 😱💻',
  category: 'ترفيه',
  group: true,

  run: async (context) => {
    const { sock, m, text } = context;
    const from = m.key.remoteJid;

    // دالة لتأخير الوقت
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    // تحديد الهدف (منشن أو ريبلاي)
    let target;
    if (m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
      target = m.message.extendedTextMessage.contextInfo.mentionedJid[0];
    } else if (m.message?.extendedTextMessage?.contextInfo?.participant) {
      target = m.message.extendedTextMessage.contextInfo.participant;
    }

    if (!target) {
      return m.reply("⚠️ لازم تعمل منشن أو ريبلاي على رسالة عشان أحدد مين أختَرِقه 😅");
    }

    const loadingSteps = [
      "*جاري الحصول علي عنوان IP هاتف الضحية...*",
      "*جاري تحميل الاختراق* 《 ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒》0%",
      "*جاري تحميل الصور* 《 █▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒》10%",
      "*تم تحميل الصور* 《 ██▒▒▒▒▒▒▒▒▒▒▒▒▒▒》20%",
      "*جاري تحميل الفيديوهات* 《 ███▒▒▒▒▒▒▒▒▒▒▒▒▒》30%",
      "*تم تحميل الفيديوهات* 《 ████▒▒▒▒▒▒▒▒▒▒▒▒》40%",
      "*جاري تحميل الاصوات* 《 █████▒▒▒▒▒▒▒▒▒▒▒》50%",
      "*تم تحميل الاصوات* 《 ██████▒▒▒▒▒▒▒▒▒▒》60%",
      "*جاري تحميل الملفات* 《 ███████▒▒▒▒▒▒▒▒▒》70%",
      "*تم تحميل الملفات* 《 ████████▒▒▒▒▒▒▒▒▒》80%",
      "*جاري تحميل محادثات واتساب* 《 █████████▒▒▒▒▒▒▒》90%",
      "*تم تحميل محادثات واتساب* 《 ███████████▒▒▒▒▒》92%",
      "*يتم رفع الاختراق علي السيرفر* 《 ███████████▒▒▒▒▒》95%",
      "*تم الاتصال بجهاز الضحيه.. جاري تحميل البيانات* 《 ███████████▒▒▒▒▒》96%",
      "*اختراق الضحيه 100% ✅* 《 ████████████████》100%",
      "*جاري حفظ بيانات الضحيه...* ⌛",
      "*تم حفظ بيانات الضحيه بنجاح ✅*"
    ];

    try {
      // نبعت أول رسالة ونحفظ الـ Key بتاعها عشان نعدلها
      let { key } = await sock.sendMessage(from, { 
        text: loadingSteps[0], 
        mentions: [target] 
      }, { quoted: m });

      // اللوب اللي بيعدل الرسالة بكل خطوة
      for (let i = 1; i < loadingSteps.length; i++) {
        await sleep(1000); // استنى ثانية بين كل خطوة
        await sock.sendMessage(from, { 
          text: loadingSteps[i], 
          edit: key, 
          mentions: [target] 
        });
      }

      // الرسالة النهائية
      await sleep(1500);
      const finalText = `━━━━━━━⬣ *👾* ⬣━━━━━━━\n> *تم اختراقك بنجاح* ✅\n@${target.split('@')[0]} ملفاتك وبياناتك صارت عندنا! 👨‍💻\n\n> *𝐒𝐎𝐅𝐀 𝐁𝐎𝐓*\n━━━━━━━⬣ *👾* ⬣━━━━━━━`;

      await sock.sendMessage(from, { 
        text: finalText, 
        edit: key, 
        mentions: [target] 
      });

    } catch (error) {
      console.error("خطأ في أمر اختراق:", error);
    }
  }
};
