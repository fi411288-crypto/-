import { sendFeedback } from '../lib/feedback.js';

export default {
    name: "اقتراح",
    aliases: ["اقتراحات", "suggest", "suggestion"],
    description: "ابعت اقتراح للمطور",
    usage: ".اقتراح نص الاقتراح",
    category: "tools",

    async run({ sock, message, args, reply, prefix }) {
        return sendFeedback({ kind: 'suggestion', sock, message, args, reply, prefix });
    }
};
