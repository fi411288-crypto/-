export default {
    name: 'ايدي',
    description: 'عرض هوية الشخص مع تحديد بلده بدقة',
    category: 'tools',

    run: async (context) => {
        const { sock, m } = context;
        const jid = m.key.remoteJid;

        // تحديد الهدف: منشن > ريبلاي > أنت
        const mentionedJid = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        const quotedJid = m.message?.extendedTextMessage?.contextInfo?.participant;
        const target = mentionedJid || quotedJid || m.key.participant || jid;

        // تنظيف الرقم تماماً
        const userNumber = target.split('@')[0].replace(/[^0-9]/g, '');

        // قائمة البلاد الموسعة (عشان ميبقاش غير معروف)
        let country = "غير معروف 🌍";
        
        const countryCodes = {
            '20': 'مصر 🇪🇬',
            '966': 'السعودية 🇸🇦',
            '212': 'المغرب 🇲🇦',
            '213': 'الجزائر 🇩🇿',
            '216': 'تونس 🇹🇳',
            '962': 'الأردن 🇯🇴',
            '964': 'العراق 🇮🇶',
            '965': 'الكويت 🇰🇼',
            '971': 'الإمارات 🇦🇪',
            '974': 'قطر 🇶🇦',
            '968': 'عمان 🇴🇲',
            '961': 'لبنان 🇱🇧',
            '963': 'سوريا 🇸🇾',
            '967': 'اليمن 🇾🇪',
            '249': 'السودان 🇸🇩',
            '218': 'ليبيا 🇱🇾',
            '973': 'البحرين 🇧🇭',
            '970': 'فلسطين 🇵🇸'
        };

        // فحص الكود من الرقم
        for (let code in countryCodes) {
            if (userNumber.startsWith(code)) {
                country = countryCodes[code];
                break;
            }
        }

        // جلب صورة البروفايل
        let ppUrl;
        try {
            ppUrl = await sock.profilePictureUrl(target, 'image');
        } catch {
            ppUrl = 'https://telegra.ph/file/ec732bd887a030513e9a4.jpg'; 
        }

        const idText = `
╭━━━〔 🆔 *𝐁𝐎𝐓 𝐈𝐃𝐄𝐍𝐓𝐈𝐓𝐘* 〕━━━╮

👤 *الحساب:* @${userNumber}
📱 *رقم الموبايل:* ${userNumber}
🌍 *البلد:* ${country}
🆔 *الايدي:* ${target}

╰━━━━━━━━━━━━━━━╯
> *𝐒𝐎𝐅𝐀 𝐁𝐎𝐓 ⚡*`;

        try {
            await sock.sendMessage(jid, { 
                image: { url: ppUrl },
                caption: idText,
                mentions: [target]
            }, { quoted: m });
        } catch (error) {
            await sock.sendMessage(jid, { text: idText, mentions: [target] }, { quoted: m });
        }
    }
};
