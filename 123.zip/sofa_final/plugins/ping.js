import os from 'os';

const fmt = (s) => {
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
    return h ? `${h}h ${m}m` : `${m}m ${Math.floor(s % 60)}s`;
};

export default {
    name: 'ping',
    aliases: ['بنج', 'سرعه'],
    description: 'قياس سرعة البوت واستهلاك السيرفر',
    category: 'tools',

    async run({ sock, message, reply }) {
        const jid = message.key.remoteJid;

        // تأخير وصول رسالتك للبوت (تقريبي لأن واتساب بيسجل بالثواني)
        const ts = Number(message.messageTimestamp?.low ?? message.messageTimestamp ?? 0);
        const incoming = ts ? Math.max(0, Date.now() - ts * 1000) : null;

        // سرعة إرسال رسالة من البوت
        const t0 = Date.now();
        const sent = await sock.sendMessage(jid, { text: '🏓 جاري القياس...' }, { quoted: message });
        const sendMs = Date.now() - t0;

        const mem = Math.round(process.memoryUsage().rss / 1024 / 1024);
        const load = os.loadavg()[0].toFixed(2);
        const text =
`🏓 *Pong!*

📥 وصول رسالتك: ${incoming === null ? '—' : `~${incoming}ms`}
📤 سرعة الإرسال: ${sendMs}ms
💾 الرام: ${mem}MB
🧠 حمل المعالج: ${load}
⏳ مدة التشغيل: ${fmt(process.uptime())}
> SOFA BOT`;

        try {
            await sock.sendMessage(jid, { text, edit: sent.key });
        } catch {
            await reply(text);
        }
    }
};
