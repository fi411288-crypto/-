import { downloadContentFromMessage } from '@whiskeysockets/baileys';

export default {
    name: 'كشف',
    aliases: ['viewonce', 'vv', 'افتح'],
    description: 'فتح رسالة مشاهدة مرة واحدة (رد على الرسالة)',
    category: 'tools',
    usage: 'رد على رسالة view once بـ .كشف',

    async run({ sock, m, message, reply, react }) {
        const msg = m || message;
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
            || msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        // baileys often puts viewOnce inside viewOnceMessage
        const q = msg.message?.extendedTextMessage?.contextInfo;
        let target = null;
        if (q?.quotedMessage) {
            const qm = q.quotedMessage;
            target = qm.viewOnceMessage?.message || qm.viewOnceMessageV2?.message || qm.viewOnceMessageV2Extension?.message || qm;
        }
        if (!target) return reply('❌ رد على رسالة *مشاهدة مرة واحدة*');

        await react?.('⏳').catch?.(() => {});
        try {
            let type = Object.keys(target).find(k => k.endsWith('Message')) || Object.keys(target)[0];
            const content = target[type];
            if (!content) throw new Error('مفيش ميديا');
            const mediaType = type.replace('Message', '').replace('image', 'image').replace('video', 'video').replace('audio', 'audio');
            const stream = await downloadContentFromMessage(content, mediaType.includes('video') ? 'video' : mediaType.includes('audio') ? 'audio' : 'image');
            const chunks = [];
            for await (const c of stream) chunks.push(c);
            const buf = Buffer.concat(chunks);
            const jid = msg.key.remoteJid;
            if (type.includes('image')) {
                await sock.sendMessage(jid, { image: buf, caption: '👁️ تم فتح المشاهدة مرة واحدة' }, { quoted: msg });
            } else if (type.includes('video')) {
                await sock.sendMessage(jid, { video: buf, caption: '👁️ تم فتح المشاهدة مرة واحدة' }, { quoted: msg });
            } else if (type.includes('audio')) {
                await sock.sendMessage(jid, { audio: buf, mimetype: content.mimetype || 'audio/mp4', ptt: !!content.ptt }, { quoted: msg });
            } else {
                return reply('❌ نوع الميديا مش مدعوم');
            }
            await react?.('✅').catch?.(() => {});
        } catch (e) {
            await react?.('❌').catch?.(() => {});
            return reply('❌ فشل الفتح: ' + (e.message || e));
        }
    }
};
