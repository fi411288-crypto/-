import { makeNsfwCommand } from '../lib/nsfw.js';
export default makeNsfwCommand({ name: 'anal', title: 'Anal', emoji: '🔞', endpoint: 'https://prexzyapis.com/nsfw/anal', usage: '.anal' });
