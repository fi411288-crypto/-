export default {
    name: 'هيدن',
    aliases: ['hidetag', 'مخفي', 'htag'],
    description: 'منشن مخفي لكل الأعضاء مع رسالة',
    category: 'admin',
    group: true,
    admin: true,

    async run({ sock, m, message, text, reply }) {
        const msg = m || message;
        const jid = msg.key.remoteJid;
        const body = (text || '').trim() || '📢';
        try {
            const meta = await sock.groupMetadata(jid);
            const mentions = (meta.participants || []).map(p => p.id).filter(Boolean);
            await sock.sendMessage(jid, { text: body, mentions }, { quoted: msg });
        } catch (e) {
            return reply('❌ ' + e.message);
        }
    }
};
