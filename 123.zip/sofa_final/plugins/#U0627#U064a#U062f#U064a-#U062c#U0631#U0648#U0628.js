export default {
    name: "ايدي_جروب",
    aliases: ["جروب_id", "groupid", "gid"],
    description: "يجيب id الجروب من لينك الدعوة",
    category: "عام",
    usage: ".ايدي_جروب https://chat.whatsapp.com/XXXX",

    async run({ sock, m, args, reply }) {
        try {
            const quoted = m?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || "";
            const input = `${args.join(" ")} ${quotedText}`;
            const match = input.match(/chat\.whatsapp\.com\/(?:invite\/)?([A-Za-z0-9]{20,24})/);
            if (!match) return reply("❌ ابعت لينك الجروب أو رد على رسالة فيها اللينك.\nمثال: .ايدي_جروب https://chat.whatsapp.com/XXXXXXXX");

            const info = await sock.groupGetInviteInfo(match[1]);
            return reply(
                `✅ *بيانات الجروب*\n\n` +
                `📛 الاسم: ${info.subject}\n` +
                `🆔 ID: ${info.id}\n` +
                `👥 الأعضاء: ${info.size ?? info.participants?.length ?? "?"}`
            );
        } catch (err) {
            return reply("❌ مقدرتش أجيب الجروب (اللينك غلط أو منتهي أو الجروب مقفول): " + err.message);
        }
    }
};
