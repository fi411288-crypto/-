import { digits, getSession, readLinkedPhones, listGroups, rankInGroup, groupLink, listChannels,
    RANK_AR, CHANNEL_ROLE_AR, chunkLines, sleep, errText } from '../lib/adminTools.js';

// .اسكا 20xxxxxxxxxx ← كل الجروبات والقنوات اللي الرقم المربوط فيها: لينك + id + الرتبة
export default [{
    name: 'اسكا',
    aliases: ['groupsof'],
    description: 'جروبات وقنوات رقم مربوط: .اسكا 20xxxxxxxxxx',
    category: 'owner',
    ownerSession: true,
    async run({ args, reply, sock, message }) {
        const phone = digits(args[0]);
        if (!phone) return reply('الاستخدام: .اسكا 20xxxxxxxxxx');
        if (!readLinkedPhones().includes(phone)) return reply('❌ الرقم ده مش من الأرقام المربوطة (شوف .مين).');
        const s = getSession(phone);
        if (!s?.isConnected || !s.sock) return reply('❌ الرقم ده مش متصل دلوقتي.');

        const jid = message.key.remoteJid;
        await reply(`⏳ بجيب جروبات وقنوات ${phone}...`);

        let groups = [];
        try { groups = await listGroups(s.sock); }
        catch (e) { return reply(`❌ مقدرتش أجيب الجروبات: ${errText(e)}`); }

        const lines = [`📱 *${phone}*`, `👥 الجروبات: ${groups.length}`, ''];
        let n = 0;
        for (const g of groups) {
            n++;
            const rank = rankInGroup(g, s.sock);
            const link = await groupLink(s.sock, g, rank);
            lines.push(`*${n}* | ${g.subject || 'بدون اسم'}`);
            lines.push(`🔗 ${link || (rank === 'member' ? 'مش متاح (عضو عادي)' : 'مش متاح')}`);
            lines.push(`🆔 ${g.id}`);
            lines.push(`${RANK_AR[rank]}`);
            lines.push('');
            if (rank !== 'member') await sleep(120);
        }

        const ch = await listChannels(s.sock);
        lines.push(`📢 القنوات: ${ch.supported ? ch.list.length : 'غير مدعومة'}`);
        lines.push('');
        if (!ch.supported) {
            lines.push(`⚠️ ${ch.error}`);
        } else {
            ch.list.forEach((c) => {
                n++;
                lines.push(`*${n}* | ${c.name || 'بدون اسم'}`);
                lines.push(`🔗 ${c.link || 'مش متاح'}`);
                lines.push(`🆔 ${c.id}`);
                lines.push(CHANNEL_ROLE_AR[c.role] || '👤 متابع');
                lines.push('');
            });
        }

        for (const part of chunkLines(lines)) {
            await sock.sendMessage(jid, { text: part }, { quoted: message });
            await sleep(500);
        }
    }
}];
