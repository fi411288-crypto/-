import fetch from 'node-fetch';

async function tts(text, lang = 'ar') {
  const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=${lang}&client=tw-ob`;
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
  if (!res.ok) throw new Error(`TTS HTTP ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}

function cleanText(text = '') {
  return String(text).trim().replace(/^(صوت_انجليزي|صوت-انجليزي|صوت_عربي|صوت-عربي|نطق_انجليزي|نطق_عربي)\s+/i, '').trim();
}

async function sendVoice({ sock, m, reply }, text, lang, label) {
  if (!text) return reply(`❌ اكتب النص.\nمثال: .${label} مرحباً بكم في SOFA BOT`);
  if (text.length > 500) return reply('❌ النص طويل. الحد الأقصى 500 حرف.');
  try {
    const audio = await tts(text, lang);
    return sock.sendMessage(m.key.remoteJid, {
      audio,
      mimetype: 'audio/mpeg',
      ptt: true
    }, { quoted: m });
  } catch (e) {
    console.error('Voice center TTS:', e);
    return reply('❌ تعذر إنشاء الصوت الآن، حاول مرة أخرى.');
  }
}

export default {
  name: 'الأصوات',
  category: 'audio',
  description: '🎙️ مركز أوامر الصوت وتحويل النص إلى رسالة صوتية',
  commands: [
    {
      name: 'اصوات',
      aliases: ['الصوت', 'صوت', 'صوتيات', 'اوامر_الصوت', 'مركز_الصوت'],
      category: 'audio',
      description: 'عرض جميع أوامر الصوت',
      async run({ reply }) {
        return reply(`╭━━━〔 🎙️ SOFA VOICE CENTER 〕━━━╮\n┃\n┃ 🗣️ .انطق <نص>\n┃ 🎤 .قول <نص>\n┃ 🇪🇬 .صوت_عربي <نص>\n┃ 🇺🇸 .صوت_انجليزي <نص>\n┃ 🎌 .صوت_انمي <شخصية>\n┃ 🎌 .انمي_صوت <شخصية>\n┃ 📚 .اصوات قائمة أصوات الأنمي\n┃\n┃ ✨ الصوت العربي مناسب للنصوص العربية\n┃ 🌐 الصوت الإنجليزي للنصوص الإنجليزية\n┃ 🎌 أصوات الأنمي تعمل من مكتبة المقاطع\n┃\n╰━━━━━━━━━━━━━━━━━━━━━━╯`);
      }
    },
    {
      name: 'صوت_عربي',
      aliases: ['صوت-عربي', 'نطق_عربي', 'نطق-عربي'],
      category: 'audio',
      description: 'تحويل النص العربي إلى رسالة صوتية',
      async run(ctx) {
        return sendVoice(ctx, cleanText(ctx.text), 'ar', 'صوت_عربي');
      }
    },
    {
      name: 'صوت_انجليزي',
      aliases: ['صوت-انجليزي', 'نطق_انجليزي', 'نطق-انجليزي'],
      category: 'audio',
      description: 'تحويل النص الإنجليزي إلى رسالة صوتية',
      async run(ctx) {
        return sendVoice(ctx, cleanText(ctx.text), 'en', 'صوت_انجليزي');
      }
    }
  ]
};
