import fs from "fs-extra";
import path from "path";

// ✨ 1. تعريف الكائن الذي يحتوي على كل الدوال
const commandHandler = {
    name: "عدل",
    description: "تعديل إعدادات الزرف (للمطورين فقط)",
    // لا حاجة لـ group: true أو developer: true، الـ handler سيكتشف ذلك تلقائيًا

    async run({ message, reply, args, downloadMedia }) {
        try {
            const configPath = path.join(process.cwd(), "data", "zarf.json");
            
            let config = {};
            if (fs.existsSync(configPath)) {
                try {
                    const raw = fs.readFileSync(configPath, "utf8");
                    config = JSON.parse(raw);
                } catch (e) {
                    return reply(`❌ خطأ في قراءة ملف الإعدادات zarf.json:\n${e.message}`);
                }
            }

            // التأكد من وجود الهياكل الأساسية
            if (!config.group) config.group = {};
            if (!config.media) config.media = {};
            if (!config.messages) config.messages = {};

            const command = args[0]?.toLowerCase();
            
            if (!command) {
                return commandHandler.showHelp(reply, config);
            }

            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quoted) {
                return reply('❌ يجب الرد على المحتوى الذي تريد تعديله.');
            }

            // تمرير الأدوات اللازمة إلى الدوال الفرعية
            const context = { message, reply, config, quoted, configPath, downloadMedia };

            switch (command) {
                case 'اسم':
                    await commandHandler.editName(context);
                    break;
                case 'وصف':
                    await commandHandler.editDescription(context);
                    break;
                case 'ملصق':
                    await commandHandler.editSticker(context);
                    break;
                case 'صوت':
                    await commandHandler.editAudio(context);
                    break;
                case 'منشن':
                    await commandHandler.editMention(context);
                    break;
                case 'رساله':
                    await commandHandler.editMessage(context);
                    break;
                default:
                    reply('❌ أمر فرعي غير معروف.\n💡 استخدم: .عدل [اسم|وصف|ملصق|صوت|منشن|رساله]');
            }

        } catch (error) {
            console.error("Error in 'عدل' command:", error);
            reply('❌ حدث خطأ فادح: ' + error.message);
        }
    },

    showHelp(reply, config) {
        let help = `📝 *أمر تعديل إعدادات الزرف*\n\n`;
        help += `*الاستخدام:*\n`;
        help += `• \`.عدل اسم\` (بالرد على نص)\n`;
        help += `• \`.عدل وصف\` (بالرد على نص)\n`;
        help += `• \`.عدل ملصق\` (بالرد على ملصق)\n`;
        help += `• \`.عدل صوت\` (بالرد على صوت)\n`;
        help += `• \`.عدل منشن\` (بالرد على نص)\n`;
        help += `• \`.عدل رساله\` (بالرد على نص)\n\n`;
        help += `*📊 الإعدادات الحالية:*\n`;
        help += `• *الاسم:* ${config.group?.name || 'غير محدد'}\n`;
        help += `• *الوصف:* ${config.group?.description || 'غير محدد'}\n`;
        help += `• *المنشن:* ${config.messages?.mention || 'غير محدد'}\n`;
        help += `• *الرسالة:* ${config.messages?.finalText || 'غير محدد'}`;
        reply(help);
    },

    async editName({ reply, config, quoted, configPath }) {
        const text = quoted.conversation || quoted.extendedTextMessage?.text;
        if (!text) return reply('❌ الرد يجب أن يكون على رسالة نصية.');
        config.group.name = text;
        commandHandler.saveConfig(config, configPath);
        reply(`✅ تم تعديل اسم المجموعة بنجاح.`);
    },

    async editDescription({ reply, config, quoted, configPath }) {
        const text = quoted.conversation || quoted.extendedTextMessage?.text;
        if (!text) return reply('❌ الرد يجب أن يكون على رسالة نصية.');
        config.group.description = text;
        commandHandler.saveConfig(config, configPath);
        reply(`✅ تم تعديل وصف المجموعة بنجاح.`);
    },

    async editMention({ reply, config, quoted, configPath }) {
        const text = quoted.conversation || quoted.extendedTextMessage?.text;
        if (!text) return reply('❌ الرد يجب أن يكون على رسالة نصية.');
        config.messages.mention = text;
        commandHandler.saveConfig(config, configPath);
        reply(`✅ تم تعديل رسالة المنشن بنجاح.`);
    },

    async editMessage({ reply, config, quoted, configPath }) {
        const text = quoted.conversation || quoted.extendedTextMessage?.text;
        if (!text) return reply('❌ الرد يجب أن يكون على رسالة نصية.');
        config.messages.finalText = text;
        commandHandler.saveConfig(config, configPath);
        reply(`✅ تم تعديل الرسالة النهائية بنجاح.`);
    },

    // ✨✨ نسخة مبسطة تعتمد على ذكاء الـ handler ✨✨
    async editSticker({ reply, config, configPath, downloadMedia, message }) {
        if (!message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage) {
            return reply('❌ الرد يجب أن يكون على ملصق.');
        }
        try {
            // استدعاء مباشر! الدالة ستبحث في الرد تلقائيًا
            const mediaBuffer = await downloadMedia(message);
            if (!mediaBuffer) return reply('❌ فشل تحميل الملصق.');
            
            const stickerPath = path.join(process.cwd(), "media", "sticker.webp");
            fs.ensureDirSync(path.dirname(stickerPath));
            fs.writeFileSync(stickerPath, mediaBuffer);
            
            config.media.stickerPath = stickerPath;
            commandHandler.saveConfig(config, configPath);
            reply('✅ تم تعديل ملصق الزرف بنجاح.');
        } catch (error) {
            reply('❌ فشل حفظ الملصق: ' + error.message);
        }
    },

    // ✨✨ نسخة مبسطة تعتمد على ذكاء الـ handler ✨✨
    async editAudio({ reply, config, configPath, downloadMedia, message }) {
        if (!message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.audioMessage) {
            return reply('❌ الرد يجب أن يكون على رسالة صوتية.');
        }
        try {
            // استدعاء مباشر!
            const mediaBuffer = await downloadMedia(message);
            if (!mediaBuffer) return reply('❌ فشل تحميل الصوت.');

            const audioPath = path.join(process.cwd(), "media", "audio.mp3");
            fs.ensureDirSync(path.dirname(audioPath));
            fs.writeFileSync(audioPath, mediaBuffer);
            
            config.media.audioPath = audioPath;
            commandHandler.saveConfig(config, configPath);
            reply('✅ تم تعديل صوت الزرف بنجاح.');
        } catch (error) {
            reply('❌ فشل حفظ الصوت: ' + error.message);
        }
    },

    saveConfig(config, configPath) {
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    }
};

export default commandHandler;