import fs from 'fs';
import path from 'path';

// أمر .اية → آية عشوائية من أي سورة، وتحتها اسم السورة ورقم الآية
// النص من data/quran.json (Tanzil.net - المصحف العثماني)
const FILE = path.join(process.cwd(), 'data', 'quran.json');
let QURAN = null;
const load = () => { if (!QURAN) QURAN = JSON.parse(fs.readFileSync(FILE, 'utf8')); return QURAN; };
const ar = (n) => String(n).replace(/\d/g, (d) => '٠١٢٣٤٥٦٧٨٩'[d]);

export default {
    name: 'اية',
    aliases: ['آية', 'ايه', 'آيه', 'ayah', 'ayat'],
    description: 'آية عشوائية من القرآن الكريم مع اسم السورة ورقم الآية',
    category: 'islamic',
    run: async (context) => {
        const { client, m } = context;
        try {
            const q = load();
            // اختيار آية عشوائية بالتساوي من كل آيات القرآن (٦٢٣٦ آية)
            const total = q.reduce((a, s) => a + s.verses.length, 0);
            let r = Math.floor(Math.random() * total), s = 0;
            while (r >= q[s].verses.length) { r -= q[s].verses.length; s++; }
            const surah = q[s];
            const msg = `╭━━━〔 📖 *آية* 📖 〕━━━╮\n\n﴿ ${surah.verses[r]} ﴾\n\n*سورة ${surah.name} — آية ${ar(r + 1)}*\n╰━━━━━━━━━━━━━━━╯\n> *𝐒𝐎𝐅𝐀 𝐁𝐎𝐓 ⚡*`;
            await client.sendMessage(m.chat, { text: msg }, { quoted: m });
        } catch (e) {
            console.error('[اية]', e.message);
            await client.sendMessage(m.chat, { text: '❌ ملف القرآن مش موجود (data/quran.json).' }, { quoted: m });
        }
    }
};
