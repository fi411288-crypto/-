import axios from 'axios';
import { setGroqKey } from '../keys.js';

export default {
    name: 'setgroq',
    aliases: ['groqkey'],
    description: 'حفظ مفتاح Groq لأوامر الذكاء الاصطناعي (للمطور فقط)',
    category: 'developer',
    developer: true,

    async run({ sock, message, args, reply, isDeveloper, prefix }) {
        if (!isDeveloper) return reply('❌ الأمر ده للمطورين فقط.');
        const key = (args[0] || '').trim();
        if (!key) {
            return reply(`🔑 ابعت مفتاح Groq بالشكل ده:\n${prefix}setgroq gsk_xxxxxxxx\n\nتجيبه مجاناً من console.groq.com`);
        }
        if (!/^gsk_[A-Za-z0-9]{20,}$/.test(key)) return reply('❌ شكل المفتاح غلط، لازم يبدأ بـ gsk_');

        // اتأكد إن المفتاح شغال قبل ما نحفظه
        let status;
        try {
            const r = await axios.get('https://api.groq.com/openai/v1/models', {
                headers: { Authorization: `Bearer ${key}` }, timeout: 15000, validateStatus: () => true
            });
            status = r.status;
        } catch (e) {
            return reply(`❌ معرفتش أوصل لـ Groq: ${e.code || e.message}`);
        }
        if (status === 401) return reply('❌ المفتاح ده غلط أو منتهي.');
        if (status !== 200) return reply(`❌ Groq رد بكود غريب (${status})، جرب بعد شوية.`);

        setGroqKey(key);
        // امسح رسالة المفتاح لو أقدر (بتشتغل على رسايلك إنت)
        await sock.sendMessage(message.key.remoteJid, { delete: message.key }).catch(() => {});
        return reply('✅ اتحفظ مفتاح Groq واشتغل فوراً.\nجرب: .gpt أهلاً\n\n🔒 لو رسالة المفتاح لسه ظاهرة، امسحها من عندك.');
    }
};
