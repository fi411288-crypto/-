import { getGroup, levelOf, levelStart } from '../lib/community.js';
import { profileCard } from '../lib/goldcards.js';
import { idsOf, realNumber, findUser, targetJid, digits } from '../lib/xtools.js';

export default {
    name: 'بروفايل',
    aliases: ['profile', 'بطاقتي', 'كارتي'],
    description: 'كارت ذهبي فيه اسمك ورقمك ومستواك ونقاطك',
    usage: '.بروفايل [منشن/رد]',
    category: 'tools',
    group: true,
    async run({ sock, message, reply, bot }) {
        const jid = message.key.remoteJid;
        const { g } = getGroup(bot?.phone, jid);
        const t = targetJid(message);
        const ids = t ? [digits(t)] : idsOf(message);
        const hit = findUser(g, ids);
        const [id, u] = hit || [ids[0], { points: 0, name: '' }];
        const name = u.name || (t ? '' : message.pushName) || id;
        const number = t ? digits(u.jid || t) : realNumber(message);
        const lvl = levelOf(u.points);
        const rank = hit ? Object.values(g.users).filter((x) => x.points > u.points).length + 1 : 0;
        const img = await profileCard({ name, number, level: lvl, points: u.points, rank, from: levelStart(lvl), to: levelStart(lvl + 1) });
        const cap = `👑 *${name}*\n🏅 المستوى: ${lvl} | ⭐ النقاط: ${u.points}${rank ? ` | 🏆 #${rank}` : ''}\n\n> SOFA BOT`;
        if (!img) return reply(cap);
        return reply({ image: img, caption: cap });
    }
};
