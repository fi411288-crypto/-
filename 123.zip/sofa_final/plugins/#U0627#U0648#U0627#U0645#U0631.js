import fs from 'fs';
import path from 'path';
import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';
import { fancy as _fancy, WA } from '../lib/theme.js';
import { devCard } from '../lib/vipCards.js';
import { isVip } from '../lib/vip.js';
import { config, developerManager } from '../config.js';
import { readLinkedPhones, getSession, listGroups } from '../lib/adminTools.js';

const fancy = _fancy;
const DEV_NAME = '𝑺𝑶𝑭𝑨';
const CHANNEL_URL = 'https://whatsapp.com/channel/0029VbE0Vqa5PO0tM4fqZD1E';
const MENU_VIDEO = 'test-video.mp4';
const MENU_GIF_PLAYBACK = true;
const BOT_TITLE = `👑 ${fancy('SOFA BOT VIP')} 👑`;
const DIVIDER = WA.div;

const DEV_LINKS = [
  { text: '🧑🏻‍💻 المطور', url: 'https://t.me/F_1_D_L_1' },
  { text: '🤖 بوت سوفا', url: 'https://t.me/Sofa48755_Bot' },
  { text: '🌌 قناة تليجرام', url: 'https://t.me/sofa_bot1' },
  { text: '📢 قناة واتساب', url: CHANNEL_URL },
  { text: '🎵 تيك توك', url: 'https://www.tiktok.com/@fadl.ibrahem1' }
];

// الأقسام المطلوبة من الواجهة المرجعية.
// مهم: كل أمر موجود في قسم واحد فقط حتى لا تتكرر الأوامر في القوائم.
const SECTIONS = {
  downloads: {
    title: `📥 ${fancy('التحميل')}`,
    desc: 'أوامر تحميل الوسائط من المصادر الأساسية',
    cmds: ['yt', 'ytmp3', 'video', 'اغنيه', 'play', 'play_dl']
  },
  extraDownloads: {
    title: `📂 ${fancy('التحميل الإضافي')}`,
    desc: 'تحميل تيك توك وإنستجرام وفيسبوك وغيرها',
    cmds: ['تيك', 'تيكتوك', 'tikdl', 'igdl', 'fbdl', 'threads', 'snackvideo', 'capcut', 'pinterest', 'mediafire', 'alldl', 'apk', 'gitclone']
  },
  wars: {
    title: `👥 ${fancy('الحروبات')}`,
    desc: 'أوامر الحروب والتحديات الجماعية',
    cmds: ['زرف', 'فنش', 'سحب', 'تصفيه', 'بوم', 'سرقة', 'رشق']
  },
  admin: {
    title: `⚖️ ${fancy('الأمن والإدارة')}`,
    desc: 'إدارة المجموعة والأعضاء والمشرفين',
    cmds: ['ادمن', 'رفع', 'خفض', 'طير', 'بان', 'فك-بان', 'كتم', 'فك-كتم', 'مسح', 'حذف', 'اسم', 'وصف', 'اخرج', 'لينك', 'pin', 'add', 'منشن', 'هيدن', 'جدولة']
  },
  toggles: {
    title: `❌ ${fancy('التفعيل والتعطيل')} ✅`,
    desc: 'تشغيل وإيقاف ميزات المجموعة',
    cmds: ['قفل', 'فتح', 'قفل_تلقائي', 'منع', 'ترحيب', 'مود-جروب']
  },
  protection: {
    title: `🛡️ ${fancy('الحماية')}`,
    desc: 'الحماية من الروابط والسبام والكلمات المخالفة',
    cmds: ['antilink', 'trustlink', 'antispam', 'antibot', 'antibadword', 'addbadword', 'removebadword', 'badwordlist', 'warn', 'warncount', 'setwarncount']
  },
  stickers: {
    title: `🌠 ${fancy('الملصقات')}`,
    desc: 'إنشاء وتحويل الملصقات',
    cmds: ['ملصق', 'attp', 'emojimix', 'brat', 'canvas']
  },
  imageEdit: {
    title: `🎨 ${fancy('تعديل الصور')}`,
    desc: 'تحسين الصور والبحث عنها وتحليلها',
    cmds: ['تعديل', 'remini', 'image', 'لصورة', 'لصوره', 'حلل-صورة']
  },
  writing: {
    title: `✍️ ${fancy('إيفوتو')}`,
    desc: 'النصوص والكتابة والترجمة والتلخيص',
    cmds: ['نص', 'writetext', 'ترجم', 'لخص', 'صحح', 'شرح', 'اكتب-بحث', 'اقتباس', 'كلمات']
  },
  effects: {
    title: `🌄 ${fancy('المؤثرات')}`,
    desc: 'مؤثرات النصوص والتصاميم',
    cmds: ['زغرفه', 'glossysilver', 'glitchtext', 'advancedglow', 'neonglitch', 'gradienttext', 'glowingtext', 'luxurygold', 'multicolored', 'galaxytext', 'makingneon', 'hackerneon', 'greenneon', 'cloudtext', 'colorfulneon', 'pixelglitch', 'texteffect', 'typography']
  },
  anime: {
    title: `🀄 ${fancy('الأنمي')}`,
    desc: 'أوامر الشخصيات والترفيه المتعلقة بالأنمي',
    cmds: ['شخصية', 'اختار', 'لقب', 'لقبي', 'لقبه']
  },
  gif: {
    title: `🎞️ ${fancy('الجيف - GIF')}`,
    desc: 'أوامر الفيديو والتحويلات المتحركة',
    cmds: ['t', 'toimg', 'لصوت']
  },
  convert: {
    title: `🔄 ${fancy('التحويل')}`,
    desc: 'تحويلات الوسائط والملفات',
    cmds: ['تحويل', 'tomp3']
  },
  audio: {
    title: `🔄 ${fancy('تحويل صوتي')}`,
    desc: 'تحويل ومعالجة الصوتيات',
    cmds: ['spotify', 'soundcloud']
  },
  sounds: {
    title: `🎙️ ${fancy('الأصوات')}`,
    desc: 'النطق والأصوات والكلمات',
    cmds: ['انطق', 'صوت']
  },
  games: {
    title: `🎮 ${fancy('الألعاب')}`,
    desc: 'ألعاب فردية وجماعية',
    cmds: ['لعبة', 'نرد', 'كرة', 'اكس', 'روليت', 'حقيقة', 'جرأة', 'تحدي', 'لغز', 'اختبرني', 'ج']
  },
  rpg: {
    title: `⚔️ ${fancy('RPG')}`,
    desc: 'تقدم ومستويات ومهام واقتصاد',
    cmds: ['مستوى', 'مهام', 'تسجيل', 'يومي', 'اسبوعي', 'إنجازاتي', 'توب']
  },
  engagement: {
    title: `📊 ${fancy('التفاعل والجوائز')}`,
    desc: 'نشاط المجموعة وترتيب الأعضاء ومكافآت أسبوعية وشهرية',
    cmds: ['التفاعل', 'المتفاعلين', 'نشاطي', 'احصائيات_الجروب', 'الجوائز', 'جوائز_الأسبوع', 'جوائز_الشهر', 'استلام_جائزة', 'سجل_الجوائز']
  },
  joinRequests: {
    title: `📨 ${fancy('طلبات الانضمام')}`,
    desc: 'عرض طلبات دخول المجموعة وقبولها أو رفضها للمشرفين',
    cmds: ['طلبات', 'قبول_طلب', 'رفض_طلب', 'قبول_الكل', 'رفض_الكل']
  },
  clash: {
    title: `🥷 ${fancy('Clash')}`,
    desc: 'منافسات وتحديات بين الأعضاء',
    cmds: ['قبول', 'رفض', 'تصويت', 'ترتيب']
  },
  clans: {
    title: `🏯 ${fancy('العشائر')}`,
    desc: 'الألقاب والمجموعات والرتب الاجتماعية',
    cmds: ['الالقاب', 'متوفر', 'حذف_لقب', 'زواج', 'مخفي']
  },
  guilds: {
    title: `🏰 ${fancy('النقابات')}`,
    desc: 'إدارة الاقتصاد والملكية والتقدم',
    cmds: ['متجر', 'شراء', 'بيع', 'تجهيز', 'املاكي', 'تحصيل']
  },
  ai: {
    title: `💡 ${fancy('الذكاء الاصطناعي')}`,
    desc: 'محادثة وتوليد وتحليل ودراسة',
    cmds: ['gpt', 'gemini', 'chat', 'darkgpt', 'claude', 'warmgpt', 'sora', 'ارسم-صورة', 'ارسم-فيديو', 'مناظرة', 'امتحان', 'ذاكر', 'فلاش', 'خطة', 'صحح-إجابتي', 'اشرح-الكود', 'راجع-الكود']
  },
  tools: {
    title: `🛠️ ${fancy('الأدوات')}`,
    desc: 'أدوات البوت اليومية',
    cmds: ['حاسبة', 'ساعة', 'طقس', 'تذكير', 'qr', 'سكرين', 'كود', 'اكواد', 'ملف', 'ملفات']
  },
  helper: {
    title: `🧰 ${fancy('أدوات مساعدة')}`,
    desc: 'فحص وتشخيص ومعلومات مساعدة',
    cmds: ['ping', 'سرعة', 'تست', 'احصاء-البوت', 'تقرير', 'حقوق', 'سوفا']
  },
  search: {
    title: `🌐 ${fancy('البحث')}`,
    desc: 'بحث عن المعلومات والصور',
    cmds: ['بحث', 'رابط']
  },
  accountSearch: {
    title: `🕵️ ${fancy('البحث عن حساب')}`,
    desc: 'أدوات التعرف على الحسابات والأرقام',
    cmds: ['رقم', 'ايدي', 'ايدي_جروب', 'بروفايل']
  },
  inspect: {
    title: `🔎 ${fancy('الفحص')}`,
    desc: 'فحص الجروبات والقنوات والأنظمة',
    cmds: ['فحص_جروب', 'فحص_قنوات', 'apicheck', 'كشف']
  },
  islamic: {
    title: `🌙 ${fancy('إسلاميات')}`,
    desc: 'أوامر دينية متنوعة',
    cmds: ['اجر', 'اية', 'سوره', 'تفسير', 'دعاء', 'قرآن_يومي']
  },
  islam: {
    title: `🕌 ${fancy('الدين الإسلامي')}`,
    desc: 'أذكار ودعوات ومحتوى ديني',
    cmds: ['دعوة']
  },
  adhkar: {
    title: `🕋 ${fancy('أذكار وأدعية')}`,
    desc: 'أذكار وأدعية يومية',
    cmds: []
  },
  bank: {
    title: `🏦 ${fancy('البنك')}`,
    desc: 'الرصيد والراتب والتحويل والقروض',
    cmds: ['بنك', 'رصيدي', 'فلوسي', 'راتب', 'قرض', 'عملات', 'تحويل_كوين', 'هدية', 'ثروة']
  },
  shop: {
    title: `🛒 ${fancy('المتجر')}`,
    desc: 'الشراء والبيع والممتلكات',
    cmds: []
  },
  subbots: {
    title: `🤖 ${fancy('البوتات الفرعية')}`,
    desc: 'إدارة وتنصيب الجلسات والأدوات الفرعية',
    cmds: ['تنصيب', 'ادخل', 'باتش']
  },
  fun: {
    title: `🎉 ${fancy('التسلية')}`,
    desc: 'أوامر خفيفة للتسلية',
    cmds: ['شيب', 'صبعلو', 'سمسم', 'قول', 'نكتة', 'حقيقة-عشوائية', 'fact']
  },
  random: {
    title: `🎲 ${fancy('العشوائي')}`,
    desc: 'اختيارات وقرعة وحظ',
    cmds: ['قرعة', 'يانصيب', 'مين', 'حظي', 'نسبه']
  },
  horoscopes: {
    title: `🔮 ${fancy('الأبراج')}`,
    desc: 'أوامر الحظ والاختيارات اليومية',
    cmds: []
  },
  botInfo: {
    title: `ℹ️ ${fancy('معلومات البوت')}`,
    desc: 'إحصائيات ومعلومات النظام',
    cmds: ['بوت', 'اوامر']
  },
  serverAdmin: {
    title: `🖥️ ${fancy('إدارة السيرفرات')}`,
    desc: 'أوامر الإدارة والتشغيل للمطور',
    cmds: ['اعادة_تشغيل', 'ايقاف', 'تنظيف', 'عدل']
  },
  servers: {
    title: `🌐 ${fancy('السيرفرات')}`,
    desc: 'الفحص والتشغيل وإدارة الخدمات',
    cmds: ['تنفيذ', 'تنفيذ-قناة']
  },
  broadcast: {
    title: `📢 ${fancy('البث الجماعي')}`,
    desc: 'أوامر الإذاعة والإرسال الجماعي للمطور',
    cmds: ['اذاعه', 'اذاعه-مهام', 'اذاعه_تلي', 'احضرو', 'ابعت']
  },
  account: {
    title: `👤 ${fancy('حسابي')}`,
    desc: 'ملفك وإحصائياتك ومستواك',
    cmds: []
  },
  general: {
    title: `⭐ ${fancy('عام')}`,
    desc: 'أوامر عامة متنوعة',
    cmds: ['اقتراح', 'شكوه', 'نصيحه']
  },
  news: {
    title: `📰 ${fancy('الأخبار')}`,
    desc: 'البحث عن الأخبار والمحتوى العام',
    cmds: []
  },
  plugins: {
    title: `💥 ${fancy('متفرقات')}`,
    desc: 'أوامر إضافية ومتنوعة',
    cmds: ['مطر', 'عيد_ميلاد', 'اسهم', 'اكبر-عدد']
  },
  content: {
    title: `📸 ${fancy('محتوى')}`,
    desc: 'إنشاء ومشاركة المحتوى',
    cmds: ['صورة']
  },
  vip: {
    title: `💎 ${fancy('VIP والعضويات')}`,
    desc: 'أوامر العضوية المدفوعة ومزايا VIP',
    cmds: ['vip', 'viphelp', 'warmgpt']
  },
  animeCenter: {
    title: `🎌 ${fancy('مركز الأنمي')}`,
    desc: 'بحث ومعلومات المواسم والأنمي القادم والتحديثات',
    cmds: ['anime_center', 'انمي', 'انمي_معلومات', 'شخصيات_انمي', 'انمي_الموسم', 'انمي_قادم', 'تحديثات_الانمي', 'قسم_الانمي']
  },
  voiceCenter: {
    title: `🎧 ${fancy('مركز الصوت')}`,
    desc: 'أصوات عربية وإنجليزية وأصوات الأنمي',
    cmds: ['اصوات', 'صوت_عربي', 'صوت_انجليزي', 'صوت_انمي', 'تصويت_صوت']
  },
  community: {
    title: `🌐 ${fancy('المجتمع والتفاعل')}`,
    desc: 'التفاعل والاقتراحات والشكاوى والردود التلقائية',
    cmds: ['رد', 'الردود_الذكية', 'ردود_البوت', 'اقتراح', 'شكوه', 'نصيحه', 'عين', 'عين_رد', 'سؤال']
  },
  economyPlus: {
    title: `💰 ${fancy('الاقتصاد المتقدم')}`,
    desc: 'المزاد والتداول والوظائف والإنجازات',
    cmds: ['احصاء-مهام', 'المزاد', 'ابدا_المزاد', 'زايد', 'خزنتي', 'سجل-تداول', 'بقشيش', 'المليون', 'مليونير']
  },
  developer: {
    title: `👨🏻‍💻 ${fancy('المطور والنظام')}`,
    desc: 'إدارة المطورين وتشخيص النظام وفحص الأوامر',
    cmds: ['مطور', 'dev_manager', 'اضف_مطور', 'حذف_مطور', 'المطورين', 'اعطاء_XP', 'XP', 'اعطاء_مال', 'رفع_مستوى', 'اعطاء_رتبة', 'حذف_رتبة', 'اعطاء_قصر', 'ثروتي_مطور', 'فحص_الاوامر', 'فحص-الاوامر', 'احصاء-البوت', 'اعادة_تشغيل', 'تنظيف']
  },
  mediaTools: {
    title: `🎬 ${fancy('الوسائط المتقدمة')}`,
    desc: 'OCR ووصف الصور والتحويلات والوسائط',
    cmds: ['ocr', 'وصف', 'حلل-صورة', 'لصورة', 'لصوره', 'كشف', 'viewonce', 'كوبي', 't']
  },
  events: {
    title: `🏆 ${fancy('المسابقات والفعاليات')}`,
    desc: 'اختبارات وتحديات ومسابقات جماعية',
    cmds: ['اختبرني', 'سؤال', 'تحدي', 'تصويت', 'ترتيب', 'لعبة', 'حقيقة', 'جرأة', 'لغز', 'اكبر-عدد']
  },
  uncategorized: {
    title: `🆕 ${fancy('أوامر إضافية')}`,
    desc: 'أوامر مسجلة في البوت ولم توضع في قسم آخر بعد',
    cmds: []
  }
};

// أسماء بديلة حتى يمكن الوصول للأقسام بالعربي والإنجليزي.
const SECTION_ALIASES = {
  تحميل: 'downloads', التحميل: 'downloads',
  'التحميل-الاضافي': 'extraDownloads',
  الحروبات: 'wars', الحروب: 'wars',
  'الامن-والادارة': 'admin', 'الأمن-والإدارة': 'admin',
  'التفعيل-والتعطيل': 'toggles',
  الحماية: 'protection', الملصقات: 'stickers', 'تعديل-الصور': 'imageEdit',
  ايفوتو: 'writing', إيفوتو: 'writing', المؤثرات: 'effects',
  الانمي: 'anime', الأنمي: 'anime', الجيف: 'gif', gif: 'gif',
  التحويل: 'convert', 'تحويل-صوتي': 'audio', الأصوات: 'audio',
  الألعاب: 'games', العاب: 'games', rpg: 'rpg', 'ار بي جي': 'rpg',
  كلاش: 'clash', العشائر: 'clans', النقابات: 'guilds',
  'الذكاء-الاصطناعي': 'ai', 'الذكاء-الإصطناعي': 'ai',
  الأدوات: 'tools', 'ادوات-مساعدة': 'helper', 'أدوات-مساعدة': 'helper',
  البحث: 'search', 'البحث-عن-حساب': 'accountSearch', الفحص: 'inspect',
  إسلاميات: 'islamic', اسلاميات: 'islamic', 'الدين-الإسلامي': 'islam', 'الدين-الاسلامي': 'islam',
  'اذكار-وادعية': 'adhkar', 'أذكار-وأدعية': 'adhkar',
  البنك: 'bank', المتجر: 'shop', 'البوتات-الفرعية': 'subbots', التسلية: 'fun',
  العشوائي: 'random', الأبراج: 'horoscopes', 'معلومات-البوت': 'botInfo',
  'ادارة-السيرفرات': 'serverAdmin', 'إدارة-السيرفرات': 'serverAdmin', السيرفرات: 'servers',
  'البث-الجماعي': 'broadcast', حسابي: 'account', عام: 'general', الأخبار: 'news',
  متفرقات: 'plugins', محتوى: 'content',
  vip: 'vip', 'vip-commands': 'vip', 'اوامر-vip': 'vip',
  'مركز-الانمي': 'animeCenter', 'مركز-الأنمي': 'animeCenter', anime_center: 'animeCenter',
  'مركز-الصوت': 'voiceCenter', 'مركز-صوت': 'voiceCenter',
  المجتمع: 'community', التفاعل: 'community', 'الردود-الذكية': 'community',
  'الاقتصاد-المتقدم': 'economyPlus', الاقتصاد: 'economyPlus',
  المطور: 'developer', 'نظام-المطور': 'developer', 'فحص-الاوامر': 'developer',
  'الوسائط-المتقدمة': 'mediaTools', الوسائط: 'mediaTools',
  الفعاليات: 'events', المسابقات: 'events', 'المسابقات-والفعاليات': 'events',
  'اوامر-اضافية': 'uncategorized', اضافية: 'uncategorized'
};

const MENU_GROUPS = [
  { title: `📊 ${fancy('التفاعل والمجتمع')}`, rows: ['engagement', 'community', 'events', 'games', 'rpg'] },
  { title: `💡 ${fancy('الذكاء والأدوات')}`, rows: ['ai', 'tools', 'helper', 'search', 'accountSearch', 'inspect'] },
  { title: `🏦 ${fancy('البنك والمتجر والتقدم')}`, rows: ['bank', 'shop', 'economyPlus', 'clans', 'guilds', 'clash'] },
  { title: `🛡️ ${fancy('إدارة المجموعات والحماية')}`, rows: ['admin', 'toggles', 'joinRequests', 'protection', 'wars'] },
  { title: `📥 ${fancy('التحميل والوسائط')}`, rows: ['downloads', 'extraDownloads', 'mediaTools', 'gif', 'convert', 'audio'] },
  { title: `🎨 ${fancy('التصميم والأنمي والصوت')}`, rows: ['stickers', 'imageEdit', 'writing', 'effects', 'anime', 'animeCenter', 'voiceCenter', 'sounds'] },
  { title: `🎮 ${fancy('التسلية والاختيارات')}`, rows: ['fun', 'random', 'horoscopes'] },
  { title: `🕌 ${fancy('الدين والمعلومات')}`, rows: ['islamic', 'islam', 'adhkar', 'account', 'general', 'news'] },
  { title: `💎 ${fancy('VIP والمطور')}`, rows: ['vip', 'developer', 'subbots', 'botInfo', 'serverAdmin', 'servers', 'broadcast', 'plugins', 'content', 'uncategorized'] }
];

const GUIDE = {
  title: `❓ ${fancy('شرح الأوامر')}`,
  desc: 'اكتب .شرح + اسم الأمر',
  info: `${fancy('الاستخدام')}: .شرح الأمر\n${fancy('مثال')}: .شرح ping`
};

function uniqueCommands() {
  const seen = new Set();
  for (const sec of Object.values(SECTIONS)) {
    sec.cmds = sec.cmds.filter((cmd) => {
      const key = String(cmd).trim().toLowerCase();
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
}
uniqueCommands();

function uptimeText() {
  const s = Math.floor(process.uptime());
  return `${String(Math.floor(s / 3600)).padStart(2, '0')}:${String(Math.floor((s % 3600) / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

function commandExists(name, handler) {
  if (!handler) return true;
  const n = String(name || '').toLowerCase();
  return handler.commands?.has(n) || handler.aliases?.has(n);
}

function menuAccess(context) {
  const m = context?.m;
  const handler = context?.handler;
  const sender = m?.key?.participantPn || m?.key?.participantAlt || m?.key?.participant || m?.participant || m?.key?.remoteJid || '';
  const owner = !!(handler?.isOwnerMessage?.(m) || handler?.isOwnerNumber?.(sender));
  const staff = owner || !!handler?.isStaffMessage?.(m);
  return { owner, staff, vip: owner || isVip(sender) };
}

function canShowCommand(name, handler, access) {
  if (!commandExists(name, handler)) return false;
  if (!handler) return true;
  const command = handler.getCommand?.(name);
  if (!command) return true;
  if (command.ownerOnly && !access.owner) return false;
  const staffOnly = (handler.bot?.config?.DEV_ONLY_COMMANDS || []).includes(command.name);
  if (staffOnly && !access.staff) return false;
  if (command.developer && !access.staff) return false;
  if ((command.vip || command.permissions?.vip) && !access.vip) return false;
  return true;
}

const STAFF_SECTIONS = new Set(['developer', 'serverAdmin', 'broadcast']);

function getUncategorizedCommands(handler) {
  if (!handler?.commands) return [];
  const listed = new Set();
  for (const [key, sec] of Object.entries(SECTIONS)) {
    if (key === 'uncategorized') continue;
    for (const cmd of sec.cmds || []) listed.add(String(cmd).trim().toLowerCase());
  }
  return [...handler.commands.keys()]
    .map((x) => String(x).trim())
    .filter(Boolean)
    .filter((x) => !listed.has(x.toLowerCase()))
    .sort((a, b) => a.localeCompare(b, 'ar'));
}

function sectionCommands(key, handler) {
  if (key === 'uncategorized') return getUncategorizedCommands(handler);
  return SECTIONS[key]?.cmds || [];
}

function sectionText(key, prefix, handler, access) {
  const sec = SECTIONS[key];
  if (!sec) return `❌ القسم غير موجود.\nاكتب ${prefix}اوامر all لعرض الأقسام.`;
  if (STAFF_SECTIONS.has(key) && !access.staff) return '❌ هذا القسم للمالك والمطورين فقط.';
  let t = `${WA.top}\n\n*${sec.title}*\n_${sec.desc}_\n\n${DIVIDER}\n`;
  const available = sectionCommands(key, handler).filter((c) => canShowCommand(c, handler, access));
  if (!available.length) t += `${WA.item(1, 'لا توجد أوامر محملة')}` + '\n';
  available.forEach((c, i) => { t += `${WA.item(i + 1, prefix + c)}\n`; });
  t += `${DIVIDER}\n\n${WA.sign}\n${WA.bottom}`;
  return t;
}

function allText(prefix, handler, access) {
  return Object.keys(SECTIONS)
    .filter((key) => !STAFF_SECTIONS.has(key) || access.staff)
    .map((key) => sectionText(key, prefix, handler, access))
    .join('\n\n');
}

async function publicDeveloperDirectory(sock) {
  const digits = (value) => String(value || '').split('@')[0].split(':')[0].replace(/\D/g, '');
  const owners = (config.OWNER_NUMBERS || [config.OWNER_NUMBER]).map(digits).filter(Boolean);
  const developers = developerManager.list().filter((n) => !owners.includes(n));
  const people = [
    ...owners.map((n, i) => `${i + 1}. 👑 +${n} — مالك`),
    ...developers.map((n, i) => `${owners.length + i + 1}. 👨‍💻 +${n} — مطور`)
  ];

  // اجمع الجروبات من الجلسة الرئيسية وكل الجلسات الفرعية المتصلة، مع منع التكرار.
  const sessions = [{ sock, label: 'الرئيسي' }];
  for (const phone of readLinkedPhones()) {
    const session = getSession(phone);
    if (session?.isConnected && session.sock && !sessions.some((x) => x.sock === session.sock)) {
      sessions.push({ sock: session.sock, label: phone });
    }
  }

  const groups = new Map();
  for (const session of sessions) {
    try {
      const found = await listGroups(session.sock);
      for (const group of found) {
        if (group?.id && !groups.has(group.id)) {
          groups.set(group.id, { name: group.subject || 'جروب بدون اسم', id: group.id });
        }
      }
    } catch (error) {
      console.error('[menu] group listing failed:', error?.message || error);
    }
  }

  const groupList = [...groups.values()].sort((a, b) => a.name.localeCompare(b.name, 'ar'));
  const groupLines = groupList.slice(0, 60).map((g, i) => `${i + 1}. 👥 ${g.name}\n   🆔 ${g.id}`);
  if (groupList.length > 60) groupLines.push(`… ويوجد ${groupList.length - 60} جروب إضافي.`);

  return `${WA.top}\n\n👑 *${fancy('SOFA DEVELOPER & CONNECTED GROUPS')}* 👑\n\n${DIVIDER}\n*👨‍💻 المالكون والمطورون (${people.length})*\n${people.join('\n') || 'لا توجد بيانات مطورين.'}\n\n${DIVIDER}\n*👥 الجروبات المرتبطة بالبوت (${groupList.length})*\n${groupLines.join('\n\n') || 'لم يتم العثور على جروبات متصلة حالياً.'}\n\n${DIVIDER}\n${WA.sign}\n${WA.bottom}`;
}

function mainCaption(userNumber, totalCmds) {
  const date = new Date().toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' });
  return `${WA.top}\n\n*${BOT_TITLE}*\n_${fancy('Ultimate VIP Edition')}_\n\n${DIVIDER}\n${WA.row('👤 ' + fancy('المستخدم'), '@' + userNumber)}\n${WA.row('🎯 ' + fancy('أوامر القائمة'), totalCmds)}\n${WA.row('🟢 ' + fancy('الحالة'), fancy('Online'))}\n${WA.row('⏳ ' + fancy('العمل'), uptimeText())}\n${WA.row('📅 ' + fancy('التاريخ'), date)}\n${WA.row('👑 ' + fancy('المطور'), DEV_NAME)}\n${DIVIDER}\n\n> 📌 اختر القسم المطلوب من الزر بالأسفل ⬇️\n\n${WA.sign}\n${WA.bottom}`;
}

async function imageHeader(IM, sock, buffer) {
  if (!buffer) return null;
  try {
    const media = await prepareWAMessageMedia({ image: buffer }, { upload: sock.waUploadToServer });
    return IM.Header.fromObject({ title: '', hasMediaAttachment: true, imageMessage: media.imageMessage });
  } catch { return null; }
}

export default {
  name: 'اوامر',
  aliases: ['menu', 'help', 'الاوامر'],
  description: 'قائمة SOFA BOT مرتبة بدون تكرار',
  usage: '.اوامر',

  async run(context) {
    const { sock, m, args = [], bot } = context;
    const jid = m.key.remoteJid;
    const prefix = bot?.config?.PREFIX || '.';
    const handler = bot?.handler || global.bot?.handler || null;
    const access = menuAccess({ m, handler });

    try {
      const rawArg = (args.join('-') || '').trim().toLowerCase();
      const arg = SECTION_ALIASES[rawArg] || rawArg;

      if (rawArg === 'guide' || rawArg === 'شرح') {
        return sock.sendMessage(jid, { text: `${WA.top}\n\n*${GUIDE.title}*\n\n${GUIDE.info}\n\n${WA.sign}\n${WA.bottom}` }, { quoted: m });
      }

      if (rawArg === 'dev' || rawArg === 'المطور') {
        // هذا الزر يعرض بيانات تعريفية عامة فقط؛ أوامر الإدارة تظل محمية في handler.js.
        const directory = await publicDeveloperDirectory(sock);
        const body = `${directory}\n\n${DIVIDER}\n*👑 ${fancy('التواصل والروابط الرسمية')}*\n${DEV_LINKS.map((l) => `${l.text}: ${l.url}`).join('\n')}`;
        const buttons = DEV_LINKS.map((l) => ({ name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: l.text, url: l.url, merchant_url: l.url }) }));
        try {
          const IM = proto.Message.InteractiveMessage;
          const interactiveMessage = IM.fromObject({
            body: IM.Body.fromObject({ text: body }),
            footer: IM.Footer.fromObject({ text: '✦ SOFA BOT VIP ✦' }),
            header: (await imageHeader(IM, sock, await devCard())) || IM.Header.fromObject({ title: '', hasMediaAttachment: false }),
            nativeFlowMessage: IM.NativeFlowMessage.fromObject({ buttons })
          });
          const msg = generateWAMessageFromContent(jid, { viewOnceMessage: { message: { messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 }, interactiveMessage } } }, { userJid: sock.user?.id, quoted: m });
          return sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
        } catch {
          return sock.sendMessage(jid, { text: body + '\n\n' + DEV_LINKS.map((l) => `${l.text}: ${l.url}`).join('\n') }, { quoted: m });
        }
      }

      if (rawArg === 'all' || rawArg === 'الكل') {
        return sock.sendMessage(jid, { text: allText(prefix, handler, access) }, { quoted: m });
      }

      if (SECTIONS[arg]) {
        return sock.sendMessage(jid, { text: sectionText(arg, prefix, handler, access) }, { quoted: m });
      }

      const sender = m.key.participant || m.participant || jid;
      const userNumber = String(sender).split('@')[0].split(':')[0];
      const total = handler?.commands?.size || new Set(Object.values(SECTIONS).flatMap((s) => s.cmds.map((c) => c.toLowerCase()))).size;
      const caption = mainCaption(userNumber, total);
      const mentions = [sender];

      const sectionsList = MENU_GROUPS.map((g) => ({
        title: g.title,
        highlight_label: 'SOFA VIP',
        rows: g.rows
          .filter((key) => !STAFF_SECTIONS.has(key) || access.staff)
          .map((key) => {
            const sec = SECTIONS[key];
            return { header: '', title: sec.title, description: sec.desc, id: `${prefix}اوامر ${key}` };
          })
      })).filter((section) => section.rows.length > 0);

      const buttons = [
        { name: 'single_select', buttonParamsJson: JSON.stringify({ title: `👑 ${fancy('اختيار القسم')}`, sections: sectionsList }) },
        { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: `📢 ${fancy('القناة الرسمية')}`, url: CHANNEL_URL, merchant_url: CHANNEL_URL }) },
        { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: `👑 ${fancy('المطور')}`, id: `${prefix}اوامر dev` }) }
      ];

      try {
        const IM = proto.Message.InteractiveMessage;
        const videoPath = path.join(process.cwd(), 'media', MENU_VIDEO);
        let header;
        if (fs.existsSync(videoPath)) {
          const media = await prepareWAMessageMedia({ video: fs.readFileSync(videoPath), gifPlayback: MENU_GIF_PLAYBACK }, { upload: sock.waUploadToServer });
          header = IM.Header.fromObject({ title: '', hasMediaAttachment: true, videoMessage: media.videoMessage });
        } else {
          header = IM.Header.fromObject({ title: '', hasMediaAttachment: false });
        }

        const interactiveMessage = IM.fromObject({
          body: IM.Body.fromObject({ text: caption }),
          footer: IM.Footer.fromObject({ text: '✦ SOFA ROYAL VIP • بدون تكرار ✦' }),
          header,
          contextInfo: { mentionedJid: mentions },
          nativeFlowMessage: IM.NativeFlowMessage.fromObject({ buttons })
        });
        const msg = generateWAMessageFromContent(jid, { viewOnceMessage: { message: { messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 }, interactiveMessage } } }, { userJid: sock.user?.id, quoted: m });
        return sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
      } catch (e) {
        console.error('[menu] interactive failed:', e.message);
        return sock.sendMessage(jid, { text: `${caption}\n\n${allText(prefix, handler, access)}`, mentions }, { quoted: m });
      }
    } catch (err) {
      console.error('Menu Error:', err);
      return sock.sendMessage(jid, { text: '❌ حدث خطأ في القائمة: ' + err.message }, { quoted: m });
    }
  }
};
