// 📖 آية المساء + ذكر الصباح تلقائي في الجروبات اللي تفعّله (بتوقيت القاهرة) — SOFA BOT
import fs from 'fs';
import path from 'path';
import { store, job, sockOf, perms, hhmm, dayIn, mins } from '../lib/xtools.js';

const db = () => store('dailyquran', {}).data;
const ph = (p) => String(p || 'main').replace(/\D/g, '') || 'main';
const load = (f) => { try { const d = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'data', f), 'utf8')); return Array.isArray(d) ? d : []; } catch { return []; } };
const rnd = (a) => a[Math.floor(Math.random() * a.length)];

function morning() {
    const d = rnd(load('duas.json'));
    return d ? `🌅 *ذكر الصباح*\n\n${d.text}\n\n📖 ${d.source || ''}\n\n> SOFA BOT` : null;
}
function evening() {
    const s = rnd(load('quran.json').filter((x) => x?.verses?.length));
    if (!s) return null;
    const len = Math.min(3, s.verses.length), st = Math.floor(Math.random() * (s.verses.length - len + 1));
    return `🌙 *آية المساء*\n\n﴿ ${s.verses.slice(st, st + len).join(' ')} ﴾\n\n📖 سورة ${s.name} (${st + 1}${len > 1 ? '-' + (st + len) : ''})\n\n> SOFA BOT`;
}
const SLOTS = { morning, evening };

job('dailyquran', async () => {
    const now = mins(hhmm()), today = dayIn();
    for (const e of Object.values(db())) {
        e.last ||= {};
        for (const slot of ['morning', 'evening']) {
            const t = mins(e[slot]);
            if (t === null || now < t || now >= t + 30 || e.last[slot] === today) continue;
            const sock = sockOf(e.phone), text = SLOTS[slot]();
            if (!sock || !text) continue;
            try { await sock.sendMessage(e.jid, { text }); e.last[slot] = today; store('dailyquran').save(); } catch {}
        }
    }
}, 30000);

export default [{
    name: 'قرآن_يومي',
    aliases: ['قران_يومي', 'قرآن-يومي', 'اذكار_يومي'],
    category: 'admin',
    group: true,
    description: 'ذكر الصباح وآية المساء تلقائي في الجروب',
    usage: '.قرآن_يومي تفعيل [06:00] [18:00] | .قرآن_يومي ايقاف | .قرآن_يومي تجربة',
    cooldown: 3000,
    async run({ sock, message, args, reply, bot, isDeveloper, prefix = '.' }) {
        const p = await perms({ sock, message, isDeveloper });
        if (!p.isAdmin) return reply('❌ الأمر ده للمشرفين فقط.');
        const jid = message.key.remoteJid, key = `${ph(bot?.phone)}:${jid}`;
        const a = args.map((x) => x.replace(/[٠-٩]/g, (d) => d.charCodeAt(0) - 1632));
        if (['ايقاف', 'إيقاف', 'الغاء', 'off'].includes(a[0])) { delete db()[key]; store('dailyquran').save(); return reply('✅ اتوقف القرآن اليومي.'); }
        if (['تجربة', 'test'].includes(a[0])) { await reply(morning() || 'ℹ️ مفيش بيانات.'); return reply(evening() || 'ℹ️ مفيش بيانات.'); }
        if (['تفعيل', 'تشغيل', 'on'].includes(a[0])) {
            const fix = (s, d) => { if (!s) return d; const m = /^(\d{1,2})(?::(\d{2}))?$/.exec(s); return m && +m[1] < 24 && +(m[2] || 0) < 60 ? `${String(+m[1]).padStart(2, '0')}:${m[2] || '00'}` : null; };
            const m = fix(a[1], '06:00'), e = fix(a[2], '18:00');
            if (!m || !e) return reply(`❌ الأوقات غلط. مثال: ${prefix}قرآن_يومي تفعيل 06:00 18:00`);
            db()[key] = { phone: ph(bot?.phone), jid, morning: m, evening: e, last: {} };
            store('dailyquran').save();
            return reply(`✅ اشتغل القرآن اليومي!\n🌅 ذكر الصباح: ${m}\n🌙 آية المساء: ${e}\n(بتوقيت القاهرة)`);
        }
        const c = db()[key];
        return reply(`📖 *القرآن اليومي*\nالحالة: ${c ? `شغال ✅\n🌅 ${c.morning} | 🌙 ${c.evening}` : 'مقفول ❌'}\n\nتفعيل: ${prefix}قرآن_يومي تفعيل 06:00 18:00\nإيقاف: ${prefix}قرآن_يومي ايقاف\nتجربة: ${prefix}قرآن_يومي تجربة`);
    }
}];
