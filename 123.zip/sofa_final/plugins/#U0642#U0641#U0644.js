import { getAdminFlags } from '../lib/compat.js';

// قفل المجموعة — للمشرفين فقط. أي عضو عادي بيستخدمه بيطلعله: "هذا الأمر للمشرفين فقط"
export default {
    name: 'قفل',
    aliases: ['غلق', 'اغلق', 'إغلاق', 'اقفل', 'lock', 'close', 'closegroup'],
    description: 'قفل دردشة المجموعة (للمشرفين فقط)',
    category: 'group',

    async run({ sock, message, reply, isGroup, isDeveloper }) {
        if (!isGroup) return reply('❌ الأمر ده للمجموعات فقط.');
        try {
            const jid = message.key.remoteJid;
            const metadata = await sock.groupMetadata(jid);
            const { isAdmin, isBotAdmin } = getAdminFlags(sock, message, metadata);
            if (!isAdmin && !isDeveloper) return reply('❌ هذا الأمر للمشرفين فقط');
            if (!isBotAdmin) return reply('❌ لازم أكون مشرف في المجموعة عشان أنفذ الأمر ده.');
            await sock.groupSettingUpdate(jid, 'announcement');
            return reply('🔒 تم قفل المجموعة، المشرفين فقط يقدروا يرسلوا.');
        } catch (e) {
            return reply(`❌ حدث خطأ: ${e.message}`);
        }
    }
};
