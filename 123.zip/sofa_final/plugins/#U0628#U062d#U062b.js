import { groqChat, MODELS, reactor, quotedOf, AiError } from '../lib/groq.js';

const SYSTEM = 'ابحث في الإنترنت وأجب بالعربية بشكل مختصر ومنظم (من 3 لـ 6 أسطر أو نقاط قصيرة). اذكر التاريخ أو اسم المصدر لو مهم. اكتب الإجابة النهائية فقط ومن غير روابط طويلة.';

// بيشيل علامات المصادر ومقتطفات البحث الخام لو ظهرت
function tidy(t) {
    let out = String(t);
    const mark = out.lastIndexOf('[truncated site snippets]');
    if (mark !== -1) out = out.slice(mark + '[truncated site snippets]'.length);
    return out.replace(/【[^】]*】/g, '').replace(/\n{3,}/g, '\n\n').trim();
}

export default {
    name: 'بحث',
    aliases: ['search', 'ابحث'],
    description: 'بحث في الإنترنت وإجابة ملخصة بالعربي',
    category: 'ai',

    async run({ sock, message, text, reply, prefix }) {
        const q = (text || '').trim() || quotedOf(sock, message)?.text?.trim() || '';
        if (!q) return reply(`🔎 اكتب اللي عايز تبحث عنه: ${prefix}بحث سعر الدولار النهارده`);

        const react = reactor(sock, message);
        await react('⌛');
        try {
            const raw = await groqChat({
                model: MODELS.fast, effort: 'low', max: 2048,
                tools: [{ type: 'browser_search' }], toolChoice: 'required',
                messages: [{ role: 'system', content: SYSTEM }, { role: 'user', content: q }]
            });
            const answer = tidy(raw);
            if (!answer) throw new AiError('مالقيتش إجابة، جرب صياغة تانية.');
            await react('✅');
            return reply(`🔎 *${q}*\n\n${answer}\n\n> SOFA BOT`);
        } catch (e) {
            await react('❌');
            return reply(`❌ ${e instanceof AiError ? e.message : 'فشل البحث: ' + e.message}`);
        }
    }
};
