import { digits, getSession, readLinkedPhones, errText } from '../lib/adminTools.js';

// .ابعت ← 3 أزرار: رقم المرسل / رقم المرسل اليه / الرسالة. لما التلاتة يتكملوا الرسالة تتبعت من الرقم المربوط.
const drafts = new Map();      // chat -> { from, to, msg }
const botSent = new Set();     // ids الرسايل اللي البوت بعتها (عشان جلسة الأونر بتشوف رسايلها هي كمان)
const BOT_TEXTS = ['اكتب رقم المرسل', 'اكتب رقم المرسل اليه', 'اكتب الرسالة', 'تم ياسوفا', '❌', '✅', '📨'];
const FIELDS = { '1': 'from', from: 'from', '2': 'to', to: 'to', '3': 'msg', msg: 'msg' };
const PROMPTS = { from: 'اكتب رقم المرسل', to: 'اكتب رقم المرسل اليه', msg: 'اكتب الرسالة' };

async function say(sock, chat, text, quoted) {
    const sent = await sock.sendMessage(chat, { text }, quoted ? { quoted } : {});
    if (sent?.key?.id) { botSent.add(sent.key.id); if (botSent.size > 200) botSent.delete(botSent.values().next().value); }
    return sent;
}

async function sendMenu(sock, chat, message, prefix) {
    const d = drafts.get(chat) || {};
    const body = `📨 *ابعت رسالة من رقم مربوط*\n\n📱 المرسل: ${d.from || '—'}\n📞 المرسل اليه: ${d.to || '—'}\n💬 الرسالة: ${d.msg ? 'تم ✅' : '—'}\n\n(أو اكتب: ${prefix}ابعت 1 / 2 / 3)`;
    const buttons = [
        { id: `${prefix}ابعت 1`, text: '📱 رقم المرسل' },
        { id: `${prefix}ابعت 2`, text: '📞 رقم المرسل اليه' },
        { id: `${prefix}ابعت 3`, text: '💬 الرسالة' }
    ];
    let sent = null;
    try { if (typeof sock.sendButtonV2 === 'function') sent = await sock.sendButtonV2(chat, body, buttons, { footer: 'SOFA BOT' }); } catch {}
    if (!sent) {
        try {
            sent = await sock.sendMessage(chat, {
                text: body, footer: 'SOFA BOT', headerType: 1,
                buttons: buttons.map((b) => ({ buttonId: b.id, buttonText: { displayText: b.text }, type: 1 }))
            }, { quoted: message });
        } catch {}
    }
    if (!sent) sent = await sock.sendMessage(chat, { text: `${body}\n\n${prefix}ابعت 1 ← رقم المرسل\n${prefix}ابعت 2 ← رقم المرسل اليه\n${prefix}ابعت 3 ← الرسالة` }, { quoted: message });
    if (sent?.key?.id) botSent.add(sent.key.id);
}

async function trySend(sock, chat, d) {
    const s = getSession(d.from);
    if (!readLinkedPhones().includes(d.from)) return `❌ ${d.from} مش من الأرقام المربوطة (شوف .مين)`;
    if (!s?.isConnected || !s.sock) return `❌ ${d.from} مش متصل دلوقتي`;
    try {
        await s.sock.sendMessage(`${d.to}@s.whatsapp.net`, { text: d.msg });
        return `✅ اتبعتت من ${d.from} إلى ${d.to}`;
    } catch (e) { return `❌ فشل الإرسال: ${errText(e)}`; }
}

export default [{
    name: 'ابعت',
    aliases: ['send_as'],
    description: 'ابعت رسالة من أي رقم مربوط لأي رقم',
    category: 'owner',
    ownerSession: true,

    async run({ args, message, sock, prefix, startContinuous }) {
        const chat = message.key.remoteJid;
        const field = FIELDS[String(args[0] || '').toLowerCase()];
        if (!field) return sendMenu(sock, chat, message, prefix);
        startContinuous({ chat, field, expires: Date.now() + 5 * 60 * 1000 });
        return say(sock, chat, PROMPTS[field], message);
    },

    // بيستقبل اللي بتكتبه بعد ما تدوس الزر
    async onContinue({ message, text, data, sock, endContinuous }) {
        const chat = message.key.remoteJid;
        if (chat !== data.chat) return 'continue';
        if (Date.now() > data.expires) { endContinuous(); return 'end'; }
        if (botSent.has(message.key.id)) return 'continue';
        const val = String(text || '').trim();
        if (!val || BOT_TEXTS.some((t) => val.startsWith(t))) return 'continue';

        const d = drafts.get(chat) || {};
        if (data.field === 'msg') {
            d.msg = val;
        } else {
            const n = digits(val);
            if (n.length < 8 || n.length > 15) { await say(sock, chat, '❌ رقم غير صالح، اكتبه تاني', message); return 'continue'; }
            d[data.field] = n;
        }
        drafts.set(chat, d);
        await say(sock, chat, 'تم ياسوفا ✅', message);

        if (d.from && d.to && d.msg) {
            const result = await trySend(sock, chat, d);
            await say(sock, chat, result, message);
            if (result.startsWith('✅')) drafts.delete(chat);
        }
        return 'end';
    }
}];
