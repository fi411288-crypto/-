export default {
  name: 'ادمن',
  category: 'group',
  description: 'منشن لكل المشرفين في الجروب',
  group: true, // يشتغل في المجموعات بس

  run: async (context) => {
    const { sock, m } = context;
    const from = m.key.remoteJid;

    try {
      // سحب بيانات الجروب
      const groupMetadata = await sock.groupMetadata(from);
      const participants = groupMetadata.participants;

      // فلترة المشرفين
      const admins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');

      if (admins.length === 0) {
        return m.reply("✘ مفيش مشرفين في الجروب ده (إزاي يعني؟ 😅)");
      }

      // تحديد المؤسس وباقي المشرفين
      const founder = admins.find(a => a.admin === 'superadmin');
      const otherAdmins = admins.filter(a => a.admin === 'admin');

      let mentions = [];
      let text = "╭━━━〔 👑 مشرفين الجروب 👑 〕━━━╮\n\n";

      if (founder) {
        text += `👑 *المؤسس:* \n ➤ @${founder.id.split('@')[0]}\n\n`;
        mentions.push(founder.id);
      }

      if (otherAdmins.length > 0) {
        text += "⚡ *باقي المشرفين:* \n";
        otherAdmins.forEach((a, i) => {
          text += ` ${i + 1} ➤ @${a.id.split('@')[0]}\n`;
          mentions.push(a.id);
        });
      }

      text += "\n╰━━━━━━━━━━━━━━━╯\n";
      text += "> *𝐒𝐎𝐅𝐀 𝐁𝐎𝐓*";

      // الإرسال مع المنشنات
      await sock.sendMessage(from, {
        text: text,
        mentions: mentions
      }, { quoted: m });

    } catch (e) {
      console.log("Error in admin command:", e);
      m.reply("⚠️ حصل خطأ، تأكد إن البوت مشرف في المجموعة.");
    }
  }
};
