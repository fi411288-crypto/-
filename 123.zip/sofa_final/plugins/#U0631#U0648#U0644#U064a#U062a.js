import fs from 'fs';
import path from 'path';

export default {
    name: 'روليت',
    category: 'games',
    description: 'جولة موت كاملة بمنشن أزرق وزرف أوتوماتيكي',
    group: true,

    run: async (context) => {
        // فك المتغيرات من context عشان نضمن إنها موجودة
        const { sock, m, args } = context;
        const chatId = m.key.remoteJid;

        // دالة رد احتياطية ذكية
        const safeReply = async (text) => {
            return await sock.sendMessage(chatId, { text }, { quoted: m });
        };

        try {
            // 1. تحديث بيانات الجروب فوراً (عشان يتأكد من الأدمن)
            const metadata = await sock.groupMetadata(chatId);
            const participants = metadata.participants;
            
            // 2. تحديد الـ ID بتاع البوت بدقة
            const botId = sock.user.id.includes(':') ? sock.user.id.split(':')[0] + '@s.whatsapp.net' : sock.user.id;
            
            // 3. فحص هل البوت أدمن فعلاً؟
            const botParticipant = participants.find(p => p.id === botId);
            const botIsAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');

            if (!botIsAdmin) {
                return safeReply('❌لازم البوت يكون ادمن');
            }

            // 4. فلترة المرشحين (استبعاد البوت، صاحب الجروب، والأدمنية)
            const candidates = participants.filter(p => 
                p.id !== botId && 
                p.id !== metadata.owner && 
                !p.admin
            );

            if (candidates.length === 0) {
                return safeReply('❌ مفيش حد يتزرف! الجروب كله محصن (أدمنية وأصحاب الجروب بس).');
            }

            // 5. بداية اللعبة
            let bullet = Math.floor(Math.random() * 6) + 1;
            await safeReply('🎲 *الجوله بدات!*');

            for (let i = 1; i <= 6; i++) {
                // اختيار ضحية عشوائية من المرشحين في كل لفة
                let victim = candidates[Math.floor(Math.random() * candidates.length)];
                let victimId = victim.id;
                let victimNumber = victimId.split('@')[0];
                
                // انتظار ثانيتين بين كل لفة
                await new Promise(res => setTimeout(res, 2000));

                if (i === bullet) {
                    // الطلقة صابت
                    await sock.sendMessage(chatId, { 
                        text: `💀 *BANG!* \nالطلقة صابت @${victimNumber} في الحجرة رقم [${i}]\n\n*باي باي يا طيز.. جاري الزرف!*`, 
                        mentions: [victimId] 
                    });
                    
                    try {
                        // تنفيذ الطرد
                        await sock.groupParticipantsUpdate(chatId, [victimId], 'remove');
                    } catch (e) {
                        await safeReply('❌ البوت حاول يطرده بس فشل، ممكن يكون الشخص ده عنده حماية أو فيه مشكلة في الصلاحيات.');
                    }
                    return; // إنهاء اللعبة بعد الإصابة
                } else {
                    // نجاة
                    await sock.sendMessage(chatId, { 
                        text: `🔫 *CLICK...* \n@${victimNumber} نجا من الحجرة رقم [${i}]\n\n*تجهيز المحاولة القادمة...*`, 
                        mentions: [victimId] 
                    });
                }
            }
        } catch (err) {
            console.error('Roulette Error:', err);
            await safeReply('❌ حصل خطأ أثناء تشغيل اللعبة، جرب تاني.');
        }
    }
};
