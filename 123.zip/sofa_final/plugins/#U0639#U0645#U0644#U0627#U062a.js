import { get } from '../lib/xtools.js';

const OZ = 31.1035;
const FIAT = [['USD', '🇺🇸', 'دولار أمريكي'], ['EUR', '🇪🇺', 'يورو'], ['GBP', '🇬🇧', 'جنيه استرليني'], ['SAR', '🇸🇦', 'ريال سعودي'], ['AED', '🇦🇪', 'درهم إماراتي'], ['KWD', '🇰🇼', 'دينار كويتي'], ['QAR', '🇶🇦', 'ريال قطري'], ['BHD', '🇧🇭', 'دينار بحريني'], ['OMR', '🇴🇲', 'ريال عماني'], ['JOD', '🇯🇴', 'دينار أردني'], ['TRY', '🇹🇷', 'ليرة تركية'], ['CAD', '🇨🇦', 'دولار كندي'], ['CHF', '🇨🇭', 'فرنك سويسري'], ['JPY', '🇯🇵', 'ين ياباني'], ['CNY', '🇨🇳', 'يوان صيني']];
const NAMES = { دولار: 'USD', دولارات: 'USD', يورو: 'EUR', جنيه: 'EGP', مصري: 'EGP', استرليني: 'GBP', ريال: 'SAR', سعودي: 'SAR', درهم: 'AED', اماراتي: 'AED', دينار: 'KWD', كويتي: 'KWD', قطري: 'QAR', بحريني: 'BHD', عماني: 'OMR', اردني: 'JOD', ليرة: 'TRY', تركي: 'TRY', ين: 'JPY', يوان: 'CNY', فرنك: 'CHF', ذهب: 'XAU', فضه: 'XAG', فضة: 'XAG', بلاتين: 'XPT', بيتكوين: 'BTC', ايثريوم: 'ETH' };
const code = (s) => { const u = String(s || '').toUpperCase(); return NAMES[String(s || '').toLowerCase()] || (/^[A-Z]{3}$/.test(u) ? u : null); };
const n = (x, d = 2) => Number(x).toLocaleString('en-US', { maximumFractionDigits: d, minimumFractionDigits: x < 10 ? d : 0 });

let cache = null;
async function data() {
    if (cache && Date.now() - cache.t < 60000) return cache.v;
    const sym = ['XAU', 'XAG', 'XPT', 'XPD', 'BTC', 'ETH'];
    const [fx, ...m] = await Promise.allSettled([get('https://open.er-api.com/v6/latest/USD'), ...sym.map((s) => get(`https://api.gold-api.com/price/${s}`))]);
    const v = { rates: fx.status === 'fulfilled' ? fx.value.rates : null, usd: {} };
    sym.forEach((s, i) => { if (m[i].status === 'fulfilled' && m[i].value?.price) v.usd[s] = Number(m[i].value.price); });
    if (!v.rates && !Object.keys(v.usd).length) throw new Error('no data');
    cache = { t: Date.now(), v };
    return v;
}
const egp = (v) => v.rates?.EGP;
const per = (v, c) => (v.rates?.[c] ? egp(v) / v.rates[c] : null); // سعر وحدة العملة بالجنيه
const row = (x, f) => (x == null ? '—' : f(x));

export default {
    name: 'عملات',
    aliases: ['اسعار', 'الدولار', 'ذهب', 'currency', 'gold', 'سعر'],
    description: 'أسعار الدولار والعملات والذهب والفضة والكريبتو (مقابل الجنيه)',
    usage: '.عملات | .عملات ذهب | .عملات فضه | .عملات دولار | .عملات 100 دولار [يورو]',
    category: 'tools',
    async run({ text, reply, command }) {
        let v;
        try { v = await data(); } catch { return reply('❌ معرفتش أجيب الأسعار دلوقتي، جرب بعد شوية.'); }
        const q = (text.trim() || (command === 'ذهب' || command === 'gold' ? 'ذهب' : '')).split(/\s+/).filter(Boolean);
        const E = egp(v);
        const gold = () => {
            const o = v.usd.XAU; if (!o) return '🥇 *الذهب*\n—';
            const g = (k) => (o / OZ) * (E || 0) * (k / 24);
            return `🥇 *الذهب* (جرام بالجنيه)\n${E ? [24, 21, 18, 14].map((k) => `• عيار ${k}: *${n(g(k), 0)}*`).join('\n') + `\n• 🪙 الجنيه الذهب (8 جم عيار 21): *${n(g(21) * 8, 0)}*` : '• سعر الجنيه مش متاح'}\n• الأونصة: *$${n(o)}*`;
        };
        const silver = () => {
            const o = v.usd.XAG; if (!o) return '🥈 *الفضة*\n—';
            const g = (k) => (o / OZ) * (E || 0) * k;
            return `🥈 *الفضة* (جرام بالجنيه)\n${E ? [[999, 1], [925, 0.925], [800, 0.8]].map(([c, k]) => `• عيار ${c}: *${n(g(k), 2)}*`).join('\n') : ''}\n• الأونصة: *$${n(o)}*${v.usd.XPT ? `\n\n🥉 *البلاتين* الأونصة: *$${n(v.usd.XPT)}*` : ''}${v.usd.XPD ? ` | *البلاديوم*: *$${n(v.usd.XPD)}*` : ''}`;
        };
        const fiat = () => `💵 *العملات مقابل الجنيه*\n${FIAT.map(([c, f, nm]) => `${f} ${nm}: *${row(per(v, c), (x) => n(x, x < 1 ? 4 : 2))}*`).join('\n')}`;
        const crypto = () => `₿ *كريبتو*\n• بيتكوين: *$${row(v.usd.BTC, (x) => n(x, 0))}*${E && v.usd.BTC ? ` (≈ ${n(v.usd.BTC * E, 0)} ج)` : ''}\n• إيثريوم: *$${row(v.usd.ETH, (x) => n(x, 0))}*${E && v.usd.ETH ? ` (≈ ${n(v.usd.ETH * E, 0)} ج)` : ''}`;
        const foot = '\n\n_الأسعار عالمية/رسمية تقريبية وممكن تختلف عن السوق المحلي._\n> SOFA BOT';

        const amt = parseFloat(String(q[0]).replace(/,/g, ''));
        if (!Number.isNaN(amt) && q[1]) {
            const from = code(q[1]), to = code(q[2]) || 'EGP';
            const usdOf = (c) => (c === 'USD' ? 1 : v.rates?.[c] ? 1 / v.rates[c] : v.usd[c] || null);
            const a = usdOf(from), b = usdOf(to);
            if (!from || !a || !b) return reply('❌ عملة مش معروفة. مثال: .عملات 100 دولار جنيه');
            return reply(`🔄 *تحويل*\n${n(amt)} ${from} = *${n((amt * a) / b, 4)} ${to}*${foot}`);
        }
        const k = (q[0] || '').toLowerCase();
        const pick = ['ذهب', 'دهب', 'gold'].includes(k) ? [gold()] : ['فضه', 'فضة', 'silver', 'معادن'].includes(k) ? [silver()] : ['كريبتو', 'crypto', 'بيتكوين'].includes(k) ? [crypto()] : ['دولار', 'عملات', 'عملة', 'fiat'].includes(k) ? [fiat()] : [`💵 *الدولار*: *${row(E, (x) => n(x))}* جنيه`, gold(), silver(), fiat(), crypto()];
        return reply(`💱 *الأسعار*\n\n${pick.join('\n\n')}${foot}`);
    }
};
