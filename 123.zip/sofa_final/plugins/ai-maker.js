import axios from 'axios';

const OLD_API = 'https://api-blackwave.vercel.app/api/v1/ai/draw';
const GAP = Number(process.env.AI_MAKER_GAP_MS ?? 16000); // الخدمة المجانية: طلب كل ~15 ثانية
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// طابور بسيط: كل طلب صور بيستنى لحد ما يعدّي الفاصل من الطلب اللي قبله
let lastRun = 0;
let chain = Promise.resolve();
function waitTurn() {
    const p = chain.then(async () => {
        const wait = lastRun + GAP - Date.now();
        if (wait > 0) await sleep(wait);
        lastRun = Date.now();
    });
    chain = p.catch(() => {});
    return p;
}

// نموذج الصور بيفهم الإنجليزي أحسن، فنترجم الوصف العربي الأول
async function toEnglish(text) {
    try {
        const r = await axios.get('https://translate.googleapis.com/translate_a/single', {
            params: { client: 'gtx', sl: 'ar', tl: 'en', dt: 't', q: text },
            timeout: 10000
        });
        const out = (r.data?.[0] || []).map((p) => p?.[0] || '').join('').trim();
        if (out) return out;
    } catch {}
    try {
        const r = await axios.get('https://api.mymemory.translated.net/get', {
            params: { q: text, langpair: 'ar|en' },
            timeout: 10000
        });
        const out = String(r.data?.responseData?.translatedText || '').trim();
        if (out) return out;
    } catch {}
    return null;
}

const BUSY = [402, 429, 503];

async function pollinations(prompt) {
    const res = await axios.get(`https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}`, {
        params: { width: 1024, height: 1024, model: 'flux', nologo: true, seed: Math.floor(Math.random() * 1e9) },
        responseType: 'arraybuffer',
        timeout: 90000
    });
    const type = String(res.headers?.['content-type'] || '');
    if (!type.startsWith('image/')) throw new Error('الخدمة رجّعت رد غير صورة');
    return Buffer.from(res.data);
}

async function makeImage(prompt) {
    let lastErr;
    for (let attempt = 0; attempt < 2; attempt++) {
        await waitTurn();
        try {
            return await pollinations(prompt);
        } catch (err) {
            lastErr = err;
            if (!BUSY.includes(err?.response?.status)) break; // خطأ تاني: مفيش فايدة من إعادة المحاولة
        }
    }
    // احتياطي: الخدمة القديمة
    try {
        const res = await axios.get(`${OLD_API}/text2img`, { params: { prompt }, timeout: 30000 });
        const data = typeof res.data === 'string' ? JSON.parse(res.data) : (res.data || {});
        if (!data.status || !data.imageUrl) throw new Error(data.message || 'فشل');
        return { url: data.imageUrl };
    } catch {
        if (BUSY.includes(lastErr?.response?.status)) {
            lastErr.userMessage = 'الخدمة مشغولة أو وصلت للحد المجاني، استنى دقيقة وجرب تاني.';
        }
        throw lastErr;
    }
}

async function makeVideo(prompt) {
    const res = await axios.get(`${OLD_API}/text2vid`, { params: { prompt }, timeout: 60000 });
    const data = typeof res.data === 'string' ? JSON.parse(res.data) : (res.data || {});
    if (!data.status || !data.videoUrl) throw new Error(data.message || 'فشل في إنشاء الفيديو');
    return { url: data.videoUrl };
}

function explain(err) {
    if (err?.userMessage) return err.userMessage;
    const code = err?.response?.status;
    if (code === 402 || code === 403) return 'الخدمة دي بقت مدفوعة أو الرصيد المجاني خلص.';
    if (code === 429) return 'طلبات كتير، استنى شوية وجرب تاني.';
    if (err?.code === 'ECONNABORTED') return 'الخدمة اتأخرت في الرد، جرب تاني.';
    return err?.message || 'خطأ غير معروف';
}

const make = (kind, cmdName) => async ({ sock, message, text, reply, prefix }) => {
    const isImage = kind === 'image';
    const prompt = (text || '').trim();

    if (!prompt) {
        return reply(`⚠️ اكتب النص بعد الأمر يا زعيم.\n\nمثال:\n${prefix}${cmdName} قطة جميلة في حديقة`);
    }

    await reply(isImage ? 'جاري إنشاء الصورة..⏳️' : 'جاري إنشاء الفيديو..⏳️');

    try {
        const jid = message.key.remoteJid;
        if (isImage) {
            // ترجمة الوصف للإنجليزي لو فيه حروف عربي
            let english = null;
            if (/[\u0600-\u06FF]/.test(prompt)) english = await toEnglish(prompt);
            const img = await makeImage(english || prompt);
            await sock.sendMessage(jid, {
                image: img,
                caption: `✅ تم توليد الصورة بنجاح\n📜 النص: ${prompt}` + (english ? `\n🌐 ${english}` : '')
            }, { quoted: message });
        } else {
            const vid = await makeVideo(prompt);
            await sock.sendMessage(jid, {
                video: vid,
                caption: `🎬 تم إنشاء الفيديو بنجاح\n📜 النص: ${prompt}`
            }, { quoted: message });
        }
    } catch (err) {
        console.error('[ai-maker]', err?.response?.status || '', err.message);
        return reply(`❌ ${isImage ? 'فشل في إنشاء الصورة' : 'فشل في إنشاء الفيديو'}\n${explain(err)}`);
    }
};

export default [
    {
        name: 'ارسم-صورة',
        aliases: ['ارسم_صورة'],
        description: 'توليد صورة بالذكاء الاصطناعي من وصف نصي',
        category: 'ai',
        run: make('image', 'ارسم-صورة')
    },
    {
        name: 'ارسم-فيديو',
        aliases: ['ارسم_فيديو'],
        description: 'توليد فيديو بالذكاء الاصطناعي من وصف نصي',
        category: 'ai',
        run: make('video', 'ارسم-فيديو')
    }
];
