export default {
  name: 'زنجي',
  description: '🏿 يعطي نسبة الزنوجة مع تعليق حسب النسبة',
  category: 'ترفيه',

  run: async (context) => {
    const { sock, m } = context;
    const jid = m.key.remoteJid;

    // تحديد الشخص (منشن > ريبلاي > الشخص نفسه)
    let targetJid = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || 
                    m.message?.extendedTextMessage?.contextInfo?.participant || 
                    (m.key.participant || jid);

    const percentage = Math.floor(Math.random() * 101);
    const targetId = targetJid.split('@')[0];

    // تعليق حسب النسبة
    let comment;
    if (percentage < 30) {
      comment = 'أبيض زيادة عن اللزوم ❄️';
    } else if (percentage < 60) {
      comment = 'اسود خفيف، نص نص! ☕';
    } else if (percentage < 85) {
      comment = 'أسود عبد 🏿';
    } else {
      comment = '🏿 ملك الزنوج،';
    }

    const text = `🏿 نسبة الزنوجة عند *@${targetId}*: *${percentage}%*\n\n${comment}`;

    await sock.sendMessage(jid, {
      text: text,
      mentions: [targetJid]
    }, { quoted: m });
  }
};
