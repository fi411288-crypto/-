// 🦹 سرقة: حاول تسرق من فلوس عضو (اللي في إيده بس، مش البنك) — SOFA BOT
import { resolveNumber, isRegistered, getUser, updateUser } from '../lib/economy.js';
import { targetJid } from '../lib/xtools.js';
import { fmt, numberOfJid, bump } from '../lib/shop.js';

const COOLDOWN = 10 * 60e3, IMMUNE = 30 * 60e3, CHANCE = 0.4, MIN_COINS = 500, MAX_STEAL = 20000, MAX_FINE = 5000;

export default [{
    name: 'سرقة',
    aliases: ['سرقه', 'rob', 'اسرق'],
    category: 'games',
    group: true,
    description: 'حاول تسرق فلوس عضو (40% نجاح) — لو فشلت بتدفع غرامة',
    usage: '.سرقة @العضو',
    cooldown: 3000,
    async run({ sock, m, message, reply, prefix = '.' }) {
        const msg = m || message;
        const from = await resolveNumber(sock, msg);
        if (!from || !isRegistered(from)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
        const t = targetJid(msg);
        if (!t) return reply(`❌ اعمل منشن للعضو أو رد على رسالته:\n*${prefix}سرقة @العضو*`);
        const to = await numberOfJid(sock, t);
        if (!to || to === from) return reply('😅 مينفعش تسرق نفسك.');
        if (!isRegistered(to)) return reply('❌ العضو ده مش مسجّل في البوت.');
        const th = getUser(from), vi = getUser(to), now = Date.now();
        const wait = COOLDOWN - (now - (th.rob?.last || 0));
        if (wait > 0) return reply(`⏳ استنى *${Math.ceil(wait / 60000)}* دقيقة قبل السرقة الجاية.`);
        if ((th.economy?.coin || 0) < MIN_COINS) return reply(`❌ لازم يكون معاك ${fmt(MIN_COINS)} كوين على الأقل (عشان لو اتمسكت تدفع غرامة).`);
        const left = IMMUNE - (now - (vi.robbedAt || 0));
        if (left > 0) return reply({ text: `🛡️ @${to} اتسرق من شوية وعنده حماية *${Math.ceil(left / 60000)}* دقيقة.`, mentions: [t] });
        if ((vi.economy?.coin || 0) < MIN_COINS) return reply({ text: `😅 @${to} فلوسه في إيده قليلة مش مستاهلة (الفلوس في البنك آمنة).`, mentions: [t] });

        updateUser(from, (u) => { u.rob = { last: now }; bump(u, 'rob'); });
        if (Math.random() < CHANCE) {
            const r = updateUser(to, (u, eco) => {
                const amt = Math.max(1, Math.min(MAX_STEAL, Math.floor(eco.coin * (0.05 + Math.random() * 0.1))));
                eco.coin -= amt; u.robbedAt = now; return { amt };
            });
            updateUser(from, (u, eco) => { eco.coin += r.amt; });
            return reply({ text: `🦹 *نجحت السرقة!*\n\nسرقت \`${fmt(r.amt)}\` كوين من @${to} 😈\n💡 يا ريت تحط فلوسك في البنك: *${prefix}بنك*`, mentions: [t] });
        }
        const fine = Math.min(MAX_FINE, Math.floor(getUser(from).economy.coin * 0.1));
        updateUser(from, (u, eco) => { eco.coin -= fine; });
        updateUser(to, (u, eco) => { eco.coin += fine; });
        return reply({ text: `🚔 *اتمسكت!*\n\nدفعت غرامة \`${fmt(fine)}\` كوين راحت لـ @${to}`, mentions: [t] });
    }
}];
