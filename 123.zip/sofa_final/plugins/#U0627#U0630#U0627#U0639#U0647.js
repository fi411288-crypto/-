import { connectedSessions, listGroups, rankInGroup, listChannels, sleep, rand, errText } from '../lib/adminTools.js';

let running = false;

// بيبعت الرسالة من رقم واحد لكل جروباته وقنواته المسموح له يكتب فيها
async function broadcastFrom(s, body) {
    const r = { phone: s.phone, sent: 0, skipped: 0, failed: 0, channels: 0 };
    let groups = [];
    try { groups = await listGroups(s.sock); } catch (e) { r.error = errText(e); return r; }

    for (const g of groups) {
        const rank = rankInGroup(g, s.sock);
        // جروب مقفول للادمنز والرقم مش ادمن = مش مسموح له يتكلم
        if (g.announce && rank === 'member') { r.skipped++; continue; }
        try { await s.sock.sendMessage(g.id, { text: body }); r.sent++; }
        catch { r.failed++; }
        await sleep(rand(3000, 6000)); // تأخير بين الرسايل عشان الرقم ميتبلكش
    }

    const ch = await listChannels(s.sock);
    for (const c of ch.list) {
        // القنوات: المالك والادمن بس يقدروا ينشروا
        if (c.role !== 'OWNER' && c.role !== 'ADMIN') { r.skipped++; continue; }
        try { await s.sock.sendMessage(c.id, { text: body }); r.sent++; r.channels++; }
        catch { r.failed++; }
        await sleep(rand(3000, 6000));
    }
    return r;
}

// .اذاعه <نص> ← كل الأرقام المربوطة (ماعدا رقم الأونر) تبعت النص في كل جروباتها وقنواتها
export default [{
    name: 'اذاعه',
    aliases: ['broadcast'],
    description: 'اذاعة رسالة من كل الأرقام المربوطة: .اذاعه <النص>',
    category: 'owner',
    ownerSession: true,
    async run({ text, reply }) {
        const body = String(text || '').trim();
        if (!body) return reply('الاستخدام: .اذاعه <النص أو الرابط>');
        if (running) return reply('⏳ في إذاعة شغالة دلوقتي، استنى تخلص.');
        const sessions = connectedSessions({ excludeOwner: true });
        if (!sessions.length) return reply('❌ مفيش أرقام مربوطة متصلة دلوقتي.');

        running = true;
        try {
            await reply(`📣 بدأت الإذاعة من ${sessions.length} رقم... (هبعتلك التقرير لما تخلص)`);
            const results = await Promise.all(sessions.map((s) => broadcastFrom(s, body)));
            const total = results.reduce((a, r) => ({ sent: a.sent + r.sent, skipped: a.skipped + r.skipped, failed: a.failed + r.failed }), { sent: 0, skipped: 0, failed: 0 });
            const lines = results.map((r) => r.error
                ? `• ${r.phone}: ❌ ${r.error}`
                : `• ${r.phone}: ✅ ${r.sent}${r.channels ? ` (منهم ${r.channels} قناة)` : ''} | ⏭️ ${r.skipped} | ❌ ${r.failed}`);
            await reply(`📣 *تقرير الإذاعة*\n\n${lines.join('\n')}\n\n✅ اتبعت: ${total.sent}\n⏭️ اتخطى (مش مسموح): ${total.skipped}\n❌ فشل: ${total.failed}`);
        } finally {
            running = false;
        }
    }
}];
