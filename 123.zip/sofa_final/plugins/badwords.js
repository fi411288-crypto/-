import { badwordManage } from './antibadword.js';

const make = (name, aliases, description, action) => ({
    name,
    aliases,
    description,
    foreign: true,
    run: async (context) => {
        if (!context.isAdmin) {
            return context.client.sendMessage(context.m.chat, { text: '❌ الأمر ده للمشرفين فقط.' }, { quoted: context.m });
        }
        return badwordManage(context, action);
    }
});

export default [
    make('addbadword', ['اضف_كلمة'], 'إضافة كلمة ممنوعة للمجموعة', 'add'),
    make('removebadword', ['حذف_كلمة'], 'حذف كلمة من قائمة الممنوع', 'remove'),
    make('listbadwords', ['الكلمات_الممنوعة'], 'عرض الكلمات الممنوعة', 'list')
];
