import fs from 'fs';
import path from 'path';

// أمر .سوره <اسم السورة أو رقمها>  →  يرسل السورة كاملة PDF
// الملفات جاهزة في data/surahs/<رقم>.pdf (نص المصحف: Tanzil.net، الخط: Amiri Quran)
const DIR = path.join(process.cwd(), 'data');
let INDEX = [];
try { INDEX = JSON.parse(fs.readFileSync(path.join(DIR, 'surah-index.json'), 'utf8')); } catch {}

// تطبيع الكلام العربي للمطابقة: شيل التشكيل والتطويل ووحّد الألف والتاء المربوطة والياء
const norm = (s) => String(s || '')
    .replace(/[ً-ٰٟـ]/g, '')
    .replace(/[إأآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/[ىئ]/g, 'ي').replace(/ؤ/g, 'و')
    .replace(/^سوره\s+/, '')
    .replace(/\s+/g, '')
    .replace(/^ال/, '')
    .toLowerCase();

const ALIASES = { 'عمران': 3, 'ال عمران': 3, 'البقره': 2, 'يس': 36, 'الملك': 67, 'الكهف': 18, 'الرحمن': 55, 'الواقعه': 56, 'الاخلاص': 112, 'قل هو الله احد': 112, 'المعوذتين': 113 };

function findSurah(q) {
    const num = parseInt(String(q).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)), 10);
    if (!isNaN(num) && String(num) === String(q).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).trim()) {
        return INDEX.find((s) => s.id === num) || null;
    }
    const n = norm(q);
    if (!n) return null;
    const alias = Object.entries(ALIASES).find(([k]) => norm(k) === n);
    if (alias) return INDEX.find((s) => s.id === alias[1]);
    return INDEX.find((s) => norm(s.name) === n)
        || INDEX.find((s) => norm(s.name).startsWith(n))
        || INDEX.find((s) => norm(s.name).includes(n))
        || null;
}

const box = (t) => `╭─❏ 「 سورة 」\n${t.split('\n').map((l) => `│ ${l}`).join('\n')}\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀`;

export default {
    name: 'سوره',
    aliases: ['سورة', 'surah', 'sura'],
    description: 'يرسل سورة كاملة من القرآن الكريم PDF: .سوره البقرة',
    category: 'islamic',
    run: async (context) => {
        const { client, m, text } = context;
        const q = (text || '').trim();
        const send = (t) => client.sendMessage(m.chat, { text: t }, { quoted: m });
        const react = (e) => client.sendMessage(m.chat, { react: { text: e, key: m.reactKey } }).catch(() => {});

        if (!q) {
            await react('❌');
            return send(box('اكتب اسم السورة أو رقمها.\nمثال: .سوره البقرة\nأو: .سوره 36'));
        }
        const s = findSurah(q);
        if (!s) {
            await react('❌');
            return send(box(`ملقتش سورة باسم "${q}".\nجرّب الاسم زي ما هو في المصحف، أو اكتب الرقم (١ - ١١٤).`));
        }
        const file = path.join(DIR, 'surahs', `${s.id}.pdf`);
        if (!fs.existsSync(file)) {
            await react('❌');
            return send(box(`ملف سورة ${s.name} مش موجود في data/surahs/`));
        }
        await react('⌛');
        try {
            await client.sendMessage(m.chat, {
                document: fs.readFileSync(file),
                mimetype: 'application/pdf',
                fileName: `سورة ${s.name}.pdf`,
                caption: `📖 *سورة ${s.name}*\nعدد آياتها: ${s.verses}\n\n> 𝐒𝐎𝐅𝐀 𝐁𝐎𝐓`
            }, { quoted: m });
            await react('✅');
        } catch (e) {
            console.error('[سوره]', e.message);
            await react('❌');
            await send(box('حصل خطأ وأنا ببعت الملف، جرّب تاني.'));
        }
    }
};
