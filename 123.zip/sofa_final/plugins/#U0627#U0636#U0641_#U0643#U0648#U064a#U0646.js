// 🛠️ أوامر المطور فقط: إضافة / خصم كوين — SOFA BOT
import { resolveNumber, isRegistered, updateUser } from '../lib/economy.js';
import { targetJid } from '../lib/xtools.js';
import { fmt, numberOfJid, toEnDigits } from '../lib/shop.js';

async function handle({ sock, m, message, args, reply, isDeveloper, prefix = '.' }, sign, cmd) {
    if (!isDeveloper) return reply('❌ الأمر ده للمطور فقط.');
    const msg = m || message;
    const raw = args.map(toEnDigits).find((a) => /^\d{1,12}$/.test(a));
    const amount = parseInt(raw || '', 10);
    if (!amount) return reply(`❌ اكتب المبلغ:\n*${prefix}${cmd} 50000* (لنفسك)\n*${prefix}${cmd} @حد 50000*`);
    const t = targetJid(msg);
    const number = t ? await numberOfJid(sock, t) : await resolveNumber(sock, msg);
    if (!number || !isRegistered(number)) return reply('❌ العضو ده مش مسجّل في البوت (.تسجيل).');
    const r = updateUser(number, (u, eco) => {
        if (sign < 0 && eco.coin < amount) { eco.coin = 0; return { floored: true }; }
        eco.coin += sign * amount;
    });
    if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ.');
    return reply({
        text: `🛠️ *${sign > 0 ? 'تمت الإضافة' : 'تم الخصم'}*\n\n👤 ${t ? '@' + number : r.user.name}\n💰 ${sign > 0 ? '+' : '-'}\`${fmt(amount)}\`\n💼 الرصيد الجديد: \`${fmt(r.eco.coin)}\``,
        mentions: t ? [t] : []
    });
}

export default [
    { name: 'اضف_كوين', aliases: ['addcoin', 'ضيف_كوين'], category: 'dev', description: 'للمطور: إضافة كوين لعضو أو لنفسك', usage: '.اضف_كوين [@حد] 50000', cooldown: 1500, run: (c) => handle(c, 1, 'اضف_كوين') },
    { name: 'خصم_كوين', aliases: ['delcoin', 'شيل_كوين'], category: 'dev', description: 'للمطور: خصم كوين من عضو', usage: '.خصم_كوين [@حد] 50000', cooldown: 1500, run: (c) => handle(c, -1, 'خصم_كوين') }
];
