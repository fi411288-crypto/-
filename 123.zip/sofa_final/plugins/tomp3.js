import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';

export default {
    name: 'لصوت',
    aliases: ['tomp3', 'toaudio', 'تحويل-صوت'],
    description: 'تحويل فيديو/فويس إلى صوت mp3 (رد على الميديا)',
    category: 'tools',

    async run({ sock, m, message, reply, react }) {
        const msg = m || message;
        const q = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!q) return reply('❌ رد على فيديو أو فويس');
        const type = Object.keys(q).find(k => /video|audio|document/.test(k));
        if (!type) return reply('❌ رد على فيديو أو صوت');
        await react?.('⏳').catch?.(() => {});
        try {
            const mediaType = type.includes('video') ? 'video' : 'audio';
            const stream = await downloadContentFromMessage(q[type], mediaType);
            const chunks = [];
            for await (const c of stream) chunks.push(c);
            const input = Buffer.concat(chunks);
            const tmpIn = path.join(os.tmpdir(), `sofa_${Date.now()}.mp4`);
            const tmpOut = path.join(os.tmpdir(), `sofa_${Date.now()}.mp3`);
            fs.writeFileSync(tmpIn, input);
            await new Promise((resolve, reject) => {
                const ff = spawn('ffmpeg', ['-y', '-i', tmpIn, '-vn', '-acodec', 'libmp3lame', '-q:a', '4', tmpOut]);
                ff.on('close', code => code === 0 ? resolve() : reject(new Error('ffmpeg failed')));
                ff.on('error', reject);
            });
            const out = fs.readFileSync(tmpOut);
            try { fs.unlinkSync(tmpIn); fs.unlinkSync(tmpOut); } catch {}
            await react?.('✅').catch?.(() => {});
            return sock.sendMessage(msg.key.remoteJid, { audio: out, mimetype: 'audio/mpeg' }, { quoted: msg });
        } catch (e) {
            await react?.('❌').catch?.(() => {});
            return reply('❌ فشل التحويل: ' + (e.message || e));
        }
    }
};
