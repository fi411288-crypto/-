import { addBan, removeBan, listBans } from '../lib/bans.js';
import { digits } from '../lib/banTargets.js';

const OWNER = '201018766845'; // الرقم الوحيد المسموح له بأوامر التليجرام دي

const allowed = (handler, message, sock) => {
    const ids = [
        ...(handler?._senderIds ? handler._senderIds(message) : []),
        ...(message.key.fromMe ? [sock?.user?.id, sock?.user?.lid] : [])
    ].map(digits).filter(Boolean);
    return ids.includes(OWNER);
};
const tg = () => (global.bot?.telegram?.telegram ? global.bot.telegram : null);
const guard = (fn) => async (ctx) => {
    if (!allowed(ctx.handler, ctx.message, ctx.sock)) return; // تجاهل صامت لأي حد غير رقمك
    if (!tg()) return ctx.reply('❌ بوت التليجرام مش شغال.');
    return fn(ctx);
};
let busy = false;

const cmds = [
    {
        name: 'اذاعه_تلي', aliases: ['اذاعة_تلي', 'بث_تلي'],
        description: 'إذاعة رسالة لكل مستخدمي بوت تليجرام (للأونر فقط)', category: 'owner',
        run: guard(async ({ text, reply }) => {
            const body = text.trim();
            if (!body) return reply('📣 الاستخدام: .اذاعه_تلي <النص>');
            if (busy) return reply('⏳ في إذاعة شغالة، استنى تخلص.');
            busy = true;
            try {
                await reply(`📣 بدأت الإذاعة على ${tg().stats().active} مستخدم...`);
                const r = await tg().broadcast(body);
                await reply(`📣 *تقرير إذاعة تليجرام*\n\n✅ اتبعت: ${r.sent}\n🚫 حاظرين البوت: ${r.blocked}\n⏭️ متخطي (محظور/حساب ميت): ${r.skipped}\n❌ فشل: ${r.failed}${Object.keys(r.reasons || {}).length ? '\n' + Object.entries(r.reasons).map(([k, v]) => `   • ${k}: ${v}`).join('\n') : ''}\n👥 الإجمالي: ${r.total}`);
            } finally { busy = false; }
        })
    },
    {
        name: 'حظر_تلي', aliases: ['بان_تلي'],
        description: 'حظر مستخدم تليجرام بالأيدي (للأونر فقط)', category: 'owner',
        run: guard(async ({ args, reply }) => {
            const ids = args.map(digits).filter((x) => x.length >= 5);
            if (!ids.length) { const l = listBans().tg; return reply(`🚫 *محظورين تليجرام* (${l.length})\n${l.join(' ، ') || 'لا يوجد'}\n\nالاستخدام: .حظر_تلي 123456789`); }
            const done = ids.filter((i) => addBan('tg', i));
            return reply(done.length ? `🚫 اتحظر: ${done.join(' ، ')}` : 'ℹ️ كلهم محظورين بالفعل.');
        })
    },
    {
        name: 'فك_تلي', aliases: ['فك_حظر_تلي'],
        description: 'فك حظر مستخدم تليجرام بالأيدي (للأونر فقط)', category: 'owner',
        run: guard(async ({ args, reply }) => {
            const ids = args.map(digits).filter((x) => x.length >= 5);
            if (!ids.length) return reply('✅ الاستخدام: .فك_تلي 123456789');
            const done = ids.filter((i) => removeBan('tg', i));
            return reply(done.length ? `✅ اتفك الحظر: ${done.join(' ، ')}` : 'ℹ️ مفيش حد منهم كان محظور.');
        })
    },
    {
        name: 'احصاء_تلي', aliases: ['احصائيات_تلي', 'stats_tg'],
        description: 'عدد مستخدمي تليجرام النشطين والجداد اليوم (للأونر فقط)', category: 'owner',
        run: guard(async ({ reply }) => {
            const s = tg().stats();
            return reply(`✈️ *إحصائيات تليجرام*\n\n👥 الإجمالي: ${s.total}\n🟢 النشطين: ${s.active}\n🚫 حاظرين البوت: ${s.blocked}\n🆕 جداد اليوم: ${s.today}\n📅 جداد آخر 7 أيام: ${s.week}\n🌐 عربي: ${s.ar} | إنجليزي: ${s.en}${s.recent.length ? `\n\n🆕 *آخر المفعّلين:*\n${s.recent.map((p) => `• ${p.username ? '@' + p.username : (p.name || p.id)} (${p.id})`).join('\n')}` : ''}\n\n> SOFA BOT`);
        })
    }
];

export default cmds;
