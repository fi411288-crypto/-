// ملف: plugins/ادمن.js
import { isDevSender } from '../lib/devAuth.js';

export default {
    name: "رفع",
    aliases: ["promote"],
    description: "ترقية عضو إلى مشرف.",
    category: "admin",
    usage: ".ادمن (رد أو منشن)",
    
    // الصلاحيات الأساسية
    group: true,     // يعمل في المجموعات فقط
   
    async run({ sock, message, reply, args, isDeveloper, handler }) {
        // --- التحقق من صلاحيات المستخدم (مشرف أو مطور) ---
        const metadata = await sock.groupMetadata(message.key.remoteJid);
        const senderIds = [
            message.key?.participant,
            message.key?.participantPn,
            message.key?.remoteJid
        ].filter(Boolean);
        const senderDigits = senderIds.map(x => String(x).split('@')[0].split(':')[0].replace(/\\D/g, '')).filter(Boolean);
        const sender = metadata.participants.find(p =>
            senderIds.includes(p.id) ||
            senderDigits.includes(String(p.id || '').split('@')[0].split(':')[0].replace(/\\D/g, '')) ||
            senderDigits.includes(String(p.phoneNumber || '').replace(/\\D/g, ''))
        );
        const isAdmin = sender?.admin === 'admin' || sender?.admin === 'superadmin';

        // لا نستخدم isDeveloper العام هنا لأنه قد يعتبر الجلسات الفرعية مطورين.
        const isRealDeveloper = await isDevSender({ sock, message, handler });
        if (!isAdmin && !isRealDeveloper) {
            return reply("❌ أمر رفع الأدمن للمطور أو لأدمن الجروب فقط. أعضاء البوتات الفرعية لا يمكنهم استخدامه لرفع أنفسهم.");
        }
        try {
            let target;
            // تحديد الهدف (من الرد أو المنشن)
            const quoted = message.message?.extendedTextMessage?.contextInfo;
            if (quoted?.participant) {
                target = quoted.participant;
            } else {
                const mentions = message.message?.extendedTextMessage?.contextInfo?.mentionedJid;
                if (mentions?.length > 0) {
                    target = mentions[0];
                }
            }

            // التحقق من وجود هدف
            if (!target) {
                return reply("❌ قم بالرد على الشخص الذي تريد ترقيته أو قم بعمل منشن له.");
            }

            // الأدمن العادي يرفع الأعضاء فقط؛ المطور الحقيقي وحده يستطيع رفع نفسه.
            const targetDigits = String(target).split('@')[0].split(':')[0].replace(/\\D/g, '');
            const senderIsTarget = senderDigits.includes(targetDigits) ||
                String(sender?.id || '') === String(target);
            if (senderIsTarget && !isRealDeveloper) {
                return reply("⛔ الأدمن لا يستطيع رفع نفسه. المطور الحقيقي فقط يقدر يرفع نفسه أدمن.");
            }

            // التحقق مما إذا كان الهدف هو البوت نفسه
            if (target === sock.user.id) {
                return reply("🤔 لا يمكنني ترقية نفسي، أنا مشرف بالفعل (أو يجب أن أكون).");
            }

            // التحقق مما إذا كان الهدف مشرفًا بالفعل
            const targetParticipant = metadata.participants.find(p => p.id === target);
            if (targetParticipant?.admin) {
                return reply("⚠️ هذا العضو مشرف بالفعل.");
            }

            // تنفيذ الترقية
            await sock.groupParticipantsUpdate(message.key.remoteJid, [target], "promote");
            
            // إرسال رسالة نجاح مع منشن للشخص الذي تمت ترقيته
            await reply(`✅ تم ترقية @${target.split('@')[0]} إلى مشرف.`, {
                mentions: [target]
            });

        } catch (error) {
            console.error("Error in 'ادمن' command:", error);
            // التعامل مع الأخطاء الشائعة
            if (error.message.includes('not-admin')) {
                await reply("❌ فشلت الترقية. يجب أن يكون البوت مشرفًا لتنفيذ هذا الأمر.");
            } else {
                await reply(`❌ حدث خطأ: ${error.message}`);
            }
        }
    }
};