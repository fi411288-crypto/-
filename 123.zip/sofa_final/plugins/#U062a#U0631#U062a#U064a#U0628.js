import { getGroup, weekKey, weekPoints, levelOf, levelStart, mentionOf, digits } from '../lib/community.js';

const MEDALS = ['🥇', '🥈', '🥉'];
const bar = (cur, total) => {
    const n = Math.max(0, Math.min(10, Math.round((cur / Math.max(1, total)) * 10)));
    return '▰'.repeat(n) + '▱'.repeat(10 - n);
};

export default {
    name: 'ترتيب',
    aliases: ['توب', 'top', 'rank', 'مستواي'],
    description: 'نظام نقاط ومستويات للأعضاء ولوحة متصدرين أسبوعية',
    usage: '.ترتيب | .ترتيب الكل | .ترتيب انا',
    category: 'fun',
    group: true,
    async run({ message, args, reply, bot, prefix }) {
        const jid = message.key.remoteJid;
        const { g } = getGroup(bot?.phone, jid);
        const sub = (args[0] || '').toLowerCase();
        const wk = weekKey();
        const entries = Object.entries(g.users);
        const mentions = [];
        const say = (text) => reply({ text, mentions });
        const label = (uid, u) => { mentions.push(u.jid || mentionOf(uid)); return `@${digits(u.jid || uid)}`; };

        if (['انا', 'أنا', 'me', 'مستواي'].includes(sub)) {
            const uid = digits(message.key.participant || message.key.remoteJid);
            const mine = entries.find(([id, u]) => id === uid || digits(u.jid) === uid);
            if (!mine) return reply('📊 لسه معندكش نقاط، ابدأ اتكلم في الجروب أو جاوب ألغاز (.لغز)!');
            const [id, u] = mine;
            const lvl = levelOf(u.points), from = levelStart(lvl), to = levelStart(lvl + 1);
            const all = entries.slice().sort((a, b) => b[1].points - a[1].points).findIndex(([k]) => k === id) + 1;
            const wkRank = entries.map(([k, x]) => [k, weekPoints(x, wk)]).filter(([, p]) => p > 0).sort((a, b) => b[1] - a[1]).findIndex(([k]) => k === id) + 1;
            return say(`📊 *بطاقتك* ${label(id, u)}\n\n🏅 المستوى: *${lvl}*\n⭐ النقاط: *${u.points}*\n${bar(u.points - from, to - from)} ${u.points}/${to}\n📅 نقاط الأسبوع: ${weekPoints(u, wk)}${wkRank ? ` (المركز ${wkRank})` : ''}\n🏆 ترتيبك الكلي: ${all} من ${entries.length}\n💬 رسائلك: ${u.msgs}`);
        }

        const all = ['الكل', 'all', 'كلي'].includes(sub);
        const rows = entries
            .map(([id, u]) => [id, u, all ? u.points : weekPoints(u, wk)])
            .filter(([, , p]) => p > 0)
            .sort((a, b) => b[2] - a[2])
            .slice(0, 10);

        if (!rows.length) return reply(all ? '📊 لسه مفيش نقاط في الجروب.' : '📊 لسه مفيش نقاط الأسبوع ده. اتكلموا وجاوبوا ألغاز (.لغز)!');

        const lines = rows.map(([id, u, p], i) => `${MEDALS[i] || `*${i + 1}.*`} ${label(id, u)} — ${p} نقطة (مستوى ${levelOf(u.points)})`);
        return say(`🏆 *${all ? 'المتصدرين (كل الأوقات)' : 'متصدري الأسبوع'}*\n${all ? '' : `📅 من ${wk}\n`}\n${lines.join('\n')}\n\n💡 النقاط: نشاط في الجروب + حل الألغاز (${prefix}لغز)\n📌 ${prefix}ترتيب انا | ${prefix}ترتيب الكل\n\n> SOFA BOT`);
    }
};
