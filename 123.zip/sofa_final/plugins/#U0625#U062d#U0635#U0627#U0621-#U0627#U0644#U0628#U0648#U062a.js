import { listBans } from '../lib/bans.js';
import { isAllowedSender } from '../lib/banTargets.js';

export default {
    name: "احصاء-البوت",
    developer: true,
    aliases: ["احصاء_البوت", "botstats", "احصائيات-البوت"],
    description: "إحصائيات مستخدمي بوت تليجرام والأرقام المربوطة",
    category: "admin",

    async run({ sock, message, reply, handler }) {
        if (!isAllowedSender(handler, message, sock)) return reply("❌ الأمر ده مش متاح لرقمك.");

        const tg = global.bot?.telegram;
        const s = tg?.telegram ? tg.stats() : null;
        const sessions = [...(global.bot?.sessions?.values?.() || [])];
        const connected = sessions.filter((x) => x?.sock && x.isConnected !== false).length;
        const bans = listBans();

        let out = `📊 *إحصائيات البوت*\n\n`;
        if (s) {
            out += `✈️ *تليجرام*\n👥 الإجمالي: ${s.total}\n🟢 نشطين: ${s.active}\n🚫 حاظرين البوت: ${s.blocked}\n🆕 جداد اليوم: ${s.today}\n📅 جداد آخر 7 أيام: ${s.week}\n🕰️ قدام (قبل التتبع): ${s.legacy}\n🌐 عربي: ${s.ar} | إنجليزي: ${s.en}\n`;
            if (s.recent.length) {
                out += `\n🆕 *آخر المفعّلين:*\n` + s.recent.map((p) => `• ${p.username ? '@' + p.username : (p.name || p.id)} (${p.id})`).join('\n') + '\n';
            }
        } else out += `✈️ تليجرام: مش شغال\n`;
        out += `\n📱 *واتساب*\n🔗 الأرقام المربوطة: ${sessions.length}\n🟢 المتصلة: ${connected}\n\n🚫 *المحظورين*\nواتساب: ${bans.wa.length} | تليجرام: ${bans.tg.length}`;
        return reply(out);
    }
};
