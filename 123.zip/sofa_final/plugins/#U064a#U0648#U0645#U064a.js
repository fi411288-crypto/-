// 🎁 المكافأة اليومية + سلسلة الأيام المتتالية — SOFA BOT
import { resolveNumber, isRegistered, updateUser } from '../lib/economy.js';
import { cairoDay } from '../lib/community.js';
import { fmt, questBump } from '../lib/shop.js';

const BASE_COIN = 500, STEP_COIN = 100, MAX_STREAK_BONUS = 30;
const BASE_XP = 50, STEP_XP = 5;
const WEEK_BONUS = 5000; // كل 7 أيام متتالية

export default [{
    name: 'يومي',
    aliases: ['daily', 'مكافأة', 'مكافاة'],
    category: 'games',
    description: 'مكافأة يومية كوين + XP، وسلسلة أيام متتالية بتزوّد الجايزة',
    cooldown: 3000,
    async run({ sock, m, message, reply, prefix = '.' }) {
        const msg = m || message;
        const number = await resolveNumber(sock, msg);
        if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);

        const today = cairoDay(), yesterday = cairoDay(Date.now() - 864e5);
        const r = updateUser(number, (u, eco) => {
            const d = (u.daily ||= { last: '', streak: 0, best: 0 });
            if (d.last === today) return { error: 'claimed', streak: d.streak };
            d.streak = d.last === yesterday ? d.streak + 1 : 1;
            d.best = Math.max(d.best || 0, d.streak);
            d.last = today;
            const s = Math.min(d.streak - 1, MAX_STREAK_BONUS);
            const coin = BASE_COIN + s * STEP_COIN, xp = BASE_XP + s * STEP_XP;
            const bonus = d.streak % 7 === 0 ? WEEK_BONUS : 0;
            eco.coin += coin + bonus; eco.exp += xp;
            return { coin, xp, bonus, streak: d.streak, best: d.best, total: eco.coin };
        });

        if (r.error === 'claimed') {
            return reply(`⏳ *استلمت مكافأتك النهارده بالفعل!*\n🔥 سلسلتك: \`${r.streak}\` يوم\nارجع بكرة عشان متكسرش السلسلة.`);
        }
        if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ، حاول تاني.');
        questBump(number, 'daily');
        const next = 7 - (r.streak % 7);
        return reply(
            `🌌 *SOFA • DAILY* 🎁\n\n` +
            `💰 كوين: \`+${fmt(r.coin)}\`\n⚡ XP: \`+${fmt(r.xp)}\`\n` +
            (r.bonus ? `🎉 *بونص أسبوع كامل:* \`+${fmt(r.bonus)}\` كوين\n` : '') +
            `\n🔥 السلسلة: \`${r.streak}\` يوم (أفضل: ${r.best})\n` +
            (r.bonus ? '' : `📅 باقي ${next} يوم على بونص الأسبوع\n`) +
            `💼 رصيدك: \`${fmt(r.total)}\`\n\n> SOFA BOT`
        );
    }
}];
