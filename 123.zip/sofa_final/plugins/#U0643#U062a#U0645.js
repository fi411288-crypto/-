import { getGroup, digits, mentionOf } from '../lib/community.js';
import { getMetadata, getAdminFlags } from '../lib/compat.js';
import { useShield } from '../lib/shop.js';

// كل أشكال هوية العضو (رقم / LID) عشان الكتم يشتغل مهما واتساب بعت
function idsOfTarget(meta, targetJid) {
    const t = digits(targetJid);
    const ids = new Set([t]);
    for (const p of meta?.participants || []) {
        const forms = [p.id, p.lid, p.jid, p.phoneNumber].filter(Boolean).map(digits);
        if (forms.includes(t)) forms.forEach((f) => ids.add(f));
    }
    const p = (meta?.participants || []).find((x) => [x.id, x.lid, x.jid, x.phoneNumber].filter(Boolean).map(digits).includes(t));
    return { ids: [...ids].filter(Boolean), admin: !!p?.admin };
}

function targetOf(message) {
    const ctx = message.message?.extendedTextMessage?.contextInfo;
    return ctx?.mentionedJid?.[0] || ctx?.participant || null;
}

async function gate(sock, message, isDeveloper) {
    const jid = message.key.remoteJid;
    const meta = await getMetadata(sock, jid);
    const f = getAdminFlags(sock, message, meta);
    if (!f.isAdmin && !isDeveloper) return { error: '❌ الأمر ده للمشرفين فقط.' };
    return { meta, bot: f.isBotAdmin };
}

export default [
    {
        name: 'كتم',
        aliases: ['mute', 'اسكت'],
        description: 'كتم عضو: بيحذف رسايله تلقائياً (البوت لازم يكون مشرف)',
        usage: '.كتم @العضو [دقائق] | .كتم قائمة',
        category: 'admin',
        group: true,
        async run({ sock, message, args, reply, bot, prefix, isDeveloper }) {
            const jid = message.key.remoteJid;
            let ctx;
            try { ctx = await gate(sock, message, isDeveloper); } catch { return reply('❌ معرفتش أجيب بيانات الجروب، جرب تاني.'); }
            if (ctx.error) return reply(ctx.error);
            const { g, save } = getGroup(bot?.phone, jid);

            if (['قائمه', 'قائمة', 'list'].includes((args[0] || '').toLowerCase())) {
                const list = Object.entries(g.muted);
                if (!list.length) return reply('🔊 مفيش حد مكتوم.');
                const mentions = list.map(([id, m]) => m.jid || mentionOf(id));
                const lines = list.map(([id, m]) => `• @${id}${m.until ? ` (لحد ${new Date(m.until).toLocaleTimeString('ar-EG', { timeZone: 'Africa/Cairo', hour: '2-digit', minute: '2-digit' })})` : ''}`);
                return reply({ text: `🔇 *المكتومين:*\n${lines.join('\n')}`, mentions });
            }

            if (!ctx.bot) return reply('❌ لازم أكون مشرف في الجروب عشان أقدر أحذف رسايل المكتومين.');
            const target = targetOf(message);
            if (!target) return reply(`❌ اعمل منشن للعضو أو رد على رسالته:\n${prefix}كتم @العضو\n${prefix}كتم @العضو 30  (لمدة 30 دقيقة)`);

            const t = idsOfTarget(ctx.meta, target);
            const botIds = [sock.user?.id, sock.user?.lid].filter(Boolean).map(digits);
            if (t.ids.some((i) => botIds.includes(i))) return reply('🤖 مينفعش أكتم نفسي.');
            if (t.admin) return reply('❌ مينفعش تكتم مشرف.');
            const ownerNumbers = (global.bot?.config?.OWNER_NUMBERS || [global.bot?.config?.OWNER_NUMBER]).map(digits);
            if (t.ids.some((id) => ownerNumbers.includes(id))) return reply('❌ مينفعش تكتم مالك البوت.');

            if (await useShield(sock, target, t.ids)) return reply({ text: `🛡️ @${digits(target)} معاه *حماية من الكتم* من المتجر — المحاولة اتلغت واتستهلكت شحنة.`, mentions: [target] });

            const mins = parseInt([...args].reverse().find((a) => /^\d{1,4}$/.test(a)) || '', 10);
            const key = t.ids[0];
            g.muted[key] = { ids: t.ids, jid: target, until: mins ? Date.now() + mins * 60000 : 0, by: digits(message.key.participant) };
            save();
            return reply({ text: `🔇 تم كتم @${digits(target)}${mins ? ` لمدة ${mins} دقيقة` : ''}.\nرسايله هتتحذف تلقائياً. لفك الكتم: ${prefix}فك-كتم @العضو`, mentions: [target] });
        }
    },
    {
        name: 'فك-كتم',
        aliases: ['فك_كتم', 'unmute', 'فككتم'],
        description: 'فك الكتم عن عضو',
        usage: '.فك-كتم @العضو',
        category: 'admin',
        group: true,
        async run({ sock, message, args, reply, bot, prefix, isDeveloper }) {
            const jid = message.key.remoteJid;
            let ctx;
            try { ctx = await gate(sock, message, isDeveloper); } catch { return reply('❌ معرفتش أجيب بيانات الجروب، جرب تاني.'); }
            if (ctx.error) return reply(ctx.error);
            const { g, save } = getGroup(bot?.phone, jid);

            if (['الكل', 'all'].includes((args[0] || '').toLowerCase())) {
                const n = Object.keys(g.muted).length;
                g.muted = {}; save();
                return reply(`🔊 تم فك الكتم عن ${n} عضو.`);
            }
            const target = targetOf(message);
            if (!target) return reply(`❌ اعمل منشن للعضو أو رد على رسالته: ${prefix}فك-كتم @العضو\nأو ${prefix}فك-كتم الكل`);
            const t = idsOfTarget(ctx.meta, target);
            const hit = Object.entries(g.muted).filter(([, m]) => m.ids.some((i) => t.ids.includes(i)));
            if (!hit.length) return reply('ℹ️ العضو ده مش مكتوم.');
            hit.forEach(([k]) => delete g.muted[k]);
            save();
            return reply({ text: `🔊 تم فك الكتم عن @${digits(target)}.`, mentions: [target] });
        }
    }
];
