// ملف: plugins/سكربتي.js

"use strict";

import fs from "fs";
import path from "path";
import { execSync } from "child_process";

const ROOT = process.cwd();

const OUTPUT = path.join(
    "/tmp",
    "SOFA.ZIP"
);

export default {

    name: "سكربتي",

    aliases: [
        "script",
        "سكريبت",
        "سكربت",
        "نسخة",
        "backup"
    ],

    category: "owner",

    description: "إنشاء نسخة احتياطية من سكربت سوفا.",

    usage: ".سكربتي",

    async run({
        sock,
        message,
        reply
    }) {

        try {

            // ─────────────────────────────
            // START
            // ─────────────────────────────

            await reply(
                `🌌 *SOFA SCRIPT*

📦 *جاري تجهيز السكربت*

⏳ يتم الآن إنشاء نسخة من ملفات SOFA.

🚫 الملفات المستثناة:

• node_modules
• session
• sessions
• telegram sessions
• .git
• cache
• tmp
• temp
• logs
• ملفات .log

⚡ انتظر قليلاً...

> SOFA 🌌`
            );


            // ─────────────────────────────
            // REMOVE OLD ZIP
            // ─────────────────────────────

            if (
                fs.existsSync(OUTPUT)
            ) {

                fs.unlinkSync(
                    OUTPUT
                );

            }


            // ─────────────────────────────
            // EXCLUDED FILES
            // ─────────────────────────────

            const excluded = [

                "node_modules/*",

                ".npm/*",
                ".npm/**",

                "session/*",
                "sessions/*",

                "telegram/*.session",
                "telegram/*.session-journal",
                "telegram/session.json",
                "telegram/sessions/*",

                ".git/*",

                ".cache/*",
                ".next/*",
                ".turbo/*",

                "tmp/*",
                "temp/*",
                "logs/*",

                "*.log"

            ];


            const excludeArgs = excluded
                .map(
                    item =>
                        `-x "${item}"`
                )
                .join(" ");


            // ─────────────────────────────
            // CREATE ZIP
            // ─────────────────────────────

            const command =
                `cd "${ROOT}" && zip -r "${OUTPUT}" . ${excludeArgs}`;


            execSync(
                command,
                {
                    stdio: "ignore",
                    maxBuffer:
                        1024 *
                        1024 *
                        50
                }
            );


            // ─────────────────────────────
            // VALIDATE
            // ─────────────────────────────

            if (
                !fs.existsSync(
                    OUTPUT
                )
            ) {

                throw new Error(
                    "Failed to create SOFA.ZIP"
                );

            }


            const stats =
                fs.statSync(
                    OUTPUT
                );


            if (
                !stats.size
            ) {

                throw new Error(
                    "Backup file is empty"
                );

            }


            // ─────────────────────────────
            // SEND FILE
            // ─────────────────────────────

            await sock.sendMessage(
                message.key.remoteJid,
                {

                    document:
                        fs.readFileSync(
                            OUTPUT
                        ),

                    mimetype:
                        "application/zip",

                    fileName:
                        "SOFA.ZIP"

                },
                {

                    quoted:
                        message

                }
            );


            // ─────────────────────────────
            // CLEANUP
            // ─────────────────────────────

            try {

                if (
                    fs.existsSync(
                        OUTPUT
                    )
                ) {

                    fs.unlinkSync(
                        OUTPUT
                    );

                }

            } catch {}


            // ─────────────────────────────
            // SUCCESS
            // ─────────────────────────────

            return await reply(
                `🌌 *SOFA SCRIPT*

✅ *تم إنشاء النسخة بنجاح*

📦 الملف
↳ SOFA.zip

📊 الحجم
↳ ${(
                    stats.size /
                    1024 /
                    1024
                ).toFixed(2)} MB

🔒 تم استثناء الملفات غير الضرورية، بما فيها سيشن التليجرام.

🌌 تم إرسال نسخة السكربت بنجاح.

> SOFA 🌌`
            );


        } catch (error) {

            console.error(
                "[SOFA SCRIPT ERROR]",
                error?.stack ||
                error?.message ||
                error
            );


            // ─────────────────────────────
            // CLEANUP AFTER ERROR
            // ─────────────────────────────

            try {

                if (
                    fs.existsSync(
                        OUTPUT
                    )
                ) {

                    fs.unlinkSync(
                        OUTPUT
                    );

                }

            } catch {}


            // ─────────────────────────────
            // ERROR MESSAGE
            // ─────────────────────────────

            return await reply(
                `🌌 *SOFA SCRIPT ERROR*

❌ *حدث خطأ أثناء إنشاء نسخة السكربت*

⚠️ ${
                    error?.message ||
                    "Unknown Error"
                }

> SOFA 🌌`
            );

        }

    }

};