
// File: plugins/رقم.js
// PRO VERSION — Works even if APIs are empty

import axios from 'axios';

// =========================================
// الخدمات + API (يعمل حتى لو فاضي)
// =========================================
const services = {
    "5sim": {
        apiKey: "",
        enabled: true,
        base: "https://5sim.net/v1/user",
        buy: (c, op, pr) => `/buy/activation/${c}/${op}/${pr}`,
        check: id => `/check/${id}`,
        cancel: id => `/cancel/${id}`,
        headers(key){ return { Authorization: `Bearer ${key}` }; },
        processBuy(d){ return { id: d.id, phone: d.phone }; },
        processCheck(d){ return { status: d.status, code: d.sms?.[0]?.code || null }; }
    },

    "sms-activate": {
        apiKey: "",
        enabled: true,
        base: "https://api.sms-activate.org/stubs/handler_api.php",
        buy: (key,c,op,pr)=>`?api_key=${key}&action=getNumber&service=${pr}&operator=${op}&country=${c}`,
        check: (key,id)=>`?api_key=${key}&action=getStatus&id=${id}`,
        cancel: (key,id)=>`?api_key=${key}&action=setStatus&status=8&id=${id}`,
        processBuy(res){
            if(!res.includes("ACCESS_NUMBER")) throw Error(res);
            const [,id,phone] = res.split(":");
            return { id, phone: `+${phone}` };
        },
        processCheck(res){
            if(res.includes("STATUS_OK")){
                const [,code] = res.split(":");
                return { status: "RECEIVED", code };
            }
            return { status: "PENDING", code: null };
        }
    }
};

const activeOrders = new Map();

// =========================================
// البلجن الرئيسي
// =========================================
export default {
    name: "رقم",
    aliases: ["ارقام"],
    category: "خدمات",

    async run({ m, args, reply }) {
        const cmd = args[0]?.toLowerCase();
        const jid = m.key.participant || m.key.remoteJid;

        // اختيار الخدمات المفعلة فقط
        const active = Object.entries(services).filter(([_,s]) => s.enabled);

        if(!cmd){
            return reply(
`📦 *خدمة الأرقام المؤقتة PRO*
• .رقم دول
• .رقم شراء <كود الدولة>
• .رقم تحقق
• .رقم الغاء`
            );
        }

        // ================================
        // عرض الدول
        // ================================
        if(cmd === "دول"){
            reply("🌍 جاري جلب قائمة الدول…");

            let countries = new Map();

            for(const [name,s] of Object.entries(services)){
                if(!s.enabled) continue;

                try{
                    let url = "";
                    if(name === "5sim"){
                        url = s.base + "/countries";
                    } else {
                        // sms-activate
                        url = s.base + `?api_key=${s.apiKey}&action=getCountries`;
                    }

                    const res = await axios.get(url);

                    if(name === "5sim"){
                        for(const group of Object.values(res.data)){
                            for(const c of group){
                                if(c.whatsapp){
                                    countries.set(c.iso.toLowerCase(), c.text_en);
                                }
                            }
                        }
                    } else {
                        // sms-activate
                        for(const [code,obj] of Object.entries(res.data)){
                            countries.set(code.toLowerCase(), obj.eng);
                        }
                    }
                }catch(e){
                    // نكمل للخدمة اللي بعدها
                }
            }

            if(countries.size === 0)
                return reply("❌ لا توجد دول متاحة حالياً.");

            let msg = "🌍 *قائمة الدول المتاحة:*\n\n";
            for(const [code,name] of countries){
                msg += `• *${name}* — \`${code}\`\n`;
            }

            msg += "\nاستخدم:\n`.رقم شراء <كود الدولة>`";

            return reply(msg);
        }

        // ================================
        // شراء رقم
        // ================================
        if(cmd === "شراء"){
            const country = args[1];
            if(!country) return reply("اكتب الدولة مثال: `.رقم شراء us`");

            if(activeOrders.has(jid))
                return reply("⚠️ لديك طلب شغال — استخدم .رقم تحقق");

            reply("🔍 جاري محاولة شراء رقم…");

            let done = null;

            for(const [name,s] of active){
                try{
                    const buyURL = 
                        name==="5sim"
                        ? s.base + s.buy(country, "any", "whatsapp")
                        : s.base + s.buy(s.apiKey, country, "any", "wa");

                    const res = await axios.get(buyURL, s.headers ? { headers: s.headers(s.apiKey) } : {});
                    const order = name==="5sim" ? s.processBuy(res.data) : s.processBuy(res.data);

                    done = { ...order, service: name };
                    break;

                }catch(e){ /* نكمل */ }
            }

            if(!done)
                return reply("❌ لم نتمكن من شراء رقم من أي خدمة.");

            activeOrders.set(jid, { ...done });

            return reply(
`✅ *تم شراء رقم جديد*
📞 الرقم: \`${done.phone}\`
اكتب: *.رقم تحقق* للحصول على الكود`
            );
        }

        // ================================
        // تحقق من الكود
        // ================================
        if(cmd === "تحقق"){
            const ord = activeOrders.get(jid);
            if(!ord) return reply("لا يوجد طلب شغال.");

            reply("⏳ جاري التحقق…");

            const service = services[ord.service];

            try{
                const url = 
                    ord.service==="5sim"
                    ? service.base + service.check(ord.id)
                    : service.base + service.check(service.apiKey, ord.id);

                const res = await axios.get(url);
                const chk = service.processCheck(res.data || res.data);

                if(chk.status === "RECEIVED" && chk.code){
                    activeOrders.delete(jid);
                    return reply(`🎉 *الكود وصل:*\n\`${chk.code}\``);
                }

                return reply("⌛ لسه ما وصلش كود — حاول بعد شوية.");

            }catch(e){
                return reply("❌ خطأ أثناء التحقق.");
            }
        }

        // ================================
        // إلغاء
        // ================================
        if(cmd === "الغاء"){
            const ord = activeOrders.get(jid);
            if(!ord) return reply("لا يوجد طلب لإلغاءه.");

            const service = services[ord.service];

            try{
                const url =
                    ord.service==="5sim"
                    ? service.base + service.cancel(ord.id)
                    : service.base + service.cancel(service.apiKey, ord.id);

                await axios.get(url);
            }catch{}

            activeOrders.delete(jid);
            return reply("✅ تم إلغاء الطلب.");
        }
    }
};