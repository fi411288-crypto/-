import { aiCommand } from '../lib/aiCmd.js';
import { MODELS } from '../lib/groq.js';

export default aiCommand({
    name: 'لخص',
    aliases: ['تلخيص', 'summarize', 'summary'],
    description: 'تلخيص النصوص الطويلة والرسائل والمقالات في نقاط',
    usage: '.لخص النص (أو رد على رسالة)',
    system: 'لخص النص اللي هيجيلك في نقاط واضحة ومرتبة بنفس لغة النص (العربي بلهجة بسيطة). ابدأ بسطر واحد فيه الفكرة العامة، وبعدين 3 لـ 8 نقاط رئيسية، ' +
        'ومتضيفش معلومات مش موجودة في النص. لو النص قصير جداً لخصه في جملة.',
    model: MODELS.fast,
    effort: 'low',
    max: 1200,
    temperature: 0.3,
    emptyHelp: '📝 رد على رسالة طويلة واكتب {p}لخص\nأو: {p}لخص النص هنا',
    wrap: (t) => `📝 *الملخص*\n\n${t}\n\n> SOFA BOT`
});
