import { jidDecode } from '@whiskeysockets/baileys';

const getNumber = (jid) => {
  const decoded = jidDecode(jid);
  const user = decoded?.user || jid.split('@')[0];
  return user.split(':')[0]; 
};

export default {
  name: 'عنصرية',
  category: 'admin',
  description: 'طرد أعضاء حسب رمز الدولة أو عرض نسب الدول',
  admin: true,
  group: true,
  
  run: async (context) => {
    const { sock, m, text } = context;
    const jid = m.key.remoteJid;

    try {
      const meta = await sock.groupMetadata(jid);
      const participants = meta.participants;
      const botJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';

      const validMembers = participants.map(p => ({
        id: p.id,
        number: getNumber(p.id),
        isAdmin: p.admin || p.id === meta.owner
      })).filter(mem => /^\d+$/.test(mem.number));

      // 1. نظام النسبة
      if (text.includes('نسبة')) {
        const countryCounts = {};

        validMembers.forEach(member => {
          const num = member.number;
          // جرب تطابق من 3 أرقام لـ 1 رقم
          for (const len of [3, 2, 1]) {
            const prefix = num.slice(0, len);
            if (prefix[0] !== '0') {
              countryCounts[prefix] = (countryCounts[prefix] || 0) + 1;
              break;
            }
          }
        });

        const total = validMembers.length;
        let message = '*📊 تحليل أرقام المجموعة:*\n\n';
        
        // ترتيب من الأكثر للأقل
        const sorted = Object.entries(countryCounts).sort((a, b) => b[1] - a[1]);
        
        for (const [prefix, count] of sorted) {
          const percentage = ((count / total) * 100).toFixed(1);
          message += `• +${prefix} = ${count} عضو (${percentage}%)\n`;
        }

        message += `\n*اكتب: .عنصرية [كود الدولة] للطرد*`;
        return await sock.sendMessage(jid, { text: message }, { quoted: m });
      }

      // 2. نظام الطرد
      const match = text.match(/\d+/);
      if (!match) {
        return await sock.sendMessage(jid, { 
          text: '❗ استخدم الأمر كدة:\n• .عنصرية 20\n• .عنصرية نسبة' 
        }, { quoted: m });
      }

      const code = match[0];

      const toKick = validMembers.filter(p => {
        const num = p.number;
        const afterCode = num.slice(code.length);
        return (
          num.startsWith(code) &&
          afterCode.length >= 6 &&   // ضمان إن الكود مش جزء من رقم تاني
          p.id !== botJid &&            
          p.id !== m.key.participant && 
          !p.isAdmin        
        );
      });

      if (toKick.length === 0) {
        return await sock.sendMessage(jid, { 
          text: `❌ مفيش حد بكود +${code} غير المشرفين.` 
        }, { quoted: m });
      }

      const ids = toKick.map(p => p.id);
      
      await sock.sendMessage(jid, { 
        text: `✅ جاري تصفية ${ids.length} عضو من كود +${code}...` 
      }, { quoted: m });
      
      // الطرد على دفعات لتفادي الحظر
      const chunkSize = 5;
      for (let i = 0; i < ids.length; i += chunkSize) {
        const chunk = ids.slice(i, i + chunkSize);
        await sock.groupParticipantsUpdate(jid, chunk, 'remove');
        if (i + chunkSize < ids.length) {
          await new Promise(resolve => setTimeout(resolve, 1500)); // انتظر 1.5 ثانية بين كل دفعة
        }
      }

      return await sock.sendMessage(jid, { 
        text: `🔥 تم تنظيف الجروب بنجاح! تم طرد ${ids.length} عضو.` 
      }, { quoted: m });

    } catch (error) {
      console.error(error);
      await sock.sendMessage(jid, { 
        text: '❌ حصل خطأ، اتأكد إني أدمن في الجروب.' 
      }, { quoted: m });
    }
  }
};