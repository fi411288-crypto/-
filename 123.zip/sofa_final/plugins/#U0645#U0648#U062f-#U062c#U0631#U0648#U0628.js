import fs from 'fs';
import path from 'path';
import { getGroupMode, setGroupMode } from '../lib/groupMode.js';

// حط الصورة في فولدر media باسم: group-mode.jpg (أو .png / .jpeg)
function findImage() {
    for (const ext of ['jpg', 'jpeg', 'png']) {
        const f = path.join(process.cwd(), 'media', `group-mode.${ext}`);
        if (fs.existsSync(f)) return f;
    }
    return null;
}

const ADMINS = ['مشرفين', 'المشرفين', 'ادمن', 'ادمنز', 'admins', 'admin'];
const ALL = ['اعضاء', 'الاعضاء', 'الأعضاء', 'أعضاء', 'الكل', 'all', 'members'];
const label = (m) => (m === 'admins' ? 'المشرفين' : 'الأعضاء');

export default {
    name: "مود-جروب",
    aliases: ["جروب-مود", "جروب_مود", "مود_جروب", "groupmode", "modegroup"],
    description: "يحدد مين يقدر يستخدم البوت في الجروب: الأعضاء أو المشرفين فقط",
    category: "admin",
    group: true,
    admin: true,

    async run({ sock, message, args, reply, prefix }) {
        const jid = message.key.remoteJid;
        const p = prefix || '.';
        const choice = (args[0] || '').trim().toLowerCase();

        if (ADMINS.includes(choice) || ALL.includes(choice)) {
            const mode = ADMINS.includes(choice) ? 'admins' : 'all';
            setGroupMode(sock, jid, mode);
            return reply(mode === 'admins'
                ? "🛡️ تم ضبط الجروب على *المشرفين فقط*.\nمحدش غير المشرفين هيقدر يستخدم البوت هنا."
                : "👥 تم ضبط الجروب على *الأعضاء*.\nالكل يقدر يستخدم البوت.");
        }

        const current = getGroupMode(sock, jid);
        const body = `⚙️ اختر وضع الجروب من الأسفل\n\n📍 الوضع الآن: *${label(current)}*`;
        const buttons = [
            { buttonId: `${p}مود-جروب مشرفين`, buttonText: { displayText: "🛡️ المشرفين" }, type: 1 },
            { buttonId: `${p}مود-جروب اعضاء`, buttonText: { displayText: "👥 الأعضاء" }, type: 1 }
        ];
        const footer = "SOFA BOT • Developed by SOFA";
        const img = findImage();

        if (img) {
            try {
                await sock.sendMessage(jid, {
                    image: fs.readFileSync(img), caption: body, footer, buttons, headerType: 4
                }, { quoted: message });
                return;
            } catch {}
        }
        try {
            await sock.sendMessage(jid, { text: body, footer, buttons, headerType: 1 }, { quoted: message });
        } catch {
            return reply(`${body}\n\n• ${p}مود-جروب مشرفين\n• ${p}مود-جروب اعضاء`);
        }
    }
};
