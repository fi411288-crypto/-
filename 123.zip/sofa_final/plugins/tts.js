import fetch from 'node-fetch';

export default {
    name: 'انطق',
    aliases: ['tts', 'قول-صوت', 'speak'],
    description: 'تحويل نص إلى صوت',
    category: 'tools',
    usage: '.انطق مرحبا بكم',

    async run({ text, reply, sock, m, message, react }) {
        const t = (text || '').trim();
        if (!t) return reply('❌ اكتب نص\nمثال: .انطق أهلاً بيك');
        if (t.length > 200) return reply('❌ النص طويل (حد 200 حرف)');
        await react?.('⏳').catch?.(() => {});
        try {
            // Google translate TTS (unofficial)
            const lang = /[\u0600-\u06FF]/.test(t) ? 'ar' : 'en';
            const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(t)}&tl=${lang}&client=tw-ob`;
            const res = await fetch(url, {
                headers: { 'User-Agent': 'Mozilla/5.0' }
            });
            if (!res.ok) throw new Error('TTS failed');
            const buf = Buffer.from(await res.arrayBuffer());
            await react?.('✅').catch?.(() => {});
            return sock.sendMessage((m || message).key.remoteJid, {
                audio: buf,
                mimetype: 'audio/mp4',
                ptt: true
            }, { quoted: m || message });
        } catch (e) {
            await react?.('❌').catch?.(() => {});
            return reply('❌ فشل التحويل لصوت');
        }
    }
};
