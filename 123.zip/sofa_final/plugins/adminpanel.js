// ⚙️ قسم الأدمن — أوامر إدارة سريعة وفعالة
export default {
    name: 'ادمن',
    aliases: ['admin', 'ادمن-بانل', 'adminpanel'],
    description: '⚙️ قائمة أوامر الأدمن السريعة',
    category: 'admin',
    admin: true,
    group: true,

    async run({ reply, prefix }) {
        const p = prefix || '.';
        return reply(`╭─❏ 「 ⚙️ قسـم الأدمن 」
│
│ 🛡️ *الحماية*
│ • ${p}antilink on/off
│ • ${p}antispam on/off
│ • ${p}antibot on/off
│ • ${p}warn @منشن
│ • ${p}كتم @منشن
│ • ${p}فك-كتم @منشن
│
│ 👥 *الأعضاء*
│ • ${p}رفع @منشن
│ • ${p}خفض @منشن
│ • ${p}طير @منشن
│ • ${p}add رقم
│ • ${p}منشن / ${p}م
│
│ 🔒 *الجروب*
│ • ${p}قفل / ${p}فتح
│ • ${p}اسم نص
│ • ${p}وصف نص
│ • ${p}لينك
│ • ${p}ترحيب on/off
│
│ 👑 *VIP*
│ • ${p}زرف
│ • ${p}فنش
│ • ${p}سحب
│ • ${p}تصفيه
│
╰───────────────
> © SOFA VIP Admin`);
    }
};
