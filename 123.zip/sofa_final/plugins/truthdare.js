const TRUTHS_AR = [
    'إيه أكتر حاجة بتخاف منها؟',
    'مين أكتر شخص بتحبه في الشات ده؟',
    'آخر مرة كذبت فيها كانت ليه؟',
    'لو تقدر تغيّر حاجة في شخصيتك هتكون إيه؟',
    'مين آخر شخص بحثت عنه؟',
    'حصلتلك موقف محرج ومحدش يعرفه؟',
    'إيه السر اللي عمرك ما قلته لحد؟',
    'لو هتعيش في بلد تانية، هتختار أنهي؟'
];
const DARES_AR = [
    'ابعت فويس وقول: أنا أحلى واحد هنا 😄',
    'غيّر صورتك لدقيقة',
    'منشن 3 أشخاص وقولهم إنك بتحبهم',
    'اكتب رسالة كأنها اعتراف مضحك',
    'قول نكتة في الشات',
    'ابعت آخر صورة من الاستوديو (اختياري)',
    'تكلم بالفصحى لمدة 3 رسائل'
];
const TRUTHS_EN = [
    'What is your biggest fear?',
    'Who do you secretly like in this chat?',
    'When was the last time you lied?',
    'What would you change about yourself?',
    'What is a secret you never told anyone?'
];
const DARES_EN = [
    'Send a voice saying you are the coolest here',
    'Change your DP for 1 minute',
    'Mention 3 people and compliment them',
    'Tell a joke in the chat',
    'Speak formally for 3 messages'
];

export default [
    {
        name: 'حقيقة',
        aliases: ['truth', 'حق'],
        description: 'سؤال حقيقة عشوائي',
        category: 'fun',
        async run({ reply }) {
            const q = TRUTHS_AR[Math.floor(Math.random() * TRUTHS_AR.length)];
            return reply(`╭─❏ 「 🔵 حقيقة 」\n│ ${q}\n╰───────────────`);
        }
    },
    {
        name: 'جرأة',
        aliases: ['dare', 'جرأه'],
        description: 'تحدي جرأة عشوائي',
        category: 'fun',
        async run({ reply }) {
            const q = DARES_AR[Math.floor(Math.random() * DARES_AR.length)];
            return reply(`╭─❏ 「 🔴 جرأة 」\n│ ${q}\n╰───────────────`);
        }
    },
    {
        name: 'truth',
        aliases: ['truthen'],
        description: 'Random truth question (EN)',
        category: 'fun',
        async run({ reply }) {
            const q = TRUTHS_EN[Math.floor(Math.random() * TRUTHS_EN.length)];
            return reply(`╭─❏ 「 🔵 TRUTH 」\n│ ${q}\n╰───────────────`);
        }
    },
    {
        name: 'dare',
        description: 'Random dare (EN)',
        category: 'fun',
        async run({ reply }) {
            const q = DARES_EN[Math.floor(Math.random() * DARES_EN.length)];
            return reply(`╭─❏ 「 🔴 DARE 」\n│ ${q}\n╰───────────────`);
        }
    }
];
