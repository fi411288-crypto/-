import fs from 'fs';
import path from 'path';
import axios from 'axios';

// أمر .تفسير → تفسير آية من القرآن من مصادر معتمدة
//   .تفسير البقرة 255      (اسم سورة + رقم آية)
//   .تفسير 2:255           (رقم سورة : رقم آية)
//   .تفسير الله لا اله الا هو الحي القيوم   (جزء من نص الآية)
// المصادر: التفسير الميسر (مجمع الملك فهد) للمعنى المختصر + تفسير السعدي للتفصيل البسيط
// الجلب من Quran.com API، ولو وقع بيجرب مصادر احتياطية تلقائي.
const QURAN_FILE = path.join(process.cwd(), 'data', 'quran.json');
let QURAN = null;
const loadQuran = () => { if (!QURAN) QURAN = JSON.parse(fs.readFileSync(QURAN_FILE, 'utf8')); return QURAN; };

const MAX_SAADI = 3000;   // أقصى طول لتفسير السعدي في الرسالة
const MAX_MUYASSAR = 1200;

const toEn = (s) => String(s || '').replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const toAr = (n) => String(n).replace(/\d/g, (d) => '٠١٢٣٤٥٦٧٨٩'[d]);

// تطبيع عربي: شيل التشكيل والتطويل ووحّد الحروف
const norm = (s) => toEn(s)
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g, '')
    .replace(/[إأآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/[ىئ]/g, 'ي').replace(/ؤ/g, 'و')
    .replace(/[﴿﴾()\[\]{}.,،؛:؟?!"'«»\-_]/g, ' ')
    .replace(/\s+/g, ' ').trim().toLowerCase();

// نسخة "هيكل" للبحث: بتشيل الألف والهمزة عشان رسم المصحف (العٰلمين) يطابق الإملاء العادي (العالمين)
const skel = (s) => norm(s).replace(/[اء]/g, '').replace(/\s+/g, ' ').trim();

const normName = (s) => norm(s).replace(/^سوره\s+/, '').replace(/\s+/g, '').replace(/^ال/, '');
const ALIASES = { 'عمران': 3, 'ال عمران': 3, 'يس': 36, 'الاخلاص': 112, 'المعوذتين': 113 };

function findSurah(name) {
    const q = loadQuran();
    const n = normName(name);
    if (!n) return null;
    const al = Object.entries(ALIASES).find(([k]) => normName(k) === n);
    if (al) return q[al[1] - 1];
    return q.find((s) => normName(s.name) === n)
        || q.find((s) => normName(s.name).startsWith(n))
        || q.find((s) => normName(s.name).includes(n))
        || null;
}

// يحاول يفهم المدخل كمرجع (سورة + آية). يرجّع { surah, ayah } أو null
function parseRef(input) {
    const q = loadQuran();
    const t = (' ' + toEn(input) + ' ').replace(/(^|\s)(سوره|سورة|اية|آية|ايه|آيه|رقم)(?=\s|$)/g, ' ').replace(/\s+/g, ' ').trim();
    let m = t.match(/^(\d{1,3})\s*[:\/\-\s]\s*(\d{1,3})$/);
    if (m) return { surah: q[+m[1] - 1], ayah: +m[2], bad: !q[+m[1] - 1] };
    m = t.match(/^(.+?)\s*[:\/\-\s]\s*(\d{1,3})$/);
    if (m && /[\u0600-\u06FF]/.test(m[1])) return { surah: findSurah(m[1]), ayah: +m[2], nameText: m[1] };
    return null;
}

// بحث بالنص: بيرجّع أفضل الآيات تطابقاً
let INDEX = null;
function buildIndex() {
    if (INDEX) return INDEX;
    INDEX = [];
    loadQuran().forEach((s, si) => s.verses.forEach((v, vi) => {
        const n = skel(v);
        INDEX.push({ si, vi, n, set: new Set(n.split(' ')) });
    }));
    return INDEX;
}
function searchText(input) {
    const nq = skel(input);
    const words = nq.split(' ').filter(Boolean);
    if (words.length < 2) return [];
    const scored = [];
    for (const e of buildIndex()) {
        let score = 0;
        if (e.n === nq) score = 3;                       // الآية كلها مطابقة بالظبط
        else if (e.n.includes(nq)) score = 2 + words.length / 100;
        else {
            const hit = words.filter((w) => e.set.has(w)).length;
            const ratio = hit / words.length;
            if (ratio >= 0.75) score = ratio;
        }
        if (score) scored.push({ ...e, score });
    }
    scored.sort((a, b) => b.score - a.score);
    if (!scored.length) return [];
    const top = scored[0].score;
    return scored.filter((x) => x.score >= top - 1e-9).slice(0, 5);
}

// ───────── جلب التفسير ─────────
const clean = (html) => String(html || '')
    .replace(/<\s*br\s*\/?>/gi, '\n').replace(/<\/(p|div|h\d)>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ').replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();

const http = (url) => axios.get(url, { timeout: 12000, headers: { 'User-Agent': 'Mozilla/5.0' } }).then((r) => r.data);

const SOURCES = {
    muyassar: {
        title: '📘 *التفسير الميسر* (مجمع الملك فهد)',
        fetchers: [
            (s, a) => http(`https://api.quran.com/api/v4/tafsirs/16/by_ayah/${s}:${a}`).then((d) => d?.tafsir?.text),
            (s, a) => http(`https://api.alquran.cloud/v1/ayah/${s}:${a}/ar.muyassar`).then((d) => d?.data?.text),
            (s, a) => http(`https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/ar-tafsir-muyassar/${s}/${a}.json`).then((d) => d?.text)
        ]
    },
    saadi: {
        title: '📗 *تفسير السعدي* (تيسير الكريم الرحمن)',
        fetchers: [
            (s, a) => http(`https://api.quran.com/api/v4/tafsirs/91/by_ayah/${s}:${a}`).then((d) => d?.tafsir?.text),
            (s, a) => http(`https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/ar-tafseer-al-saddi/${s}/${a}.json`).then((d) => d?.text)
        ]
    }
};

async function getTafsir(key, s, a) {
    for (const f of SOURCES[key].fetchers) {
        try {
            const t = clean(await f(s, a));
            if (t && t.length > 5) return t;
        } catch { /* جرب المصدر اللي بعده */ }
    }
    return null;
}

function trim(text, max) {
    if (text.length <= max) return text;
    const cut = text.slice(0, max);
    const last = Math.max(cut.lastIndexOf('۔'), cut.lastIndexOf('.'), cut.lastIndexOf('\n'));
    return (last > max * 0.6 ? cut.slice(0, last + 1) : cut) + ' …';
}

const FOOT = '> *𝐒𝐎𝐅𝐀 𝐁𝐎𝐓 ⚡*';
const USAGE = '*طريقة الاستخدام:*\n• `.تفسير البقرة 255`\n• `.تفسير 2:255`\n• `.تفسير` + جزء من نص الآية\n\nالمصدر: التفسير الميسر + تفسير السعدي';

export default {
    name: 'تفسير',
    aliases: ['tafsir', 'tafseer', 'فسر', 'تفسير_اية'],
    description: 'تفسير آية من القرآن (الميسر + السعدي): .تفسير البقرة 255',
    category: 'islamic',
    run: async (context) => {
        const { client, m, text } = context;
        const send = (t) => client.sendMessage(m.chat, { text: t }, { quoted: m });
        const react = (e) => client.sendMessage(m.chat, { react: { text: e, key: m.reactKey || m.key } }).catch(() => {});
        const input = (text || '').trim();

        try {
            if (!input) return send(`╭━━━〔 📖 *تفسير* 📖 〕━━━╮\n\n${USAGE}\n╰━━━━━━━━━━━━━━━╯\n${FOOT}`);

            let surah, ayah;
            const ref = parseRef(input);
            if (ref) {
                if (!ref.surah) { await react('❌'); return send(`❌ ملقتش سورة باسم *${ref.nameText || input}*.\nاكتب اسمها زي المصحف أو رقمها (١ - ١١٤).`); }
                if (ref.ayah < 1 || ref.ayah > ref.surah.verses.length) {
                    await react('❌');
                    return send(`❌ سورة *${ref.surah.name}* عدد آياتها *${toAr(ref.surah.verses.length)}* بس.`);
                }
                surah = ref.surah; ayah = ref.ayah;
            } else {
                const found = searchText(input);
                if (!found.length) {
                    await react('❌');
                    return send(`❌ ملقتش آية بالنص ده.\nجرب تكتب كلمات أكتر من الآية، أو اكتب اسم السورة ورقم الآية.\n\n${USAGE}`);
                }
                if (found.length > 1) {
                    const q = loadQuran();
                    const list = found.map((f) => `• *${q[f.si].name}* آية ${toAr(f.vi + 1)}\n   ﴿ ${q[f.si].verses[f.vi].slice(0, 60)}… ﴾`).join('\n');
                    return send(`🔎 لقيت أكتر من آية قريبة من كلامك:\n\n${list}\n\nاختار واحدة واكتب مثلاً: \`.تفسير ${q[found[0].si].name} ${found[0].vi + 1}\``);
                }
                surah = loadQuran()[found[0].si]; ayah = found[0].vi + 1;
            }

            await react('⌛');
            const [muy, saadi] = await Promise.all([getTafsir('muyassar', surah.id, ayah), getTafsir('saadi', surah.id, ayah)]);
            if (!muy && !saadi) {
                await react('❌');
                return send('❌ مقدرتش أجيب التفسير دلوقتي (مشكلة اتصال بمصدر التفسير). جرب كمان شوية.');
            }

            let out = `╭━━━〔 📖 *تفسير* 📖 〕━━━╮\n\n﴿ ${surah.verses[ayah - 1]} ﴾\n*سورة ${surah.name} — آية ${toAr(ayah)}*\n`;
            if (muy) out += `\n${SOURCES.muyassar.title}\n${trim(muy, MAX_MUYASSAR)}\n`;
            if (saadi) out += `\n${SOURCES.saadi.title}\n${trim(saadi, MAX_SAADI)}\n`;
            out += `\n╰━━━━━━━━━━━━━━━╯\n${FOOT}`;
            await send(out);
            await react('✅');
        } catch (e) {
            console.error('[تفسير]', e.message);
            await react('❌');
            await send('❌ حصل خطأ أثناء جلب التفسير، جرب تاني.');
        }
    }
};
