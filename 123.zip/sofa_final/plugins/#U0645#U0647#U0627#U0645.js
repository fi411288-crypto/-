// 📋 مهام يومية: 3 مهام كل يوم + بونص لو خلصتهم كلهم — SOFA BOT
import { resolveNumber, isRegistered, updateUser } from '../lib/economy.js';
import { fmt, dayQuests, questState, QUEST_BONUS } from '../lib/shop.js';

export default [{
    name: 'مهام',
    aliases: ['quests', 'مهمات', 'missions'],
    category: 'games',
    description: 'مهام اليوم وجوايزها (بتتصرف أول ما تكتب الأمر بعد ما تخلص)',
    cooldown: 3000,
    async run({ sock, m, message, reply, prefix = '.' }) {
        const msg = m || message, number = await resolveNumber(sock, msg);
        if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
        const list = dayQuests();
        const r = updateUser(number, (u, eco) => {
            const q = questState(u); let got = 0, bonus = 0;
            const rows = list.map((x) => {
                const p = Math.min(q.prog[x.id] || 0, x.target), done = p >= x.target;
                if (done && !q.claimed[x.id]) { q.claimed[x.id] = true; eco.coin += x.reward; eco.exp += 20; got += x.reward; }
                return { ...x, p, done };
            });
            if (rows.every((x) => x.done) && !q.bonus) { q.bonus = true; eco.coin += QUEST_BONUS; bonus = QUEST_BONUS; }
            return { rows, got, bonus, total: eco.coin, all: rows.every((x) => x.done) };
        });
        if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ.');
        const lines = r.rows.map((x) => `${x.done ? '✅' : '🔸'} ${x.text}\n    ${x.p}/${x.target} • 🎁 ${fmt(x.reward)}`).join('\n');
        return reply(
            `📋 *SOFA • QUESTS*\n\n${lines}\n\n` +
            (r.got ? `🎉 استلمت \`${fmt(r.got)}\` كوين!\n` : '') + (r.bonus ? `🏆 بونص خلص كل المهام: \`+${fmt(r.bonus)}\`\n` : '') +
            (r.all ? '✨ خلصت كل مهام النهارده!' : `🎁 خلّص الـ3 وخد بونص ${fmt(QUEST_BONUS)}`) + `\n💰 رصيدك: \`${fmt(r.total)}\`\n🔄 المهام بتتجدد كل يوم 12 بالليل (القاهرة)`
        );
    }
}];
