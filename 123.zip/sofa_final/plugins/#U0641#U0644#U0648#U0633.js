// 💰 .فلوسي = فلوسك | .فلوس @حد (منشن أو ريبلاي) = فلوس حد — SOFA BOT
import { resolveNumber, isRegistered, getUser, getLevel } from '../lib/economy.js';
import { targetJid } from '../lib/xtools.js';
import { fmt, displayName, numberOfJid } from '../lib/shop.js';

async function show({ sock, m, message, reply, prefix = '.', isDeveloper = false }, allowTarget) {
    const msg = m || message;
    const t = allowTarget ? targetJid(msg) : null;
    const number = t ? await numberOfJid(sock, t) : await resolveNumber(sock, msg);
    if (!number || !isRegistered(number)) {
        return reply(t ? '❌ العضو ده مش مسجّل في البوت.' : `❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
    }
    const u = getUser(number);
    const coin = Number(u.economy?.coin || 0), exp = Number(u.economy?.exp || 0);
    const shownCoin = isDeveloper && !allowTarget ? '∞ (غير محدود)' : fmt(coin);
    const customRank = u.customRank ? `\n🏅 *الرتبة:* ${u.customRank}` : '';
    const text = `💰 *SOFA • WALLET*\n\n👤 *${t ? 'صاحب الحساب' : 'الاسم'}:* ${t ? '@' + number : displayName(u)}\n💵 *الفلوس:* \`${shownCoin}\` كوين\n⚡ *XP:* \`${fmt(exp)}\`\n📈 *المستوى:* \`${getLevel(exp)}\`\n\n> SOFA BOT`;
    return reply(t ? { text, mentions: [t] } : text);
}

export default [
    { name: 'فلوسي', aliases: ['فلوسى', 'محفظتي'], category: 'games', description: 'يعرض فلوسك', cooldown: 2000, run: (c) => show(c, false) },
    { name: 'فلوس', aliases: ['محفظة'], category: 'games', description: 'يعرض فلوسك أو فلوس حد (منشن/ريبلاي)', usage: '.فلوس @حد', cooldown: 2000, run: (c) => show(c, true) }
];
