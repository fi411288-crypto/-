import fs from 'fs';
import path from 'path';

// أمر .دعاء → دعاء عشوائي من القرآن الكريم أو من السنة الصحيحة (مع ذكر المصدر)
// الأدعية في data/duas.json (آيات القرآن منقولة حرفياً من نص Tanzil)
// عشان تزوّد دعاء: ضيف { "text": "...", "source": "..." } في الملف
const FILE = path.join(process.cwd(), 'data', 'duas.json');
let last = -1;

export default {
    name: 'دعاء',
    aliases: ['دعاء', 'ادعيه', 'ادعية', 'dua'],
    description: 'دعاء عشوائي من القرآن والسنة الصحيحة مع المصدر',
    category: 'islamic',
    run: async (context) => {
        const { client, m } = context;
        try {
            const list = JSON.parse(fs.readFileSync(FILE, 'utf8'));
            if (!list.length) throw new Error('empty');
            let i;
            do { i = Math.floor(Math.random() * list.length); } while (list.length > 1 && i === last);
            last = i;
            const d = list[i];
            const msg = `╭━━━〔 🤲 *دعاء* 🤲 〕━━━╮\n\n*${d.text}*\n\n📚 *المصدر:* ${d.source}\n╰━━━━━━━━━━━━━━━╯\n> *𝐒𝐎𝐅𝐀 𝐁𝐎𝐓 ⚡*`;
            await client.sendMessage(m.chat, { text: msg }, { quoted: m });
        } catch (e) {
            console.error('[دعاء]', e.message);
            await client.sendMessage(m.chat, { text: '❌ ملف الأدعية مش موجود أو فاضي (data/duas.json).' }, { quoted: m });
        }
    }
};
