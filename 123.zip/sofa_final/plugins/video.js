import { ytCommand } from '../lib/youtube.js';

export default {
    name: 'video',
    aliases: ['ytmp4', 'ytvideo'],
    description: 'تحميل فيديو من يوتيوب (رابط أو اسم)',
    category: 'downloader',
    run: (ctx) => ytCommand(ctx, 'video', 'video')
};
