// .رابط تلجرام F_1_D_L_1 ← t.me/F_1_D_L_1
// .رابط واتساب 201018766845 ← wa.me/201018766845
// .رابط انستا sofa_bot ← instagram.com/sofa_bot
export default [{
    name: 'رابط',
    aliases: ['link', 'url'],
    description: 'توليد روابط سريعة (تلجرام / واتساب / انستا)',
    category: 'tools',
    async run({ args, reply }) {
        const platform = String(args[0] || '').toLowerCase();
        const handle = String(args[1] || '').trim();

        if (!platform || !handle) {
            return reply(`الاستخدام:\n.رابط تلجرام معرّفك\n.رابط واتساب رقمك\n.رابط انستا معرّفك\n\nأمثلة:\n.رابط تلجرام F_1_D_L_1\n.رابط واتساب 201018766845\n.رابط انستا sofa_bot`);
        }

        let link = null;
        if (['telegram', 'تلجرام', 'tg'].includes(platform)) {
            link = `https://t.me/${handle}`;
        } else if (['whatsapp', 'واتساب', 'wa'].includes(platform)) {
            const phone = handle.replace(/\D/g, '');
            link = `https://wa.me/${phone}`;
        } else if (['instagram', 'انستا', 'ig'].includes(platform)) {
            link = `https://instagram.com/${handle}`;
        } else if (['tiktok', 'تيك', 'tt'].includes(platform)) {
            link = `https://tiktok.com/@${handle}`;
        } else if (['youtube', 'يوتيوب', 'yt'].includes(platform)) {
            link = `https://youtube.com/@${handle}`;
        } else {
            return reply('❌ منصة غير معروفة. استخدم: تلجرام / واتساب / انستا / تيك توك / يوتيوب');
        }

        return reply(`🔗 ${link}`);
    }
}];