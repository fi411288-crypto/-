// 🎓 جلسات تفاعلية بالذكاء الاصطناعي: .اختبرني (10 أسئلة اختيار + درجتك) و .اسألني (أسئلة مفتوحة وتصحيح لكل إجابة)
// الإجابة: في الجروب اكتب الإجابة عادي (أ/ب/ج/د) أو في أي مكان استخدم .ج <الإجابة> — SOFA BOT
import { groqChat, MODELS, AiError } from '../lib/groq.js';
import { hook } from '../lib/xtools.js';

const sessions = new Map(); // "chat|sender" -> session
const IDLE = 20 * 60 * 1000;
const LETTERS = ['أ', 'ب', 'ج', 'د'];
const LMAP = { 'أ': 0, 'ا': 0, 'a': 0, '1': 0, 'ب': 1, 'b': 1, '2': 1, 'ج': 2, 'c': 2, '3': 2, 'د': 3, 'd': 3, '4': 3 };
const FOOT = '\n\n> SOFA BOT';

const keyOf = (message) => `${message.key.remoteJid}|${String(message.key.fromMe ? 'me' : (message.key.participant || message.key.remoteJid)).split('@')[0].split(':')[0]}`;
const clean = () => { const now = Date.now(); for (const [k, s] of sessions) if (now - s.last > IDLE) sessions.delete(k); };
const shuffle = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

async function askJson(system, user, max = 4000) {
    for (let attempt = 0; attempt < 2; attempt++) {
        const out = await groqChat({ model: MODELS.chat, effort: 'low', max, temperature: 0.5, messages: [{ role: 'system', content: system }, { role: 'user', content: user }] });
        const a = out.search(/[\[{]/), b = Math.max(out.lastIndexOf(']'), out.lastIndexOf('}'));
        try { if (a >= 0 && b > a) return JSON.parse(out.slice(a, b + 1)); } catch {}
    }
    throw new AiError('مقدرتش أجهّز الأسئلة، جرّب تاني بموضوع تاني.');
}

const parseNum = (t) => { const n = parseInt(String(t || '').replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)), 10); return n >= 1 && n <= 10 ? n : 0; };

// ───────── اختبرني ─────────
async function buildQuiz(topic, n) {
    const raw = await askJson(
        'أنت مدرس بتعمل اختبارات. ارجع JSON فقط (من غير أي كلام تاني أو markdown) على شكل مصفوفة من ' + n + ' عناصر، كل عنصر: {"q":"السؤال","options":["..","..","..",".."],"answer":0,"why":"شرح مختصر للإجابة الصح"} حيث answer هو رقم الاختيار الصح (0 لـ 3). ' +
        'الأسئلة بالعربي (أو بلغة الموضوع لو لغة تانية)، متدرجة الصعوبة، 4 اختيارات واضحة وواحد بس صح، ومن غير ما الإجابة تتكرر في نفس المكان دايماً.',
        `المادة/الموضوع: ${topic}`);
    const qs = (Array.isArray(raw) ? raw : raw?.questions || []).filter((x) => x?.q && Array.isArray(x.options) && x.options.length === 4 && Number.isInteger(x.answer) && x.answer >= 0 && x.answer < 4).slice(0, n);
    if (qs.length < 3) throw new AiError('مقدرتش أجهّز أسئلة كفاية، جرّب موضوع أوضح.');
    return qs.map((x) => {
        const correct = x.options[x.answer];
        const options = shuffle(x.options.map(String));
        return { q: String(x.q), options, answer: options.indexOf(String(correct)), why: String(x.why || '') };
    });
}

const quizQ = (s) => {
    const q = s.qs[s.i];
    return `📝 *اختبرني • سؤال ${s.i + 1}/${s.qs.length}* — ${s.topic}\n\n${q.q}\n\n${q.options.map((o, i) => `${LETTERS[i]}) ${o}`).join('\n')}\n\n✍️ جاوب بحرف: *أ* / *ب* / *ج* / *د*   (أو *.ج أ*)`;
};

async function quizAnswer(s, text, send) {
    const t = String(text || '').trim().toLowerCase().replace(/[.)\s]+$/g, '').replace(/^[(\s]+/, '');
    if (!(t in LMAP)) return false;
    const q = s.qs[s.i], pick = LMAP[t];
    const ok = pick === q.answer;
    if (ok) s.score++; else s.wrong.push({ i: s.i, q, pick });
    let msg = `${ok ? '✅ *صح!*' : `❌ *غلط!* الصح: *${LETTERS[q.answer]}) ${q.options[q.answer]}*`}${q.why ? `\n💡 ${q.why}` : ''}`;
    s.i++; s.last = Date.now();
    if (s.i < s.qs.length) return send(`${msg}\n\n${quizQ(s)}`);
    sessions.delete(s.key);
    const n = s.qs.length, pct = Math.round((s.score / n) * 100);
    const grade = pct >= 90 ? '🏆 ممتاز!' : pct >= 75 ? '🌟 جيد جداً' : pct >= 60 ? '👍 جيد' : pct >= 50 ? '🙂 مقبول — محتاج مراجعة' : '📚 محتاج مذاكرة أكتر';
    const review = s.wrong.length ? `\n\n*🔁 راجع الأسئلة دي:*\n${s.wrong.map((w) => `• ${w.q.q}\n   ✅ ${w.q.options[w.q.answer]}`).join('\n')}` : '\n\n🎯 جاوبت كل الأسئلة صح!';
    return send(`${msg}\n\n━━━━━━━━━━━━\n🏁 *خلص الاختبار!*\n📊 درجتك: *${s.score}/${n}* (${pct}%)\n${grade}${review}\n\nلاختبار جديد: *.اختبرني <موضوع>*${FOOT}`);
}

// ───────── اسألني ─────────
async function buildQa(topic, n) {
    const raw = await askJson(
        'أنت مدرس بتعمل جلسة أسئلة تفاعلية. ارجع JSON فقط (من غير markdown) مصفوفة من ' + n + ' عناصر، كل عنصر: {"q":"سؤال مفتوح قصير بيتطلب إجابة من سطر لتلاتة","a":"الإجابة النموذجية باختصار"}. الأسئلة متدرجة الصعوبة وتغطي الموضوع، بالعربي (أو بلغة الموضوع).',
        `الموضوع: ${topic}`, 3000);
    const qs = (Array.isArray(raw) ? raw : raw?.questions || []).filter((x) => x?.q && x?.a).slice(0, n);
    if (qs.length < 2) throw new AiError('مقدرتش أجهّز الأسئلة، جرّب موضوع أوضح.');
    return qs.map((x) => ({ q: String(x.q), a: String(x.a) }));
}

const qaQ = (s) => `🎤 *اسألني • سؤال ${s.i + 1}/${s.qs.length}* — ${s.topic}\n\n${s.qs[s.i].q}\n\n✍️ اكتب إجابتك دلوقتي (أو *.ج إجابتك*) — ولإنهاء الجلسة: *.انهاء_الاختبار*`;

async function qaAnswer(s, text, send) {
    if (s.busy) return true;
    s.busy = true;
    try {
        const q = s.qs[s.i];
        let r;
        try {
            r = await askJson('أنت مدرس بتصحح إجابة طالب بعدل وتشجيع. ارجع JSON فقط: {"score":رقم من 0 لـ 10,"feedback":"تعليق مختصر (سطرين) بيوضّح الصح والناقص أو الغلط"}.',
                `السؤال: ${q.q}\nالإجابة النموذجية: ${q.a}\nإجابة الطالب: ${text}`, 600);
        } catch { r = { score: 0, feedback: 'معرفتش أصحح الإجابة دي، فكمّل للسؤال اللي بعده.' }; }
        const sc = Math.max(0, Math.min(10, Math.round(Number(r?.score) || 0)));
        s.total += sc; s.i++; s.last = Date.now();
        const head = `${sc >= 8 ? '✅' : sc >= 5 ? '🟡' : '❌'} *${sc}/10*\n💬 ${String(r?.feedback || '').slice(0, 400)}\n📖 *الإجابة النموذجية:* ${q.a}`;
        if (s.i < s.qs.length) return await send(`${head}\n\n${qaQ(s)}`);
        sessions.delete(s.key);
        const max = s.qs.length * 10, pct = Math.round((s.total / max) * 100);
        const grade = pct >= 85 ? '🏆 مستواك ممتاز!' : pct >= 70 ? '🌟 جيد جداً' : pct >= 50 ? '👍 كويس — راجع النقاط الناقصة' : '📚 محتاج مراجعة للموضوع';
        return await send(`${head}\n\n━━━━━━━━━━━━\n🏁 *خلصت الجلسة!*\n📊 درجتك: *${s.total}/${max}* (${pct}%)\n${grade}\n\nلجلسة جديدة: *.اسألني <موضوع>*${FOOT}`);
    } finally { s.busy = false; }
}

// ───────── المشترك ─────────
const sender = (sock, jid, quoted) => (text) => sock.sendMessage(jid, { text }, quoted ? { quoted } : {}).catch(() => {});

async function handleAnswer(s, text, send) {
    if (!s.qs.length) return true; // لسه بيجهّز الأسئلة
    return s.type === 'quiz' ? quizAnswer(s, text, send) : qaAnswer(s, text, send);
}

// الجروب: الإجابة بتتلقط من الرسالة العادية (بس من صاحب الجلسة)
hook('study-sessions', async ({ message, text, sock, jid, isCmd }) => {
    if (!text || isCmd || message.key.fromMe) return;
    const s = sessions.get(keyOf(message));
    if (!s || Date.now() - s.last > IDLE) return;
    if (s.type === 'qa' && text.trim().length < 2) return;
    await handleAnswer(s, text, sender(sock, jid, message));
});

async function start(ctx, type) {
    const { sock, m, message, text, reply, prefix = '.' } = ctx;
    const msg = m || message, jid = msg.key.remoteJid;
    clean();
    const raw = String(text || '').trim();
    const cmd = type === 'quiz' ? 'اختبرني' : 'اسألني';
    if (!raw) return reply(type === 'quiz'
        ? `🎓 *اختبرني*\nبعملك اختبار اختيار من متعدد وبحسبلك درجتك.\n\nالاستخدام: *${prefix}${cmd} <المادة/الموضوع> [عدد الأسئلة]*\nمثال: *${prefix}${cmd} الأحياء الوراثة 10*`
        : `🎤 *اسألني*\nبسألك أسئلة مفتوحة في أي موضوع وبصحّح كل إجابة.\n\nالاستخدام: *${prefix}${cmd} <الموضوع>*\nمثال: *${prefix}${cmd} الثورة الفرنسية*`);
    const key = keyOf(msg);
    if (sessions.has(key)) return reply(`⏳ عندك جلسة شغالة! كمّلها أو اكتب *${prefix}انهاء_الاختبار*.`);
    let topic = raw, n = type === 'quiz' ? 10 : 5;
    const last = raw.split(/\s+/).pop();
    if (raw.split(/\s+/).length > 1 && parseNum(last)) { n = type === 'quiz' ? parseNum(last) : Math.min(parseNum(last), 10); topic = raw.slice(0, raw.lastIndexOf(last)).trim(); }
    if (topic.length > 200) return reply('❌ الموضوع طويل، اختصره.');
    sessions.set(key, { key, type, topic, last: Date.now(), busy: true, qs: [], i: 0, score: 0, total: 0, wrong: [] }); // حجز المكان لحد ما الأسئلة تجهز
    try {
        await reply(`⌛ بجهّز ${type === 'quiz' ? 'الاختبار' : 'الأسئلة'}...`);
        const qs = type === 'quiz' ? await buildQuiz(topic, n) : await buildQa(topic, Math.min(n, 10));
        const s = sessions.get(key);
        if (!s) return; // اتلغت
        Object.assign(s, { qs, last: Date.now(), busy: false, sock });
        return sender(sock, jid, msg)(type === 'quiz' ? quizQ(s) : qaQ(s));
    } catch (e) {
        sessions.delete(key);
        return reply(`❌ ${e instanceof AiError ? e.message : 'حصل خطأ: ' + e.message}`);
    }
}

export default [
    { name: 'اختبرني', aliases: ['اختبرنى', 'quizme', 'اختبار'], category: 'ai', description: 'يسألك سؤال سؤال (اختيار من متعدد) ويحسب درجتك', usage: '.اختبرني <المادة> [عدد الأسئلة]', cooldown: 3000, run: (c) => start(c, 'quiz') },
    { name: 'اسألني', aliases: ['اسالني', 'askme'], category: 'ai', description: 'يحوّل أي موضوع لجلسة أسئلة تفاعلية بتصحيح لكل إجابة', usage: '.اسألني <الموضوع>', cooldown: 3000, run: (c) => start(c, 'qa') },
    {
        name: 'ج', aliases: ['اجب', 'اجابه', 'اجابة'], category: 'ai', description: 'الإجابة على سؤال الاختبار الحالي: .ج أ', usage: '.ج <الإجابة>', cooldown: 500,
        async run({ sock, m, message, text, reply, prefix = '.' }) {
            const msg = m || message;
            const s = sessions.get(keyOf(msg));
            if (!s || Date.now() - s.last > IDLE) return reply(`❌ مفيش جلسة شغالة. ابدأ بـ *${prefix}اختبرني* أو *${prefix}اسألني*`);
            if (!String(text || '').trim()) return reply('✍️ اكتب إجابتك بعد الأمر: *.ج أ*');
            const ok = await handleAnswer(s, text, sender(sock, msg.key.remoteJid, msg));
            if (ok === false) return reply('❌ جاوب بحرف: أ / ب / ج / د');
        }
    },
    {
        name: 'انهاء_الاختبار', aliases: ['وقف_الاختبار', 'وقف-الاختبار', 'انهاء-الاختبار', 'انهاء_الجلسة'], category: 'ai', description: 'ينهي جلسة اختبرني/اسألني الحالية', cooldown: 1000,
        async run({ m, message, reply }) {
            const msg = m || message, k = keyOf(msg), s = sessions.get(k);
            if (!s) return reply('ℹ️ مفيش جلسة شغالة.');
            sessions.delete(k);
            return reply(s.type === 'quiz' && s.i ? `🛑 اتنهى الاختبار. درجتك لحد دلوقتي: *${s.score}/${s.i}*` : '🛑 اتنهت الجلسة.');
        }
    }
];
