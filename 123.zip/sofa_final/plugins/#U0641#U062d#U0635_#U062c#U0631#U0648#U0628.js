import { digits } from '../lib/adminTools.js';

export default [{
    name: 'فحص_جروب',
    description: 'فحص تفاصيل الجروب (رد على رسالة فيه)',
    category: 'owner',
    ownerSession: true,
    async run({ m, sock, reply }) {
        const groupJid = m.chat;
        if (!String(groupJid).includes('@g.us')) {
            return reply('❌ هذا الأمر للجروبات فقط');
        }

        try {
            const meta = await sock.groupMetadata(groupJid);
            
            let msg = `📊 *فحص الجروب*\n\n`;
            msg += `🆔 JID: ${meta.id}\n`;
            msg += `📝 الاسم: ${meta.subject}\n`;
            msg += `👥 الأعضاء: ${meta.participants.length}\n\n`;
            
            msg += `👑 *المالك (Owner):*\n`;
            if (meta.owner) {
                msg += `• ${meta.owner}\n`;
                msg += `• الرقم: ${digits(meta.owner)}\n`;
            } else {
                msg += `• لا يوجد\n`;
            }
            
            msg += `\n🛡️ *الأدمنز:*\n`;
            const admins = meta.participants.filter((p) => p.admin);
            if (admins.length) {
                admins.forEach((a) => {
                    msg += `• ID: ${a.id} (${a.admin})\n`;
                    msg += `  الرقم: ${digits(a.id)}\n`;
                    if (a.phoneNumber) msg += `  Phone: ${a.phoneNumber}\n`;
                    if (a.lid) msg += `  LID: ${a.lid}\n`;
                });
            } else {
                msg += `• لا يوجد\n`;
            }
            
            msg += `\n*كل الأعضاء مع أرقام هواتفهم:*\n`;
            meta.participants.slice(0, 10).forEach((p, i) => {
                const phone = p.phoneNumber || digits(p.id) || 'unknown';
                const lid = p.lid || '-';
                msg += `${i + 1}. ${phone} (LID: ${lid}) - ${p.admin || 'عضو'}\n`;
            });
            
            return reply(msg);
        } catch (error) {
            return reply(`❌ خطأ: ${error.message}`);
        }
    }
}];