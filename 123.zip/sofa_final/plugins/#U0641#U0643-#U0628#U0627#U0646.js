import { removeBan, listBans } from '../lib/bans.js';
import { isLinkedSender, extractTargets } from '../lib/banTargets.js';

export default {
    name: "فك-بان",
    aliases: ["فك_بان", "بان-فك", "فك-حظر", "unban"],
    description: "يفك الحظر عن مستخدم (منشن / رد / رقم / tg:ID)",
    category: "admin",

    async run({ sock, message, args, reply, handler, prefix }) {
        if (!isLinkedSender(handler, message)) return reply("❌ الأمر ده للأرقام المربوطة بالبوت بس.");
        const p = prefix || '.';

        if (args[0] === 'الكل' || args[0] === 'all') {
            const l = listBans();
            l.wa.forEach((n) => removeBan('wa', n));
            l.tg.forEach((n) => removeBan('tg', n));
            return reply(`✅ تم فك الحظر عن الكل (${l.wa.length + l.tg.length}).`);
        }

        const t = await extractTargets({ sock, message, args });
        if (!t.wa.length && !t.tg.length) return reply(`📌 الاستخدام:\n• ${p}فك-بان (رد أو منشن)\n• ${p}فك-بان 2010xxxxxxx\n• ${p}فك-بان tg:123456789\n• ${p}فك-بان الكل`);

        const done = [];
        for (const n of t.wa) if (removeBan('wa', n)) done.push(n);
        for (const n of t.tg) if (removeBan('tg', n)) done.push(`tg:${n}`);

        if (!done.length) return reply("ℹ️ مفيش حد منهم كان محظور.");
        return reply(`✅ تم فك الحظر عن:\n${done.map((d) => `• ${d}`).join('\n')}`);
    }
};
