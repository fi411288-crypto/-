import { sendFeedback } from '../lib/feedback.js';

export default {
    name: "شكوه",
    aliases: ["شكوى", "شكوي", "complaint"],
    description: "ابعت شكوى للمطور",
    usage: ".شكوه نص الشكوى",
    category: "tools",

    async run({ sock, message, args, reply, prefix }) {
        return sendFeedback({ kind: 'complaint', sock, message, args, reply, prefix });
    }
};
