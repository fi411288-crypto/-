// أوامر التفاعل والجوائز وطلبات الانضمام — SOFA BOT
import { getGroup, weekPoints, weekKey, monthKey, addPoints, userOf } from '../lib/community.js';
import { addRewards, resolveNumber, digits } from '../lib/economy.js';
import { getAdminFlags } from '../lib/compat.js';

const fmt = n => Number(n || 0).toLocaleString('en-US');
const senderId = m => digits(m?.key?.participantPn || m?.key?.participantAlt || m?.key?.participant || m?.key?.remoteJid);
const groupOnly = (isGroup, reply) => { if (isGroup) return true; reply('❌ الأمر ده للمجموعات فقط.'); return false; };
async function adminCheck(ctx) {
  const { sock, message, reply, isDeveloper } = ctx;
  const jid = message.key.remoteJid;
  const meta = await sock.groupMetadata(jid);
  const flags = getAdminFlags(sock, message, meta);
  if (!flags.isBotAdmin) { await reply('❌ لازم أكون مشرف في المجموعة لتنفيذ الأمر.'); return false; }
  if (!flags.isAdmin && !isDeveloper) { await reply('❌ الأمر ده للمشرفين فقط.'); return false; }
  return true;
}
function ranking(g, period) {
  const key = period === 'week' ? weekKey() : monthKey();
  return Object.entries(g.users || {}).map(([id, u]) => ({
    id, name: u.name || id, points: period === 'week' ? (u.week?.key === key ? Number(u.week.points || 0) : 0) : (u.month?.key === key ? Number(u.month.points || 0) : 0),
    msgs: period === 'week' ? undefined : (u.month?.key === key ? Number(u.month.msgs || 0) : 0)
  })).filter(x => x.points > 0 || x.msgs > 0).sort((a,b) => b.points-a.points || (b.msgs||0)-(a.msgs||0));
}
function board(title, rows) {
  if (!rows.length) return `📭 لا توجد بيانات كافية لعرض ${title} حتى الآن.`;
  return `🏆 *${title}*\n\n` + rows.slice(0, 10).map((u,i) => `${i+1}. ${u.name} — ⭐ ${fmt(u.points)} نقطة${u.msgs === undefined ? '' : ` · 💬 ${fmt(u.msgs)} رسالة`}`).join('\n') + '\n\n> SOFA BOT';
}

export default [
  { name:'التفاعل', aliases:['نشاط_الجروب','تفاعل_الجروب'], category:'community', description:'ملخص نشاط المجموعة', cooldown:5000, async run(ctx) {
    if (!groupOnly(ctx.isGroup, ctx.reply)) return;
    const { g } = getGroup(ctx.bot.phone, ctx.message.key.remoteJid);
    const day = new Date().toLocaleDateString('en-CA',{timeZone:'Africa/Cairo'});
    const week = ranking(g,'week'); const month = ranking(g,'month');
    return ctx.reply(`📊 *إحصائيات تفاعل المجموعة*\n\n💬 إجمالي الرسائل المسجلة: ${fmt(g.msgs)}\n📅 رسائل اليوم: ${fmt(g.days?.[day]||0)}\n👥 أعضاء لهم نشاط مسجل: ${fmt(Object.keys(g.users||{}).length)}\n⭐ نقاط هذا الأسبوع: ${fmt(week.reduce((s,x)=>s+x.points,0))}\n🏅 نقاط هذا الشهر: ${fmt(month.reduce((s,x)=>s+x.points,0))}\n\n> SOFA BOT`);
  }},
  { name:'المتفاعلين', aliases:['توب_التفاعل','نشطاء'], category:'community', description:'ترتيب أكثر الأعضاء تفاعلاً هذا الأسبوع', cooldown:5000, async run(ctx) {
    if (!groupOnly(ctx.isGroup, ctx.reply)) return;
    const { g } = getGroup(ctx.bot.phone, ctx.message.key.remoteJid);
    return ctx.reply(board('أكثر المتفاعلين هذا الأسبوع', ranking(g,'week')));
  }},
  { name:'نشاطي', aliases:['تفاعلي'], category:'community', description:'عرض نشاطك داخل المجموعة', cooldown:3000, async run(ctx) {
    if (!groupOnly(ctx.isGroup, ctx.reply)) return;
    const { g } = getGroup(ctx.bot.phone, ctx.message.key.remoteJid);
    const id = senderId(ctx.message); const u = g.users?.[id];
    if (!u) return ctx.reply('لم يتم تسجيل نشاطك بعد. أرسل رسائل عادية في المجموعة وسيظهر نشاطك هنا.');
    const rank = ranking(g,'week').findIndex(x=>x.id===id)+1;
    return ctx.reply(`📈 *نشاطك في المجموعة*\n\n💬 إجمالي الرسائل: ${fmt(u.msgs)}\n⭐ نقاطك الكلية: ${fmt(u.points)}\n📅 نقاط الأسبوع: ${fmt(weekPoints(u))}\n🏅 ترتيبك الأسبوعي: ${rank ? `#${rank}` : 'غير مصنف'}\n> SOFA BOT`);
  }},
  { name:'احصائيات_الجروب', aliases:['احصائيات-الجروب','احصاء_الجروب'], category:'community', description:'إحصائيات المجموعة التفصيلية', cooldown:5000, async run(ctx) {
    if (!groupOnly(ctx.isGroup, ctx.reply)) return;
    const { g } = getGroup(ctx.bot.phone, ctx.message.key.remoteJid);
    const top = Object.entries(g.cmds||{}).sort((a,b)=>b[1]-a[1]).slice(0,5);
    return ctx.reply(`📊 *تفاصيل المجموعة*\n\n💬 الرسائل: ${fmt(g.msgs)}\n⚡ الأوامر المستخدمة: ${fmt(g.cmdTotal)}\n👥 الأعضاء النشطون: ${fmt(Object.keys(g.users||{}).length)}\n🗓️ أيام محفوظة: ${fmt(Object.keys(g.days||{}).length)}\n\n🔥 *أكثر الأوامر استخداماً*\n${top.length?top.map(([n,c],i)=>`${i+1}. ${n}: ${fmt(c)}`).join('\n'):'لا توجد بيانات بعد.'}\n> SOFA BOT`);
  }},
  { name:'جوائز_الأسبوع', aliases:['جوائز-الأسبوع','جوائز_اسبوعية'], category:'community', description:'عرض جوائز أفضل المتفاعلين أسبوعياً', cooldown:5000, async run(ctx) {
    if (!groupOnly(ctx.isGroup, ctx.reply)) return;
    const { g } = getGroup(ctx.bot.phone, ctx.message.key.remoteJid);
    return ctx.reply(`🎁 *جوائز الأسبوع*\n🥇 الأول: 500 كوين + 100 XP\n🥈 الثاني: 300 كوين + 60 XP\n🥉 الثالث: 150 كوين + 30 XP\n\nاستخدم .استلام_جائزة بعد ظهور اسمك ضمن أول 3 في الترتيب الأسبوعي.\n\n${board('ترتيب الأسبوع',ranking(g,'week'))}`);
  }},
  { name:'جوائز_الشهر', aliases:['جوائز-الشهر','جوائز_شهرية'], category:'community', description:'عرض جوائز أفضل المتفاعلين شهرياً', cooldown:5000, async run(ctx) {
    if (!groupOnly(ctx.isGroup, ctx.reply)) return;
    const { g } = getGroup(ctx.bot.phone, ctx.message.key.remoteJid);
    return ctx.reply(`🏅 *جوائز الشهر*\n🥇 الأول: 2000 كوين + 500 XP\n🥈 الثاني: 1200 كوين + 250 XP\n🥉 الثالث: 600 كوين + 120 XP\n\nاستخدم .استلام_جائزة بعد ظهور اسمك ضمن أول 3 في ترتيب الشهر.\n\n${board('ترتيب الشهر',ranking(g,'month'))}`);
  }},
  { name:'الجوائز', aliases:['جوائز','قائمة_الجوائز'], category:'community', description:'عرض نظام الجوائز والترتيبات', cooldown:3000, async run(ctx) {
    if (!groupOnly(ctx.isGroup, ctx.reply)) return;
    return ctx.reply('🎁 *مركز جوائز SOFA*\n\n🏆 .جوائز_الأسبوع — ترتيب وجوائز الأسبوع\n🏅 .جوائز_الشهر — ترتيب وجوائز الشهر\n🎖️ .استلام_جائزة — استلام مكافأتك إذا كنت ضمن أول 3\n📜 .سجل_الجوائز — سجل استلاماتك\n📊 .التفاعل — ملخص نشاط المجموعة\n👑 .المتفاعلين — أفضل المتفاعلين\n📈 .نشاطي — إحصائياتك الشخصية');
  }},
  { name:'استلام_جائزة', aliases:['استلم_جائزتي'], category:'community', description:'استلام جائزة التفاعل الأسبوعية أو الشهرية مرة واحدة لكل فترة', cooldown:10000, async run(ctx) {
    if (!groupOnly(ctx.isGroup, ctx.reply)) return;
    const jid=ctx.message.key.remoteJid, {g,save}=getGroup(ctx.bot.phone,jid), id=senderId(ctx.message);
    const week=ranking(g,'week'), month=ranking(g,'month');
    const wr=week.findIndex(x=>x.id===id), mr=month.findIndex(x=>x.id===id);
    let period, rank, coins, xp;
    if (wr>=0 && wr<3) { period=`week:${weekKey()}`; rank=wr; coins=[500,300,150][wr]; xp=[100,60,30][wr]; }
    else if (mr>=0 && mr<3) { period=`month:${monthKey()}`; rank=mr; coins=[2000,1200,600][mr]; xp=[500,250,120][mr]; }
    else return ctx.reply('لم تصل بعد إلى أحد المراكز الثلاثة الأولى. راجع .جوائز_الأسبوع و.جوائز_الشهر.');
    g.rewardClaims ||= {};
    const claimKey=`${period}:${id}`;
    if(g.rewardClaims[claimKey]) return ctx.reply('✅ سبق واستلمت جائزة هذه الفترة.');
    let number=''; try { number=await resolveNumber(ctx.sock,ctx.message); } catch {}
    number=digits(number);
    if(!number) return ctx.reply('تعذر تحديد حسابك لاستلام الجائزة.');
    const paid=addRewards(number,xp,coins);
    if(!paid.success) return ctx.reply('❌ يجب التسجيل أولاً في نظام الاقتصاد حتى تستلم الجائزة.');
    g.rewardClaims[claimKey]={at:Date.now(),rank:rank+1,coins,xp}; save();
    return ctx.reply(`🎉 تم استلام الجائزة بنجاح!\n🏆 المركز: ${rank+1}\n💰 +${coins} كوين\n⭐ +${xp} XP\n> SOFA BOT`);
  }},
  { name:'سجل_الجوائز', aliases:['سجل-الجوائز'], category:'community', description:'عرض سجل جوائزك في المجموعة', cooldown:3000, async run(ctx) {
    if (!groupOnly(ctx.isGroup, ctx.reply)) return;
    const {g}=getGroup(ctx.bot.phone,ctx.message.key.remoteJid), id=senderId(ctx.message);
    const rows=Object.entries(g.rewardClaims||{}).filter(([k])=>k.endsWith(`:${id}`)).sort((a,b)=>b[1].at-a[1].at).slice(0,10);
    return ctx.reply(rows.length?`📜 *سجل جوائزك*\n\n${rows.map(([k,v])=>`🏅 ${k.split(':')[0]==='week'?'أسبوعية':'شهرية'} — مركز ${v.rank} — ${fmt(v.coins)} كوين — ${fmt(v.xp)} XP`).join('\n')}`:'لا يوجد لديك سجل جوائز بعد.');
  }},
  { name:'طلبات', aliases:['طلبات_الانضمام','طلبات_الجروب'], category:'group', description:'عرض طلبات الانضمام المعلقة', cooldown:5000, async run(ctx) {
    if (!groupOnly(ctx.isGroup,ctx.reply)) return;
    if (!(await adminCheck(ctx))) return;
    try { const req=await ctx.sock.groupRequestParticipantsList(ctx.message.key.remoteJid); if(!req?.length) return ctx.reply('📭 لا توجد طلبات انضمام معلقة.');
      return ctx.reply('📨 *طلبات الانضمام المعلقة*\n\n'+req.map((r,i)=>`${i+1}. ${r.jid||r.phone_number||r.id}`).join('\n')+'\n\nللقبول: .قبول_طلب رقم_العضو\nللرفض: .رفض_طلب رقم_العضو');
    } catch(e){ return ctx.reply(`❌ تعذر جلب الطلبات: ${e.message}`); }
  }},
  { name:'قبول_طلب', aliases:['وافق_طلب'], category:'group', description:'قبول طلب انضمام محدد بالرقم', cooldown:3000, async run(ctx) {
    if (!groupOnly(ctx.isGroup,ctx.reply)) return; if(!(await adminCheck(ctx))) return;
    const raw=String(ctx.args?.[0]||'').replace(/[^\d@.a-z_-]/gi,''); if(!raw) return ctx.reply('اكتب رقم العضو بعد الأمر. مثال: .قبول_طلب 201xxxxxxxxx');
    const jid=raw.includes('@')?raw:`${raw.replace(/\D/g,'')}@s.whatsapp.net`;
    try { const res=await ctx.sock.groupRequestParticipantsUpdate(ctx.message.key.remoteJid,[jid],'approve'); return ctx.reply(`📨 نتيجة القبول: ${JSON.stringify(res).slice(0,1200)}`); } catch(e){ return ctx.reply(`❌ فشل قبول الطلب: ${e.message}`); }
  }},
  { name:'رفض_طلب', aliases:['ارفض_طلب'], category:'group', description:'رفض طلب انضمام محدد بالرقم', cooldown:3000, async run(ctx) {
    if (!groupOnly(ctx.isGroup,ctx.reply)) return; if(!(await adminCheck(ctx))) return;
    const raw=String(ctx.args?.[0]||'').replace(/[^\d@.a-z_-]/gi,''); if(!raw) return ctx.reply('اكتب رقم العضو بعد الأمر. مثال: .رفض_طلب 201xxxxxxxxx');
    const jid=raw.includes('@')?raw:`${raw.replace(/\D/g,'')}@s.whatsapp.net`;
    try { const res=await ctx.sock.groupRequestParticipantsUpdate(ctx.message.key.remoteJid,[jid],'reject'); return ctx.reply(`📨 نتيجة الرفض: ${JSON.stringify(res).slice(0,1200)}`); } catch(e){ return ctx.reply(`❌ فشل رفض الطلب: ${e.message}`); }
  }},
  { name:'قبول_الكل', aliases:['قبول-الكل'], category:'group', description:'قبول جميع طلبات الانضمام المعلقة', cooldown:10000, async run(ctx) {
    if (!groupOnly(ctx.isGroup,ctx.reply)) return; if(!(await adminCheck(ctx))) return;
    try { const req=await ctx.sock.groupRequestParticipantsList(ctx.message.key.remoteJid); const ids=(req||[]).map(x=>x.jid||x.phone_number||x.id).filter(Boolean); if(!ids.length) return ctx.reply('📭 لا توجد طلبات معلقة.');
      let ok=0,fail=0; for(let i=0;i<ids.length;i+=20){const res=await ctx.sock.groupRequestParticipantsUpdate(ctx.message.key.remoteJid,ids.slice(i,i+20),'approve'); if(Array.isArray(res)) {ok+=res.filter(x=>String(x.status)==='200').length; fail+=res.filter(x=>String(x.status)!=='200').length;} else ok+=ids.slice(i,i+20).length; await new Promise(r=>setTimeout(r,400));} return ctx.reply(`✅ تم قبول ${ok} طلب\n❌ تعذر قبول ${fail} طلب`);
    } catch(e){return ctx.reply(`❌ فشل تنفيذ الطلبات: ${e.message}`);}
  }},
  { name:'رفض_الكل', aliases:['رفض-الكل'], category:'group', description:'رفض جميع طلبات الانضمام المعلقة', cooldown:10000, async run(ctx) {
    if (!groupOnly(ctx.isGroup,ctx.reply)) return; if(!(await adminCheck(ctx))) return;
    try { const req=await ctx.sock.groupRequestParticipantsList(ctx.message.key.remoteJid); const ids=(req||[]).map(x=>x.jid||x.phone_number||x.id).filter(Boolean); if(!ids.length) return ctx.reply('📭 لا توجد طلبات معلقة.');
      let ok=0,fail=0; for(let i=0;i<ids.length;i+=20){const res=await ctx.sock.groupRequestParticipantsUpdate(ctx.message.key.remoteJid,ids.slice(i,i+20),'reject'); if(Array.isArray(res)) {ok+=res.filter(x=>String(x.status)==='200').length; fail+=res.filter(x=>String(x.status)!=='200').length;} else ok+=ids.slice(i,i+20).length; await new Promise(r=>setTimeout(r,400));} return ctx.reply(`🚫 تم رفض ${ok} طلب\n❌ تعذر رفض ${fail} طلب`);
    } catch(e){return ctx.reply(`❌ فشل تنفيذ الطلبات: ${e.message}`);}
  }}
];
