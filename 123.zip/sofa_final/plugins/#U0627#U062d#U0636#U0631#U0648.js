import { connectedSessions, ownerNumber, sleep, rand, errText } from '../lib/adminTools.js';

// .احضرو ← كل الأرقام المربوطة (ماعدا رقم الأونر) تبعتلك برايفت "موجود ياسوفا؟"
export default [{
    name: 'احضرو',
    description: 'كل الأرقام المربوطة تبعتلك رسالة خاصة',
    category: 'owner',
    ownerSession: true,
    async run({ reply }) {
        const sessions = connectedSessions({ excludeOwner: true });
        if (!sessions.length) return reply('❌ مفيش أرقام مربوطة متصلة دلوقتي.');
        const target = `${ownerNumber()}@s.whatsapp.net`;
        let ok = 0;
        const fails = [];
        for (const s of sessions) {
            try {
                await s.sock.sendMessage(target, { text: 'موجود ياسوفا؟' });
                ok++;
            } catch (e) { fails.push(`${s.phone}: ${errText(e)}`); }
            await sleep(rand(800, 2000));
        }
        let msg = `✅ ${ok} رقم بعتولك من ${sessions.length}`;
        if (fails.length) msg += `\n❌ فشل ${fails.length}:\n${fails.slice(0, 10).map((f) => `• ${f}`).join('\n')}`;
        return reply(msg);
    }
}];
