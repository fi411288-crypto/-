import fs from 'fs';
import path from 'path';

// ملفات آمنة للحذف (مفاتيح مؤقتة). مش بنقرب لـ creds.json ولا app-state-sync-key
const SAFE = /^(pre-key|sender-key|sender-key-memory|app-state-sync-version)-/;
const MAX_AGE = 60 * 60 * 1000;

function clean(dir) {
    let removed = 0;
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) { removed += clean(full); continue; }
        if (!SAFE.test(entry.name)) continue;
        if (Date.now() - fs.statSync(full).mtimeMs < MAX_AGE) continue;
        fs.unlinkSync(full);
        removed++;
    }
    return removed;
}

export default {
    name: 'تنظيف',
    aliases: ['clearsession'],
    description: 'حذف ملفات الجلسة المؤقتة القديمة من غير فقدان الاتصال',
    category: 'developer',
    developer: true,

    async run({ reply }) {
        try {
            const dir = path.join(process.cwd(), 'sessions');
            if (!fs.existsSync(dir)) return reply('⚠️ مجلد الجلسات غير موجود!');
            const removed = clean(dir);
            return reply(removed ? `🧹 تم حذف ${removed} ملف مؤقت قديم.` : '✅ لا حاجة للتنظيف.');
        } catch (e) {
            return reply(`❌ حدث خطأ: ${e.message}`);
        }
    }
};
