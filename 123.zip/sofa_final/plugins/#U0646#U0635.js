import { groqTranscribe, quotedOf, reactor, AiError } from '../lib/groq.js';

const extOf = (mime) => {
    if (/ogg|opus/.test(mime)) return 'audio.ogg';
    if (/mpeg|mp3/.test(mime)) return 'audio.mp3';
    if (/mp4|m4a|aac/.test(mime)) return 'audio.m4a';
    if (/webm/.test(mime)) return 'audio.webm';
    if (/wav/.test(mime)) return 'audio.wav';
    return 'audio.ogg';
};

export default {
    name: 'نص',
    aliases: ['تفريغ', 'stt'],
    description: 'تحويل رسالة صوتية (أو فيديو) لنص — رد عليها واكتب .نص',
    category: 'ai',

    async run({ sock, message, args, reply, prefix }) {
        const q = quotedOf(sock, message);
        const mime = q?.mimetype || '';
        if (!q || !/audio|video/.test(mime)) {
            return reply(`🎙️ رد على رسالة صوتية (فويس أو مقطع صوت أو فيديو) واكتب ${prefix}نص`);
        }
        const react = reactor(sock, message);
        await react('⌛');
        try {
            const buffer = await q.download();
            if (!buffer?.length) throw new AiError('معرفتش أحمّل الصوت.');
            if (buffer.length > 24 * 1024 * 1024) throw new AiError('الملف كبير (أكتر من 24 ميجا).');

            const lang = /^[a-z]{2}$/i.test(args[0] || '') ? args[0].toLowerCase() : undefined;
            const text = await groqTranscribe(buffer, extOf(mime), lang);
            if (!text) {
                await react('❌');
                return reply('🤷 ما سمعتش كلام واضح في الصوت ده.');
            }
            await react('✅');
            return reply(`📝 *النص:*\n\n${text}\n\n> SOFA BOT`);
        } catch (e) {
            await react('❌');
            return reply(`❌ ${e instanceof AiError ? e.message : 'فشل التفريغ: ' + e.message}`);
        }
    }
};
