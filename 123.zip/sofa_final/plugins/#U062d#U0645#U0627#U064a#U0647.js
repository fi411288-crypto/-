import fs from 'fs';
import path from 'path';
import { getAdminFlags } from '../lib/compat.js';

const dir = path.join(process.cwd(), 'data');
const file = path.join(dir, 'monitorState.json');

const load = () => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; } };
const save = (d) => { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(file, JSON.stringify(d, null, 2)); };

export default {
    name: 'منع',
    aliases: ['منع_الروابط'],
    description: 'تشغيل/إيقاف مراقبة الروابط وطرد من يرسل 3 روابط',
    category: 'الحماية',

    async run({ sock, message, args, reply, isGroup, isDeveloper }) {
        if (!isGroup) return reply('❌ الأمر ده للمجموعات فقط.');
        try {
            const jid = message.key.remoteJid;
            const metadata = await sock.groupMetadata(jid);
            const { isAdmin, isBotAdmin } = getAdminFlags(sock, message, metadata);
            if (!isAdmin && !isDeveloper) return reply('❌ الأمر ده للمشرفين فقط.');
            if (!isBotAdmin) return reply('❌ لازم أكون مشرف في المجموعة.');

            const state = load();
            const arg = (args[0] || '').toLowerCase();
            if (['تشغيل', 'on', 'فتح'].includes(arg)) state[jid] = true;
            else if (['ايقاف', 'إيقاف', 'off', 'قفل'].includes(arg)) state[jid] = false;
            else state[jid] = !state[jid];
            save(state);
            return reply(state[jid]
                ? '✅ تم تشغيل مراقبة الروابط: أي عضو يرسل 3 روابط هيتطرد.'
                : '⛔ تم إيقاف مراقبة الروابط.');
        } catch (e) {
            return reply(`❌ حدث خطأ: ${e.message}`);
        }
    }
};
