import { makeNsfwCommand } from '../lib/nsfw.js';
// غيّر ENDPOINT لو الـ API وقع
export default makeNsfwCommand({ name: 'cum', title: 'Cum', emoji: '💦', endpoint: 'https://prexzyapis.com/nsfw/anal', usage: '.cum' });
