import axios from 'axios';
import { quotedOf, reactor } from '../lib/groq.js';

// بيعمل صورة QR من نص أو رابط عن طريق api.qrserver.com (مجاني، من غير مفتاح)
export default {
    name: 'qr',
    aliases: ['كيوار', 'qrcode', 'باركود'],
    description: 'إنشاء QR Code من نص أو رابط',
    usage: '.qr https://example.com',
    category: 'tools',
    async run({ sock, message, text, reply, prefix }) {
        const react = reactor(sock, message);
        const data = ((text || '').trim() || (quotedOf(sock, message)?.text || '').trim());
        if (!data) return reply(`📱 اكتب النص أو الرابط:\n${prefix}qr https://example.com\nأو رد على رسالة واكتب ${prefix}qr`);
        if (data.length > 900) return reply('❌ النص طويل أوي (الحد 900 حرف).');

        await react('⌛');
        try {
            const url = `https://api.qrserver.com/v1/create-qr-code/?size=600x600&margin=10&format=png&data=${encodeURIComponent(data)}`;
            const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 30000 });
            await sock.sendMessage(message.key.remoteJid, {
                image: Buffer.from(res.data),
                caption: `📱 *QR Code*\n\n${data.length > 200 ? data.slice(0, 200) + '…' : data}\n\n> SOFA BOT`
            }, { quoted: message });
            await react('✅');
        } catch (e) {
            await react('❌');
            return reply(`❌ معرفتش أعمل الـ QR: ${e.message}`);
        }
    }
};
