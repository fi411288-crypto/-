import { get } from '../lib/xtools.js';

const W = (c) => c === 0 ? ['☀️', 'صافي'] : c <= 2 ? ['🌤️', 'غيم خفيف'] : c === 3 ? ['☁️', 'غائم'] : c <= 48 ? ['🌫️', 'ضباب'] : c <= 57 ? ['🌦️', 'رذاذ'] : c <= 67 ? ['🌧️', 'مطر'] : c <= 77 ? ['❄️', 'ثلج'] : c <= 82 ? ['🌧️', 'زخات مطر'] : c <= 86 ? ['🌨️', 'زخات ثلج'] : ['⛈️', 'عاصفة رعدية'];
const DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

export default {
    name: 'طقس',
    aliases: ['weather', 'الطقس', 'جو'],
    description: 'طقس أي مدينة',
    usage: '.طقس القاهرة',
    category: 'tools',
    async run({ text, reply }) {
        const q = text.trim() || 'القاهرة';
        try {
            const geo = (await get('https://geocoding-api.open-meteo.com/v1/search', { name: q, count: 1, language: 'ar' })).results?.[0];
            if (!geo) return reply(`❌ مالقيتش مدينة اسمها «${q}».`);
            const d = await get('https://api.open-meteo.com/v1/forecast', {
                latitude: geo.latitude, longitude: geo.longitude, timezone: 'auto', forecast_days: 4,
                current: 'temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m',
                daily: 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max'
            });
            const c = d.current, [ic, ds] = W(c.weather_code);
            const days = d.daily.time.slice(1).map((t, i) => {
                const j = i + 1;
                return `${W(d.daily.weather_code[j])[0]} ${DAYS[new Date(t).getUTCDay()]}: ${Math.round(d.daily.temperature_2m_min[j])}° – ${Math.round(d.daily.temperature_2m_max[j])}° 🌧️${d.daily.precipitation_probability_max[j] ?? 0}%`;
            });
            return reply(`${ic} *طقس ${geo.name}${geo.country ? ` — ${geo.country}` : ''}*\n\n🌡️ الحرارة: *${Math.round(c.temperature_2m)}°م* (تحس بـ ${Math.round(c.apparent_temperature)}°)\n📝 الحالة: ${ds}\n💧 الرطوبة: ${c.relative_humidity_2m}%\n💨 الرياح: ${Math.round(c.wind_speed_10m)} كم/س\n⬆️ النهاردة: ${Math.round(d.daily.temperature_2m_min[0])}° – ${Math.round(d.daily.temperature_2m_max[0])}°\n\n📅 *الأيام الجاية:*\n${days.join('\n')}\n\n> SOFA BOT`);
        } catch { return reply('❌ معرفتش أجيب الطقس دلوقتي، جرب بعد شوية.'); }
    }
};
