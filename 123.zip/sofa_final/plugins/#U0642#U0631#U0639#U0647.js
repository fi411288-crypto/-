import { winnerCard } from '../lib/goldcards.js';
import { getMetadata } from '../lib/compat.js';
import { getGroup } from '../lib/community.js';
import { digits } from '../lib/xtools.js';

export default {
    name: 'قرعة',
    aliases: ['سحب-فائز', 'draw', 'قرعه'],
    description: 'سحب فائز عشوائي من الجروب ويطلع كارت باسمه',
    usage: '.قرعة [الجايزة] | .قرعة -ادمن (من غير المشرفين)',
    category: 'fun',
    group: true,
    async run({ sock, message, text, reply, bot }) {
        const jid = message.key.remoteJid;
        const meta = await getMetadata(sock, jid);
        const noAdmin = /(^|\s)-(ادمن|مشرف)/.test(text);
        const prize = text.replace(/(^|\s)-(ادمن|مشرف)/g, '').trim();
        const botIds = [sock.user?.id, sock.user?.lid].map(digits);
        const pool = meta.participants.filter((p) => !(noAdmin && p.admin) && ![p.id, p.lid, p.phoneNumber].map(digits).some((d) => botIds.includes(d)));
        if (!pool.length) return reply('❌ مفيش أعضاء أسحب منهم.');
        const w = pool[Math.floor(Math.random() * pool.length)];
        const { g } = getGroup(bot?.phone, jid);
        const wids = [w.id, w.lid, w.phoneNumber].filter(Boolean).map(digits);
        const known = Object.entries(g.users).find(([id, u]) => wids.includes(id) || wids.includes(digits(u.jid)));
        const name = known?.[1]?.name || digits(w.id);
        const img = await winnerCard({ name, group: meta.subject, count: pool.length, prize });
        const cap = `🎉 *مبروك الفائز!*\n\n🏆 @${digits(w.id)}${prize ? `\n🎁 الجايزة: *${prize}*` : ''}\n👥 من ${pool.length} مشارك\n\n> SOFA BOT`;
        const mentions = [w.id];
        return reply(img ? { image: img, caption: cap, mentions } : { text: cap, mentions });
    }
};
