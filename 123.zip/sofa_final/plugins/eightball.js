const ANS = [
    'نعم بكل تأكيد ✅', 'لا 🚫', 'ممكن 🤔', 'مستحيل 😅',
    'اسأل تاني بعدين 🌙', 'الإشارات تقول نعم ✨', 'مش متأكد 😶',
    'اعتمد على نفسك 💪', 'فرصة ضعيفة 📉', 'فرصة قوية 📈',
    'بلاش تفكر كتير 😌', 'خليك واقعي 🧠'
];
export default {
    name: 'كرة',
    aliases: ['8ball', 'eightball', 'هل'],
    description: 'جاوب على سؤال بنعم/لا بشكل عشوائي',
    category: 'fun',
    usage: '.كرة هل هنجح؟',
    async run({ text, reply }) {
        if (!(text || '').trim()) return reply('❓ اسأل سؤال\nمثال: .كرة هل هسافر قريب؟');
        const a = ANS[Math.floor(Math.random() * ANS.length)];
        return reply(`╭─❏ 「 🎱 كرة السحر 」\n│ سؤالك: ${(text || '').trim()}\n│ الجواب: *${a}*\n╰───────────────`);
    }
};
