// 🛠️ للمطور: تصفير مهام المتابعة لعضو عشان يقدر يستلم تاني — SOFA BOT
import { targetJid, digits } from '../lib/xtools.js';
import { numberOfJid, toEnDigits } from '../lib/shop.js';
import { resolveNumber } from '../lib/economy.js';
import { isDevSender } from '../lib/devAuth.js';
import { resetTasks } from '../lib/tgTasks.js';

export default [{
    name: 'تصفير_مهام',
    aliases: ['تصفير-مهام', 'resettasks'],
    category: 'dev',
    description: 'للمطور: تصفير مهام المتابعة لعضو (منشن / ريبلاي / رقم)',
    usage: '.تصفير_مهام @حد',
    cooldown: 1500,
    async run(ctx) {
        const { sock, m, message, args, reply } = ctx;
        if (!(await isDevSender(ctx))) return reply('❌ الأمر ده للمطور فقط.');
        const msg = m || message;
        const t = targetJid(msg);
        const typed = args.map((a) => toEnDigits(a).replace(/\D/g, '')).find((a) => a.length >= 8);
        const number = t ? await numberOfJid(sock, t) : (typed || await resolveNumber(sock, msg));
        if (!number) return reply('❌ حدد العضو (منشن / ريبلاي / رقمه).');
        return reply(resetTasks(number) ? `✅ اتصفّرت مهام *${number}* — يقدر يستلمهم تاني.` : `ℹ️ *${number}* ماخلّصش أي مهمة أصلاً.`);
    }
}];
