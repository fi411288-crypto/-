import { groqChat, MODELS, quotedOf, imageOf, reactor, AiError } from '../lib/groq.js';

const SYSTEM = 'أنت مساعد ذكي اسمه SOFA BOT. جاوب بالعربية بلهجة بسيطة ومفهومة إلا لو السائل كتب بلغة تانية. خلي الإجابة مختصرة ومباشرة ومناسبة للقراءة على الموبايل، ومن غير مقدمات.';

export default {
    name: 'سؤال',
    aliases: ['اسأل', 'ask'],
    description: 'اسأل أي سؤال، أو رد على صورة واسأل عنها',
    category: 'ai',

    async run({ sock, message, text, reply, prefix }) {
        const react = reactor(sock, message);
        const q = (text || '').trim();
        const quotedText = quotedOf(sock, message)?.text?.trim();

        let image = null;
        try { image = await imageOf(sock, message); }
        catch (e) { return reply(`❌ ${e.message}`); }

        if (!q && !image) {
            return reply(`❓ اكتب سؤالك: ${prefix}سؤال إيه عاصمة اليابان؟\n🖼️ أو رد على صورة واكتب ${prefix}سؤال ده ايه؟`);
        }

        await react('⌛');
        try {
            let answer;
            if (image) {
                answer = await groqChat({
                    model: MODELS.vision,
                    messages: [
                        { role: 'system', content: SYSTEM },
                        { role: 'user', content: [
                            { type: 'text', text: q || 'اشرح الصورة دي بالتفصيل.' },
                            { type: 'image_url', image_url: { url: image } }
                        ] }
                    ]
                });
            } else {
                const content = quotedText ? `الرسالة المردود عليها:\n${quotedText}\n\nالسؤال: ${q}` : q;
                answer = await groqChat({ effort: 'high', max: 4096, messages: [{ role: 'system', content: SYSTEM }, { role: 'user', content }] });
            }
            await react('✅');
            return reply(`${answer}\n\n> SOFA BOT`);
        } catch (e) {
            await react('❌');
            return reply(`❌ ${e instanceof AiError ? e.message : 'حصل خطأ: ' + e.message}`);
        }
    }
};
