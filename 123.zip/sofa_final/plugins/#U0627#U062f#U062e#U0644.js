import { parseChannelLink, getTargetSessions, resolveChannel, sleep, rand, errText } from '../lib/channels.js';

// .ادخل https://whatsapp.com/channel/<كود>
// كل الأرقام المربوطة (المتصلة) بتعمل متابعة للقناة.
export default {
    name: 'ادخل',
    aliases: ['follow_all'],
    description: 'كل الأرقام المربوطة تدخل (تتابع) قناة: .ادخل <لينك القناة>',
    usage: '.ادخل https://whatsapp.com/channel/xxxx',
    category: 'tools',
    developer: true,
    run: async (context) => {
        const { client, m, text } = context;
        const send = (t) => client.sendMessage(m.chat, { text: t }, { quoted: m });
        const react = (e) => client.sendMessage(m.chat, { react: { text: e, key: m.reactKey } }).catch(() => {});

        const link = parseChannelLink(text);
        if (!link) {
            await react('❌');
            return send('╭─❏ 「 ادخل 」\n│ الاستخدام:\n│ .ادخل https://whatsapp.com/channel/كود\n╰───────────────');
        }

        const sessions = getTargetSessions(context);
        if (!sessions.length) { await react('❌'); return send('❌ مفيش أرقام متصلة دلوقتي.'); }

        await react('⌛');
        let jid, name;
        try {
            ({ jid, name } = await resolveChannel(sessions[0].sock, link.code));
        } catch (e) {
            await react('❌');
            return send(`❌ مقدرتش أوصل للقناة: ${errText(e)}`);
        }

        let ok = 0;
        const fails = [];
        for (const s of sessions) {
            try {
                await s.sock.newsletterFollow(jid);
                ok++;
            } catch (e) {
                const msg = errText(e);
                // لو الرقم متابع القناة قبل كده نعتبره نجاح
                if (/already|subscribed|exist|409/i.test(msg)) ok++;
                else fails.push(`${s.phone}: ${msg}`);
            }
            await sleep(rand(800, 2000));
        }

        await react(ok ? '✅' : '❌');
        let msg = `╭─❏ 「 ادخل 」\n│ القناة: ${name || link.code}\n│ ✅ دخل: ${ok} رقم\n│ ❌ فشل: ${fails.length} رقم\n╰───────────────`;
        if (fails.length) msg += `\n\n${fails.slice(0, 10).map((f) => `• ${f}`).join('\n')}`;
        return send(msg);
    }
};
