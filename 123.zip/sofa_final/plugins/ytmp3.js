import { ytCommand } from '../lib/youtube.js';

export default {
    name: 'ytmp3',
    aliases: ['ytaudio'],
    description: 'تحميل صوت من يوتيوب (رابط أو اسم)',
    category: 'downloader',
    run: (ctx) => ytCommand(ctx, 'audio', 'ytmp3')
};
