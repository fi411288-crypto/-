// 🎂 أعياد الميلاد: سجّل ميلادك والبوت يبارك لك في الجروب تلقائي الساعة 9 الصبح (القاهرة) + هدية كوين — SOFA BOT
import { store, job, sockOf, hhmm, dayIn, mins } from '../lib/xtools.js';
import { resolveNumber, addRewards } from '../lib/economy.js';

const AT = 9 * 60, GIFT_COIN = 1000, GIFT_XP = 100;
const db = () => store('birthdays', {}).data;
const save = () => store('birthdays').save();
const ph = (p) => String(p || 'main').replace(/\D/g, '') || 'main';
const toEn = (s) => String(s || '').replace(/[٠-٩]/g, (d) => d.charCodeAt(0) - 1632);
const parts = (day = dayIn()) => { const [y, m, d] = day.split('-').map(Number); return { y, m, d }; };
const leap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
const dim = (m, y = 2024) => [31, leap(y) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1];
const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

// عدد الأيام لحد الميلاد الجاي (0 = النهارده)
function daysLeft(b, t = parts()) {
    const day = (y) => (b.m === 2 && b.d === 29 && !leap(y) ? 28 : b.d);
    let next = Date.UTC(t.y, b.m - 1, day(t.y));
    const now = Date.UTC(t.y, t.m - 1, t.d);
    if (next < now) next = Date.UTC(t.y + 1, b.m - 1, day(t.y + 1));
    return Math.round((next - now) / 864e5);
}

job('birthdays', async () => {
    const now = mins(hhmm()), today = dayIn(), t = parts(today);
    if (now < AT || now >= AT + 60) return;
    for (const [key, e] of Object.entries(db())) {
        if (e.last === today) continue;
        const list = Object.entries(e.users || {}).filter(([, b]) => daysLeft(b, t) === 0);
        if (!list.length) { e.last = today; save(); continue; }
        const sock = sockOf(e.phone);
        if (!sock) continue;
        const lines = list.map(([num, b]) => `🎈 @${num}${b.y ? ` — ${t.y - b.y} سنة` : ''}`);
        for (const [num] of list) { try { addRewards(num, GIFT_XP, GIFT_COIN); } catch {} }
        try {
            await sock.sendMessage(e.jid, {
                text: `🎂 *SOFA • BIRTHDAY* 🎉\n\nالنهارده عيد ميلاد:\n${lines.join('\n')}\n\nكل سنة وانتم طيبين وبألف خير! 🥳💐\n🎁 هدية: \`${GIFT_COIN}\` كوين + ${GIFT_XP} XP (للمسجّلين في البوت)\n\n> SOFA BOT`,
                mentions: list.map(([num, b]) => b.jid || `${num}@s.whatsapp.net`)
            });
            e.last = today; save();
        } catch {}
    }
}, 30000);

export default [{
    name: 'عيد_ميلاد',
    aliases: ['ميلادي', 'birthday', 'عيد-ميلاد', 'اعياد_الميلاد'],
    category: 'tools',
    group: true,
    description: 'سجّل عيد ميلادك والبوت يبارك لك تلقائي في الجروب',
    usage: '.عيد_ميلاد 25/10 | .عيد_ميلاد 25/10/2000 | .عيد_ميلاد قائمة | .عيد_ميلاد مسح',
    cooldown: 3000,
    async run({ sock, m, message, args, reply, bot, prefix = '.' }) {
        const msg = m || message, jid = msg.key.remoteJid;
        const number = await resolveNumber(sock, msg);
        if (!number) return reply('❌ مقدرتش أحدد رقمك. جرب تاني.');
        const key = `${ph(bot?.phone)}:${jid}`;
        const g = () => (db()[key] ||= { phone: ph(bot?.phone), jid, users: {}, last: '' });
        const a = toEn(args.join(' ')).trim();

        if (['مسح', 'حذف', 'الغاء'].includes(a)) {
            if (!db()[key]?.users?.[number]) return reply('ℹ️ مفيش عيد ميلاد متسجّل ليك.');
            delete db()[key].users[number]; save();
            return reply('🗑️ اتمسح عيد ميلادك.');
        }
        if (['قائمة', 'قايمة', 'list'].includes(a)) {
            const rows = Object.entries(db()[key]?.users || {}).map(([num, b]) => ({ num, b, left: daysLeft(b) })).sort((x, y) => x.left - y.left).slice(0, 10);
            if (!rows.length) return reply(`📭 محدش سجّل ميلاده هنا لسه.\nسجّل بـ: *${prefix}عيد_ميلاد 25/10*`);
            return reply({
                text: `🎂 *أقرب أعياد الميلاد*\n\n${rows.map((r) => `${r.left === 0 ? '🎉' : '🎈'} @${r.num} — ${r.b.d} ${MONTHS[r.b.m - 1]} ${r.left === 0 ? '(النهارده!)' : `(بعد ${r.left} يوم)`}`).join('\n')}\n\n> SOFA BOT`,
                mentions: rows.map((r) => r.b.jid || `${r.num}@s.whatsapp.net`)
            });
        }
        const mt = /^(\d{1,2})\s*[\/\-.]\s*(\d{1,2})(?:\s*[\/\-.]\s*(\d{4}))?$/.exec(a);
        if (!a) {
            const b = db()[key]?.users?.[number];
            return reply(b
                ? `🎂 ميلادك المسجّل: *${b.d} ${MONTHS[b.m - 1]}*${b.y ? ` ${b.y}` : ''}\n⏳ باقي *${daysLeft(b)}* يوم\n\nللتغيير: ${prefix}عيد_ميلاد 25/10\nللمسح: ${prefix}عيد_ميلاد مسح`
                : `🎂 *عيد الميلاد*\n\nسجّل ميلادك والبوت يبارك لك تلقائي ويديك هدية كوين 🎁\n\n${prefix}عيد_ميلاد 25/10\n${prefix}عيد_ميلاد 25/10/2000 (عشان يحسب سنك)\n${prefix}عيد_ميلاد قائمة`);
        }
        if (!mt) return reply(`❌ اكتب التاريخ كده: *${prefix}عيد_ميلاد 25/10* (يوم/شهر)`);
        const d = +mt[1], mo = +mt[2], y = mt[3] ? +mt[3] : 0;
        const thisYear = parts().y;
        if (mo < 1 || mo > 12 || d < 1 || d > dim(mo, y || 2024) || (y && (y < 1940 || y > thisYear - 5))) return reply('❌ التاريخ غلط، راجعه.');
        g().users[number] = { d, m: mo, y: y || 0, jid: msg.key.participant || msg.key.remoteJid };
        save();
        const left = daysLeft(g().users[number]);
        return reply(`✅ *اتسجّل عيد ميلادك!*\n\n🎂 ${d} ${MONTHS[mo - 1]}${y ? ` ${y}` : ''}\n${left === 0 ? '🎉 النهارده يومك! كل سنة وانت طيب!' : `⏳ باقي ${left} يوم`}\n\nالبوت هيبارك لك في الجروب الساعة 9 الصبح 🎁`);
    }
}];
