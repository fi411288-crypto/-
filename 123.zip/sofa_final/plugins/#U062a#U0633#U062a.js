import fs from 'fs';
import path from 'path';
import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';

// ====== إعدادات الأمر (عدّل من هنا) ======
const CAPTION = '*👑 SOFA BOT VIP SYSTEM*\n_*Dev : SOFA*_ ☆\n_*SOFA BOT VIP is now working*_\n🌸 WarmGPT • VIP Edition';
const DEV_LINK = 'https://t.me/F_1_D_L_1';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbE0Vqa5PO0tM4fqZD1E';
const MAIN_VIDEO = 'test-video.mp4';     // الفيديو اللي مع الرسالة والأزرار
const CIRCLE_VIDEO = 'test-circle.mp4';  // الفيديو الدايري
// =========================================

const mediaPath = (name) => path.join(process.cwd(), 'media', name);

function urlButton(text, url) {
    return {
        name: 'cta_url',
        buttonParamsJson: JSON.stringify({ display_text: text, url, merchant_url: url })
    };
}

export default {
    name: 'تست',
    aliases: ['test'],
    description: 'عرض رسالة SOFA BOT SYSTEM بالفيديو والأزرار',
    category: 'general',

    async run({ sock, message, reply }) {
        const jid = message.key.remoteJid;

        // تفاعل فوري على رسالة .تست
        await sock.sendMessage(jid, { react: { text: '💠', key: message.key } }).catch(() => {});

        const mainFile = mediaPath(MAIN_VIDEO);
        const circleFile = mediaPath(CIRCLE_VIDEO);

        if (!fs.existsSync(mainFile)) {
            return reply(`❌ مفيش فيديو في فولدر media.\nحط فيديو باسم: ${MAIN_VIDEO}`);
        }

        const video = fs.readFileSync(mainFile);

        // 1) رسالة الفيديو + النص + الأزرار
        try {
            const media = await prepareWAMessageMedia({ video }, { upload: sock.waUploadToServer });
            const IM = proto.Message.InteractiveMessage;
            const interactiveMessage = IM.fromObject({
                body: IM.Body.fromObject({ text: CAPTION }),
                footer: IM.Footer.fromObject({ text: '' }),
                header: IM.Header.fromObject({ title: '', hasMediaAttachment: true, videoMessage: media.videoMessage }),
                nativeFlowMessage: IM.NativeFlowMessage.fromObject({
                    buttons: [urlButton('Dev', DEV_LINK), urlButton('Channel', CHANNEL_LINK)]
                })
            });
            const msg = generateWAMessageFromContent(jid, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                        interactiveMessage
                    }
                }
            }, { userJid: sock.user?.id, quoted: message });
            await sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
        } catch (e) {
            console.error('[تست] فشل إرسال الأزرار، إرسال بديل:', e.message);
            // بديل: فيديو عادي والروابط في النص
            await sock.sendMessage(jid, {
                video,
                caption: `${CAPTION}\n\n💬 Dev: ${DEV_LINK}\n📢 Channel: ${CHANNEL_LINK}`
            }, { quoted: message });
        }

        // 2) الفيديو الدايري (اختياري)
        if (fs.existsSync(circleFile)) {
            try {
                await sock.sendMessage(jid, { video: fs.readFileSync(circleFile), ptv: true, mimetype: 'video/mp4' });
            } catch (e) {
                console.error('[تست] فشل إرسال الفيديو الدايري:', e.message);
            }
        }
    }
};
