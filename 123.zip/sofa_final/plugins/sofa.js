// ✅ .سوفا — رسالة "البوت شغال" + أزرار روابط المطور (نفس أزرار .اوامر) — SOFA BOT
import { generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';

const CHANNEL_URL = 'https://whatsapp.com/channel/0029VbE0Vqa5PO0tM4fqZD1E';
const LINKS = [
    { text: '🧑🏻‍💻 المطور', url: 'https://t.me/F_1_D_L_1' },
    { text: '🤖 بوت سوفا', url: 'https://t.me/Sofa48755_Bot' },
    { text: '🌌 قناة تليجرام', url: 'https://t.me/sofa_bot1' },
    { text: '📢 قناة واتساب', url: CHANNEL_URL },
    { text: '🎵 تيك توك', url: 'https://www.tiktok.com/@fadl.ibrahem1' }
];
const BODY = '*SOFA BOT IS READY* ✅';

export default {
    name: 'سوفا',
    description: 'يظهر ان البوت موجود (مع أزرار روابط المطور)',
    usage: '.سوفا',
    async run({ sock, message }) {
        const jid = message.key.remoteJid;
        try {
            const IM = proto.Message.InteractiveMessage;
            const interactiveMessage = IM.fromObject({
                body: IM.Body.fromObject({ text: BODY }),
                footer: IM.Footer.fromObject({ text: '𝑺𝑶𝑭𝑨 BOT • POWERED BY 𝑺𝑶𝑭𝑨' }),
                header: IM.Header.fromObject({ title: '', hasMediaAttachment: false }),
                nativeFlowMessage: IM.NativeFlowMessage.fromObject({
                    buttons: LINKS.map((l) => ({ name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: l.text, url: l.url, merchant_url: l.url }) }))
                })
            });
            const msg = generateWAMessageFromContent(jid, {
                viewOnceMessage: { message: { messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 }, interactiveMessage } }
            }, { userJid: sock.user?.id, quoted: message });
            await sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
        } catch (err) {
            console.error('[sofa] buttons failed:', err.message);
            await sock.sendMessage(jid, { text: `${BODY}\n\n` + LINKS.map((l) => `${l.text}: ${l.url}`).join('\n') }, { quoted: message }).catch(() => {});
        }
    }
};
