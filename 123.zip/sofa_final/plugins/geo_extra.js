// 15 أمر إضافي بدون أي API خارجي:
// الألقاب: لقب، لقبي، لقبه، متوفر، حذف_لقب، الالقاب
// الجروب: مخفي، زواج
// تسلية وأدوات: اختار، احسب، صراحه، لو_خيروك، نسبه، حظي
import { getGroup, normAr, senderIds } from '../lib/community.js';
import { getMetadata, getAdminFlags } from '../lib/compat.js';

const pickOf = (a) => a[Math.floor(Math.random() * a.length)];
const dig = (j) => String(j || '').split('@')[0].split(':')[0].replace(/\D/g, '');
const isGroupJid = (j) => String(j).endsWith('@g.us');
const ctxOf = (message) => message.message?.extendedTextMessage?.contextInfo || {};
const targetsOf = (message) => {
    const c = ctxOf(message);
    const list = [...(c.mentionedJid || [])];
    if (!list.length && c.participant) list.push(c.participant);
    return list;
};

async function adminCheck(sock, message, isDeveloper) {
    if (isDeveloper) return true;
    try { return getAdminFlags(sock, message, await getMetadata(sock, message.key.remoteJid)).isAdmin; } catch { return false; }
}

// هاش ثابت (نفس المدخلات = نفس النتيجة)
function hash(str) {
    let h = 2166136261;
    for (const ch of String(str)) { h ^= ch.codePointAt(0); h = Math.imul(h, 16777619); }
    return h >>> 0;
}

const SARAHA = [
    'إيه أكتر حاجة بتندم عليها؟', 'مين أكتر شخص في الجروب بتحب كلامه؟', 'آخر مرة عيطت فيها كانت إمتى وليه؟',
    'لو ينفع تغيّر حاجة واحدة في شخصيتك هتكون إيه؟', 'إيه أغرب عادة عندك؟', 'عمرك كدبت على حد قريب منك؟ في إيه؟',
    'مين الشخص اللي نفسك تصالحه؟', 'إيه أكتر حاجة بتخوفك؟', 'لو معاك مليون جنيه دلوقتي هتعمل بيهم إيه؟',
    'إيه أكتر موقف محرج حصلك؟', 'بتحب مين أكتر في عيلتك؟', 'إيه الحاجة اللي مستحيل تسامح فيها؟',
    'آخر حاجة بحثت عليها في جوجل إيه؟', 'لو هتسافر بكرة هتروح فين؟', 'إيه أحلى ذكرى عندك؟',
    'عندك سر لسه محدش يعرفه؟ (قول نوعه من غير تفاصيل)', 'إيه رأيك في صاحبك اللي جنبك في الشات؟', 'إيه الحاجة اللي بتتفاخر بيها؟',
    'لو اتحولت لحيوان هتبقى إيه؟', 'إيه أول حاجة بتعملها لما تصحى؟', 'مين أكتر واحد بيضحكك؟',
    'إيه أسوأ هدية جاتلك؟', 'لو اتحبست في أوضة مع حد من الجروب، تختار مين؟', 'إيه أكتر لعبة أو أنمي مدمنه؟', 'إيه الحاجة اللي بتعملها وإنت لوحدك بس؟'
];
const KHAYROOK = [
    'تعيش من غير موبايل شهر ولا من غير أكل بره شهر؟', 'تبقى غني ومحدش بيحبك ولا فقير وكل الناس بتحبك؟',
    'تطير ولا تبقى شفاف؟', 'تعرف مستقبلك كله ولا تعرف ماضي كل الناس؟', 'تنام 3 ساعات وتبقى نشيط ولا تنام 12 ساعة وتبقى تعبان؟',
    'تاكل أكلة واحدة طول عمرك ولا كل يوم أكلة جديدة بس بشعة؟', 'تسافر الماضي ولا المستقبل؟',
    'تفقد الذاكرة ولا تفقد حاسة الشم والتذوق؟', 'تعيش في صحرا مع كل اللي بتحبهم ولا في مدينة لوحدك؟',
    'تفضل صديق واحد وفي ولا عشرة أصحاب عاديين؟', 'تتكلم كل لغات العالم ولا تعزف كل الآلات؟',
    'يبقى عندك فلوس بلا حدود ومفيش وقت فاضي ولا وقت فاضي طول الوقت وفلوس قليلة؟', 'ماتسمعش صوتك أبداً ولا ماتشوفش وشك في المراية؟',
    'تعيش من غير إنترنت ولا من غير كهربا؟', 'كل الناس تسمع أفكارك ولا إنت تسمع أفكار الناس؟',
    'تتجوز حد بتحبه وفقير ولا حد مش بتحبه وغني؟', 'تبقى أشهر واحد في العالم ولا أذكى واحد؟', 'تعيش 200 سنة وحيد ولا 60 سنة مع اللي بتحبهم؟'
];
const MARRY = ['💍 مبروك! عقد القران تم بحضور الجروب كله', '👰🤵 الفرح الليلة والكل مدعو', '💒 اتجوزوا في الجروب وعيشوا في سعادة وهنا'];

export default [
    // ===================== الألقاب =====================
    {
        name: 'لقب', aliases: ['حجز_لقب', 'nick'], description: 'احجز لقب ليك في الجروب: .لقب الأسطورة', category: 'fun',
        async run({ message, reply, args, bot, prefix }) {
            const jid = message.key.remoteJid;
            if (!isGroupJid(jid)) return reply('❌ الألقاب للجروبات بس.');
            const uid = senderIds(message)[0];
            const name = args.join(' ').trim();
            if (!name) return reply(`🏷️ الاستخدام: ${prefix}لقب <اللقب>\nمثال: ${prefix}لقب الأسطورة\n(اللقب مينفعش يتكرر في نفس الجروب)`);
            if (name.length > 25 || /https?:|www\.|@/i.test(name)) return reply('❌ اللقب لازم يبقى أقل من 25 حرف ومن غير روابط أو @.');
            const { g, save } = getGroup(bot?.phone, jid);
            g.nicks ||= {};
            const key = normAr(name);
            if (!key) return reply('❌ اللقب غير صالح.');
            const owner = Object.entries(g.nicks).find(([, v]) => normAr(v) === key);
            if (owner && owner[0] !== uid) return reply(`❌ اللقب "${name}" محجوز لحد تاني (@${owner[0]}).`);
            g.nicks[uid] = name; save();
            return reply(`✅ تم حجز لقبك: *${name}* 🏷️`);
        }
    },
    {
        name: 'لقبي', aliases: ['mynickname'], description: 'اعرف لقبك في الجروب: .لقبي', category: 'fun',
        async run({ message, reply, bot, prefix }) {
            const jid = message.key.remoteJid;
            if (!isGroupJid(jid)) return reply('❌ الألقاب للجروبات بس.');
            const { g } = getGroup(bot?.phone, jid);
            const nick = g.nicks?.[senderIds(message)[0]];
            return reply(nick ? `🏷️ لقبك: *${nick}*` : `ملكش لقب لسه. احجز لقب بـ ${prefix}لقب <اللقب>`);
        }
    },
    {
        name: 'لقبه', aliases: ['lakabe'], description: 'اعرف لقب عضو: .لقبه @منشن', category: 'fun',
        async run({ sock, message, reply, bot }) {
            const jid = message.key.remoteJid;
            if (!isGroupJid(jid)) return reply('❌ الألقاب للجروبات بس.');
            const t = targetsOf(message)[0];
            if (!t) return reply('❌ منشن العضو أو رد على رسالته.');
            const { g } = getGroup(bot?.phone, jid);
            const nick = g.nicks?.[dig(t)];
            return sock.sendMessage(jid, { text: nick ? `🏷️ لقب @${dig(t)}: *${nick}*` : `@${dig(t)} ملوش لقب لسه.`, mentions: [t] }, { quoted: message });
        }
    },
    {
        name: 'متوفر', aliases: ['available'], description: 'تأكد إن لقب متاح: .متوفر الأسطورة', category: 'fun',
        async run({ message, reply, args, bot, prefix }) {
            const jid = message.key.remoteJid;
            if (!isGroupJid(jid)) return reply('❌ الألقاب للجروبات بس.');
            const name = args.join(' ').trim();
            if (!name) return reply(`الاستخدام: ${prefix}متوفر <اللقب>`);
            const { g } = getGroup(bot?.phone, jid);
            const key = normAr(name);
            const owner = Object.entries(g.nicks || {}).find(([, v]) => normAr(v) === key);
            return reply(owner ? `❌ اللقب "${name}" محجوز (@${owner[0]}).` : `✅ اللقب "${name}" متاح! احجزه بـ ${prefix}لقب ${name}`);
        }
    },
    {
        name: 'حذف_لقب', aliases: ['delnick', 'مسح_لقب'], description: 'احذف لقبك (أو لقب عضو لو إنت أدمن)', category: 'fun',
        async run({ sock, message, reply, bot, isDeveloper }) {
            const jid = message.key.remoteJid;
            if (!isGroupJid(jid)) return reply('❌ الألقاب للجروبات بس.');
            const { g, save } = getGroup(bot?.phone, jid);
            g.nicks ||= {};
            const t = targetsOf(message)[0];
            let uid = senderIds(message)[0];
            if (t && dig(t) !== uid) {
                if (!(await adminCheck(sock, message, isDeveloper))) return reply('❌ حذف لقب حد تاني للأدمنز بس.');
                uid = dig(t);
            }
            if (!g.nicks[uid]) return reply('❌ مفيش لقب متسجل.');
            const old = g.nicks[uid]; delete g.nicks[uid]; save();
            return reply(`🗑️ اتحذف اللقب "${old}".`);
        }
    },
    {
        name: 'الالقاب', aliases: ['الألقاب', 'nicks'], description: 'قائمة ألقاب الجروب', category: 'fun',
        async run({ sock, message, reply, bot }) {
            const jid = message.key.remoteJid;
            if (!isGroupJid(jid)) return reply('❌ الألقاب للجروبات بس.');
            const { g } = getGroup(bot?.phone, jid);
            const list = Object.entries(g.nicks || {});
            if (!list.length) return reply('مفيش ألقاب محجوزة لسه.');
            const text = '🏷️ *ألقاب الجروب*\n\n' + list.slice(0, 60).map(([u, n], i) => `${i + 1}. ${n} ← @${u}`).join('\n');
            return sock.sendMessage(jid, { text, mentions: list.slice(0, 60).map(([u]) => `${u}@s.whatsapp.net`) }, { quoted: message });
        }
    },

    // ===================== الجروب =====================
    {
        name: 'مخفي', aliases: ['hidetag', 'notificar'], description: 'منشن مخفي للكل (أدمن): .مخفي رسالتك', category: 'admin',
        async run({ sock, message, reply, args, isDeveloper, prefix }) {
            const jid = message.key.remoteJid;
            if (!isGroupJid(jid)) return reply('❌ الأمر ده للجروبات بس.');
            if (!(await adminCheck(sock, message, isDeveloper))) return reply('❌ الأمر ده للأدمنز بس.');
            const quoted = ctxOf(message).quotedMessage;
            const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || '';
            const text = args.join(' ').trim() || quotedText;
            if (!text) return reply(`الاستخدام: ${prefix}مخفي <الرسالة> (أو رد على رسالة)`);
            const md = await getMetadata(sock, jid);
            const mentions = (md.participants || []).map((p) => p.id || p.jid).filter(Boolean);
            return sock.sendMessage(jid, { text, mentions });
        }
    },
    {
        name: 'زواج', aliases: ['زوجني', 'marry'], description: 'يزوّج عضوين عشوائي في الجروب', category: 'fun',
        async run({ sock, message, reply }) {
            const jid = message.key.remoteJid;
            if (!isGroupJid(jid)) return reply('❌ الأمر ده للجروبات بس.');
            const md = await getMetadata(sock, jid);
            const me = dig(sock.user?.id);
            const ids = (md.participants || []).map((p) => p.id || p.jid).filter((x) => x && dig(x) !== me);
            if (ids.length < 2) return reply('❌ محتاج عضوين على الأقل.');
            const a = pickOf(ids);
            const b = pickOf(ids.filter((x) => x !== a));
            const pct = 50 + Math.floor(Math.random() * 51);
            const text = `${pickOf(MARRY)}\n\n🤵 @${dig(a)}\n👰 @${dig(b)}\n\n❤️ نسبة التوافق: *${pct}%*\n> نتيجة عشوائية للتسلية 😄`;
            return sock.sendMessage(jid, { text, mentions: [a, b] }, { quoted: message });
        }
    },

    // ===================== تسلية وأدوات =====================
    {
        name: 'اختار', aliases: ['choose', 'pick'], description: 'يختار لك واحد: .اختار بيتزا | برجر | كشري', category: 'fun',
        async run({ reply, args, prefix }) {
            const opts = args.join(' ').split(/\s*(?:\||،|,|\s+او\s+|\s+أو\s+)\s*/).map((s) => s.trim()).filter(Boolean);
            if (opts.length < 2) return reply(`🤔 الاستخدام: ${prefix}اختار بيتزا | برجر | كشري`);
            return reply(`🎯 اخترتلك: *${pickOf(opts)}*`);
        }
    },
    {
        name: 'احسب', aliases: ['calc'], description: 'آلة حاسبة: .احسب 5*(3+2)', category: 'tools',
        async run({ reply, args, prefix }) {
            const raw = args.join(' ').trim();
            if (!raw) return reply(`🧮 الاستخدام: ${prefix}احسب 12*(3+4)/2\nالعمليات: + - * / % ^ ( )`);
            const expr = raw.replace(/[×x]/g, '*').replace(/÷/g, '/').replace(/\^/g, '**').replace(/،/g, '.');
            if (expr.length > 80 || !/^[\d+\-*/%().\s]+$/.test(expr)) return reply('❌ معادلة غير صالحة (أرقام وعمليات حسابية بس).');
            try {
                const v = Function(`"use strict"; return (${expr});`)();
                if (typeof v !== 'number' || !Number.isFinite(v)) return reply('❌ الناتج غير معروف (قسمة على صفر؟).');
                return reply(`🧮 ${raw} = *${Math.round(v * 1e10) / 1e10}*`);
            } catch { return reply('❌ المعادلة فيها خطأ.'); }
        }
    },
    {
        name: 'صراحه', aliases: ['صراحة', 'truth'], description: 'سؤال صراحة عشوائي', category: 'fun',
        async run({ reply }) { return reply(`🫣 *صراحة*\n\n${pickOf(SARAHA)}`); }
    },
    {
        name: 'لو_خيروك', aliases: ['خيروك', 'wyr'], description: 'سؤال "لو خيروك" عشوائي', category: 'fun',
        async run({ reply }) { return reply(`🤷 *لو خيروك*\n\n${pickOf(KHAYROOK)}`); }
    },
    {
        name: 'نسبه', aliases: ['نسبة', 'love'], description: 'نسبة التوافق بين اتنين: .نسبه @a @b', category: 'fun',
        async run({ sock, message, reply, args, prefix }) {
            const jid = message.key.remoteJid;
            const t = targetsOf(message);
            const me = senderIds(message)[0] || 'me';
            let a, b, an, bn;
            if (t.length >= 2) { a = dig(t[0]); b = dig(t[1]); an = `@${a}`; bn = `@${b}`; }
            else if (t.length === 1) { a = me; b = dig(t[0]); an = `@${a}`; bn = `@${b}`; }
            else {
                const parts = args.join(' ').split(/\s*[|،,]\s*|\s+و\s+/).filter(Boolean);
                if (parts.length < 2) return reply(`❤️ الاستخدام: ${prefix}نسبه @فلان (أو @فلان @علان)\nأو: ${prefix}نسبه احمد | منى`);
                a = normAr(parts[0]); b = normAr(parts[1]); an = parts[0]; bn = parts[1];
            }
            const pct = hash([a, b].sort().join('+')) % 101;
            const bar = '█'.repeat(Math.round(pct / 10)) + '░'.repeat(10 - Math.round(pct / 10));
            const verdict = pct >= 80 ? 'توأم الروح 💞' : pct >= 60 ? 'ممتاز 😍' : pct >= 40 ? 'ممكن 🙂' : pct >= 20 ? 'ضعيف 😅' : 'بعيد جداً 💔';
            const text = `❤️ *نسبة التوافق*\n\n${an} 💘 ${bn}\n\n${bar} *${pct}%*\n${verdict}\n> للتسلية بس 😄`;
            const mentions = t.slice(0, 2);
            return sock.sendMessage(jid, { text, mentions }, { quoted: message });
        }
    },
    {
        name: 'حظي', aliases: ['luck', 'برجي'], description: 'حظك النهاردة', category: 'fun',
        async run({ reply, message }) {
            const uid = senderIds(message)[0] || 'x';
            const day = new Date().toLocaleDateString('en-CA', { timeZone: 'Africa/Cairo' });
            const h = hash(`${uid}|${day}`);
            const luck = h % 101;
            const colors = ['أحمر ❤️', 'أزرق 💙', 'أخضر 💚', 'أصفر 💛', 'بنفسجي 💜', 'برتقالي 🧡', 'أسود 🖤', 'أبيض 🤍'];
            const msg = luck >= 80 ? 'يوم عسل! جرّب أي حاجة جديدة 🍀' : luck >= 50 ? 'يوم كويس، خليك متفائل 🙂' : luck >= 25 ? 'يوم عادي، خد بالك من قراراتك 🤏' : 'خليك في البيت وارتاح النهاردة 😴';
            return reply(`🔮 *حظك النهاردة*\n\n🍀 الحظ: *${luck}%*\n🔢 رقمك المحظوظ: *${(h >>> 3) % 100}*\n🎨 لونك: *${colors[(h >>> 7) % colors.length]}*\n\n${msg}\n> بيتغير كل يوم`);
        }
    }
];
