// .play <اسم أو رابط>  ← يعرض أول 10 نتائج كقايمة اختيار، واللي تختاره يتبعت "ريكورد" (voice) + لينكه
import { spawn } from 'child_process';
import yts from 'yt-search';
import { proto, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import { resolve, getAudio, videoIdOf } from '../lib/youtube.js';

const MAX_SECONDS = 30 * 60;

// mp3 (أو أي صوت) -> ogg/opus عشان يتبعت كريكورد حقيقي ومدته تظهر صح
function toOpus(buf) {
    return new Promise((ok, fail) => {
        const ff = spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-i', 'pipe:0', '-vn', '-c:a', 'libopus', '-b:a', '48k', '-ar', '48000', '-ac', '1', '-f', 'ogg', 'pipe:1']);
        const out = [];
        let err = '';
        ff.stdout.on('data', (d) => out.push(d));
        ff.stderr.on('data', (d) => (err += d));
        ff.on('error', fail);
        ff.on('close', (code) => {
            const r = Buffer.concat(out);
            code === 0 && r.length > 1000 ? ok(r) : fail(new Error(err.slice(0, 120) || `ffmpeg code ${code}`));
        });
        ff.stdin.on('error', () => {});
        ff.stdin.end(buf);
    });
}

async function sendList(sock, jid, quoted, { text, title, rows }) {
    const IM = proto.Message.InteractiveMessage;
    const im = IM.fromObject({
        body: IM.Body.fromObject({ text }),
        footer: IM.Footer.fromObject({ text: 'SOFA BOT' }),
        header: IM.Header.fromObject({ title: '', hasMediaAttachment: false }),
        nativeFlowMessage: IM.NativeFlowMessage.fromObject({
            buttons: [{ name: 'single_select', buttonParamsJson: JSON.stringify({ title, sections: [{ title, rows }] }) }]
        })
    });
    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: { messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 }, interactiveMessage: im } }
    }, { userJid: sock.user?.id, quoted });
    await sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
}

// تحميل فيديو واحد وإرساله كريكورد + اللينك
async function sendVoice({ sock, message, reply }, videoId) {
    const jid = message.key.remoteJid;
    const react = (e) => sock.sendMessage(jid, { react: { text: e, key: message.key } }).catch(() => {});
    await react('⌛');
    try {
        const v = await resolve(`https://youtube.com/watch?v=${videoId}`);
        if (v.seconds && v.seconds > MAX_SECONDS) {
            await react('❌');
            return reply(`❌ المقطع طويل (${Math.round(v.seconds / 60)} دقيقة). الحد الأقصى ${MAX_SECONDS / 60} دقيقة.`);
        }
        const media = await getAudio(v);
        let voice = null;
        try { voice = await toOpus(media.buffer); } catch (e) { console.error('[play] ffmpeg:', e.message); }

        const payload = voice
            ? { audio: voice, mimetype: 'audio/ogg; codecs=opus', ptt: true }
            : { audio: media.buffer, mimetype: 'audio/mpeg', ptt: true }; // لو ffmpeg مش موجود
        if (v.seconds) payload.seconds = v.seconds;

        await sock.sendMessage(jid, payload, { quoted: message });
        await sock.sendMessage(jid, { text: `🎵 *${v.title || 'YouTube'}*\n🔗 ${v.url}` }, { quoted: message });
        await react('✅');
    } catch (e) {
        await react('❌');
        const d = e.details?.length ? `\n\n${e.details.join('\n')}` : '';
        return reply(`❌ فشل التحميل: ${e.message}${d}`);
    }
}

export default [
    {
        name: 'play',
        aliases: ['ply', 'playy', 'pl', 'تشغيل'],
        description: 'بحث يوتيوب: بيعرض أول 10 نتايج، تختار واحدة وتتبعتلك ريكورد + لينك',
        category: 'downloader',
        async run(ctx) {
            const { sock, message, reply } = ctx;
            const prefix = ctx.prefix || '.';
            const jid = message.key.remoteJid;
            const query = String(ctx.text || '').trim();
            if (!query) return reply(`🎵 اكتب اسم الأغنية أو رابط يوتيوب.\nمثال: ${prefix}play عمرو دياب تملي معاك`);

            // رابط مباشر: من غير قايمة
            const direct = videoIdOf(query);
            if (direct) return sendVoice(ctx, direct);

            await sock.sendMessage(jid, { react: { text: '🔎', key: message.key } }).catch(() => {});
            let videos = [];
            try { videos = ((await yts(query)).videos || []).slice(0, 10); }
            catch (e) { return reply(`❌ البحث فشل: ${String(e.message || e).slice(0, 80)}`); }
            if (!videos.length) return reply(`❌ مالقيتش نتايج لـ "${query}".`);

            const rows = videos.map((v, i) => ({
                header: '',
                title: `${i + 1}. ${v.title}`.slice(0, 24),
                description: `${v.title} • ${v.timestamp || '?'} • ${v.author?.name || ''}`.slice(0, 72),
                id: `${prefix}play_dl ${v.videoId}`
            }));
            try {
                await sendList(sock, jid, message, {
                    text: `🎵 *نتايج البحث:* ${query}\n\nاختار اللي عايزه من القايمة 👇`,
                    title: 'النتايج (10)',
                    rows
                });
            } catch {
                // لو القايمة مش اتبعتت: نعرض النتايج نص
                return reply(videos.map((v, i) => `*${i + 1}.* ${v.title} (${v.timestamp})\n${prefix}play_dl ${v.videoId}`).join('\n\n'));
            }
        }
    },
    {
        name: 'play_dl',
        aliases: ['playdl'],
        description: 'تحميل نتيجة اخترتها من .play (بيتشغل من الزر)',
        category: 'downloader',
        async run(ctx) {
            const id = String(ctx.text || '').trim().match(/[\w-]{11}/)?.[0];
            if (!id) return ctx.reply('❌ id غير صالح.');
            return sendVoice(ctx, id);
        }
    }
];
