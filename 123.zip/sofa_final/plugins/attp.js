// نص → ملصق
import fetch from 'node-fetch';

export default {
    name: 'attp',
    aliases: ['نص-ملصق', 'textsticker'],
    description: 'تحويل نص إلى ملصق',
    category: 'media',
    usage: '.attp مرحبا',

    async run({ text, reply, sock, m, message, react }) {
        const t = (text || '').trim();
        if (!t) return reply('❌ اكتب نص بعد الأمر\nمثال: .attp SOFA VIP');
        if (t.length > 80) return reply('❌ النص طويل أوي (حد أقصى 80 حرف)');
        await react?.('⏳').catch?.(() => {});
        try {
            const url = `https://api.lolhuman.xyz/api/attp?apikey=GataDios&text=${encodeURIComponent(t)}`;
            let res = await fetch(url);
            if (!res.ok) {
                // بديل
                res = await fetch(`https://api.dreaded.site/api/maker/attp?text=${encodeURIComponent(t)}`);
            }
            if (!res.ok) throw new Error('API failed');
            const buf = Buffer.from(await res.arrayBuffer());
            await react?.('✅').catch?.(() => {});
            return sock.sendMessage((m || message).key.remoteJid, { sticker: buf }, { quoted: m || message });
        } catch (e) {
            await react?.('❌').catch?.(() => {});
            return reply('❌ فشل إنشاء الملصق: ' + (e.message || e));
        }
    }
};
