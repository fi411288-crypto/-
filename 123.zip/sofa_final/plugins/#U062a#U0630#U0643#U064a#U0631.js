import { store, job, sockOf, digits } from '../lib/xtools.js';

const db = () => (store('reminders', { list: [] }).data.list ||= []);
const U = { د: 1, دقيقه: 1, دقيقة: 1, دقايق: 1, m: 1, min: 1, س: 60, ساعه: 60, ساعة: 60, h: 60, hr: 60, ي: 1440, يوم: 1440, d: 1440 };

job('reminders', async () => {
    const l = db(), now = Date.now();
    for (const r of l.filter((x) => x.at <= now)) {
        const sock = sockOf(r.phone);
        if (!sock) continue;
        try {
            await sock.sendMessage(r.jid, { text: `⏰ *تذكير!*${r.jid.endsWith('@g.us') ? ` @${digits(r.user)}` : ''}\n\n📝 ${r.text}\n\n> SOFA BOT`, mentions: [r.user] });
            l.splice(l.indexOf(r), 1); store('reminders').save();
        } catch {}
    }
}, 15000);

export default {
    name: 'تذكير',
    aliases: ['ذكرني', 'remind', 'تنبيه'],
    description: 'ينبهك في الموعد (مثال: .تذكير 30د اجتماع)',
    usage: '.تذكير 30د اجتماع | .تذكير قائمة | .تذكير الغاء 1',
    category: 'tools',
    async run({ message, text, reply, bot }) {
        const phone = String(bot?.phone || 'main').replace(/\D/g, '') || 'main';
        const jid = message.key.remoteJid;
        const user = message.key.participant || jid;
        const mine = () => db().filter((r) => r.phone === phone && digits(r.user) === digits(user)).sort((a, b) => a.at - b.at);
        const t = text.trim().replace(/[٠-٩]/g, (d) => d.charCodeAt(0) - 1632);
        if (/^(قائمة|قايمة|list)$/.test(t)) {
            const m = mine();
            return reply(m.length ? `⏰ *تذكيراتك*\n\n${m.map((r, i) => `${i + 1}. ${r.text} — ${new Date(r.at).toLocaleString('ar-EG', { timeZone: 'Africa/Cairo', hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' })}`).join('\n')}\n\nللإلغاء: .تذكير الغاء رقم` : '⏰ مفيش تذكيرات عندك.');
        }
        const del = /^(الغاء|إلغاء|حذف)\s+(\d+)$/.exec(t);
        if (del) {
            const r = mine()[+del[2] - 1];
            if (!r) return reply('❌ رقم غلط.');
            db().splice(db().indexOf(r), 1); store('reminders').save();
            return reply('🗑️ اتلغى التذكير.');
        }
        const m = /^(\d+)\s*([^\d\s]+)?\s*([\s\S]*)$/.exec(t);
        if (!m) return reply('⏰ الاستخدام:\n.تذكير 30د اجتماع\n.تذكير 2س اشرب مياه\n.تذكير 1ي سداد الفاتورة\n(د = دقيقة، س = ساعة، ي = يوم)');
        const mult = U[(m[2] || '').toLowerCase()];
        const body = (mult ? m[3] : `${m[2] || ''} ${m[3]}`).trim() || 'تذكير';
        const minutes = +m[1] * (mult || 1);
        if (minutes < 1 || minutes > 43200) return reply('❌ المدة لازم تكون من دقيقة لـ 30 يوم.');
        if (mine().length >= 20) return reply('❌ عندك 20 تذكير، الغي بعضهم الأول.');
        const at = Date.now() + minutes * 60000;
        db().push({ phone, jid, user, text: body.slice(0, 300), at });
        store('reminders').save();
        return reply(`✅ هنبهك بعد ${m[1]}${mult ? ` ${m[2]}` : ' دقيقة'}\n📝 ${body}\n🕐 ${new Date(at).toLocaleTimeString('ar-EG', { timeZone: 'Africa/Cairo', hour: '2-digit', minute: '2-digit' })}`);
    }
};
