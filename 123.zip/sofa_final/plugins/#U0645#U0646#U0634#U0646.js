export default {
  name: "منشن",
  description: "يمنشن كل أعضاء الجروب بدون ظهور أرقام مع اشعار جماعي.",
  usage: ".منشن",
  group: true,

  async run({ sock, message, reply, groupMetadata }) {
    try {
      const from = message.key.remoteJid;
      if (!from.endsWith("@g.us")) return reply("الأمر ده يشتغل جوه الجروبات بس.");

      // جلب أعضاء الجروب
      let participants = [];
      if (groupMetadata?.participants) {
        participants = groupMetadata.participants.map(p => p.id || p.jid);
      } else {
        const meta = await sock.groupMetadata(from);
        participants = meta.participants.map(p => p.id || p.jid);
      }

      // استبعاد رقم البوت نفسه
      const botJid = sock.user?.id || sock.user?.jid;
      participants = participants.filter(jid => jid && jid !== botJid);
      if (!participants.length) return reply("مافيش أعضاء لأمنشنهم.");

      // الرسالة الأساسية بدون أرقام
      const text = "*عـبـدو الروسي؟*";

      // إرسال الرسالة مع mentions (من غير ما نعرض أرقام)
      await sock.sendMessage(from, {
        text,
        mentions: participants
      });

    } catch (err) {
      console.error("Mention Error:", err);
      reply("حصل خطأ وأنا بحاول أمنشن. حاول تاني أو ابعتلي صورة الخطأ.");
    }
  }
};