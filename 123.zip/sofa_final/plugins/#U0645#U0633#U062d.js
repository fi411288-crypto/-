import { hook, perms, sleep } from '../lib/xtools.js';

const recent = new Map(); // jid -> [key,...]
hook('recent', ({ message, jid }) => {
    if (!message?.key?.id) return;
    const a = recent.get(jid) || [];
    a.push({ remoteJid: jid, id: message.key.id, participant: message.key.participant, fromMe: false });
    if (a.length > 300) a.shift();
    recent.set(jid, a);
});

export default {
    name: 'مسح',
    aliases: ['امسح', 'clear', 'purge'],
    description: 'يمسح آخر عدد من الرسائل (أو رد على رسالة لمسحها)',
    usage: '.مسح 10',
    category: 'admin',
    group: true,
    async run({ sock, message, args, reply, isDeveloper }) {
        const jid = message.key.remoteJid;
        const p = await perms({ sock, message, isDeveloper });
        if (!p.isAdmin) return reply('❌ الأمر ده للمشرفين فقط.');
        if (!p.isBotAdmin) return reply('❌ لازم البوت يكون مشرف عشان يمسح رسائل.');
        const n = Math.min(100, parseInt(args[0], 10) || 0);
        const ctx = Object.values(message.message || {}).map((v) => v?.contextInfo).find((c) => c?.stanzaId);
        const keys = [];
        if (ctx?.stanzaId && !n) keys.push({ remoteJid: jid, id: ctx.stanzaId, participant: ctx.participant, fromMe: false });
        else if (n > 0) keys.push(...(recent.get(jid) || []).filter((k) => k.id !== message.key.id).slice(-n).reverse());
        else return reply('🧹 الاستخدام: .مسح 10\nأو رد على رسالة واكتب .مسح');
        if (!keys.length) return reply('❌ معنديش رسائل محفوظة أمسحها (البوت بيحفظ من وقت ما اشتغل).');
        let done = 0;
        for (const k of keys) { try { await sock.sendMessage(jid, { delete: k }); done++; } catch {} await sleep(350); }
        try { await sock.sendMessage(jid, { delete: message.key }); } catch {}
        const ok = await sock.sendMessage(jid, { text: `🧹 اتمسح ${done} رسالة.` });
        setTimeout(() => sock.sendMessage(jid, { delete: ok.key }).catch(() => {}), 4000);
    }
};
