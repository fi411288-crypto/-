// 🏦 القرض الافتراضي بموعد سداد — SOFA BOT
// .قرض            → حالة قرضك
// .قرض 5000       → خد قرض
// .قرض سداد 2000  → سدّد جزء  |  .قرض سداد كله → سدّد الأقصى اللي تقدر عليه
import { resolveNumber, isRegistered, updateUser, getLevel } from '../lib/economy.js';
import { fmt, toEnDigits } from '../lib/shop.js';

const DAY = 864e5;
const INTEREST = 0.10;   // فايدة 10% على المبلغ
const TERM_DAYS = 3;     // مدة السداد
const LATE_RATE = 0.05;  // غرامة تأخير 5% عن كل يوم
const MIN_LOAN = 1000;
const maxLoan = (level) => Math.min(500000, 10000 + (level - 1) * 5000);

// غرامة التأخير بتتحسب أوتوماتيك (بحد أقصى ضعف المبلغ الأصلي)
function accrue(L) {
    if (!L || Date.now() <= L.due) return;
    const from = L.lastLate || L.due;
    const days = Math.floor((Date.now() - from) / DAY);
    if (days > 0) {
        L.owed = Math.min(Math.ceil(L.principal * 2), Math.ceil(L.owed * Math.pow(1 + LATE_RATE, days)));
        L.lastLate = from + days * DAY;
    }
}

const when = (t) => new Date(t).toLocaleString('en-GB', { timeZone: 'Africa/Cairo', hour12: false, day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
const left = (t) => {
    const ms = t - Date.now();
    if (ms <= 0) return '⚠️ متأخر';
    const h = Math.floor(ms / 36e5), d = Math.floor(h / 24);
    return d ? `${d} يوم و ${h % 24} ساعة` : `${h} ساعة و ${Math.floor((ms % 36e5) / 6e4)} دقيقة`;
};

export default [{
    name: 'قرض',
    aliases: ['loan', 'قروض', 'سلفة'],
    category: 'games',
    description: 'قرض افتراضي بفايدة وموعد سداد',
    usage: '.قرض 5000 | .قرض سداد 2000',
    cooldown: 3000,
    async run({ sock, m, message, args, reply, prefix = '.' }) {
        const msg = m || message;
        const number = await resolveNumber(sock, msg);
        if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);

        const sub = (args[0] || '').toLowerCase();
        const isPay = ['سداد', 'سدد', 'ادفع', 'pay'].includes(sub);
        const rawAmt = toEnDigits(isPay ? (args[1] || '') : (args[0] || ''));
        const all = ['كله', 'الكل', 'all'].includes(rawAmt);
        const n = parseInt(rawAmt, 10);

        // ───── سداد ─────
        if (isPay) {
            if (!all && !(n > 0)) return reply(`❌ اكتب المبلغ: *${prefix}قرض سداد 2000* أو *${prefix}قرض سداد كله*`);
            const r = updateUser(number, (u, eco) => {
                const L = u.loan;
                if (!L) return { error: 'none' };
                accrue(L);
                const amount = all ? Math.min(L.owed, eco.coin) : Math.min(n, L.owed);
                if (amount < 1 || eco.coin < amount) return { error: 'funds', have: eco.coin, owed: L.owed };
                eco.coin -= amount; L.owed -= amount;
                let cleared = false;
                if (L.owed <= 0) { delete u.loan; u.loansPaid = (u.loansPaid || 0) + 1; cleared = true; }
                return { paid: amount, owed: L.owed, cleared, coin: eco.coin, due: L.due };
            });
            if (r.error === 'none') return reply('✅ مفيش عليك أي قرض.');
            if (r.error === 'funds') return reply(`❌ رصيدك مش كفاية!\n💰 معاك: \`${fmt(r.have)}\`\n📋 المتبقي عليك: \`${fmt(r.owed)}\``);
            if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ، حاول تاني.');
            return reply(
                `🏦 *SOFA • LOAN*\n\n✅ سدّدت \`${fmt(r.paid)}\` كوين\n` +
                (r.cleared ? '🎉 *خلصت القرض بالكامل!*' : `📋 المتبقي: \`${fmt(r.owed)}\`\n⏳ الموعد: ${when(r.due)} (${left(r.due)})`) +
                `\n💼 رصيدك: \`${fmt(r.coin)}\``
            );
        }

        // ───── حالة القرض ─────
        if (!args.length) {
            const r = updateUser(number, (u, eco) => {
                if (u.loan) accrue(u.loan);
                return { L: u.loan ? { ...u.loan } : null, max: maxLoan(getLevel(eco.exp)), paid: u.loansPaid || 0 };
            });
            if (!r.ok) return reply('❌ حصل خطأ، حاول تاني.');
            if (!r.L) {
                return reply(`🏦 *SOFA • LOAN*\n\n✅ مفيش عليك قرض.\n💳 أقصى قرض ليك: \`${fmt(r.max)}\`\n📈 الفايدة: ${INTEREST * 100}% • المدة: ${TERM_DAYS} أيام\n⚠️ غرامة التأخير: ${LATE_RATE * 100}% كل يوم\n\n*${prefix}قرض 5000* لتاخد قرض`);
            }
            const late = Date.now() > r.L.due;
            return reply(
                `🏦 *SOFA • LOAN*\n\n💵 المبلغ الأصلي: \`${fmt(r.L.principal)}\`\n📋 المتبقي عليك: \`${fmt(r.L.owed)}\`\n` +
                `⏳ الموعد: ${when(r.L.due)} (${left(r.L.due)})\n` + (late ? `🚨 القرض متأخر والغرامة شغالة ${LATE_RATE * 100}% كل يوم!\n` : '') +
                `\n*${prefix}قرض سداد 2000* | *${prefix}قرض سداد كله*`
            );
        }

        // ───── أخد قرض ─────
        if (!(n > 0)) return reply(`❌ اكتب مبلغ صح: *${prefix}قرض 5000*`);
        const r = updateUser(number, (u, eco) => {
            if (u.loan) { accrue(u.loan); return { error: 'active', owed: u.loan.owed, due: u.loan.due }; }
            const max = maxLoan(getLevel(eco.exp));
            if (n < MIN_LOAN) return { error: 'min' };
            if (n > max) return { error: 'max', max };
            const now = Date.now(), owed = Math.ceil(n * (1 + INTEREST));
            u.loan = { principal: n, owed, taken: now, due: now + TERM_DAYS * DAY };
            eco.coin += n;
            return { owed, due: u.loan.due, coin: eco.coin };
        });
        if (r.error === 'active') return reply(`❌ عندك قرض شغال بالفعل!\n📋 المتبقي: \`${fmt(r.owed)}\`\nسدّده الأول: *${prefix}قرض سداد كله*`);
        if (r.error === 'min') return reply(`❌ أقل قرض \`${fmt(MIN_LOAN)}\` كوين.`);
        if (r.error === 'max') return reply(`❌ أقصى قرض ليك دلوقتي \`${fmt(r.max)}\` (بيزيد مع مستواك).`);
        if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ، حاول تاني.');
        return reply(
            `🏦 *SOFA • LOAN*\n\n✅ استلمت \`${fmt(n)}\` كوين\n📋 المطلوب سداده: \`${fmt(r.owed)}\` (فايدة ${INTEREST * 100}%)\n` +
            `⏳ آخر موعد: ${when(r.due)} (${TERM_DAYS} أيام)\n⚠️ بعد الموعد: غرامة ${LATE_RATE * 100}% كل يوم\n💼 رصيدك: \`${fmt(r.coin)}\``
        );
    }
}];
