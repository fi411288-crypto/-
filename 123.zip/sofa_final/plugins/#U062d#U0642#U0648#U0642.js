import webpmux from "node-webpmux";

export default {
    name: "حقوق",
    description: "إضافة حقوق لملصق ثابت أو متحرك",
    aliases: ["wm", "take"],
    category: "sticker",

    async run(context) {
        const { sock, m, text, downloadMedia } = context;
        const jid = m.key.remoteJid;

        try {
            // 1. التحقق من الرد على ملصق
            const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quoted || !quoted.stickerMessage) {
                return await sock.sendMessage(jid, { text: "❌ *يا سوفا لازم تعمل ريبلاي على ملصق!*" }, { quoted: m });
            }

            // 2. التحقق من وجود نص للحقوق
            if (!text) {
                return await sock.sendMessage(jid, { text: "💡 *استخدمه كدة:*\n.حقوق اسم الحزمة | اسمك\n\n*مثال:*\n.حقوق سوفا | بوت" }, { quoted: m });
            }

            // 3. فصل الحقوق
            let [packname, author] = text.split('|');
            packname = packname?.trim() || 'SOFA BOT';
            author = author?.trim() || 'SOFA BOT';

            // 4. تحميل الملصق (ثابت أو متحرك)
            const stickerBuffer = await downloadMedia(m);
            if (!stickerBuffer) {
                return await sock.sendMessage(jid, { text: "❌ فشلت في تحميل الملصق يا برو." }, { quoted: m });
            }

            // 5. تعديل البيانات باستخدام webpmux
            const img = new webpmux.Image();
            await img.load(stickerBuffer);

            const exifData = {
                "sticker-pack-id": `sofa-${Date.now()}`,
                "sticker-pack-name": packname,
                "sticker-pack-publisher": author,
                "emojis": ["⚡️"]
            };
            
            const exifHeader = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
            const jsonBuffer = Buffer.from(JSON.stringify(exifData), "utf-8");
            const exifFinal = Buffer.concat([exifHeader, jsonBuffer]);
            exifFinal.writeUIntLE(jsonBuffer.length, 14, 4);

            img.exif = exifFinal;

            // 6. حفظ وإرسال الملصق الجديد
            const resultSticker = await img.save(null);
            
            await sock.sendMessage(jid, { sticker: resultSticker }, { quoted: m });

        } catch (error) {
            console.error("Error in 'حقوق' command:", error);
            await sock.sendMessage(jid, { text: "❌ حصل مشكلة وأنا بعدل الحقوق." }, { quoted: m });
        }
    }
};
