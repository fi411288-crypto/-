// 🏆 جوايز الأسبوع: أعلى 3 في نقاط الجروب الأسبوعية (نفس .توب اسبوع) بياخدوا كوين + XP تلقائي — SOFA BOT
import { store, job, hook, sockOf } from '../lib/xtools.js';
import { getGroup, weekKey, mentionOf } from '../lib/community.js';
import { addRewards } from '../lib/economy.js';

const PRIZES = [{ coin: 10000, xp: 500 }, { coin: 5000, xp: 250 }, { coin: 2500, xp: 100 }];
const MEDALS = ['🥇', '🥈', '🥉'];
const fmt = (n) => Number(n).toLocaleString('en-US');
const tracked = () => (store('weekly_groups', { list: [] }).data.list ||= []);

// نفتكر الجروبات اللي فيها نشاط
hook('weekly-track', async ({ phone, jid }) => {
    const l = tracked();
    if (!l.some((x) => x.phone === phone && x.jid === jid)) { l.push({ phone, jid }); store('weekly_groups').save(); }
});

const topRows = (g, wk) => Object.entries(g.users)
    .map(([uid, u]) => ({ uid, jid: u.jid, num: u.num, name: u.name, points: u.week?.key === wk ? u.week.points : 0 }))
    .filter((r) => r.points > 0).sort((a, b) => b.points - a.points).slice(0, 3);

// كل دقيقة: نحفظ لقطة لأعلى 3 في الأسبوع الحالي، ولما الأسبوع يتغير (الاثنين 12 ص القاهرة) نصرف جوايز اللقطة القديمة
job('weekly-prizes', async () => {
    const cur = weekKey();
    for (const { phone, jid } of [...tracked()]) {
        const { g, save } = getGroup(phone, jid);
        const snap = g.weekSnap;
        if (snap && snap.key !== cur && g.weeklyPaid !== snap.key) {
            const sock = sockOf(phone);
            if (!sock) continue; // نحاول تاني لما البوت يتصل
            if (snap.rows?.length) {
                const lines = snap.rows.map((r, i) => {
                    const p = PRIZES[i];
                    const paid = r.num && addRewards(r.num, p.xp, p.coin).success;
                    return `${MEDALS[i]} @${r.uid} — ${r.points} نقطة\n   🎁 ${fmt(p.coin)} كوين + ${p.xp} XP${paid ? '' : ' (محتاج .تسجيل عشان تتصرف)'}`;
                });
                await sock.sendMessage(jid, { text: `🏆 *أبطال الأسبوع الماضي*\n\n${lines.join('\n\n')}\n\nمبروك! 🎉\n\n> SOFA BOT`, mentions: snap.rows.map((r) => r.jid || mentionOf(r.uid)) }).catch(() => {});
            }
            g.weeklyPaid = snap.key;
        }
        g.weekSnap = { key: cur, rows: topRows(g, cur) };
        save();
    }
}, 60000);

export default [{
    name: 'اسبوعي',
    aliases: ['weekly', 'اسبوعى', 'جوايز_الاسبوع'],
    category: 'games',
    group: true,
    description: 'ترتيب الأسبوع الحالي وجوايز أعلى 3 (بتتوزع تلقائي كل اثنين)',
    cooldown: 4000,
    async run({ message, reply, bot, prefix = '.' }) {
        const { g } = getGroup(bot?.phone, message.key.remoteJid);
        const rows = topRows(g, weekKey());
        const c = new Date(new Date().toLocaleString('en-US', { timeZone: 'Africa/Cairo' }));
        const days = 6 - ((c.getDay() + 6) % 7), hours = 23 - c.getHours();
        const prizes = PRIZES.map((p, i) => `${MEDALS[i]} ${fmt(p.coin)} كوين + ${p.xp} XP`).join('\n');
        const board = rows.length ? rows.map((r, i) => `${MEDALS[i]} @${r.uid} — ${r.points} نقطة`).join('\n') : 'لسه مفيش نقاط الأسبوع ده.';
        return reply({
            text: `🏆 *SOFA • WEEKLY*\n\n📊 *المتصدرين دلوقتي:*\n${board}\n\n🎁 *الجوايز:*\n${prizes}\n\n⏳ باقي: ${days} يوم و${hours} ساعة\n💡 لازم تكون مسجّل (${prefix}تسجيل) والنقاط من الألعاب والنشاط (${prefix}توب اسبوع)\n\n> SOFA BOT`,
            mentions: rows.map((r) => r.jid || mentionOf(r.uid))
        });
    }
}];
