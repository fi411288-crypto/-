import { groqChat, MODELS, AiError } from '../lib/groq.js';
import { getGroup, normAr } from '../lib/community.js';
import { getMetadata, getAdminFlags } from '../lib/compat.js';

const TOPICS = ['حيوانات', 'أكل وشرب', 'أدوات منزلية', 'جسم الإنسان', 'طبيعة', 'مواصلات', 'تكنولوجيا', 'مدرسة وتعليم', 'رياضة', 'مهن', 'ملابس', 'وقت وتواريخ', 'فواكه وخضار', 'أماكن'];

async function makeRiddle(history) {
    const topic = TOPICS[Math.floor(Math.random() * TOPICS.length)];
    const avoid = history.slice(-20).join('، ');
    const raw = await groqChat({
        model: MODELS.chat, effort: 'low', max: 600, temperature: 1,
        messages: [
            { role: 'system', content: 'إنت بتألف ألغاز عربية مسلية لجروب واتساب. رجّع JSON فقط من غير أي كلام تاني بالشكل: {"riddle":"نص اللغز","answer":"الإجابة (كلمة أو كلمتين)","alt":["إجابات بديلة مقبولة"],"hint1":"تلميح خفيف","hint2":"تلميح أوضح"}. اللغز بالعربي بلهجة بسيطة، إجابته معروفة ومحددة ومفيهاش لبس، ومتذكرش الإجابة في نص اللغز.' },
            { role: 'user', content: `ألّف لغز جديد في موضوع: ${topic}.${avoid ? ` متكررش الإجابات دي: ${avoid}` : ''}` }
        ]
    });
    const m = raw.match(/\{[\s\S]*\}/);
    if (!m) throw new AiError('معرفتش أألف لغز دلوقتي، جرب تاني.');
    let j;
    try { j = JSON.parse(m[0]); } catch { throw new AiError('معرفتش أألف لغز دلوقتي، جرب تاني.'); }
    if (!j.riddle || !j.answer) throw new AiError('معرفتش أألف لغز دلوقتي، جرب تاني.');
    return { q: String(j.riddle), answer: String(j.answer), alt: (j.alt || []).map(String).slice(0, 6), hints: [String(j.hint1 || ''), String(j.hint2 || '')] };
}

export default {
    name: 'لغز',
    aliases: ['لغز_اليوم', 'riddle', 'الغاز'],
    description: 'ألغاز بتلميحات ونقاط لأول إجابة صحيحة',
    usage: '.لغز | .لغز تلميح | .لغز تخطي (ادمن)',
    category: 'fun',
    group: true,
    async run({ sock, message, args, reply, bot, prefix, isDeveloper }) {
        const jid = message.key.remoteJid;
        const { g, save } = getGroup(bot?.phone, jid);
        const sub = normAr(args[0] || '');
        let r = g.riddle;

        if (sub === 'تلميح' || sub === 'hint') {
            if (!r || r.solved) return reply(`❌ مفيش لغز شغال. اكتب ${prefix}لغز.`);
            if ((r.hints || 0) >= 2 || !r.hintList?.[r.hints || 0]) return reply('💡 مفيش تلميحات تانية!');
            const h = r.hintList[r.hints || 0];
            r.hints = (r.hints || 0) + 1; save();
            return reply(`💡 *تلميح ${r.hints}/2:* ${h}\n(نقاط الفوز بتقل مع كل تلميح)`);
        }

        if (sub === 'تخطي' || sub === 'skip') {
            let admin = !!isDeveloper;
            if (!admin) { try { admin = getAdminFlags(sock, message, await getMetadata(sock, jid)).isAdmin; } catch {} }
            if (!admin) return reply('❌ تخطي اللغز للأدمنز بس.');
            if (!r || r.solved) return reply(`❌ مفيش لغز شغال. اكتب ${prefix}لغز.`);
            r.solved = true; save();
            return reply(`⏭️ اتخطينا اللغز. الإجابة كانت: *${r.answer}*\nاكتب ${prefix}لغز لغز جديد.`);
        }

        if (r && !r.solved) {
            return reply(`🧩 *لغز شغال:*\n\n${r.q}\n\n✍️ اكتب الإجابة في الشات مباشرة (من غير أمر)\n💡 ${prefix}لغز تلميح`);
        }

        await sock.sendMessage(jid, { react: { text: '🧩', key: message.key } }).catch(() => {});
        try {
            const n = await makeRiddle(g.riddleHistory || []);
            g.riddle = { q: n.q, answer: n.answer, alt: n.alt, hintList: n.hints, hints: 0, solved: false, at: Date.now() };
            g.riddleHistory = [...(g.riddleHistory || []), n.answer].slice(-50);
            save();
            return reply(`🧩 *لغز جديد!*\n\n${n.q}\n\n✍️ أول واحد يكتب الإجابة صح في الشات ياخد *10 نقاط*\n💡 ${prefix}لغز تلميح\n🏆 ${prefix}ترتيب`);
        } catch (e) {
            return reply(`❌ ${e instanceof AiError ? e.message : 'حصل خطأ: ' + e.message}`);
        }
    }
};
