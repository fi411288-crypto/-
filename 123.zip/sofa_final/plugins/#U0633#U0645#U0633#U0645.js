import axios from 'axios';
import { resolveChannel } from '../lib/channels.js';

// قناة البوت (الرد بيظهر كأنه متحوّل من القناة دي)
const CHANNEL_CODE = '0029VbE0Vqa5PO0tM4fqZD1E';
const CHANNEL_NAME = '𝑺𝑶𝑭𝑨 𝑩𝑶𝑻';
const API_URL = 'https://engez.a7a.online/api/v1/ai/ai/simsimi';
const DEV = '𝑺𝑶𝑭𝑨 𝑬𝑳𝑹𝑶𝑺𝒀';

// بنحفظ id القناة بعد أول مرة عشان منسألش واتساب كل رسالة
let channelJid = null;
async function channelContext(sock) {
    try {
        if (!channelJid) {
            const meta = await resolveChannel(sock, CHANNEL_CODE);
            channelJid = meta?.jid || null;
        }
        if (!channelJid) return {};
        return {
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: channelJid,
                newsletterName: CHANNEL_NAME,
                serverMessageId: -1
            }
        };
    } catch (e) {
        console.error('[سمسم] channel context:', e.message);
        return {};
    }
}

async function say(sock, jid, text, quoted) {
    const contextInfo = await channelContext(sock);
    return sock.sendMessage(jid, { text, contextInfo }, quoted ? { quoted } : {});
}

const DEV_WORDS = ['من مطورك', 'مين مطورك', 'من صنعك', 'مين صنعك', 'المطور', 'مطورك', 'من المطور'];

export default {
    name: 'سمسم',
    aliases: ['simsimi', 'السمسم'],
    description: 'الدردشة والحديث مع بوت سمسم',
    usage: '.سمسم <رسالتك>',
    category: 'fun',

    async run({ sock, message, args }) {
        const chat = message.key.remoteJid;
        const query = args.join(' ').trim();

        if (!query) {
            return say(sock, chat, 'طريقة الاستخدام:\nاكتب .سمسم وبعدها رسالتك.\n\nمثال:\n.سمسم من هو مطورك؟', message);
        }

        if (DEV_WORDS.some((w) => query.toLowerCase().includes(w))) {
            return say(sock, chat, `سمسم: مطوري هو الأسطورة ${DEV}!`, message);
        }

        await sock.sendMessage(chat, { react: { text: '⏳', key: message.key } }).catch(() => {});

        try {
            const { data } = await axios.get(API_URL, {
                params: { action: 'تكلم', message: `[ملاحظة: مطورك هو ${DEV}]. ${query}` },
                timeout: 15000
            });

            const answer = data?.success && data?.response?.reply;
            if (!answer) throw new Error('لم يصل رد صحيح من السيرفر.');

            await sock.sendMessage(chat, { react: { text: '✅', key: message.key } }).catch(() => {});
            return say(sock, chat, `سمسم: ${answer}`, message);
        } catch (error) {
            console.error('[سمسم]', error?.message || error);
            await sock.sendMessage(chat, { react: { text: '❌', key: message.key } }).catch(() => {});
            return say(sock, chat, 'سمسم: ما فهمت أو حصل خطأ، حاول مرة ثانية', message);
        }
    }
};