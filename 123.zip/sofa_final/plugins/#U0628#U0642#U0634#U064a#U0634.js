// 💸 بقشيش: هدية عشوائية كل 6 ساعات — SOFA BOT
import { resolveNumber, isRegistered, updateUser } from '../lib/economy.js';
import { fmt } from '../lib/shop.js';

const COOLDOWN = 6 * 60 * 60 * 1000;
const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));

function roll() {
    const x = Math.random();
    if (x < 0.05) return { coin: rnd(3000, 6000), tag: '🎰 *جاكبوت!*' };
    if (x < 0.30) return { coin: rnd(1000, 2500), tag: '💎 بقشيش محترم' };
    return { coin: rnd(300, 1000), tag: '💸 بقشيش' };
}

const left = (ms) => { const t = Math.ceil(ms / 6e4), h = Math.floor(t / 60), m = t % 60; return h ? `${h} ساعة${m ? ` و ${m} دقيقة` : ''}` : `${m} دقيقة`; };

export default [{
    name: 'بقشيش',
    aliases: ['tip', 'صندوق'],
    category: 'games',
    description: 'بقشيش عشوائي كل 6 ساعات',
    cooldown: 3000,
    async run({ sock, m, message, reply, prefix = '.' }) {
        const number = await resolveNumber(sock, m || message);
        if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
        const r = updateUser(number, (u, eco) => {
            const t = (u.tip ||= { last: 0 });
            const wait = COOLDOWN - (Date.now() - (t.last || 0));
            if (wait > 0) return { error: 'wait', wait };
            const g = roll(); const xp = rnd(10, 40);
            t.last = Date.now(); eco.coin += g.coin; eco.exp += xp;
            return { ...g, xp, total: eco.coin };
        });
        if (r.error === 'wait') return reply(`⏳ *البقشيش لسه مجاش!*\nارجع بعد \`${left(r.wait)}\``);
        if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ، حاول تاني.');
        return reply(`💸 *SOFA • TIP*\n\n${r.tag}\n💰 \`+${fmt(r.coin)}\` كوين\n⚡ \`+${r.xp}\` XP\n💼 رصيدك: \`${fmt(r.total)}\`\n\n⏰ البقشيش الجاي بعد 6 ساعات`);
    }
}];
