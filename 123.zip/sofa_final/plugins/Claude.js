import axios from 'axios';
import { groqChat, MODELS, AiError } from '../lib/groq.js';

// .Claude <وصف>        ← بيولّد صورة حقيقية مباشرة (من غير برومت)
// .Claude نص <فكرة>    ← نص إبداعي
// .Claude شرح <موضوع>  ← شرح مبسط
// (كلمة "صورة" قبل الوصف اختيارية: .Claude صورة قطة = .Claude قطة)

const OLD_API = 'https://api-blackwave.vercel.app/api/v1/ai/draw';
const IMAGE = ['صورة', 'صوره', 'image'];
const TEXT = ['نص', 'text'];
const EXPLAIN = ['شرح', 'explain'];
const BUSY = [402, 429, 503];

async function toEnglish(text) {
    try {
        const r = await axios.get('https://translate.googleapis.com/translate_a/single', {
            params: { client: 'gtx', sl: 'ar', tl: 'en', dt: 't', q: text }, timeout: 10000
        });
        const out = (r.data?.[0] || []).map((p) => p?.[0] || '').join('').trim();
        if (out) return out;
    } catch {}
    try {
        const r = await axios.get('https://api.mymemory.translated.net/get', {
            params: { q: text, langpair: 'ar|en' }, timeout: 10000
        });
        const out = String(r.data?.responseData?.translatedText || '').trim();
        if (out) return out;
    } catch {}
    return null;
}

async function generate(prompt) {
    let lastErr;
    for (let i = 0; i < 2; i++) {
        try {
            const res = await axios.get(`https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}`, {
                params: { width: 1024, height: 1024, model: 'flux', nologo: true, seed: Math.floor(Math.random() * 1e9) },
                responseType: 'arraybuffer', timeout: 90000
            });
            if (!String(res.headers?.['content-type'] || '').startsWith('image/')) throw new Error('الخدمة رجّعت رد غير صورة');
            return Buffer.from(res.data);
        } catch (e) {
            lastErr = e;
            if (!BUSY.includes(e?.response?.status)) break;
            await new Promise((r) => setTimeout(r, 4000));
        }
    }
    try { // احتياطي
        const res = await axios.get(`${OLD_API}/text2img`, { params: { prompt }, timeout: 30000 });
        const data = typeof res.data === 'string' ? JSON.parse(res.data) : (res.data || {});
        if (!data.status || !data.imageUrl) throw new Error(data.message || 'فشل');
        return { url: data.imageUrl };
    } catch {
        throw lastErr || new Error('فشل توليد الصورة');
    }
}

export default [{
    name: 'claude',
    aliases: ['Claude', 'ai', 'generate'],
    description: 'اكتب .Claude وبعدها وصف وهيرسم لك الصورة مباشرة',
    usage: '.Claude قطة بتلبس نضارة في الفضاء',
    category: 'tools',
    async run({ sock, message, args, text, reply, react, prefix = '.' }) {
        const first = String(args[0] || '').toLowerCase();
        const isText = TEXT.includes(first), isExplain = EXPLAIN.includes(first);
        const body = (isText || isExplain || IMAGE.includes(first) ? args.slice(1) : args).join(' ').trim();

        if (!body) {
            return reply(`🎨 اكتب وصف الصورة بعد الأمر وهرسمها لك:\n${prefix}Claude أسد بتاج دهب في الصحرا وقت الغروب\n\n📝 ${prefix}Claude نص <فكرة>\n📚 ${prefix}Claude شرح <موضوع>`);
        }

        await react?.('⏳');
        try {
            if (isText || isExplain) {
                const sys = isText
                    ? 'إنت كاتب مبدع. اكتب نص قصير وجميل بالعربية حول الموضوع.'
                    : 'إنت معلم ذكي. اشرح الموضوع بطريقة سهلة وممتعة بالعربي.';
                const result = await groqChat({
                    model: MODELS.chat, effort: 'low', max: 1200, temperature: 0.8,
                    messages: [{ role: 'system', content: sys }, { role: 'user', content: body }]
                });
                await react?.('✅');
                return reply(`${isText ? '📝' : '📚'}\n\n${result}`);
            }

            const english = /[؀-ۿ]/.test(body) ? await toEnglish(body) : null;
            const img = await generate(english || body);
            const jid = message?.key?.remoteJid;
            await sock.sendMessage(jid, {
                image: img,
                caption: `🎨 ${body}`
            }, { quoted: message });
            await react?.('✅');
        } catch (e) {
            console.error('[claude]', e?.response?.status || '', e.message);
            await react?.('❌');
            const code = e?.response?.status;
            const msg = e instanceof AiError ? e.message
                : BUSY.includes(code) ? 'الخدمة مشغولة أو وصلت للحد المجاني، استنى دقيقة وجرب تاني.'
                : e?.code === 'ECONNABORTED' ? 'الخدمة اتأخرت في الرد، جرب تاني.'
                : e.message;
            return reply(`❌ ${msg}`);
        }
    }
}];
