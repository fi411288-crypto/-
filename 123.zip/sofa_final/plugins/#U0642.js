import { getAdminFlags } from '../lib/compat.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export default {
    name: 'ق',
    aliases: ['قبول_الطلبات'],
    description: 'قبول كل طلبات الانضمام المعلقة في المجموعة',
    category: 'group',

    async run({ sock, message, reply, isGroup, isDeveloper }) {
        if (!isGroup) return reply('❌ الأمر ده للمجموعات فقط.');
        try {
            const jid = message.key.remoteJid;
            const meta = await sock.groupMetadata(jid);
            const { isAdmin, isBotAdmin } = getAdminFlags(sock, message, meta);

            if (!isBotAdmin) return reply('❌ لازم أكون مشرف عشان أقبل الطلبات.');
            if (!isAdmin && !isDeveloper) return reply('❌ الأمر ده للمشرفين فقط.');

            const requests = await sock.groupRequestParticipantsList(jid);
            const items = (requests || []).map((r) => ({ jid: r.jid || r.phone_number || r.id, phone: r.phone_number || r.jid || r.id })).filter((x) => x.jid);
            if (!items.length) return reply('📭 لا توجد طلبات حالياً.');

            const acceptedJids = new Set();
            for (let i = 0; i < items.length; i += 20) {
                const chunk = items.slice(i, i + 20).map((x) => x.jid);
                const res = await sock.groupRequestParticipantsUpdate(jid, chunk, 'approve');
                if (Array.isArray(res) && res.length) {
                    res.filter((x) => String(x.status) === '200').forEach((x) => acceptedJids.add(x.jid));
                } else {
                    chunk.forEach((j) => acceptedJids.add(j));
                }
                await sleep(500);
            }

            const ok = items.filter((x) => acceptedJids.has(x.jid)).length;
            const failed = items.length - ok;

            await sock.sendMessage(jid, { react: { text: ok > 0 ? '✅' : '❌', key: message.key } }).catch(() => {});
            return reply(`تم قبول ${ok} طلب ✔️\nفشل ${failed} ❌️\n> SOFA BOT`);
        } catch (e) {
            console.error('[ق]', e);
            return reply(`❌ حصل خطأ: ${e.message}`);
        }
    }
};
