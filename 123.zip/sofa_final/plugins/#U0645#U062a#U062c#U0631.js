// 🛍️ المتجر: ألقاب / إطارات / حماية من الكتم / عقارات بدخل — SOFA BOT
import { resolveNumber, isRegistered, updateUser, getUser } from '../lib/economy.js';
import { ITEMS, itemById, inv, fmt, pendingIncome, displayName, MAX_SHIELD, MAX_PROP, toEnDigits, questBump } from '../lib/shop.js';

const SELL_RATE = 0.6; // البيع بـ 60% من السعر

const CATS = {
    'القاب': ['title'], 'ألقاب': ['title'], 'اطارات': ['frame'], 'إطارات': ['frame'],
    'حمايه': ['shield'], 'حماية': ['shield'],
    'سيارات': ['prop', 'سيارات'], 'بيوت': ['prop', 'بيوت'], 'قصور': ['prop', 'قصور'],
    'عقارات': ['prop'], 'املاك': ['prop'], 'أملاك': ['prop']
};
const line = (i) => `*${i.id}.* ${i.name} — \`${fmt(i.price)}\`${i.income ? ` 💸 ${fmt(i.income)}/ساعة` : ''}${i.note ? `\n   ↳ ${i.note}` : ''}`;
const who = async (sock, msg) => { const n = await resolveNumber(sock, msg); return n && isRegistered(n) ? n : null; };
const noReg = (p) => `❌ *أنت غير مسجّل!*\nاكتب *${p}تسجيل* الأول.`;

export default [
    {
        name: 'متجر',
        aliases: ['shop', 'السوق'],
        category: 'games',
        description: 'متجر الكوينات: ألقاب، إطارات، حماية من الكتم، سيارات وبيوت وقصور',
        cooldown: 3000,
        async run({ args, reply, prefix = '.' }) {
            const key = (args[0] || '').trim();
            const c = CATS[key];
            if (!c) {
                return reply(
                    `🌌 *SOFA • SHOP* 🛍️\n\n` +
                    `🏷️ *${prefix}متجر القاب*\n🖼️ *${prefix}متجر اطارات*\n🛡️ *${prefix}متجر حمايه*\n` +
                    `🚗 *${prefix}متجر سيارات*\n🏠 *${prefix}متجر بيوت*\n🏰 *${prefix}متجر قصور*\n\n` +
                    `🛒 للشراء: *${prefix}شراء <رقم>*\n🎒 حاجاتك: *${prefix}املاكي*`
                );
            }
            const list = ITEMS.filter((i) => i.type === c[0] && (!c[1] || i.cat === c[1]));
            return reply(`🌌 *SOFA • SHOP* — ${key}\n\n${list.map(line).join('\n')}\n\n🛒 *${prefix}شراء <رقم>*${c[0] === 'prop' ? ` (حتى ${MAX_PROP} من كل نوع، والدخل بيتجمع لحد 24 ساعة — اجمعه بـ *${prefix}تحصيل*)` : ''}`);
        }
    },
    {
        name: 'شراء',
        aliases: ['buy', 'اشتري'],
        category: 'games',
        description: 'شراء حاجة من المتجر بالرقم',
        cooldown: 2500,
        async run({ sock, m, message, args, reply, prefix = '.', isDeveloper = false }) {
            const msg = m || message;
            const number = await who(sock, msg);
            if (!number) return reply(noReg(prefix));
            const id = parseInt(toEnDigits(args[0]), 10);
            const item = itemById(id);
            if (!item) return reply(`❌ اكتب رقم صح من المتجر: *${prefix}شراء <رقم>*\nشوف الأرقام بـ *${prefix}متجر*`);

            const r = updateUser(number, (u, eco) => {
                const i = inv(u);
                if (item.type === 'title' && i.titles.includes(id)) return { error: 'have' };
                if (item.type === 'frame' && i.frames.includes(id)) return { error: 'have' };
                if (item.type === 'shield' && i.shield >= MAX_SHIELD) return { error: 'max', max: MAX_SHIELD };
                if (!isDeveloper && item.type === 'prop' && (i.props[id] || 0) >= MAX_PROP) return { error: 'max', max: MAX_PROP };
                if (!isDeveloper && eco.coin < item.price) return { error: 'funds', have: eco.coin };
                if (item.type === 'prop') { // نصفّي الدخل المتراكم قبل ما المعدل يتغير
                    const p = pendingIncome(u); eco.coin += p.amount; i.lastCollect = Date.now();
                    if (!isDeveloper && eco.coin < item.price) { eco.coin -= p.amount; return { error: 'funds', have: eco.coin }; }
                    i.props[id] = (i.props[id] || 0) + 1;
                }
                if (!isDeveloper) eco.coin -= item.price;
                if (item.type === 'title') { i.titles.push(id); if (!i.title) i.title = id; }
                if (item.type === 'frame') { i.frames.push(id); if (!i.frame) i.frame = id; }
                if (item.type === 'shield') i.shield++;
                return { left: eco.coin };
            });

            if (r.error === 'have') return reply('ℹ️ أنت مالك الحاجة دي بالفعل.');
            if (r.error === 'max') return reply(`❌ وصلت للحد الأقصى (${r.max}).`);
            if (r.error === 'funds') return reply(`❌ رصيدك مش كفاية!\n💰 معاك: \`${fmt(r.have)}\`\n🏷️ السعر: \`${fmt(item.price)}\``);
            if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ، حاول تاني.');
            questBump(number, 'buy');
            const tip = item.type === 'title' || item.type === 'frame' ? `\n🎨 اتفعّل تلقائياً لو أول واحد. غيّره بـ *${prefix}تجهيز <رقم>*` : item.type === 'prop' ? `\n💸 دخل جديد: ${fmt(item.income)}/ساعة — *${prefix}تحصيل*` : '';
            return reply(`✅ *تم الشراء!*\n\n🛍️ ${item.name}\n💰 المتبقي: \`${fmt(r.left)}\`${tip}`);
        }
    },
    {
        name: 'بيع',
        aliases: ['sell', 'بيع_عقار'],
        category: 'games',
        description: 'بيع سيارة أو بيت أو قصر بـ 60% من سعره',
        usage: '.بيع <رقم العقار>',
        cooldown: 2500,
        async run({ sock, m, message, args, reply, prefix = '.' }) {
            const msg = m || message;
            const number = await who(sock, msg);
            if (!number) return reply(noReg(prefix));
            const id = parseInt(toEnDigits(args[0]), 10);
            const item = itemById(id);
            if (!item || item.type !== 'prop') return reply(`❌ اكتب رقم عقار/سيارة اللي معاك: *${prefix}بيع <رقم>*
شوف أرقامك في *${prefix}املاكي*`);
            const refund = Math.floor(item.price * SELL_RATE);
            const r = updateUser(number, (u, eco) => {
                const i = inv(u), n = i.props[id] || 0;
                if (!n) return { error: 'none' };
                const p = pendingIncome(u); eco.coin += p.amount; i.lastCollect = Date.now(); // نصفّي الدخل الأول
                if (n === 1) delete i.props[id]; else i.props[id] = n - 1;
                eco.coin += refund;
                return { total: eco.coin, income: p.amount };
            });
            if (r.error === 'none') return reply('❌ مش مالك العقار ده.');
            if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ.');
            return reply(`💰 *تم البيع!*

${item.name}
💵 استلمت: \`${fmt(refund)}\` (60% من السعر)${r.income ? `
💸 + دخل متراكم: \`${fmt(r.income)}\`` : ''}
💼 رصيدك: \`${fmt(r.total)}\``);
        }
    },
    {
        name: 'تجهيز',
        aliases: ['equip', 'البس'],
        category: 'games',
        description: 'تفعيل لقب أو إطار اشتريته',
        cooldown: 2000,
        async run({ sock, m, message, args, reply, prefix = '.' }) {
            const msg = m || message;
            const number = await who(sock, msg);
            if (!number) return reply(noReg(prefix));
            const id = parseInt(toEnDigits(args[0]), 10);
            const item = itemById(id);
            const r = updateUser(number, (u) => {
                const i = inv(u);
                if (!item || !['title', 'frame'].includes(item.type)) return { error: 'bad' };
                if (!(item.type === 'title' ? i.titles : i.frames).includes(id)) return { error: 'own' };
                i[item.type] = id;
            });
            if (r.error === 'bad') return reply(`❌ اكتب رقم لقب أو إطار: *${prefix}تجهيز <رقم>*`);
            if (r.error === 'own') return reply('❌ مش مالك الحاجة دي. اشتريها الأول.');
            return reply(r.ok ? `✨ تم التفعيل: ${item.name}` : '❌ حصل خطأ أثناء الحفظ.');
        }
    },
    {
        name: 'املاكي',
        aliases: ['حاجاتي', 'inventory', 'inv', 'ممتلكاتي'],
        category: 'games',
        description: 'ألقابك وإطاراتك وعقاراتك والدخل المتراكم',
        cooldown: 3000,
        async run({ sock, m, message, reply, prefix = '.' }) {
            const msg = m || message;
            const number = await who(sock, msg);
            if (!number) return reply(noReg(prefix));
            const u = getUser(number), i = inv(u);
            const names = (ids) => ids.map((x) => itemById(x)?.name).filter(Boolean).join('، ') || '—';
            const props = Object.entries(i.props || {}).map(([id, n]) => `${itemById(id)?.name} ×${n}`).join('\n') || '—';
            const p = pendingIncome(u);
            return reply(
                `🌌 *SOFA • INVENTORY*\n\n👤 ${displayName(u)}\n\n🏷️ *الألقاب:* ${names(i.titles)}\n🖼️ *الإطارات:* ${names(i.frames)}\n🛡️ *حماية الكتم:* ${i.shield}/${MAX_SHIELD}\n\n🏘️ *العقارات:*\n${props}\n\n💸 *الدخل:* ${fmt(p.perHour)}/ساعة\n📥 *متراكم:* \`${fmt(p.amount)}\` → *${prefix}تحصيل*`
            );
        }
    },
    {
        name: 'تحصيل',
        aliases: ['collect', 'ايجار', 'إيجار'],
        category: 'games',
        description: 'تحصيل دخل السيارات والبيوت والقصور',
        cooldown: 3000,
        async run({ sock, m, message, reply, prefix = '.' }) {
            const msg = m || message;
            const number = await who(sock, msg);
            if (!number) return reply(noReg(prefix));
            const r = updateUser(number, (u, eco) => {
                const p = pendingIncome(u);
                if (!p.perHour) return { error: 'none' };
                if (p.amount < 1) return { error: 'wait' };
                eco.coin += p.amount; inv(u).lastCollect = Date.now();
                return { got: p.amount, total: eco.coin };
            });
            if (r.error === 'none') return reply(`📭 معندكش عقارات بتدّي دخل.\nشوف *${prefix}متجر سيارات* / *بيوت* / *قصور*`);
            if (r.error === 'wait') return reply('⏳ لسه مفيش دخل متراكم، ارجع بعد شوية.');
            return reply(r.ok ? `💸 *تم التحصيل!*\n💰 +\`${fmt(r.got)}\` كوين\n💼 رصيدك: \`${fmt(r.total)}\`` : '❌ حصل خطأ أثناء الحفظ.');
        }
    }
];
