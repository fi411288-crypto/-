import { groqChat, MODELS, imageOf, reactor, AiError } from '../lib/groq.js';

export default {
    name: 'ocr',
    aliases: ['استخراج', 'نص-صورة', 'اقرأ'],
    description: 'يستخرج النص من صورة',
    usage: '.ocr (رد على صورة أو ابعتها بالكابشن)',
    category: 'tools',
    async run({ sock, message, reply, prefix }) {
        const react = reactor(sock, message);
        let image;
        try { image = await imageOf(sock, message); } catch (e) { return reply(`❌ ${e.message}`); }
        if (!image) return reply(`🖼️ رد على صورة واكتب ${prefix}ocr\nأو ابعت الصورة وفي الكابشن ${prefix}ocr`);
        await react('⌛');
        try {
            const out = await groqChat({
                model: MODELS.vision, max: 3000,
                messages: [{ role: 'user', content: [
                    { type: 'text', text: 'Extract ALL text from this image exactly as written, in its original language and line order. Output only the extracted text with no commentary. If there is no text, reply exactly: لا يوجد نص' },
                    { type: 'image_url', image_url: { url: image } }
                ] }]
            });
            await react('✅');
            return reply(`📝 *النص المستخرج*\n\n${out}\n\n> SOFA BOT`);
        } catch (e) {
            await react('❌');
            return reply(`❌ ${e instanceof AiError ? e.message : 'حصل خطأ: ' + e.message}`);
        }
    }
};
