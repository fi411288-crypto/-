// 🧮 حاسبة سريعة — SOFA BOT
import { calc, fmtNum } from '../lib/calc.js';

export default [{
    name: 'حاسبة',
    aliases: ['حاسبه'],
    category: 'tools',
    description: 'حساب سريع: + - × ÷ ^ % () sqrt abs pi',
    usage: '.حاسبة 25*4+10 | .حاسبة 15% من 200 | .حاسبة sqrt(144)',
    cooldown: 1500,
    async run({ text, reply, prefix = '.' }) {
        const q = String(text || '').trim();
        if (!q) return reply(`🧮 *الحاسبة*\n\n${prefix}حاسبة 25*4+10\n${prefix}حاسبة 15% من 200\n${prefix}حاسبة sqrt(144)\n${prefix}حاسبة 2^10\n\nالرموز: + - × ÷ ^ % ( ) sqrt abs pi`);
        try { return reply(`🧮 *${q}*\n\n= *${fmtNum(calc(q))}*`); }
        catch { return reply('❌ المسألة مش مفهومة. اكتب أرقام وعمليات بس، مثال: 25*4+10'); }
    }
}];
