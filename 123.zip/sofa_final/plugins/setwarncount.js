import { getAdminFlags } from '../lib/compat.js';
import { getWarnLimit, setWarnLimit } from '../database/config.js';

const fmt = (msg) => `╭─❏ 「 SETWARNCOUNT」\n│ ${msg}\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐒𝐎𝐅𝐀`;

export default {
    name: 'setwarncount',
    aliases: ['setwarnlimit'],
    description: 'تحديد عدد التحذيرات قبل الطرد (1-20)',
    category: 'group',

    async run({ sock, message, args, reply, isGroup, isDeveloper, prefix }) {
        if (!isGroup) return reply(fmt('Groups only.'));
        const jid = message.key.remoteJid;
        const meta = await sock.groupMetadata(jid);
        const { isAdmin } = getAdminFlags(sock, message, meta);
        if (!isAdmin && !isDeveloper) return reply(fmt('Admins only.'));

        const n = parseInt(args[0], 10);
        if (!Number.isInteger(n) || n < 1 || n > 20) {
            const cur = await getWarnLimit(jid);
            return reply(fmt(`Current warn limit: *${cur}*\n│ Usage: ${prefix}setwarncount <1-20>\n│ Example: ${prefix}setwarncount 5`));
        }
        await setWarnLimit(jid, n);
        return reply(fmt(`✅ Warn limit set to *${n}*. Members are kicked after ${n} warns.`));
    }
};
