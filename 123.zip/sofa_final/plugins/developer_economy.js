// 👑 SOFA BOT — نظام صلاحيات المطور + XP + المال + الرتب + القصور
import { resolveNumber, isRegistered, registerUser, updateUser, getUser, addRewards, getLevel } from '../lib/economy.js';
import { targetJid } from '../lib/xtools.js';
import { getGroup, userOf, levelStart } from '../lib/community.js';
import { ITEMS, inv, itemById, fmt, numberOfJid } from '../lib/shop.js';

const digits = (v) => String(v || '').replace(/\D/g, '');

async function targetNumber(sock, m, args = []) {
    const t = targetJid(m);
    if (t) return await numberOfJid(sock, t);
    const raw = args.find((x) => digits(x).length >= 8);
    return digits(raw || '');
}

async function ensureUser(sock, m, args, name = 'عضو') {
    const n = await targetNumber(sock, m, args);
    if (!n) return null;
    if (!isRegistered(n)) registerUser(n, name);
    return n;
}

function amountArg(args, index = 0) {
    const a = args[index];
    const n = Number(String(a || '').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
    return Number.isFinite(n) && n >= 0 ? Math.floor(n) : null;
}

function deny(isDeveloper, reply) {
    if (!isDeveloper) { reply('❌ الأمر ده للمطور فقط.'); return true; }
    return false;
}

const commands = [
    {
        name: 'اعطاء_XP', aliases: ['XP', 'اضف_xp', 'اعطاء_xp', 'اعطي_xp'], category: 'dev', developer: true,
        description: 'إعطاء XP لأي عضو ورفع مستواه', usage: '.XP @عضو 1000',
        async run({ sock, m, args, reply, isDeveloper, bot }) {
            if (deny(isDeveloper, reply)) return;
            const n = await ensureUser(sock, m, args);
            const amount = amountArg(args, args.findIndex(x => /^\d+$/.test(String(x).replace(/[٠-٩]/g,''))));
            if (!n || amount === null || amount <= 0) return reply('❌ الاستخدام: .XP @عضو 1000');
            const r = addRewards(n, amount, 0);
            if (!r.success) return reply('❌ تعذر حفظ XP.');
            let groupLevel = null;
            const chat = m?.key?.remoteJid;
            if (chat?.endsWith('@g.us')) {
                const { g, save } = getGroup(bot?.phone, chat);
                const u = userOf(g, n);
                u.jid = `${n}@s.whatsapp.net`;
                u.num = n;
                u.points = Number(u.points || 0) + amount;
                u.msgs = Number(u.msgs || 0);
                save();
                groupLevel = Math.floor(Math.sqrt(Math.max(0, u.points) / 10)) + 1;
            }
            return reply(`⚡ تم منح @${n}\n⭐ +${fmt(amount)} XP\n📈 مستوى الاقتصاد: ${getLevel(r.newXP)}${groupLevel ? `\n🏅 مستوى الجروب: ${groupLevel}` : ''}`, { mentions: [`${n}@s.whatsapp.net`] });
        }
    },
    {
        name: 'اعطاء_مال', aliases: ['اعطي_مال', 'اضف_مال', 'مال', 'اعطاء_كوين'], category: 'dev', developer: true,
        description: 'إعطاء كوين لأي عضو', usage: '.اعطاء_مال @عضو 100000',
        async run({ sock, m, args, reply, isDeveloper, bot }) {
            if (deny(isDeveloper, reply)) return;
            const n = await ensureUser(sock, m, args);
            const idx = args.findIndex(x => /^\d+$/.test(String(x).replace(/[٠-٩]/g,'')));
            const amount = amountArg(args, idx);
            if (!n || idx < 0 || amount === null || amount <= 0) return reply('❌ الاستخدام: .اعطاء_مال @عضو 100000');
            const r = addRewards(n, 0, amount);
            if (!r.success) return reply('❌ تعذر حفظ المال.');
            return reply(`💰 تم منح @${n}\n💵 +${fmt(amount)} كوين\n💼 الرصيد: ${fmt(r.newCoins)}`, { mentions: [`${n}@s.whatsapp.net`] });
        }
    },
    {
        name: 'رفع_مستوى', aliases: ['رفع_لفل', 'levelup', 'setlevel'], category: 'dev', developer: true,
        description: 'رفع مستوى عضو مباشرة', usage: '.رفع_مستوى @عضو 10',
        async run({ sock, m, args, reply, isDeveloper, bot }) {
            if (deny(isDeveloper, reply)) return;
            const n = await ensureUser(sock, m, args);
            const idx = args.findIndex(x => /^\d+$/.test(String(x).replace(/[٠-٩]/g,'')));
            const level = amountArg(args, idx);
            if (!n || idx < 0 || !level || level < 1 || level > 1000000) return reply('❌ الاستخدام: .رفع_مستوى @عضو 10');
            // XP المطلوب لمستوى L حسب نظام الاقتصاد: floor(sqrt(XP/100))+1
            const needed = Math.max(0, 100 * ((level - 1) ** 2));
            const u = getUser(n);
            const current = Number(u?.economy?.exp || 0);
            const r = updateUser(n, (user, eco) => { eco.exp = Math.max(current, needed); });
            if (!r.ok) return reply('❌ تعذر تعديل المستوى.');
            let groupMsg = '';
            const chat = m?.key?.remoteJid;
            if (chat?.endsWith('@g.us')) {
                const { g, save } = getGroup(bot?.phone, chat);
                const u = userOf(g, n);
                u.jid = `${n}@s.whatsapp.net`; u.num = n;
                u.points = Math.max(Number(u.points || 0), levelStart(level));
                save();
                groupMsg = `\n🏅 مستوى الجروب: ${Math.floor(Math.sqrt(Math.max(0, u.points) / 10)) + 1}`;
            }
            return reply(`📈 تم رفع مستوى @${n} إلى *${getLevel(r.eco.exp)}*${groupMsg}\n⚡ XP: ${fmt(r.eco.exp)}`, { mentions: [`${n}@s.whatsapp.net`] });
        }
    },
    {
        name: 'اعطاء_رتبة', aliases: ['اعطي_رتبه', 'رتبة', 'رتبه', 'setrank'], category: 'dev', developer: true,
        description: 'إعطاء لقب/رتبة مخصصة لعضو', usage: '.اعطاء_رتبة @عضو قائد السيرفر',
        async run({ sock, m, args, reply, isDeveloper }) {
            if (deny(isDeveloper, reply)) return;
            const n = await ensureUser(sock, m, args);
            const t = args.filter(x => !String(x).startsWith('@') && digits(x).length < 8).join(' ').trim();
            if (!n || !t) return reply('❌ الاستخدام: .اعطاء_رتبة @عضو قائد السيرفر');
            const r = updateUser(n, (u) => { u.customRank = t.slice(0, 60); });
            if (!r.ok) return reply('❌ تعذر حفظ الرتبة.');
            return reply(`🏅 تم إعطاء @${n} رتبة:\n👑 *${t.slice(0,60)}*`, { mentions: [`${n}@s.whatsapp.net`] });
        }
    },
    {
        name: 'حذف_رتبة', aliases: ['شيل_رتبة', 'حذف_رتبه'], category: 'dev', developer: true,
        description: 'حذف الرتبة المخصصة', usage: '.حذف_رتبة @عضو',
        async run({ sock, m, args, reply, isDeveloper }) {
            if (deny(isDeveloper, reply)) return;
            const n = await ensureUser(sock, m, args);
            if (!n) return reply('❌ حدد العضو بمنشن أو رقم.');
            const r = updateUser(n, (u) => { delete u.customRank; });
            return reply(r.ok ? `✅ تم حذف رتبة @${n}.` : '❌ تعذر الحفظ.', { mentions: [`${n}@s.whatsapp.net`] });
        }
    },
    {
        name: 'اعطاء_قصر', aliases: ['اعطي_قصر', 'قصر', 'قصور'], category: 'dev', developer: true,
        description: 'إعطاء قصور بلا حد للمطور أو عضو محدد', usage: '.اعطاء_قصر @عضو 5',
        async run({ sock, m, args, reply, isDeveloper }) {
            if (deny(isDeveloper, reply)) return;
            const n = await ensureUser(sock, m, args);
            if (!n) return reply('❌ حدد العضو.');
            const idx = args.findIndex(x => /^\d+$/.test(String(x).replace(/[٠-٩]/g,'')));
            const count = idx >= 0 ? amountArg(args, idx) : 1;
            if (!count || count > 1000000000) return reply('❌ العدد يجب أن يكون بين 1 و 1,000,000,000.');
            const palace = ITEMS.find(x => x.type === 'prop' && x.cat === 'قصور');
            const palaceId = palace?.id || 19;
            const r = updateUser(n, (u) => { const i = inv(u); i.props[palaceId] = (i.props[palaceId] || 0) + count; });
            if (!r.ok) return reply('❌ تعذر حفظ القصور.');
            return reply(`🏰 تم منح @${n}\n🏰 +${fmt(count)} قصر\n♾️ المطور يستطيع تجاوز حد العقارات.`, { mentions: [`${n}@s.whatsapp.net`] });
        }
    },
    {
        name: 'ثروتي_مطور', aliases: ['ممتلكاتي_كمطور', 'صلاحيات_مطور', 'developer_power'], category: 'dev', developer: true,
        description: 'عرض صلاحيات المطور الاقتصادية غير المحدودة',
        async run({ reply, isDeveloper }) {
            if (deny(isDeveloper, reply)) return;
            return reply('╭━━━〔 👑 SOFA • DEV POWER 〕━━━╮\n┃ 💰 المال: ♾️ غير محدود\n┃ ⚡ XP: ♾️ غير محدود\n┃ 🏅 الرتب: متاح\n┃ 🏰 القصور: ♾️ غير محدود\n┃ 🛍️ الشراء: بدون خصم كوين للمطور\n╰━━━━━━━━━━━━━━━━━━━━╯');
        }
    }
];

export default commands;
