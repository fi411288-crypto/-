export default {
    name: "سرعة",
    desc: "يعرض سرعة استجابة البوت بالمللي ثانية",
    category: "tools",
    usage: "/سرعة",
    
    async run({ bot, message, args }) {
        const start = Date.now(); // بداية القياس
        
        // نرسل رسالة مؤقتة لحساب الاستجابة
        const sentMessage = await bot.sendMessage(message.key.remoteJid, { 
            text: "𝑷𝑯𝒀𝑺𝑰𝑪𝑺 𝑺𝑷𝑬𝑬𝑹.."
        });
        
        const end = Date.now(); // نهاية القياس
        const latency = end - start; // حساب الفرق بالمللي ثانية
        
        // تعديل الرسالة لإظهار النتيجة النهائية
        await bot.sendMessage(message.key.remoteJid, { 
            text: `𝑺𝑷𝑬𝑬𝑫:\n\n` +
                  `⏱️ ${latency}𝑴𝑺\n\n` +
                  "𝑷𝑯𝒀𝑺𝑰𝑪𝑺 𝑩𝑶𝑻 ⚡︎"
        });
    }
};