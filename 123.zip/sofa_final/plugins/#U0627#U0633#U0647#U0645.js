// 📈 سوق الأسهم: سهم SOFA سعره بيبدأ 100 وبيتحرك عشوائي كل دقيقة — SOFA BOT
import { resolveNumber, isRegistered, updateUser } from '../lib/economy.js';
import { store, job } from '../lib/xtools.js';
import { fmt, toEnDigits, bump } from '../lib/shop.js';

const BASE = 100, MIN_P = 20, MAX_P = 500, FEE = 0.01, MAX_SHARES = 50000;
const market = () => { const d = store('stocks', { price: BASE, prev: BASE, hist: [BASE] }).data; d.hist ||= [d.price]; return d; };
const SPARK = '▁▂▃▄▅▆▇█';

// كل دقيقة: حركة عشوائية ±6% مع سحب خفيف ناحية 100 عشان السعر ميطيرش
job('stocks', async () => {
    const m = market();
    let p = m.price * (1 + (Math.random() - 0.5) * 0.12) + (BASE - m.price) * 0.03;
    p = Math.min(MAX_P, Math.max(MIN_P, p));
    m.prev = m.price; m.price = Math.round(p * 100) / 100;
    m.hist.push(m.price); if (m.hist.length > 15) m.hist.shift();
    store('stocks').save();
}, 60000);

const spark = (h) => { const lo = Math.min(...h), hi = Math.max(...h), r = hi - lo || 1; return h.slice(-12).map((v) => SPARK[Math.min(7, Math.floor(((v - lo) / r) * 7.99))]).join(''); };
const pct = (a, b) => (((a - b) / b) * 100).toFixed(1);

export default [{
    name: 'اسهم',
    aliases: ['أسهم', 'stocks', 'سهم', 'البورصة'],
    category: 'games',
    description: 'سوق الأسهم: شوف السعر، اشتري وبيع',
    usage: '.اسهم | .اسهم شراء 100 | .اسهم بيع 100',
    cooldown: 2500,
    async run({ sock, m, message, args, reply, prefix = '.' }) {
        const msg = m || message, number = await resolveNumber(sock, msg);
        if (!number || !isRegistered(number)) return reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`);
        const mk = market(), price = mk.price;
        const buy = ['شراء', 'اشتري', 'buy'].includes(args[0]), sell = ['بيع', 'sell'].includes(args[0]);
        const a = toEnDigits(args[1] || ''), all = ['كله', 'الكل', 'all'].includes(a), n = parseInt(a, 10);
        if ((buy || sell) && !all && !(n > 0)) return reply(`❌ اكتب العدد: *${prefix}اسهم ${args[0]} 100* أو "كله"`);

        const r = updateUser(number, (u, eco) => {
            const h = (u.stocks ||= { shares: 0, cost: 0 });
            let note = '';
            if (buy) {
                const per = price * (1 + FEE);
                const qty = all ? Math.min(Math.floor(eco.coin / per), MAX_SHARES - h.shares) : n;
                if (qty < 1) return { error: 'funds', have: eco.coin };
                if (h.shares + qty > MAX_SHARES) return { error: 'max' };
                const cost = Math.ceil(price * qty * (1 + FEE));
                if (cost > eco.coin) return { error: 'funds', have: eco.coin, need: cost };
                eco.coin -= cost; h.shares += qty; h.cost += cost; bump(u, 'stock');
                note = `✅ اشتريت *${fmt(qty)}* سهم بـ \`${fmt(cost)}\` (شامل رسوم ${FEE * 100}%)`;
            } else if (sell) {
                const qty = all ? h.shares : n;
                if (h.shares < 1) return { error: 'none' };
                if (qty > h.shares) return { error: 'few', have: h.shares };
                const got = Math.floor(price * qty * (1 - FEE)), basis = h.cost * (qty / h.shares), pl = got - basis;
                eco.coin += got; h.cost = h.shares - qty ? h.cost - basis : 0; h.shares -= qty;
                note = `💵 بعت *${fmt(qty)}* سهم بـ \`${fmt(got)}\`\n${pl >= 0 ? '🟢 ربح' : '🔴 خسارة'}: \`${fmt(Math.abs(Math.round(pl)))}\``;
            }
            return { note, shares: h.shares, cost: h.cost, coin: eco.coin };
        });
        if (r.error === 'funds') return reply(`❌ رصيدك مش كفاية!\n💰 معاك: \`${fmt(r.have)}\`${r.need ? `\n📤 المطلوب: \`${fmt(r.need)}\`` : ''}`);
        if (r.error === 'max') return reply(`❌ الحد الأقصى ${fmt(MAX_SHARES)} سهم.`);
        if (r.error === 'none') return reply('❌ معاكش أسهم تبيعها.');
        if (r.error === 'few') return reply(`❌ معاك بس *${fmt(r.have)}* سهم.`);
        if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ.');

        const ch = pct(price, mk.prev), arrow = price >= mk.prev ? '🟢▲' : '🔴▼';
        const val = r.shares * price, pl = val - r.cost;
        return reply(
            `📈 *SOFA • STOCKS*\n\n${r.note ? r.note + '\n\n' : ''}💹 سعر السهم: *${price.toFixed(2)}* ${arrow} ${ch}%\n${spark(mk.hist)}\n🔻 أقل: ${Math.min(...mk.hist).toFixed(2)} | 🔺 أعلى: ${Math.max(...mk.hist).toFixed(2)}\n\n` +
            `📦 أسهمك: *${fmt(r.shares)}*${r.shares ? ` (قيمتها \`${fmt(Math.round(val))}\` • ${pl >= 0 ? '🟢' : '🔴'} ${fmt(Math.round(pl))})` : ''}\n💰 رصيدك: \`${fmt(r.coin)}\`\n⏱️ السعر بيتغير كل دقيقة\n\n*${prefix}اسهم شراء 100* | *${prefix}اسهم بيع 100*`
        );
    }
}];
