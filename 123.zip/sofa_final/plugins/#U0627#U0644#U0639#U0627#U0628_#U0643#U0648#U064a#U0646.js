// 🎰 ألعاب كوين سريعة: .سلوت (ماكينة حظ) + .رهان (ملك وكتابة) — SOFA BOT
import { resolveNumber, isRegistered, updateUser } from '../lib/economy.js';
import { fmt, toEnDigits, questBump } from '../lib/shop.js';

const MIN = 10, MAX = 100000;
// [رمز, وزن, مضاعف الثلاثي]  — العائد المتوقع ≈ 92.6% (البيت بيكسب شوية)
const SYM = [['🍒', 30, 5], ['🍋', 25, 8], ['🍉', 20, 12], ['⭐', 12, 25], ['💎', 8, 50], ['7️⃣', 5, 100]];
const spin = () => { let r = Math.random() * 100; for (const s of SYM) if ((r -= s[1]) < 0) return s; return SYM[0]; };

async function parseBet(sock, msg, arg, reply, prefix, cmd) {
    const n = await resolveNumber(sock, msg);
    if (!n || !isRegistered(n)) { reply(`❌ *أنت غير مسجّل!*\nاكتب *${prefix}تسجيل* الأول.`); return null; }
    const a = toEnDigits(arg || '');
    const all = ['كله', 'الكل', 'all'].includes(a);
    const bet = all ? MAX : parseInt(a, 10);
    if (!all && (!bet || bet < MIN)) { reply(`🎰 اكتب المبلغ: *${prefix}${cmd} 500*\n(من ${fmt(MIN)} لـ ${fmt(MAX)} — أو "كله")`); return null; }
    return { n, bet: Math.min(bet, MAX), all };
}

export default [
    {
        name: 'سلوت',
        aliases: ['slot', 'slots', 'ماكينة'],
        category: 'games',
        description: 'ماكينة حظ: 3 رموز متشابهة بتكسب مضاعفات كبيرة',
        usage: '.سلوت 500',
        cooldown: 4000,
        async run({ sock, m, message, args, reply, prefix = '.' }) {
            const msg = m || message;
            const b = await parseBet(sock, msg, args[0], reply, prefix, 'سلوت');
            if (!b) return;
            const reels = [spin(), spin(), spin()];
            const same = new Set(reels.map((r) => r[0])).size;
            const mult = same === 1 ? reels[0][2] : same === 2 ? 1 : 0;
            const r = updateUser(b.n, (u, eco) => {
                const bet = b.all ? Math.min(MAX, eco.coin) : b.bet;
                if (bet < MIN || eco.coin < bet) return { error: 'funds', have: eco.coin };
                const back = Math.floor(bet * mult);
                eco.coin += back - bet; if (mult > 1) eco.exp += 5;
                return { bet, back, coin: eco.coin };
            });
            if (r.error === 'funds') return reply(`❌ رصيدك مش كفاية! معاك: \`${fmt(r.have)}\``);
            if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ.');
            questBump(b.n, 'gamble');
            const view = `┃ ${reels.map((x) => x[0]).join(' ┃ ')} ┃`;
            const res = mult > 1 ? `🎉 *كسبت x${mult}!* +\`${fmt(r.back - r.bet)}\`` : mult === 1 ? '🤝 اتنين متشابهين — رجعلك رهانك' : `💸 خسرت \`${fmt(r.bet)}\``;
            return reply(`🎰 *SOFA • SLOT*\n\n${view}\n\n${res}\n💼 رصيدك: \`${fmt(r.coin)}\``);
        }
    },
    {
        name: 'رهان',
        aliases: ['bet', 'قلب', 'عملة'],
        category: 'games',
        description: 'رهان ملك أو كتابة: لو خمنت صح بتاخد 1.9x',
        usage: '.رهان 500 ملك | .رهان 500 كتابة',
        cooldown: 4000,
        async run({ sock, m, message, args, reply, prefix = '.' }) {
            const msg = m || message;
            const b = await parseBet(sock, msg, args[0], reply, prefix, 'رهان');
            if (!b) return;
            const guess = ['كتابة', 'كتابه', 'tails'].includes((args[1] || '').toLowerCase()) ? 'كتابة' : 'ملك';
            const result = Math.random() < 0.5 ? 'ملك' : 'كتابة';
            const win = guess === result;
            const r = updateUser(b.n, (u, eco) => {
                const bet = b.all ? Math.min(MAX, eco.coin) : b.bet;
                if (bet < MIN || eco.coin < bet) return { error: 'funds', have: eco.coin };
                const back = win ? Math.floor(bet * 1.9) : 0;
                eco.coin += back - bet;
                return { bet, back, coin: eco.coin };
            });
            if (r.error === 'funds') return reply(`❌ رصيدك مش كفاية! معاك: \`${fmt(r.have)}\``);
            if (!r.ok) return reply('❌ حصل خطأ أثناء الحفظ.');
            questBump(b.n, 'gamble');
            return reply(`🪙 *SOFA • BET*\n\nاخترت: *${guess}*\nالعملة وقعت على: *${result}* ${result === 'ملك' ? '👑' : '✍️'}\n\n${win ? `🎉 كسبت +\`${fmt(r.back - r.bet)}\`` : `💸 خسرت \`${fmt(r.bet)}\``}\n💼 رصيدك: \`${fmt(r.coin)}\``);
        }
    }
];
