// 🗑️ مضاد الحذف: بيحفظ الرسايل اللي اتمسحت في الجروب و.محذوف 10 يعرض آخر 10 — SOFA BOT
import { store, job, perms, digits } from '../lib/xtools.js';

const CACHE_PER_GROUP = 400, LOG_PER_GROUP = 100, MAX_SHOW = 50, TEXT_LEN = 220;
const log = () => store('deleted_log', {}).data;
const attached = (globalThis.__antiDeleteSocks ||= new WeakSet());
const cache = (globalThis.__antiDeleteCache ||= new Map()); // jid -> Map(id -> entry)

const unwrap = (m) => {
    for (let i = 0; i < 5 && m; i++) {
        const n = m.ephemeralMessage?.message || m.viewOnceMessage?.message || m.viewOnceMessageV2?.message || m.viewOnceMessageV2Extension?.message || m.documentWithCaptionMessage?.message || m.editedMessage?.message;
        if (!n) break; m = n;
    }
    return m || {};
};
function describe(m) {
    m = unwrap(m);
    if (m.conversation) return { kind: '', text: m.conversation };
    if (m.extendedTextMessage) return { kind: '', text: m.extendedTextMessage.text || '' };
    if (m.imageMessage) return { kind: '📷 صورة', text: m.imageMessage.caption || '' };
    if (m.videoMessage) return { kind: m.videoMessage.gifPlayback ? '🎞️ GIF' : '🎬 فيديو', text: m.videoMessage.caption || '' };
    if (m.audioMessage) return { kind: m.audioMessage.ptt ? '🎤 فويس' : '🎵 صوت', text: '' };
    if (m.stickerMessage) return { kind: '🏷️ ملصق', text: '' };
    if (m.documentMessage) return { kind: '📄 ملف', text: m.documentMessage.fileName || m.documentMessage.caption || '' };
    if (m.locationMessage) return { kind: '📍 موقع', text: '' };
    if (m.contactMessage || m.contactsArrayMessage) return { kind: '👤 جهة اتصال', text: '' };
    if (m.pollCreationMessage || m.pollCreationMessageV3) return { kind: '📊 استطلاع', text: (m.pollCreationMessage || m.pollCreationMessageV3).name || '' };
    return null;
}

function remember(msg) {
    const jid = msg?.key?.remoteJid;
    if (!jid?.endsWith('@g.us') || msg.key.fromMe || !msg.message) return;
    const d = describe(msg.message);
    if (!d) return;
    let c = cache.get(jid); if (!c) cache.set(jid, (c = new Map()));
    c.set(msg.key.id, { from: msg.key.participant || msg.participant || '', name: msg.pushName || '', t: (Number(msg.messageTimestamp) || Math.floor(Date.now() / 1000)) * 1000, ...d });
    if (c.size > CACHE_PER_GROUP) c.delete(c.keys().next().value);
}
function revoked(jid, id, by) {
    const c = cache.get(jid), e = c?.get(id);
    if (!e) return;
    c.delete(id);
    const l = (log()[jid] ||= []);
    if (l.some((x) => x.id === id)) return;
    l.push({ id, ...e, by: by || '', at: Date.now() });
    if (l.length > LOG_PER_GROUP) l.splice(0, l.length - LOG_PER_GROUP);
    store('deleted_log').save();
}

job('antidelete-attach', async () => {
    for (const s of global.bot?.sessions?.values?.() || []) {
        const sock = s?.sock;
        if (!sock?.ev || attached.has(sock)) continue;
        attached.add(sock);
        sock.ev.on('messages.upsert', ({ messages }) => {
            try {
                for (const msg of messages || []) {
                    const pm = msg.message?.protocolMessage;
                    if (pm && (pm.type === 0 || pm.type === 'REVOKE') && pm.key?.id) revoked(msg.key.remoteJid, pm.key.id, msg.key.participant);
                    else remember(msg);
                }
            } catch {}
        });
        sock.ev.on('messages.update', (ups) => {
            try { for (const u of ups || []) if (u.key?.remoteJid?.endsWith('@g.us') && (u.update?.messageStubType === 1 || u.update?.message === null)) revoked(u.key.remoteJid, u.key.id, ''); } catch {}
        });
    }
}, 10000);

export default [{
    name: 'محذوف',
    aliases: ['المحذوف', 'deleted', 'antidelete', 'محذوفات'],
    category: 'admin',
    group: true,
    description: 'آخر الرسايل المحذوفة في الجروب (.محذوف 10 يعرض آخر 10)',
    usage: '.محذوف [عدد] | .محذوف مسح',
    cooldown: 3000,
    async run({ sock, message, args, reply, isDeveloper }) {
        const p = await perms({ sock, message, isDeveloper });
        if (!p.isAdmin) return reply('❌ الأمر ده للمشرفين فقط.');
        const jid = message.key.remoteJid;
        if (['مسح', 'clear'].includes(args[0])) { delete log()[jid]; store('deleted_log').save(); return reply('🗑️ اتمسح سجل المحذوفات.'); }
        const n = Math.max(1, Math.min(MAX_SHOW, parseInt(String(args[0] || '10').replace(/[٠-٩]/g, (d) => d.charCodeAt(0) - 1632), 10) || 10));
        const l = (log()[jid] || []).slice(-n).reverse();
        if (!l.length) return reply('📭 مفيش رسايل محذوفة اتسجّلت لسه.\n(البوت بيبدأ يسجّل من وقت تشغيله)');
        const when = (t) => new Date(t).toLocaleString('ar-EG', { timeZone: 'Africa/Cairo', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
        const mentions = new Set();
        const lines = l.map((e, i) => {
            if (e.from) mentions.add(e.from);
            const body = [e.kind, e.text ? e.text.replace(/\s+/g, ' ').slice(0, TEXT_LEN) + (e.text.length > TEXT_LEN ? '…' : '') : ''].filter(Boolean).join(' ');
            const by = e.by && digits(e.by) !== digits(e.from) ? `\n   👮 اتمسحت بواسطة @${digits(e.by)}` : '';
            if (by) mentions.add(e.by);
            return `*${i + 1}.* ${e.from ? '@' + digits(e.from) : e.name || '؟'} • 🕐 ${when(e.t)}\n   💬 ${body || '—'}${by}`;
        });
        return reply({ text: `🗑️ *آخر ${l.length} رسايل محذوفة*\n\n${lines.join('\n\n')}\n\n> SOFA BOT`, mentions: [...mentions] });
    }
}];
