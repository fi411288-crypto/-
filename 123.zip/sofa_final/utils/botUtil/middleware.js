// يتأكد إن الأمر داخل مجموعة والمرسل أدمن (والبوت أدمن لو لازم)
export default async function middleware(context, next) {
    const { client, m, isAdmin, isBotAdmin, command } = context;
    const say = (text) => client.sendMessage(m.chat, { text }, { quoted: m });
    if (!m.isGroup) return say('❌ الأمر ده للمجموعات فقط.');
    if (!isAdmin) return say('❌ الأمر ده للمشرفين فقط.');
    const needsBotAdmin = !['warncount'].includes(command);
    if (needsBotAdmin && !isBotAdmin) return say('❌ لازم أكون مشرف في المجموعة عشان أنفذ الأمر.');
    return next();
}
