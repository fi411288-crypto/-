"use strict";

import fs from "fs-extra";
import path from "path";
import { Telegraf, Markup } from "telegraf";
import { isBannedTG } from "./lib/bans.js";
import { TG, fancy, SIGN } from "./lib/theme.js";
import { pairCard } from "./lib/vipCards.js";
import { setPending, rewardOnLink, REF_REWARD } from "./lib/referral.js";
import { TASK_REWARD, TG_CHANNEL, TG_CHANNEL_URL as TASK_TG_URL, WA_CHANNEL_URL as TASK_WA_URL, taskState, claimTask, isRegistered, isFollowingWaChannel } from "./lib/tgTasks.js";

// =============================================================
// إعدادات البوت
// data/token.json ممكن يكون بالشكل ده (كلهم اختياري ماعدا token):
// {
//   "token": "123456:ABC...",
//   "channel": "@YourChannel",          // اتركه فاضي لإلغاء الاشتراك الإجباري
//   "channelUrl": "https://t.me/YourChannel",
//   "developer": "@YourTelegramUsername"
// }
// =============================================================

const TOKEN_FILE = path.join(process.cwd(), "data", "token.json");
const USERS_FILE = path.join(process.cwd(), "data", "telegramUsers.json");
const PROFILES_FILE = path.join(process.cwd(), "data", "telegramProfiles.json");

const BOT_NAME = "𝗦𝗢𝗙𝗔 𝗕𝗢𝗧";
const DEFAULT_CHANNEL = "@sofa_bot1";
const DEFAULT_CHANNEL_URL = "https://t.me/sofa_bot1";
const DEV_WHATSAPP = "201018766845";   // للاستخدام الداخلي بس (مش بيظهر لأي مستخدم)
const DEV_WA_NUMBER = "201018766845"; // رقم واتساب اللي بيظهر في الزرار
const OWNER_TG_IDS = ["PUT_YOUR_TELEGRAM_NUMERIC_ID_HERE"]; // أيدي تليجرام بتاع الأونر (بيشتغل بيه أمر .مين)
const LINE = TG.line;
const DEV_TG = "F_1_D_L_1";
const DEV_BOT = "Sofa_41818Bot";
const TG_CHANNEL_URL = "https://t.me/sofa_bot1";
const WA_CHANNEL_URL = "https://whatsapp.com/channel/0029VbE0Vqa5PO0tM4fqZD1E";
const TIKTOK_URL = "https://www.tiktok.com/@fadl.ibrahem1";

export class TelegramBot {
    constructor(bot) {
        this.bot = bot;
        this.telegram = null;
        this.token = null;
        this.started = false;

        this.channel = "";
        this.channelUrl = "";
        this.developer = "";

        this.users = new Map();
        this.busy = new Set();
        this.profiles = new Map(); // id -> { name, username, joinedAt, lastSeen, blocked }
        this.ownerId = "";

        this.heroFileIds = new Map(); // مسار الميديا -> file_id (عشان ما نرفعش الفيديو كل مرة)
        this.heroMsg = new Map();     // chat:message -> الميديا المعروضة

        this.bot.telegramNotify = (telegramId, event) => this.notifyTelegram(telegramId, event);
    }

    // =========================================================
    // CONFIG / TOKEN / USERS
    // =========================================================

    async loadToken() {
        await fs.ensureDir(path.dirname(TOKEN_FILE));

        let data = null;
        if (await fs.pathExists(TOKEN_FILE)) data = await fs.readJSON(TOKEN_FILE);

        let token = "";
        if (typeof data === "string") token = data.trim();
        else if (data && typeof data.token === "string") token = data.token.trim();
        else if (data && typeof data.TELEGRAM_BOT_TOKEN === "string") token = data.TELEGRAM_BOT_TOKEN.trim();
        if (!token && process.env.TELEGRAM_TOKEN) token = process.env.TELEGRAM_TOKEN.trim();

        if (!token) throw new Error("Telegram token غير موجود داخل data/token.json");

        if (data && typeof data === "object") {
            this.channel = String(data.channel || "").trim();
            this.channelUrl = String(data.channelUrl || "").trim();
            this.developer = String(data.developer || "").trim().replace(/^@?/, "@");
            if (this.developer === "@") this.developer = "";
            if (this.channel && !this.channelUrl) {
                this.channelUrl = `https://t.me/${this.channel.replace(/^@/, "")}`;
            }
        }

        if (data && typeof data === "object" && data.ownerId) this.ownerId = String(data.ownerId).trim();

        // الاشتراك الإجباري: لو القناة مش متحددة في token.json نستخدم القناة الافتراضية
        if (!this.channel) {
            this.channel = DEFAULT_CHANNEL;
            this.channelUrl = DEFAULT_CHANNEL_URL;
        }

        this.token = token;
        return token;
    }

    async loadUsers() {
        try {
            if (await fs.pathExists(USERS_FILE)) {
                const data = await fs.readJSON(USERS_FILE);
                for (const [id, lang] of Object.entries(data || {})) {
                    this.users.set(String(id), { language: lang === "en" ? "en" : "ar", state: "idle", promptId: null });
                }
            }
        } catch {}
    }

    async loadProfiles() {
        try {
            if (await fs.pathExists(PROFILES_FILE)) {
                const data = await fs.readJSON(PROFILES_FILE);
                for (const [id, p] of Object.entries(data || {})) this.profiles.set(String(id), p);
            }
        } catch {}
    }

    saveProfiles() {
        clearTimeout(this._profilesTimer);
        this._profilesTimer = setTimeout(async () => {
            try {
                const out = {};
                for (const [id, p] of this.profiles.entries()) out[id] = p;
                await fs.writeJSON(PROFILES_FILE, out, { spaces: 2 });
            } catch {}
        }, 1500);
    }

    // =========================================================
    // OWNER NOTIFICATIONS / TRACKING / BROADCAST / STATS
    // =========================================================

    ownerIds() {
        const ids = new Set(OWNER_TG_IDS);
        if (this.ownerId) ids.add(this.ownerId);
        const owners = this.bot?.sessionOwners;
        const mapped = owners?.get?.(DEV_WHATSAPP);
        if (mapped) ids.add(String(mapped));
        return [...ids];
    }

    userTag(p) {
        if (p?.username) return `@${this.escape(p.username)}`;
        const name = this.escape(p?.name || p?.id || "user");
        return `<a href="tg://user?id=${p?.id}">${name}</a>`;
    }

    async notifyOwner(text, plain = false) {
        let ok = 0;
        for (const id of this.ownerIds()) {
            try {
                await this.telegram.telegram.sendMessage(id, text, plain
                    ? { disable_web_page_preview: true }
                    : { parse_mode: "HTML", disable_web_page_preview: true });
                ok++;
            } catch {}
        }
        return ok;
    }

    totalUserIds() {
        return new Set([...this.users.keys(), ...this.profiles.keys()]);
    }

    async trackUser(ctx) {
        if (!ctx.from || ctx.from.is_bot) return;
        const id = String(ctx.from.id);
        const known = this.users.has(id) || this.profiles.has(id);
        const prev = this.profiles.get(id);
        const name = [ctx.from.first_name, ctx.from.last_name].filter(Boolean).join(" ").trim();
        const p = {
            ...(prev || {}),
            id,
            name,
            username: ctx.from.username || "",
            lastSeen: Date.now(),
            joinedAt: prev ? prev.joinedAt : (known ? 0 : Date.now()),
            blocked: false
        };
        const wasBlocked = !!prev?.blocked;
        this.profiles.set(id, p);
        this.saveProfiles();

        if (this.ownerIds().includes(id)) return;

        if (!known) {
            this.notifyOwner(`✅ قام ${this.userTag(p)} بتفعيل البوت\n🆔 <code>${id}</code>\n👥 إجمالي المستخدمين: <b>${this.totalUserIds().size}</b>`);
        } else if (wasBlocked) {
            this.notifyOwner(`🔓 قام ${this.userTag(p)} بإلغاء حظر البوت\n🆔 <code>${id}</code>`);
        }
    }

    async broadcast(text) {
        let sent = 0, failed = 0, blocked = 0, skipped = 0, dead = 0;
        const reasons = {}; // سبب الفشل -> العدد
        const note = (e) => {
            const k = String(e?.response?.description || e?.message || "unknown").replace(/^Bad Request: |^Forbidden: /, "").slice(0, 60);
            reasons[k] = (reasons[k] || 0) + 1;
        };
        for (const id of this.totalUserIds()) {
            const prof = this.profiles.get(id);
            if (prof?.blocked || prof?.dead || isBannedTG(id)) { skipped++; continue; }
            let done = false;
            for (let attempt = 0; attempt < 3 && !done; attempt++) {
                try {
                    await this.telegram.telegram.sendMessage(id, text, { disable_web_page_preview: true });
                    sent++; done = true;
                } catch (error) {
                    const code = error?.response?.error_code;
                    const desc = String(error?.response?.description || "");
                    if (code === 429) { // Too Many Requests: نستنى المدة اللي تليجرام طلبها ونعيد
                        const wait = Number(error?.response?.parameters?.retry_after || 3);
                        await new Promise((r) => setTimeout(r, (wait + 1) * 1000));
                        continue;
                    }
                    done = true;
                    const p = prof || { id, name: "", username: "" };
                    if (code === 403 && /deactivated/i.test(desc)) {
                        dead++; p.dead = true; this.profiles.set(id, p); note(error); failed++;
                    } else if (code === 403) {
                        blocked++; p.blocked = true; this.profiles.set(id, p);
                    } else if (code === 400 && /chat not found|user not found|PEER_ID_INVALID/i.test(desc)) {
                        dead++; p.dead = true; this.profiles.set(id, p); note(error); failed++; // محادثة مش موجودة (مش هنحاول تاني)
                    } else {
                        failed++; note(error);
                        console.log("[BROADCAST] failed", id, code, desc || error?.message);
                    }
                }
            }
            if (!done) { failed++; reasons["Too Many Requests"] = (reasons["Too Many Requests"] || 0) + 1; }
            await new Promise((r) => setTimeout(r, 80));
        }
        this.saveProfiles();
        return { sent, failed, blocked, skipped, dead, reasons, total: this.totalUserIds().size };
    }

    stats() {
        const all = this.totalUserIds();
        const now = Date.now();
        let blocked = 0, today = 0, week = 0, legacy = 0, ar = 0, en = 0;
        const recent = [];
        for (const id of all) {
            const p = this.profiles.get(id);
            if (p?.blocked) blocked++;
            if (this.users.get(id)?.language === "en") en++; else ar++;
            if (!p || !p.joinedAt) { legacy++; continue; }
            if (now - p.joinedAt < 864e5) today++;
            if (now - p.joinedAt < 7 * 864e5) week++;
            recent.push(p);
        }
        recent.sort((a, b) => b.joinedAt - a.joinedAt);
        return { total: all.size, active: all.size - blocked, blocked, today, week, legacy, ar, en, recent: recent.slice(0, 5) };
    }

    async saveUsers() {
        try {
            const out = {};
            for (const [id, u] of this.users.entries()) out[id] = u.language;
            await fs.writeJSON(USERS_FILE, out, { spaces: 2 });
        } catch {}
    }

    getUser(id) {
        const key = String(id);
        if (!this.users.has(key)) {
            this.users.set(key, { language: "ar", state: "idle", promptId: null });
        }
        return this.users.get(key);
    }

    getLanguage(id) {
        return this.getUser(id).language === "en" ? "en" : "ar";
    }

    t(id, ar, en) {
        return this.getLanguage(id) === "en" ? en : ar;
    }

    escape(value) {
        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    // =========================================================
    // HELPERS
    // =========================================================

    normalizePhone(phone) {
        let clean = String(phone || "").replace(/[^\d+]/g, "");
        if (!clean.startsWith("+")) {
            if (clean.startsWith("00")) clean = "+" + clean.slice(2);
            else if (clean.startsWith("01")) clean = "+20" + clean.slice(1);
            else clean = "+" + clean;
        }
        return clean;
    }

    getSessionName(phone) {
        return this.normalizePhone(phone).replace("+", "");
    }

    formatCode(code) {
        const c = String(code || "").replace(/[^A-Za-z0-9]/g, "").toUpperCase();
        return c.length === 8 ? `${c.slice(0, 4)}-${c.slice(4)}` : c;
    }

    async tryDelete(chatId, messageId) {
        if (!chatId || !messageId) return;
        try { await this.telegram.telegram.deleteMessage(chatId, messageId); } catch {}
    }

    // =========================================================
    // 🎬 VIP HERO MEDIA — صورة/فيديو فوق كل شاشة
    // الملفات في media/telegram/ بالأسماء:
    //   menu / connect / status / settings / developer / channel / subscribe / success
    //   default  ← بتتستخدم لأي شاشة ملهاش ملف خاص
    // الامتدادات المدعومة: mp4 gif jpg jpeg png
    // لو مفيش ملفات بيستخدم media/menu.mp4 أو media/welcome.jpg، ولو مفيش خالص بيشتغل نص عادي.
    // =========================================================

    heroPath(screen, fallback = true) {
        const dir = path.join(process.cwd(), "media", "telegram");
        const find = (base) => {
            for (const ext of ["mp4", "gif", "jpg", "jpeg", "png"]) {
                const p = path.join(dir, `${base}.${ext}`);
                if (fs.existsSync(p)) return p;
            }
            return null;
        };
        let p = find(screen);
        if (!p && fallback) p = find("default");
        if (!p && fallback) {
            for (const f of ["menu.mp4", "welcome.jpg"]) {
                const lp = path.join(process.cwd(), "media", f);
                if (fs.existsSync(lp)) return lp;
            }
        }
        return p;
    }

    heroKind(p) {
        return /\.(mp4|gif)$/i.test(p) ? "animation" : "photo";
    }

    heroSource(p) {
        const key = `${p}:${fs.statSync(p).mtimeMs}`;
        return { key, src: this.heroFileIds.get(key) || { source: p } };
    }

    rememberHero(key, msg) {
        const fid = msg?.animation?.file_id || msg?.video?.file_id ||
            (Array.isArray(msg?.photo) ? msg.photo[msg.photo.length - 1]?.file_id : null) || msg?.document?.file_id;
        if (fid) this.heroFileIds.set(key, fid);
    }

    async sendHero(chatId, heroFile, caption, extra = {}) {
        const { key, src } = this.heroSource(heroFile);
        const opts = { caption, parse_mode: "HTML", ...extra };
        const sent = this.heroKind(heroFile) === "animation"
            ? await this.telegram.telegram.sendAnimation(chatId, src, opts)
            : await this.telegram.telegram.sendPhoto(chatId, src, opts);
        this.rememberHero(key, sent);
        this.heroMsg.set(`${chatId}:${sent.message_id}`, key);
        return sent;
    }

    // يعرض الشاشة: ميديا + كابشن (لو فيه ميديا) أو نص عادي. بيعدّل نفس الرسالة لو الضغط جه من زرار.
    async show(ctx, text, extra = {}) {
        const opts = { parse_mode: "HTML", disable_web_page_preview: true, ...extra };
        const cb = ctx.callbackQuery?.message;
        const cbIsMedia = !!(cb && (cb.photo || cb.video || cb.animation || cb.document));
        const hero = this.heroPath(ctx.screen || "menu");
        const plainLen = String(text).replace(/<[^>]+>/g, "").length;

        try {
            if (hero && plainLen <= 1000) {
                const { key, src } = this.heroSource(hero);
                const kind = this.heroKind(hero);
                const markup = extra.reply_markup ? { reply_markup: extra.reply_markup } : {};

                if (cbIsMedia) {
                    const mk = `${ctx.chat.id}:${cb.message_id}`;
                    if (this.heroMsg.get(mk) === key) {
                        return await ctx.editMessageCaption(text, { parse_mode: "HTML", ...markup });
                    }
                    const r = await ctx.editMessageMedia(
                        { type: kind, media: src, caption: text, parse_mode: "HTML" },
                        markup
                    );
                    this.heroMsg.set(mk, key);
                    if (r && typeof r === "object") this.rememberHero(key, r);
                    return r;
                }

                if (ctx.callbackQuery) await this.tryDelete(ctx.chat.id, cb?.message_id);
                const sent = await this.sendHero(ctx.chat.id, hero, text, markup);
                return sent;
            }

            if (ctx.callbackQuery) {
                if (cbIsMedia) {
                    await this.tryDelete(ctx.chat.id, cb.message_id);
                } else {
                    try {
                        return await ctx.editMessageText(text, opts);
                    } catch (error) {
                        if (/not modified/i.test(error.message || "")) return;
                    }
                }
            }
        } catch (error) {
            if (/not modified/i.test(error.message || "")) return;
            console.log("⚠️ Telegram media fallback:", error.message);
        }
        return ctx.reply(text, opts);
    }

    async editById(ctx, messageId, text, extra = {}) {
        const opts = { parse_mode: "HTML", disable_web_page_preview: true, ...extra };
        try {
            return await ctx.telegram.editMessageText(ctx.chat.id, messageId, undefined, text, opts);
        } catch {
            return ctx.reply(text, opts);
        }
    }

    // =========================================================
    // FORCE SUBSCRIPTION (اختياري)
    // =========================================================

    async isSubscribed(ctx) {
        if (!this.channel) return true;

        try {
            const member = await ctx.telegram.getChatMember(this.channel, ctx.from.id);
            return ["creator", "administrator", "member"].includes(member.status);
        } catch (error) {
            // لو البوت مش أدمن في القناة نسمح بالدخول بدل ما نقفل على الكل
            console.log("⚠️ Subscription check failed (allowing access):", error.message);
            return true;
        }
    }

    async requireSubscription(ctx) {
        if (await this.isSubscribed(ctx)) return true;
        ctx.screen = "subscribe";

        const id = String(ctx.from.id);

        await this.show(
            ctx,
            this.t(
                id,
                `👑 <b>SOFA BOT</b>\n${LINE}\n🔒 <b>الاشتراك الإجباري</b>\n\nلاستخدام <b>SOFA BOT</b>، يجب الاشتراك في قناة البوت أولاً.\n\n📢 اشترك في القناة ثم اضغط على <b>تحقق من الاشتراك</b>.\n\n<i>${SIGN}</i>`,
                `👑 <b>SOFA BOT</b>\n${LINE}\n🔒 <b>Mandatory Subscription</b>\n\nTo use <b>SOFA BOT</b>, you must join the bot's channel first.\n\n📢 Join the channel, then tap <b>Verify Subscription</b>.\n\n<i>${SIGN}</i>`
            ),
            Markup.inlineKeyboard([
                [Markup.button.url(this.t(id, "📢 اشترك في القناة", "📢 Join Channel"), this.channelUrl)],
                [Markup.button.callback(this.t(id, "✅ تحقق من الاشتراك", "✅ Verify Subscription"), "check_subscription")]
            ])
        );

        return false;
    }

    async checkAccess(ctx) {
        if (!ctx.from) return false;
        return this.requireSubscription(ctx);
    }

    // =========================================================
    // START
    // =========================================================

    async start() {
        if (this.started) return;

        await this.loadToken();
        await this.loadUsers();
        await this.loadProfiles();

        this.telegram = new Telegraf(this.token);

        this.registerMiddleware();
        this.registerCommands();
        this.registerActions();
        this.registerText();
        this.registerErrors();

        // التأكد من صحة التوكن (لو غلط هيرمي خطأ واضح)
        const me = await this.telegram.telegram.getMe();
        this.botUsername = me.username;

        await this.telegram.telegram
            .setMyCommands([
                { command: "start", description: "القائمة الرئيسية | Main menu" },
                { command: "install", description: "ربط واتساب | Link WhatsApp" },
                { command: "status", description: "الحالة | Status" },
                { command: "tasks", description: "المهام والجوايز | Tasks & rewards" }
            ])
            .catch(() => {});

        // وصف البوت (بيظهر في شاشة البوت قبل ما حد يدوس Start)
        const tg = this.telegram.telegram;
        await tg.setMyShortDescription("👑 SOFA BOT — Royal Edition | مركز تحكم واتساب VIP").catch(() => {});
        await tg.setMyShortDescription("👑 SOFA BOT — Royal Edition | VIP WhatsApp Control", "en").catch(() => {});
        await tg.setMyDescription("👑 SOFA BOT\n\nاربط رقم واتساب بنفسك في ثواني وتحكم في بوتك من هنا.\n⚡ أوامر كتير • ألعاب • ديني • إدارة جروبات\n\nاضغط START للبدء ✦ ROYAL EDITION • POWERED BY SOFA").catch(() => {});
        await tg.setMyDescription("👑 SOFA BOT\n\nLink your WhatsApp in seconds and control your bot from here.\n⚡ Tons of commands • Games • Islamic • Group admin\n\nTap START to begin ✦ POWERED BY SOFA", "en").catch(() => {});

        // launch بيفضل شغال طول الوقت، فمش بنعمله await عشان ما يعطلش باقي البوت
        this.telegram.launch({ dropPendingUpdates: true }).catch((error) => {
            console.log("❌ Telegram polling stopped:", error.message);
        });

        this.started = true;

        console.log(`🤖 SOFA BOT Telegram: ON (@${this.botUsername})`);
        console.log(`🔒 Force Subscription: ${this.channel ? "ON" : "OFF"}`);
        console.log("📱 WhatsApp Control: READY");
    }

    // =========================================================
    // MIDDLEWARE (خاص فقط)
    // =========================================================

    registerMiddleware() {
        this.telegram.use(async (ctx, next) => {
            if (ctx.chat && ctx.chat.type !== "private") return;

            // 🚫 المحظورين (الأونر مستثنى)
            if (ctx.from && isBannedTG(ctx.from.id) && !this.ownerIds().includes(String(ctx.from.id))) {
                if (ctx.message || ctx.callbackQuery) {
                    await ctx.reply("🚫 تم حظرك من استخدام البوت.").catch(() => {});
                }
                return;
            }

            if (ctx.updateType !== "my_chat_member") await this.trackUser(ctx).catch(() => {});
            return next();
        });

        // 🚫 لما حد يحظر البوت (أو يفك الحظر)
        this.telegram.on("my_chat_member", async (ctx) => {
            try {
                if (ctx.chat?.type !== "private") return;
                const status = ctx.myChatMember?.new_chat_member?.status;
                const id = String(ctx.from.id);
                const name = [ctx.from.first_name, ctx.from.last_name].filter(Boolean).join(" ").trim();
                const p = { ...(this.profiles.get(id) || { joinedAt: 0 }), id, name, username: ctx.from.username || "" };

                if (status === "kicked") {
                    p.blocked = true;
                    this.profiles.set(id, p);
                    this.saveProfiles();
                    this.notifyOwner(`🚫 تم حظر البوت بواسطة ${this.userTag(p)}\n🆔 <code>${id}</code>`);
                } else if (status === "member" && p.blocked) {
                    p.blocked = false;
                    this.profiles.set(id, p);
                    this.saveProfiles();
                    this.notifyOwner(`🔓 قام ${this.userTag(p)} بإلغاء حظر البوت\n🆔 <code>${id}</code>`);
                }
            } catch {}
        });
    }

    // =========================================================
    // COMMANDS
    // =========================================================

    registerCommands() {
        const guard = (fn) => async (ctx) => {
            if (!(await this.checkAccess(ctx))) return;
            return fn(ctx);
        };

        this.telegram.start(async (ctx) => {
            // لينك دعوة: https://t.me/<bot>?start=ref_<رقم الداعي>
            const payload = String(ctx.startPayload || "");
            if (payload.startsWith("ref_") && ctx.from && !this.bot.getPhoneByTelegramId(String(ctx.from.id))) {
                setPending(ctx.from.id, payload.slice(4));
            }
            if (!(await this.checkAccess(ctx))) return;
            return this.showMenu(ctx);
        });
        this.telegram.command("menu", guard((ctx) => this.showMenu(ctx)));
        this.telegram.command("install", guard((ctx) => this.connectMenu(ctx)));
        this.telegram.command("status", guard((ctx) => this.showStatus(ctx)));
        this.telegram.command("tasks", guard((ctx) => this.showTasks(ctx)));
    }

    // =========================================================
    // ACTIONS
    // =========================================================

    registerActions() {
        const guard = (fn) => async (ctx) => {
            await ctx.answerCbQuery().catch(() => {});
            if (!(await this.checkAccess(ctx))) return;
            return fn(ctx);
        };

        const bind = (name, fn) => this.telegram.action(name, guard(fn));

        bind("menu", (ctx) => {
            this.getUser(ctx.from.id).state = "idle";
            return this.showMenu(ctx);
        });
        bind("connect", (ctx) => this.connectMenu(ctx));
        bind("status", (ctx) => this.showStatus(ctx));
        bind("reconnect", (ctx) => this.reconnect(ctx));
        bind("disconnect", (ctx) => this.disconnectMenu(ctx));
        bind("confirm_disconnect", (ctx) => this.doDisconnect(ctx));
        bind("cancel_link", (ctx) => this.doDisconnect(ctx, true));
        bind("settings", (ctx) => this.showSettings(ctx));
        bind("developer", (ctx) => this.showDeveloper(ctx));
        bind("channel", (ctx) => this.showChannel(ctx));
        bind("tasks", (ctx) => this.showTasks(ctx));
        bind("verify_tasks", (ctx) => this.verifyTasks(ctx));

        bind("lang_ar", (ctx) => this.changeLanguage(ctx, "ar"));
        bind("lang_en", (ctx) => this.changeLanguage(ctx, "en"));

        bind("cancel", (ctx) => {
            this.getUser(ctx.from.id).state = "idle";
            return this.showMenu(ctx);
        });

        this.telegram.action("check_subscription", async (ctx) => {
            if (await this.isSubscribed(ctx)) {
                await ctx.answerCbQuery(this.t(ctx.from.id, "✅ تم التحقق", "✅ Verified")).catch(() => {});
                return this.showMenu(ctx);
            }
            await ctx
                .answerCbQuery(
                    this.t(ctx.from.id, "❌ لم يتم العثور على اشتراكك", "❌ Subscription not found"),
                    { show_alert: true }
                )
                .catch(() => {});
        });
    }

    // =========================================================
    // .مين — (للأونر بس) كل حسابات تليجرام المربوطة + أرقام واتساب بتاعتهم
    // =========================================================

    async showLinked(ctx) {
        const rows = [];
        for (const [phone, tgId] of this.bot.sessionOwners.entries()) {
            const id = String(tgId);
            const p = this.profiles.get(id) || {};
            const st = this.bot.getTelegramSessionStatus(id);
            rows.push({
                id,
                phone,
                user: p.username ? `@${this.escape(p.username)}` : "—",
                name: this.escape(p.name || ""),
                dot: st.connected ? "🟢" : st.connecting ? "🟡" : "🔴"
            });
        }

        if (!rows.length) return ctx.reply("❌ مفيش حسابات مربوطة.");

        const online = rows.filter((r) => r.dot === "🟢").length;
        const blocks = rows.map((r, i) =>
            `<b>${i + 1}.</b> ${r.dot} ${r.user}${r.name ? ` • ${r.name}` : ""}\n     🆔 <code>${r.id}</code>\n     📱 <code>+${this.escape(r.phone)}</code>`
        );
        const head = `👑 <b>الحسابات المربوطة</b>\n${LINE}\n`;
        const foot = `\n${LINE}\n🔢 العدد: <b>${rows.length}</b>\n🟢 متصل: <b>${online}</b> | 🔴 مش متصل: <b>${rows.length - online}</b>\n<i>${SIGN}</i>`;

        // تليجرام بيحدد 4096 حرف للرسالة الواحدة
        let chunk = head;
        const out = [];
        for (const b of blocks) {
            if ((chunk + b + foot).length > 3800) { out.push(chunk); chunk = ""; }
            chunk += b + "\n\n";
        }
        out.push(chunk + foot);
        for (const part of out) await ctx.reply(part, { parse_mode: "HTML", disable_web_page_preview: true });
    }

    // =========================================================
    // TEXT
    // =========================================================

    registerText() {
        this.telegram.on("text", async (ctx) => {
            // أمر الأونر: .مين
            if (/^[.\/!]?مين$/.test(String(ctx.message.text || "").trim()) && this.ownerIds().includes(String(ctx.from.id))) {
                return this.showLinked(ctx);
            }

            if (!(await this.checkAccess(ctx))) return;

            const id = String(ctx.from.id);
            const user = this.getUser(id);
            const text = String(ctx.message.text || "").trim();

            if (user.state === "phone" && !text.startsWith("/")) {
                return this.install(ctx, text);
            }

            return this.showMenu(ctx);
        });
    }

    // =========================================================
    // KEYBOARDS
    // =========================================================

    mainKeyboard(id) {
        const rows = [
            [Markup.button.callback(this.t(id, "🔗  ربط رقم واتساب", "🔗  Link WhatsApp"), "connect")],
            [
                Markup.button.callback(this.t(id, "📊 الحالة", "📊 Status"), "status"),
                Markup.button.callback(this.t(id, "🔄 إعادة الاتصال", "🔄 Reconnect"), "reconnect")
            ],
            [
                Markup.button.callback(this.t(id, "🔌 فصل الحساب", "🔌 Disconnect"), "disconnect"),
                Markup.button.callback(this.t(id, "⚙️ الإعدادات", "⚙️ Settings"), "settings")
            ]
        ];

        rows.push([Markup.button.callback(this.t(id, "🎁 المهام • 10,000 كوين", "🎁 Tasks • 10,000 coins"), "tasks")]);

        const last = [Markup.button.callback(this.t(id, "👨‍💻 المطور", "👨‍💻 Developer"), "developer")];
        if (this.channel) last.push(Markup.button.callback(this.t(id, "📢 القناة", "📢 Channel"), "channel"));
        rows.push(last);

        return Markup.inlineKeyboard(rows);
    }

    backKeyboard(id, extraRows = []) {
        return Markup.inlineKeyboard([
            ...extraRows,
            [Markup.button.callback(this.t(id, "🔙 القائمة الرئيسية", "🔙 Main Menu"), "menu")]
        ]);
    }

    // =========================================================
    // STATUS TEXT
    // =========================================================

    statusInfo(id) {
        const s = this.bot.getTelegramSessionStatus(String(id));

        let label;
        if (s.connected) label = this.t(id, "🟢 متصل", "🟢 Connected");
        else if (s.connecting) label = this.t(id, "🟡 جاري الاتصال...", "🟡 Connecting...");
        else if (s.exists) label = this.t(id, "🔴 غير متصل", "🔴 Disconnected");
        else label = this.t(id, "⚪ غير مربوط", "⚪ Not linked");

        const phone = s.phone ? `+${s.phone}` : this.t(id, "—", "—");

        return { ...s, label, phone };
    }

    // =========================================================
    // MENU
    // =========================================================

    async showMenu(ctx) {
        ctx.screen = "menu";
        const id = String(ctx.from.id);
        const s = this.statusInfo(id);
        const name = this.escape([ctx.from.first_name, ctx.from.last_name].filter(Boolean).join(" ").trim() || "VIP");

        return this.show(
            ctx,
            this.t(
                id,
                `👑 <b>${BOT_NAME}</b> 👑\n<i>${fancy("ROYAL EDITION")} • مركز تحكم واتساب</i>\n${LINE}\n<blockquote>👤 <b>أهلاً بيك:</b> ${name}\n📱 <b>الرقم:</b> <code>${this.escape(s.phone)}</code>\n📡 <b>الحالة:</b> ${s.label}</blockquote>\n${LINE}\n⚡ اختر من الأزرار بالأسفل 👇\n\n<i>${SIGN}</i>`,
                `👑 <b>${BOT_NAME}</b> 👑\n<i>${fancy("ROYAL EDITION")} • WhatsApp Control Center</i>\n${LINE}\n<blockquote>👤 <b>Welcome:</b> ${name}\n📱 <b>Number:</b> <code>${this.escape(s.phone)}</code>\n📡 <b>Status:</b> ${s.label}</blockquote>\n${LINE}\n⚡ Choose from the buttons below 👇\n\n<i>${SIGN}</i>`
            ),
            this.mainKeyboard(id)
        );
    }

    // =========================================================
    // CONNECT
    // =========================================================

    async connectMenu(ctx) {
        ctx.screen = "connect";
        const id = String(ctx.from.id);
        const user = this.getUser(id);
        const s = this.statusInfo(id);

        if (s.connected) {
            return this.show(
                ctx,
                this.t(
                    id,
                    `🟢 <b>حسابك متصل بالفعل</b>\n${LINE}\n📱 <code>${this.escape(s.phone)}</code>\n\nلو عايز تربط رقم تاني افصل الحساب الحالي أولاً.`,
                    `🟢 <b>Your account is already connected</b>\n${LINE}\n📱 <code>${this.escape(s.phone)}</code>\n\nDisconnect the current one first to link another number.`
                ),
                this.mainKeyboard(id)
            );
        }

        user.state = "phone";

        const sent = await this.show(
            ctx,
            this.t(
                id,
                `🔗 <b>ربط رقم واتساب</b>\n${LINE}\nابعت رقم واتساب مع كود الدولة.\n\n<b>مثال:</b> <code>+201222222222</code>\n\n💡 تقدر تكتبه بأي شكل وهيتظبط تلقائياً.\nبعدها هيوصلك <b>كود الربط</b> 🔐`,
                `🔗 <b>Link WhatsApp</b>\n${LINE}\nSend your WhatsApp number with country code.\n\n<b>Example:</b> <code>+201222222222</code>\n\n💡 Any format works, it will be auto-formatted.\nYou will then receive your <b>pairing code</b> 🔐`
            ),
            Markup.inlineKeyboard([[Markup.button.callback(this.t(id, "❌ إلغاء", "❌ Cancel"), "cancel")]])
        );

        user.promptId = ctx.callbackQuery?.message?.message_id || sent?.message_id || null;
    }

    // =========================================================
    // INSTALL
    // =========================================================

    async install(ctx, input) {
        const id = String(ctx.from.id);
        const user = this.getUser(id);

        // نمسح رسالة الرقم عشان الشات يفضل نضيف
        await this.tryDelete(ctx.chat.id, ctx.message?.message_id);

        const formatted = this.normalizePhone(input);
        const phone = this.getSessionName(formatted);

        if (phone.length < 8 || phone.length > 15) {
            return ctx.reply(
                this.t(
                    id,
                    "❌ <b>رقم غير صالح</b>\nابعت الرقم مرة تانية مع كود الدولة.",
                    "❌ <b>Invalid number</b>\nSend it again with the country code."
                ),
                {
                    parse_mode: "HTML",
                    ...Markup.inlineKeyboard([[Markup.button.callback(this.t(id, "❌ إلغاء", "❌ Cancel"), "cancel")]])
                }
            );
        }

        if (this.busy.has(id)) return;

        const linkedPhone = this.bot.getPhoneByTelegramId(id);
        if (linkedPhone && linkedPhone !== phone) {
            user.state = "idle";
            return ctx.reply(
                this.t(
                    id,
                    `⚠️ <b>حسابك مربوط برقم تاني</b>\n${LINE}\n📱 <code>+${this.escape(linkedPhone)}</code>\n\nافصله أولاً من زر «فصل الحساب» لو عايز تربط رقم جديد.`,
                    `⚠️ <b>Your account is linked to another number</b>\n${LINE}\n📱 <code>+${this.escape(linkedPhone)}</code>\n\nDisconnect it first to link a new number.`
                ),
                { parse_mode: "HTML", ...this.mainKeyboard(id) }
            );
        }

        const owner = this.bot.sessionOwners?.get(phone);
        if (owner && String(owner) !== id) {
            user.state = "idle";
            return ctx.reply(
                this.t(
                    id,
                    `⚠️ <b>الرقم مربوط بحساب تليجرام تاني</b>\n${LINE}\n📱 <code>${this.escape(formatted)}</code>`,
                    `⚠️ <b>This number is linked to another Telegram account</b>\n${LINE}\n📱 <code>${this.escape(formatted)}</code>`
                ),
                { parse_mode: "HTML", ...this.mainKeyboard(id) }
            );
        }

        user.state = "idle";
        await this.tryDelete(ctx.chat.id, user.promptId);
        user.promptId = null;

        this.busy.add(id);

        const loading = await ctx.reply(
            this.t(
                id,
                `⏳ <b>جاري إنشاء جلسة واتساب...</b>\n<i>ممكن ياخد لحد 30 ثانية</i>`,
                `⏳ <b>Creating WhatsApp session...</b>\n<i>This may take up to 30 seconds</i>`
            ),
            { parse_mode: "HTML" }
        );

        try {
            // الترتيب (phone, telegramId)
            const result = await this.bot.createWhatsAppSession(phone, id);

            if (result?.connected) {
                return await this.editById(
                    ctx,
                    loading.message_id,
                    this.t(
                        id,
                        `🟢 <b>الحساب متصل بنجاح</b>\n${LINE}\n📱 <code>${this.escape(formatted)}</code>`,
                        `🟢 <b>Account connected</b>\n${LINE}\n📱 <code>${this.escape(formatted)}</code>`
                    ),
                    this.mainKeyboard(id)
                );
            }

            if (!result?.pairingCode) throw new Error("لم يتم الحصول على Pairing Code");

            const code = this.formatCode(result.pairingCode);

            // كارت VIP لكود الربط (لو فشل بنرجع للنص العادي)
            const pairText = this.t(
                id,
                `🔐 <b>كود الربط جاهز</b>\n${LINE}\n📱 <b>الرقم:</b> <code>${this.escape(formatted)}</code>\n\n🔑 <b>الكود:</b> <code>${this.escape(code)}</code>\n<i>(اضغط على الكود لنسخه)</i>\n${LINE}\n<b>طريقة الربط:</b>\n1️⃣ افتح واتساب\n2️⃣ الأجهزة المرتبطة\n3️⃣ ربط جهاز\n4️⃣ الربط برقم الهاتف بدلاً من ذلك\n5️⃣ اكتب الكود\n\n⏱ الكود صالح لدقائق قليلة، وهبلغك أول ما الاتصال يتم.`,
                `🔐 <b>Pairing code ready</b>\n${LINE}\n📱 <b>Number:</b> <code>${this.escape(formatted)}</code>\n\n🔑 <b>Code:</b> <code>${this.escape(code)}</code>\n<i>(tap the code to copy)</i>\n${LINE}\n<b>How to link:</b>\n1️⃣ Open WhatsApp\n2️⃣ Linked Devices\n3️⃣ Link a Device\n4️⃣ Link with phone number instead\n5️⃣ Enter the code\n\n⏱ The code is valid for a few minutes. I'll notify you once connected.`
            );
            const pairKb = Markup.inlineKeyboard([
                [
                    Markup.button.callback(this.t(id, "📊 تحديث الحالة", "📊 Refresh"), "status"),
                    Markup.button.callback(this.t(id, "❌ إلغاء الربط", "❌ Cancel link"), "cancel_link")
                ],
                [Markup.button.callback(this.t(id, "🔙 القائمة الرئيسية", "🔙 Main Menu"), "menu")]
            ]);
            try {
                const card = await pairCard({ code, phone: formatted });
                if (card) {
                    const sentCard = await ctx.replyWithPhoto({ source: card }, { caption: pairText, parse_mode: "HTML", ...pairKb });
                    await this.tryDelete(ctx.chat.id, loading.message_id);
                    return sentCard;
                }
            } catch (error) {
                console.log("⚠️ Telegram pair card failed:", error.message);
            }

            return await this.editById(
                ctx,
                loading.message_id,
                this.t(
                    id,
                    `🔐 <b>كود الربط جاهز</b>\n${LINE}\n📱 <b>الرقم:</b> <code>${this.escape(formatted)}</code>\n\n🔑 <b>الكود:</b>\n<code>${this.escape(code)}</code>\n<i>(اضغط على الكود لنسخه)</i>\n${LINE}\n<b>طريقة الربط:</b>\n1️⃣ افتح واتساب\n2️⃣ الأجهزة المرتبطة\n3️⃣ ربط جهاز\n4️⃣ الربط برقم الهاتف بدلاً من ذلك\n5️⃣ اكتب الكود\n\n⏱ الكود صالح لدقائق قليلة، وهبلغك أول ما الاتصال يتم.`,
                    `🔐 <b>Pairing code ready</b>\n${LINE}\n📱 <b>Number:</b> <code>${this.escape(formatted)}</code>\n\n🔑 <b>Code:</b>\n<code>${this.escape(code)}</code>\n<i>(tap the code to copy)</i>\n${LINE}\n<b>How to link:</b>\n1️⃣ Open WhatsApp\n2️⃣ Linked Devices\n3️⃣ Link a Device\n4️⃣ Link with phone number instead\n5️⃣ Enter the code\n\n⏱ The code is valid for a few minutes. I'll notify you once connected.`
                ),
                Markup.inlineKeyboard([
                    [
                        Markup.button.callback(this.t(id, "📊 تحديث الحالة", "📊 Refresh"), "status"),
                        Markup.button.callback(this.t(id, "❌ إلغاء الربط", "❌ Cancel link"), "cancel_link")
                    ],
                    [Markup.button.callback(this.t(id, "🔙 القائمة الرئيسية", "🔙 Main Menu"), "menu")]
                ])
            );
        } catch (error) {
            console.log(`❌ Connection error [${phone}]:`, error.message);

            return await this.editById(
                ctx,
                loading.message_id,
                this.t(
                    id,
                    `❌ <b>فشل الاتصال</b>\n${LINE}\n<code>${this.escape(error.message)}</code>\n\nجرّب مرة تانية بعد شوية.`,
                    `❌ <b>Connection failed</b>\n${LINE}\n<code>${this.escape(error.message)}</code>\n\nTry again in a moment.`
                ),
                Markup.inlineKeyboard([
                    [Markup.button.callback(this.t(id, "🔁 حاول مرة تانية", "🔁 Try again"), "connect")],
                    [Markup.button.callback(this.t(id, "🔙 القائمة الرئيسية", "🔙 Main Menu"), "menu")]
                ])
            );
        } finally {
            this.busy.delete(id);
        }
    }

    // =========================================================
    // STATUS
    // =========================================================

    async showStatus(ctx) {
        ctx.screen = "status";
        const id = String(ctx.from.id);
        const s = this.statusInfo(id);

        return this.show(
            ctx,
            this.t(
                id,
                `📊 <b>حالة الاتصال</b>\n${LINE}\n<blockquote>📱 <b>الرقم:</b> <code>${this.escape(s.phone)}</code>\n📁 <b>الجلسة:</b> ${s.exists ? "✅ موجودة" : "❌ غير موجودة"}\n📡 <b>واتساب:</b> ${s.label}</blockquote>\n${LINE}\n<i>${SIGN}</i>`,
                `📊 <b>Connection status</b>\n${LINE}\n<blockquote>📱 <b>Number:</b> <code>${this.escape(s.phone)}</code>\n📁 <b>Session:</b> ${s.exists ? "✅ Exists" : "❌ Not found"}\n📡 <b>WhatsApp:</b> ${s.label}</blockquote>\n${LINE}\n<i>${SIGN}</i>`
            ),
            this.backKeyboard(id, [[Markup.button.callback(this.t(id, "🔃 تحديث", "🔃 Refresh"), "status")]])
        );
    }

    // =========================================================
    // DISCONNECT
    // =========================================================

    async disconnectMenu(ctx) {
        const id = String(ctx.from.id);
        const s = this.statusInfo(id);

        if (!s.exists) {
            return this.show(
                ctx,
                this.t(id, "ℹ️ <b>مفيش جلسة مربوطة بحسابك.</b>", "ℹ️ <b>No session is linked to your account.</b>"),
                this.mainKeyboard(id)
            );
        }

        return this.show(
            ctx,
            this.t(
                id,
                `⚠️ <b>فصل الحساب</b>\n${LINE}\n📱 <code>${this.escape(s.phone)}</code>\n\nهيتم فصل واتساب وحذف الجلسة بالكامل.\nمتأكد إنك عايز تكمل؟`,
                `⚠️ <b>Disconnect</b>\n${LINE}\n📱 <code>${this.escape(s.phone)}</code>\n\nWhatsApp will be disconnected and the whole session deleted.\nAre you sure?`
            ),
            Markup.inlineKeyboard([
                [
                    Markup.button.callback(this.t(id, "🗑️ نعم، احذف", "🗑️ Yes, delete"), "confirm_disconnect"),
                    Markup.button.callback(this.t(id, "❌ إلغاء", "❌ Cancel"), "cancel")
                ]
            ])
        );
    }

    async doDisconnect(ctx, silentCancel = false) {
        const id = String(ctx.from.id);

        try {
            await this.bot.disconnectWhatsAppSession(id);
            this.getUser(id).state = "idle";

            return this.show(
                ctx,
                silentCancel
                    ? this.t(id, "❌ <b>تم إلغاء عملية الربط.</b>", "❌ <b>Linking cancelled.</b>")
                    : this.t(
                          id,
                          "🗑️ <b>تم فصل واتساب وحذف الجلسة.</b>\n\nتقدر تربط من جديد من زر «ربط رقم واتساب».",
                          "🗑️ <b>WhatsApp disconnected and session deleted.</b>\n\nYou can link again from “Link WhatsApp”."
                      ),
                this.mainKeyboard(id)
            );
        } catch (error) {
            return this.show(ctx, `❌ <code>${this.escape(error.message)}</code>`, this.mainKeyboard(id));
        }
    }

    // =========================================================
    // RECONNECT
    // =========================================================

    async reconnect(ctx) {
        const id = String(ctx.from.id);
        const s = this.statusInfo(id);

        if (!s.exists) {
            return this.show(
                ctx,
                this.t(
                    id,
                    "❌ <b>مفيش جلسة محفوظة لإعادة الاتصال.</b>\n\nاستخدم «ربط رقم واتساب».",
                    "❌ <b>No saved session to reconnect.</b>\n\nUse “Link WhatsApp”."
                ),
                this.mainKeyboard(id)
            );
        }

        try {
            const result = await this.bot.reconnectWhatsAppSession(id);

            return this.show(
                ctx,
                result?.connected
                    ? this.t(id, "🟢 <b>الحساب متصل بالفعل.</b>", "🟢 <b>Already connected.</b>")
                    : this.t(
                          id,
                          "🟡 <b>بدأت إعادة الاتصال.</b>\nهبلغك أول ما يتصل.",
                          "🟡 <b>Reconnection started.</b>\nI'll notify you once connected."
                      ),
                this.backKeyboard(id, [[Markup.button.callback(this.t(id, "📊 الحالة", "📊 Status"), "status")]])
            );
        } catch (error) {
            return this.show(ctx, `❌ <code>${this.escape(error.message)}</code>`, this.mainKeyboard(id));
        }
    }

    // =========================================================
    // SETTINGS
    // =========================================================

    async showSettings(ctx) {
        ctx.screen = "settings";
        const id = String(ctx.from.id);
        const lang = this.getLanguage(id);

        return this.show(
            ctx,
            this.t(
                id,
                `⚙️ <b>الإعدادات</b>\n${LINE}\n🌐 اختر لغة البوت:`,
                `⚙️ <b>Settings</b>\n${LINE}\n🌐 Choose the bot language:`
            ),
            Markup.inlineKeyboard([
                [
                    Markup.button.callback(`${lang === "ar" ? "✅ " : ""}🇪🇬 العربية`, "lang_ar"),
                    Markup.button.callback(`${lang === "en" ? "✅ " : ""}🇺🇸 English`, "lang_en")
                ],
                [Markup.button.callback(this.t(id, "🔙 القائمة الرئيسية", "🔙 Main Menu"), "menu")]
            ])
        );
    }

    async changeLanguage(ctx, language) {
        const id = String(ctx.from.id);
        this.getUser(id).language = language === "en" ? "en" : "ar";
        await this.saveUsers();
        return this.showSettings(ctx);
    }

    // =========================================================
    // DEVELOPER / CHANNEL
    // =========================================================

    async showDeveloper(ctx) {
        ctx.screen = "developer";
        const id = String(ctx.from.id);

        const rows = [
            [Markup.button.url(this.t(id, "🧑🏻‍💻 المطور", "🧑🏻‍💻 Developer"), `https://t.me/${DEV_TG}`)],
            [Markup.button.url(this.t(id, "🤖 بوت سوفا", "🤖 SOFA BOT"), `https://t.me/${DEV_BOT}`)],
            [
                Markup.button.url(this.t(id, "🌌 قناة تليجرام", "🌌 Telegram"), TG_CHANNEL_URL),
                Markup.button.url(this.t(id, "📢 قناة واتساب", "📢 WhatsApp"), WA_CHANNEL_URL)
            ],
            [
                Markup.button.url("🎵 TikTok", TIKTOK_URL),
                Markup.button.url("💬 WhatsApp", `https://wa.me/${DEV_WA_NUMBER}`)
            ]
        ];

        return this.show(
            ctx,
            this.t(
                id,
                `👑 <b>SOFA DEVELOPER</b>\n${LINE}\n<blockquote>👨🏻‍💻 <b>المطور:</b> 𝑺𝑶𝑭𝑨\n👑 <b>BOT OWNER</b>\n⚡ SOFA VIP SYSTEM • Egypt 🇪🇬</blockquote>\n${LINE}\n<i>${SIGN}</i>`,
                `👑 <b>SOFA DEVELOPER</b>\n${LINE}\n<blockquote>👨🏻‍💻 <b>Developer:</b> 𝑺𝑶𝑭𝑨\n👑 <b>BOT OWNER</b>\n⚡ SOFA VIP SYSTEM • Egypt 🇪🇬</blockquote>\n${LINE}\n<i>${SIGN}</i>`
            ),
            this.backKeyboard(id, rows)
        );
    }

    async showChannel(ctx) {
        ctx.screen = "channel";
        const id = String(ctx.from.id);

        if (!this.channel) return this.showMenu(ctx);

        return this.show(
            ctx,
            this.t(
                id,
                `📢 <b>القناة الرسمية</b>\n${LINE}\nتابع القناة لمعرفة كل جديد عن ${BOT_NAME}.\n\n${this.escape(this.channel)}`,
                `📢 <b>Official channel</b>\n${LINE}\nFollow the channel for ${BOT_NAME} updates.\n\n${this.escape(this.channel)}`
            ),
            this.backKeyboard(id, [[Markup.button.url(this.t(id, "📢 فتح القناة", "📢 Open Channel"), this.channelUrl)]])
        );
    }


    // =========================================================
    // TASKS — متابعة القناتين = 5000 كوين لكل مهمة
    // =========================================================

    numberOfTg(id) {
        return this.bot.getPhoneByTelegramId(String(id)) || "";
    }

    tasksKeyboard(id) {
        return Markup.inlineKeyboard([
            [Markup.button.url(this.t(id, "📢 قناة التليجرام", "📢 Telegram Channel"), TASK_TG_URL)],
            [Markup.button.url(this.t(id, "💬 قناة الواتساب", "💬 WhatsApp Channel"), TASK_WA_URL)],
            [Markup.button.callback(this.t(id, "✅ تحقق واستلم الجوائز", "✅ Verify & Claim"), "verify_tasks")],
            [Markup.button.callback(this.t(id, "🔙 القائمة الرئيسية", "🔙 Main Menu"), "menu")]
        ]);
    }

    tasksText(id, extra = "") {
        const num = this.numberOfTg(id);
        const st = taskState(id, num);
        const mark = (d) => (d ? "✅" : "⬜");
        const coin = TASK_REWARD.toLocaleString("en-US");
        return this.t(
            id,
            `🎁 <b>المهام والجوائز</b>\n${LINE}\n<blockquote>${mark(st.tg)} <b>المهمة 1:</b> تابع قناة التليجرام\n     🎁 <b>${coin}</b> كوين\n\n${mark(st.wa)} <b>المهمة 2:</b> تابع قناة الواتساب\n     🎁 <b>${coin}</b> كوين</blockquote>\n${LINE}\n1️⃣ اضغط على زر كل قناة واشترك.\n2️⃣ ارجع واضغط <b>تحقق واستلم الجوائز</b>.\n\n⚠️ <i>الكوين بتنزل على رقم الواتساب المربوط (لازم يكون مربوط ومسجّل بـ .تسجيل). والجايزة مرة واحدة لكل مهمة.</i>${extra ? `\n\n${extra}` : ""}\n\n<i>${SIGN}</i>`,
            `🎁 <b>Tasks & Rewards</b>\n${LINE}\n<blockquote>${mark(st.tg)} <b>Task 1:</b> Follow the Telegram channel\n     🎁 <b>${coin}</b> coins\n\n${mark(st.wa)} <b>Task 2:</b> Follow the WhatsApp channel\n     🎁 <b>${coin}</b> coins</blockquote>\n${LINE}\n1️⃣ Tap each channel button and join.\n2️⃣ Come back and tap <b>Verify & Claim</b>.\n\n⚠️ <i>Coins go to your linked WhatsApp number (it must be linked and registered with .تسجيل). Each reward can be claimed once.</i>${extra ? `\n\n${extra}` : ""}\n\n<i>${SIGN}</i>`
        );
    }

    async showTasks(ctx, extra = "") {
        ctx.screen = "tasks";
        const id = String(ctx.from.id);
        return this.show(ctx, this.tasksText(id, extra), this.tasksKeyboard(id));
    }

    async verifyTasks(ctx) {
        const id = String(ctx.from.id);
        const lines = [];
        const number = this.numberOfTg(id);

        if (!number) {
            return this.showTasks(ctx, this.t(id,
                "❌ <b>اربط رقم الواتساب الأول</b> (من القائمة الرئيسية) عشان الكوين تنزل عليه.",
                "❌ <b>Link your WhatsApp number first</b> (main menu) so the coins can be sent to it."));
        }
        if (!isRegistered(number)) {
            return this.showTasks(ctx, this.t(id,
                "❌ رقمك مش مسجّل. ابعت <b>.تسجيل</b> على الواتساب الأول وبعدين اضغط تحقق.",
                "❌ Your number is not registered. Send <b>.تسجيل</b> on WhatsApp first, then verify again."));
        }

        let state = taskState(id, number);

        // ── مهمة 1: قناة التليجرام (تحقق حقيقي بـ getChatMember — لازم البوت يكون أدمن في القناة)
        if (!state.tg) {
            let status = null;
            try {
                const m = await ctx.telegram.getChatMember(TG_CHANNEL, ctx.from.id);
                status = ["creator", "administrator", "member"].includes(m.status);
            } catch (e) {
                console.log("⚠️ Task TG check failed:", e.message);
            }
            if (status === true) {
                const r = claimTask(id, number, "tg");
                lines.push(r.ok
                    ? this.t(id, `✅ تابعت قناة التليجرام: <b>+${TASK_REWARD.toLocaleString("en-US")}</b> كوين`, `✅ Telegram channel followed: <b>+${TASK_REWARD.toLocaleString("en-US")}</b> coins`)
                    : this.t(id, "⚠️ تعذر صرف جايزة التليجرام، جرّب تاني.", "⚠️ Couldn't pay the Telegram reward, try again."));
            } else if (status === false) {
                lines.push(this.t(id, "❌ لسه مش متابع قناة التليجرام.", "❌ You haven't joined the Telegram channel yet."));
            } else {
                lines.push(this.t(id, "⚠️ مقدرتش أتحقق من قناة التليجرام دلوقتي، جرّب بعد شوية.", "⚠️ Couldn't verify the Telegram channel right now, try later."));
            }
        }

        // ── مهمة 2: قناة الواتساب (التحقق من خلال جلسة الواتساب المربوطة بتاعتك)
        if (!state.wa) {
            const session = this.bot.sessions.get(number);
            if (!session?.isConnected || !session?.sock) {
                lines.push(this.t(id, "⚠️ رقم الواتساب مش متصل دلوقتي — اضغط 🔄 إعادة الاتصال من القائمة وجرّب تاني.", "⚠️ Your WhatsApp is not connected — use Reconnect from the menu and try again."));
            } else {
                const following = await isFollowingWaChannel(session.sock);
                if (following === true) {
                    const r = claimTask(id, number, "wa");
                    lines.push(r.ok
                        ? this.t(id, `✅ تابعت قناة الواتساب: <b>+${TASK_REWARD.toLocaleString("en-US")}</b> كوين`, `✅ WhatsApp channel followed: <b>+${TASK_REWARD.toLocaleString("en-US")}</b> coins`)
                        : this.t(id, "⚠️ تعذر صرف جايزة الواتساب، جرّب تاني.", "⚠️ Couldn't pay the WhatsApp reward, try again."));
                } else if (following === false) {
                    lines.push(this.t(id, "❌ رقمك لسه مش متابع قناة الواتساب.", "❌ Your number hasn't followed the WhatsApp channel yet."));
                } else {
                    lines.push(this.t(id, "⚠️ مقدرتش أتحقق من قناة الواتساب دلوقتي، جرّب بعد شوية.", "⚠️ Couldn't verify the WhatsApp channel right now, try later."));
                }
            }
        }

        state = taskState(id, number);
        if (state.tg && state.wa && !lines.length) {
            lines.push(this.t(id, "🏆 خلصت كل المهام واستلمت كل الجوائز!", "🏆 All tasks done and all rewards claimed!"));
        }
        return this.showTasks(ctx, lines.join("\n"));
    }


    // الداعي ياخد كوين لما المدعو يربط رقمه (مرة واحدة لكل رقم)
    handleReferral(tgId, phone) {
        try {
            const r = rewardOnLink(tgId, String(phone || ""));
            if (!r) return;
            const inviterTg = this.bot.sessionOwners.get(r.inviter);
            if (inviterTg) {
                this.telegram.telegram.sendMessage(inviterTg,
                    `🤝 <b>دعوة ناجحة!</b>\nصديق ربط رقمه من لينكك: <b>+${REF_REWARD.toLocaleString("en-US")}</b> كوين 🎁\n💰 رصيدك: <b>${r.coins.toLocaleString("en-US")}</b>`,
                    { parse_mode: "HTML" }).catch(() => {});
            }
            const sess = this.bot.sessions.get(r.inviter);
            if (sess?.isConnected && sess.sock) {
                sess.sock.sendMessage(`${r.inviter}@s.whatsapp.net`, { text: `🤝 *دعوة ناجحة!*\nصديق ربط رقمه من لينكك: \`+${REF_REWARD.toLocaleString("en-US")}\` كوين 🎁\n💰 رصيدك: \`${r.coins.toLocaleString("en-US")}\`` }).catch(() => {});
            }
        } catch (e) { console.log("⚠️ referral:", e.message); }
    }

    // =========================================================
    // WHATSAPP NOTIFICATIONS
    // =========================================================

    async notifyTelegram(telegramId, event) {
        if (!this.telegram) return;

        const id = String(telegramId);
        const phone = event?.phone ? `+${event.phone}` : "";
        const phoneLine = phone ? `\n📱 <code>${this.escape(phone)}</code>` : "";

        let text = "";

        switch (event?.type) {
            case "connected":
                this.handleReferral(id, event?.phone);
                text = this.t(
                    id,
                    `👑 <b>تم الاتصال بنجاح</b>\n${LINE}\n🟢 واتساب متصل الآن${phoneLine}\n\n🤖 <b>${BOT_NAME} شغال</b>\n<i>${SIGN}</i>`,
                    `👑 <b>Connected successfully</b>\n${LINE}\n🟢 WhatsApp is now connected${phoneLine}\n\n🤖 <b>${BOT_NAME} is running</b>\n<i>${SIGN}</i>`
                );
                break;

            case "disconnected":
                text = this.t(
                    id,
                    `🔴 <b>انقطع اتصال واتساب</b>${phoneLine}\n\nالنظام بيحاول يعيد الاتصال تلقائياً.`,
                    `🔴 <b>WhatsApp disconnected</b>${phoneLine}\n\nThe system is trying to reconnect automatically.`
                );
                break;

            case "logged_out":
                text = this.t(
                    id,
                    `⚠️ <b>تم تسجيل خروج واتساب</b>${phoneLine}\n\nتم حذف الجلسة، اربط من جديد.`,
                    `⚠️ <b>WhatsApp was logged out</b>${phoneLine}\n\nThe session was deleted, please link again.`
                );
                break;

            case "replaced":
                text = this.t(
                    id,
                    `⚠️ <b>تم استبدال اتصال واتساب</b>${phoneLine}\n\nالحساب اتفتح من مكان تاني.`,
                    `⚠️ <b>WhatsApp connection was replaced</b>${phoneLine}\n\nThe account was opened elsewhere.`
                );
                break;

            default:
                return;
        }

        try {
            const hero = event?.type === "connected" ? this.heroPath("success", false) : null;
            if (hero) {
                try {
                    await this.sendHero(id, hero, text, this.mainKeyboard(id));
                    return;
                } catch (error) {
                    console.log("⚠️ Telegram success media failed:", error.message);
                }
            }
            await this.telegram.telegram.sendMessage(id, text, {
                parse_mode: "HTML",
                ...this.mainKeyboard(id)
            });
        } catch (error) {
            console.log("❌ Telegram notification:", error.message);
        }
    }

    // =========================================================
    // ERRORS / STOP
    // =========================================================

    registerErrors() {
        this.telegram.catch((error, ctx) => {
            console.log(`❌ Telegram error [${ctx?.from?.id || "unknown"}]:`, error.message);
        });
    }

    async stop() {
        if (!this.telegram) return;
        try { this.telegram.stop("shutdown"); } catch {}
        this.started = false;
    }
}

export default TelegramBot;
