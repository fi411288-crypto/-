"use strict";

import fs from "fs-extra";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const source = path.join(__dirname, "socket.js");

const target = path.join(
    process.cwd(),
    "node_modules",
    "@whiskeysockets",
    "baileys",
    "lib",
    "Socket",
    "socket.js"
);

async function changeSocket() {
    if (!(await fs.pathExists(source))) {
        throw new Error("Change/socket.js not found");
    }

    if (!(await fs.pathExists(target))) {
        throw new Error("Baileys socket.js not found");
    }

    await fs.copyFile(source, target);
}

await changeSocket();