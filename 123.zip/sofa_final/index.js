"use strict";

import "./lib/heap.js";
import { attachWelcome } from "./lib/welcome.js";
import { addChannelContext } from "./lib/channelForward.js";
import fs from "fs-extra";
import path from "path";
import pino from "pino";
import chalk from "chalk";
import gradient from "gradient-string";
import os from "os";
import { randomInt } from "crypto";

const logger = pino({ level: process.env.WA_LOG || "silent" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class SofaBot {
    constructor() {
        this.sessions = new Map();
        this.sessionOwners = new Map();
        this.config = null;
        this.telegram = null;
        this.startTime = Date.now();
        this.version = "v2.0 🔥";
        this.maxRetries = 10;

        this.directories = {
            sessions: path.join(process.cwd(), "sessions"),
            plugins: path.join(process.cwd(), "plugins"),
            data: path.join(process.cwd(), "data"),
            media: path.join(process.cwd(), "media")
        };

        this.sessionOwnersFile = path.join(this.directories.data, "sessionOwners.json");

        global.bot = this;
    }

    // ---------- توافق مع الـ plugins القديمة اللي بتستخدم global.bot.sock ----------
    get firstSession() {
        for (const s of this.sessions.values()) if (s.isConnected) return s;
        return this.sessions.values().next().value || null;
    }
    get sock() { return this.firstSession?.sock || null; }
    get isConnected() { return !!this.firstSession?.isConnected; }
    get handler() { return this.firstSession?.handler || null; }
    get messages() { return this.firstSession?.messages || null; }
    get console() { return this.firstSession?.console || null; }

    // =========================================================
    // INITIALIZE
    // =========================================================

    async initialize() {
        console.clear();
        this.showBanner();
        this.createDirectories();
        await this.loadConfig();
        await this.loadSessionOwners();

        // الإصلاح: استرجاع الجلسات الأول، لأن telegram.start() ممكن ما يخلصش أبداً (launch)
        await this.restoreSessions();

        console.log(chalk.green("\n🎉 SOFA BOT is fully operational!"));

        await this.startTelegram();
    }

    showBanner() {
        const uptime = ((Date.now() - this.startTime) / 1000).toFixed(0);
        console.log(gradient.cristal(`
   ╔════════════════════════════════════════════╗
   ║           𓆩 𝐒𝐎𝐅𝐀 𝐁𝐎𝐓 SYSTEM 𓆪          ║
   ║          Developed by 𝐒𝐎𝐅𝐀              ║
   ║           Contact: +201018766845          ║
   ╚════════════════════════════════════════════╝
        `));
        console.log(chalk.cyanBright("🚀 Starting advanced WhatsApp bot..."));
        console.log(chalk.yellowBright(`⚡ Version: ${this.version} | Uptime: ${uptime}s | OS: ${os.type()} ${os.release()}`));
        console.log(chalk.magentaBright("──────────────────────────────────────────\n"));
    }

    createDirectories() {
        Object.values(this.directories).forEach((dir) => fs.ensureDirSync(dir));
        if (!fs.existsSync(this.sessionOwnersFile)) {
            fs.writeJSONSync(this.sessionOwnersFile, {}, { spaces: 4 });
        }
    }

    async loadConfig() {
        try {
            const { config } = await import("./config.js");
            this.config = config;
            if (!this.config.PREFIX) this.config.PREFIX = ".";
            console.log(chalk.green("✅ Config loaded"));
        } catch (error) {
            console.log(chalk.red("❌ Config load FAILED (using defaults):"), error);
            this.config = { PREFIX: ".", OWNER_NUMBER: "", OWNER_NUMBERS: [], DEVELOPERS: [], DEV_ONLY_COMMANDS: [], SECURITY: { BLOCKED_USERS: [] } };
        }
    }

    // =========================================================
    // SESSION OWNERS
    // =========================================================

    async loadSessionOwners() {
        try {
            const data = await fs.readJSON(this.sessionOwnersFile);
            this.sessionOwners.clear();
            if (data && typeof data === "object") {
                for (const [phone, telegramId] of Object.entries(data)) {
                    if (phone && telegramId !== undefined && telegramId !== null) {
                        this.sessionOwners.set(String(phone), String(telegramId));
                    }
                }
            }
            console.log(chalk.green(`✅ Session owners loaded: ${this.sessionOwners.size}`));
        } catch (error) {
            console.log(chalk.yellow("⚠️ Could not load session owners:"), error.message);
            this.sessionOwners.clear();
        }
    }

    async saveSessionOwners() {
        const data = {};
        for (const [phone, telegramId] of this.sessionOwners.entries()) data[phone] = String(telegramId);
        await fs.writeJSON(this.sessionOwnersFile, data, { spaces: 4 });
    }

    // =========================================================
    // HELPERS
    // =========================================================

    normalizePhone(phone) {
        return String(phone || "").replace(/\D/g, "");
    }

    getSessionPath(phone) {
        return path.join(this.directories.sessions, this.normalizePhone(phone));
    }

    getPhoneByTelegramId(telegramId) {
        const id = String(telegramId);
        for (const [phone, ownerId] of this.sessionOwners.entries()) {
            if (String(ownerId) === id) return phone;
        }
        return null;
    }

    async getBaileys() {
        return await import("@whiskeysockets/baileys");
    }

    newSessionObject(phone, telegramId, state = null, saveCreds = null) {
        return {
            phone,
            telegramId: String(telegramId),
            path: this.getSessionPath(phone),
            sock: null,
            authState: state,
            saveCreds,
            isConnected: false,
            connecting: true,
            pairingCode: null,
            pairingPromise: null,
            handler: null,
            messages: null,
            console: null,
            destroyed: false,
            reconnectTimer: null,
            connectionRetries: 0,
            startTime: Date.now()
        };
    }

    async notify(phone, payload) {
        const telegramId = this.sessionOwners.get(phone);
        if (String(telegramId || '').startsWith('wa:')) return; // تنصيب من واتساب: التبليغ بيتم من أمر .تنصيب نفسه
        if (telegramId && this.telegram?.notifyTelegram) {
            try {
                await this.telegram.notifyTelegram(telegramId, { ...payload, phone });
            } catch (error) {
                console.log(chalk.yellow("⚠️ Telegram notify failed:"), error.message);
            }
        }
    }

    async closeSocket(sessionObject) {
        const sock = sessionObject.sock;
        if (!sock) return;
        sessionObject.sock = null;
        try { sock.ev.removeAllListeners("connection.update"); } catch {}
        try { sock.ev.removeAllListeners("messages.upsert"); } catch {}
        try { sock.ev.removeAllListeners("creds.update"); } catch {}
        try {
            if (typeof sock.end === "function") sock.end(new Error("Socket replaced"));
            else sock.ws?.close();
        } catch {}
    }

    // =========================================================
    // TELEGRAM
    // =========================================================

    async startTelegram() {
        try {
            const { default: TelegramBot } = await import("./telegram.js");
            this.telegram = new TelegramBot(this);
            await this.telegram.start();
            console.log(chalk.green("✅ Telegram bot started"));
        } catch (error) {
            // مش بنوقف البوت لو تليجرام فشل — الواتساب يفضل شغال
            console.log(chalk.red("❌ Telegram startup failed:"), error.message);
            console.log(chalk.yellow("⚠️ Continuing without Telegram..."));
            this.telegram = null;
        }
    }

    // =========================================================
    // SAFE SEND MESSAGE
    // =========================================================

    async safeSendMessage(socket, jid, content, options = {}, maxRetries = 5) {
        let delay = 1000;
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                if (!socket || !socket.user?.id || !socket.ws?.isOpen) {
                    throw new Error("WHATSAPP_SOCKET_NOT_CONNECTED");
                }
                return await socket.sendMessage(jid, content, options);
            } catch (error) {
                const message = String(error?.message || error);
                const connectionError =
                    /connection closed|connection lost|socket.*closed|not open|stream errored|NOT_CONNECTED/i.test(message);
                if (!connectionError || attempt === maxRetries) throw error;
                await sleep(delay);
                delay = Math.min(delay * 2, 10000);
            }
        }
    }

    // =========================================================
    // BUTTON V2 / NATIVE SEND MESSAGE
    // =========================================================

    async installSofaButtonSender(socket) {
        if (!socket || socket.__sofaButtonSenderInstalled) return socket;

        const { ButtonV2, proto, generateWAMessageFromContent } = await this.getBaileys();

        socket.ButtonV2 = ButtonV2;
        const originalSendMessage = socket.sendMessage.bind(socket);

        socket.sendButtonV2 = async function (jid, body, buttons = [], options = {}) {
            if (!ButtonV2) throw new Error("ButtonV2 is not available in the installed Baileys version.");

            const btnV2 = new ButtonV2(socket);
            btnV2.setBody(String(body || ""));
            if (options.footer) btnV2.setFooter(String(options.footer));
            if (options.thumbnail) btnV2.setThumbnail(options.thumbnail);

            for (const button of buttons) {
                if (!button) continue;
                const text = button.text || button.displayText || button.title || "Button";
                const id = button.id || button.buttonId || button.command || "";
                if (!id) continue;
                btnV2.addButton(String(text), String(id));
            }

            return await btnV2.send(jid, {
                userJid: options.userJid || socket.user?.id,
                mentions: options.mentions || []
            });
        };

        socket.sendButtonV2Message = socket.sendButtonV2;
        socket.sendButtonsV2 = socket.sendButtonV2;

        socket.sendMessage = async function (jid, content = {}, options = {}) {
            const hasButtons = Array.isArray(content?.buttons) && content.buttons.length > 0;
            const hasInteractiveButtons = Array.isArray(content?.interactiveButtons) && content.interactiveButtons.length > 0;
            const hasTemplateButtons = Array.isArray(content?.templateButtons) && content.templateButtons.length > 0;
            const hasList = Array.isArray(content?.sections) && content.sections.length > 0;

            if (!hasButtons && !hasInteractiveButtons && !hasTemplateButtons && !hasList) {
                const __t0 = Date.now();
                try {
                    const gc = socket.__groupCache;
                    if (gc && String(jid).endsWith("@g.us") && !gc.get(jid)) {
                        try { gc.set(jid, await socket.groupMetadata(jid)); } catch {}
                    }
                    content = await addChannelContext(socket, jid, content);
                    return await originalSendMessage(jid, content, options);
                } finally {
                    const __ms = Date.now() - __t0;
                    if (__ms > 5000) console.log(chalk.yellow(`🐢 إرسال بطيء: ${__ms}ms → ${String(jid).endsWith("@g.us") ? "مجموعة" : "خاص"}`));
                }
            }

            const nativeButtons = [];

            if (hasButtons) {
                for (const button of content.buttons) {
                    const id = button?.buttonId || button?.id || button?.selectedId || "";
                    const displayText = button?.buttonText?.displayText || button?.displayText || button?.text || "Button";
                    if (!id) continue;
                    nativeButtons.push({
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({ display_text: String(displayText), id: String(id) })
                    });
                }
            }

            if (hasInteractiveButtons) {
                for (const button of content.interactiveButtons) {
                    if (!button?.name) continue;
                    nativeButtons.push({
                        name: String(button.name),
                        buttonParamsJson:
                            typeof button.buttonParamsJson === "string"
                                ? button.buttonParamsJson
                                : JSON.stringify(button.buttonParamsJson || {})
                    });
                }
            }

            if (hasTemplateButtons) {
                for (const button of content.templateButtons) {
                    const id = button?.index?.toString() || button?.buttonId || button?.id || "";
                    const displayText =
                        button?.quickReplyButton?.displayText ||
                        button?.urlButton?.displayText ||
                        button?.displayText ||
                        "Button";
                    if (!id) continue;
                    nativeButtons.push({
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({ display_text: String(displayText), id: String(id) })
                    });
                }
            }

            if (hasList) {
                nativeButtons.push({
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: content?.buttonText || content?.title || "اختيار",
                        sections: content.sections
                    })
                });
            }

            const IM = proto.Message.InteractiveMessage;

            const interactiveMessage = IM.fromObject({
                body: IM.Body.fromObject({ text: String(content?.text || content?.caption || "") }),
                footer: IM.Footer.fromObject({ text: String(content?.footer || "") }),
                header: IM.Header.fromObject({
                    title: String(content?.title || content?.subtitle || ""),
                    hasMediaAttachment: false
                }),
                nativeFlowMessage: IM.NativeFlowMessage.fromObject({ buttons: nativeButtons })
            });

            const message = generateWAMessageFromContent(
                jid,
                {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                            interactiveMessage
                        }
                    }
                },
                { ...options, userJid: options?.userJid || socket.user?.id }
            );

            if (!socket?.ws?.isOpen) throw new Error("WHATSAPP_SOCKET_NOT_CONNECTED");

            await socket.relayMessage(jid, message.message, { messageId: message.key.id });
            return message;
        };

        socket.__sofaButtonSenderInstalled = true;
        return socket;
    }

    // =========================================================
    // CREATE WHATSAPP SESSION (من تليجرام)
    // =========================================================

    async createWhatsAppSession(phone, telegramId) {
        // الترتيب (phone, telegramId) زي ما telegram.js بيستدعيها
        const cleanPhone = this.normalizePhone(phone);
        const ownerId = String(telegramId);

        if (cleanPhone.length < 8 || cleanPhone.length > 15) {
            throw new Error("رقم الهاتف غير صالح");
        }

        for (const [existingPhone, existingTelegramId] of this.sessionOwners.entries()) {
            if (existingTelegramId === ownerId && existingPhone !== cleanPhone) {
                throw new Error(`حساب Telegram مربوط بالفعل بالرقم ${existingPhone}`);
            }
        }

        const previousOwner = this.sessionOwners.get(cleanPhone);
        this.sessionOwners.set(cleanPhone, ownerId);
        await this.saveSessionOwners();

        const existing = this.sessions.get(cleanPhone);

        if (existing) {
            existing.telegramId = ownerId;

            if (existing.isConnected) {
                return { connected: true, pairingCode: null, phone: cleanPhone };
            }
            if (existing.connecting && existing.pairingPromise && !existing.pairingCode) {
                const result = await existing.pairingPromise;
                return {
                    connected: !!result?.connected,
                    pairingCode: result?.pairingCode || null,
                    phone: cleanPhone
                };
            }
            // جلسة قديمة عالقة: نقفلها ونبدأ من جديد
            await this.closeSocket(existing);
            if (existing.reconnectTimer) clearTimeout(existing.reconnectTimer);
            existing.destroyed = true;
            this.sessions.delete(cleanPhone);
        }

        try {
            return await this.startWhatsAppSession(cleanPhone, ownerId);
        } catch (error) {
            // rollback لو الرقم كان جديد
            if (!previousOwner) {
                this.sessionOwners.delete(cleanPhone);
                await this.saveSessionOwners().catch(() => {});
                await fs.remove(this.getSessionPath(cleanPhone)).catch(() => {});
            }
            throw error;
        }
    }

    // =========================================================
    // START WHATSAPP SESSION
    // =========================================================

    async startWhatsAppSession(phone, telegramId) {
        const cleanPhone = this.normalizePhone(phone);
        const sessionObject = this.newSessionObject(cleanPhone, telegramId);
        this.sessions.set(cleanPhone, sessionObject);

        try {
            const { useMultiFileAuthState } = await this.getBaileys();
            await fs.ensureDir(sessionObject.path);

            // جلسة قديمة ناقصة (اتطلب لها كود قبل كده ومتربطتش) بتبوّظ الكود الجديد: نمسحها
            try {
                const credsFile = path.join(sessionObject.path, "creds.json");
                if (await fs.pathExists(credsFile)) {
                    const old = await fs.readJson(credsFile).catch(() => null);
                    if (!old?.registered) await fs.emptyDir(sessionObject.path);
                }
            } catch {}

            const { state, saveCreds } = await useMultiFileAuthState(sessionObject.path);
            sessionObject.authState = state;
            sessionObject.saveCreds = saveCreds;

            await this.createSocket(sessionObject);

            if (state.creds.registered) {
                sessionObject.pairingPromise = this.waitForSessionConnection(sessionObject);
                await sessionObject.pairingPromise;

                return {
                    connected: sessionObject.isConnected,
                    pairingCode: null,
                    phone: cleanPhone
                };
            }

            // الإصلاح: زي النسخة القديمة، نطلب الكود مباشرة بعد تهيئة الـ socket
            sessionObject.pairingPromise = this.requestPairingCode(sessionObject);
            return await sessionObject.pairingPromise;
        } catch (error) {
            sessionObject.connecting = false;
            sessionObject.destroyed = true;
            await this.closeSocket(sessionObject);
            this.sessions.delete(cleanPhone);
            throw error;
        }
    }

    // =========================================================
    // CREATE SOCKET
    // =========================================================

    async createSocket(sessionObject) {
        if (sessionObject.destroyed) return;

        const { makeWASocket, makeCacheableSignalKeyStore, Browsers } = await this.getBaileys();

        // نفس إعدادات النسخة القديمة الشغالة: بدون fetchLatestBaileysVersion
        // (ممكن تحط config.WA_VERSION = [2,3000,xxxx] لو عايز نسخة محددة)
        const version = Array.isArray(this.config?.WA_VERSION) ? this.config.WA_VERSION : undefined;

        // قفل أي socket قديم قبل إنشاء الجديد
        await this.closeSocket(sessionObject);

        // كاش بيانات المجموعات: بيوفّر استعلام شبكة مع كل رسالة بتتبعت في مجموعة
        const groupCache = new Map();
        const GROUP_TTL = 10 * 60 * 1000;
        const gcGet = (jid) => { const e = groupCache.get(jid); return e && Date.now() - e.t < GROUP_TTL ? e.v : undefined; };

        const sock = makeWASocket({
            cachedGroupMetadata: async (jid) => gcGet(jid),
            auth: {
                creds: sessionObject.authState.creds,
                keys: makeCacheableSignalKeyStore(sessionObject.authState.keys, logger)
            },
            ...(version ? { version } : {}),
            browser: Browsers?.ubuntu ? Browsers.ubuntu("Chrome") : ["Ubuntu", "Chrome", "22.04.4"],
            printQRInTerminal: false,
            markOnlineOnConnect: true,
            generateHighQualityLinkPreview: true,
            syncFullHistory: false,
            qrTimeout: 180000, // وقت أطول قبل ما الجلسة تتقفل (408) لحد ما تكتب الكود
            retryRequestDelayMs: 1000,
            maxRetries: 3,
            logger
        });

        sock.__groupCache = { get: gcGet, set: (jid, v) => groupCache.set(jid, { v, t: Date.now() }) };
        const refreshGroup = async (id) => { try { sock.__groupCache.set(id, await sock.groupMetadata(id)); } catch {} };
        sock.ev.on("groups.update", (events) => (events || []).forEach((e) => e?.id && refreshGroup(e.id)));
        sock.ev.on("group-participants.update", (e) => e?.id && refreshGroup(e.id));
        // الأرقام الساكتة مفيهاش رسايل ترحيب تلقائية
        if (!(this.config?.SILENT_NUMBERS || []).map((n) => this.normalizePhone(n)).includes(this.normalizePhone(sessionObject.phone))) attachWelcome(sock);

        sessionObject.sock = sock;
        sessionObject.handshake = false;
        this.setupSessionEvents(sessionObject, sock);

        try {
            await this.installSofaButtonSender(sock);
        } catch (error) {
            console.log(chalk.yellow(`⚠️ Button sender install failed [${sessionObject.phone}]:`), error.message);
        }

        sock.__sofaVersion = version;
        sock.__sofaSessionDir = sessionObject.path;
        sock.__sofaSaveCreds = sessionObject.saveCreds;
        sock.__sofaTelegram = true;
        sock.__sofaTelegramId = sessionObject.telegramId;
    }

    // =========================================================
    // SESSION EVENTS
    // =========================================================

    setupSessionEvents(sessionObject, sock) {
        sock.ev.on("connection.update", (update) => {
            // تجاهل أحداث socket قديم
            if (sessionObject.sock !== sock) return;
            this.handleSessionConnectionUpdate(sessionObject, update).catch((error) => {
                console.log(chalk.red(`❌ Connection update error [${sessionObject.phone}]:`), error.message);
            });
        });

        sock.ev.on("messages.upsert", (update) => {
            if (sessionObject.sock !== sock) return;
            this.handleMessagesUpsert(sessionObject, update);
        });

        sock.ev.on("creds.update", async () => {
            try {
                if (sessionObject.saveCreds) await sessionObject.saveCreds();
            } catch (error) {
                console.log(chalk.red(`❌ Creds save error [${sessionObject.phone}]:`), error.message);
            }
        });
    }

    // =========================================================
    // PAIRING CODE
    // =========================================================

    // كود ربط عشوائي من نفس حروف واتساب (بدون 0 O 1 I U) عشان يتقبل صح على الموبايل
    generatePairingCode() {
        const alphabet = "23456789ABCDEFGHJKLMNPQRSTVWXYZ";
        let code = "";
        for (let i = 0; i < 8; i++) code += alphabet[randomInt(alphabet.length)];
        return code;
    }

    async requestPairingCode(sessionObject) {
        const phone = sessionObject.phone;
        console.log(chalk.cyan(`⏳ Requesting pairing code for ${phone}...`));

        const isOpen = () => {
            const ws = sessionObject.sock?.ws;
            return ws ? (ws.isOpen ?? ws.readyState === 1) : false;
        };

        // نستنى الـ WebSocket يفتح فعلاً قبل طلب الكود (حتى 20 ثانية)
        for (let i = 0; i < 40 && !isOpen() && !sessionObject.destroyed; i++) await sleep(500);
        console.log(chalk.gray(`📡 [${phone}] websocket open: ${isOpen()}`));
        await sleep(2000);

        let lastError = null;

        for (let attempt = 1; attempt <= 4; attempt++) {
            try {
                if (sessionObject.destroyed || !sessionObject.sock) {
                    throw new Error("WHATSAPP_SOCKET_NOT_READY");
                }

                const code = await sessionObject.sock.requestPairingCode(phone, this.generatePairingCode());

                sessionObject.pairingCode = code;
                sessionObject.connecting = true;

                console.log(chalk.greenBright(`🔐 Pairing Code [${phone}]: ${code}`));

                return { connected: false, pairingCode: code, phone };
            } catch (error) {
                lastError = error;
                console.log(chalk.yellow(`⚠️ Pairing attempt ${attempt}/4 failed [${phone}]: ${error.message}`));
                await sleep(2000 * attempt);

                // لو الـ socket اتقفل نعمل واحد جديد ونستنى يفتح
                if (attempt < 4 && !isOpen() && !sessionObject.destroyed) {
                    await this.createSocket(sessionObject);
                    for (let i = 0; i < 20 && !isOpen(); i++) await sleep(500);
                    await sleep(1500);
                }
            }
        }

        console.log(chalk.red(`❌ Pairing failed [${phone}]:`), lastError?.message);
        throw lastError || new Error("PAIRING_FAILED");
    }

    // =========================================================
    // WAIT FOR CONNECTION
    // =========================================================

    waitForSessionConnection(sessionObject, timeout = 45000) {
        return new Promise((resolve) => {
            const started = Date.now();
            const check = () => {
                if (sessionObject.isConnected) return resolve({ connected: true });
                if (sessionObject.destroyed) return resolve({ connected: false });
                if (Date.now() - started > timeout) return resolve({ connected: false });
                setTimeout(check, 500);
            };
            check();
        });
    }

    // =========================================================
    // CONNECTION UPDATE
    // =========================================================

    async handleSessionConnectionUpdate(sessionObject, update) {
        const { connection, lastDisconnect } = update;
        const phone = sessionObject.phone;

        if (connection === "connecting" || update.qr) sessionObject.handshake = true;
        if (connection) console.log(chalk.gray(`📡 [${phone}] connection: ${connection}`));

        if (connection === "open") {
            sessionObject.isConnected = true;
            sessionObject.connecting = false;
            sessionObject.pairingCode = null;
            sessionObject.connectionRetries = 0;

            console.log(chalk.green(`✅ WhatsApp connected [${phone}]`));

            try {
                await this.loadSystems(sessionObject);
            } catch (error) {
                console.log(chalk.red(`❌ System loading failed [${phone}]:`), error.message);
            }

            await this.notify(phone, { type: "connected" });
            return;
        }

        if (connection === "close") {
            sessionObject.isConnected = false;
            sessionObject.connecting = false;

            if (sessionObject.destroyed) return;

            const statusCode = lastDisconnect?.error?.output?.statusCode;
            const { DisconnectReason } = await this.getBaileys();

            if (statusCode === DisconnectReason.loggedOut) {
                console.log(chalk.red(`❌ WhatsApp logged out [${phone}]`));
                await this.removeSession(phone, true);
                return;
            }

            if (statusCode === DisconnectReason.connectionReplaced) {
                console.log(chalk.yellow(`⚠️ WhatsApp connection replaced [${phone}]`));
                await this.notify(phone, { type: "replaced" });
                await this.closeSocket(sessionObject);
                return;
            }

            console.log(chalk.yellow(`🔴 WhatsApp disconnected [${phone}] (code: ${statusCode ?? "unknown"}) ${lastDisconnect?.error?.message || ""}`));

            // restartRequired (515) طبيعي بعد الربط، مش محتاج إشعار
            if (statusCode !== DisconnectReason.restartRequired) {
                await this.notify(phone, { type: "disconnected" });
            }

            this.scheduleReconnect(
                sessionObject,
                statusCode === DisconnectReason.restartRequired ? 500 : 3000
            );
        }
    }

    // =========================================================
    // RECONNECT
    // =========================================================

    scheduleReconnect(sessionObject, delay = 3000) {
        if (sessionObject.destroyed || sessionObject.reconnectTimer) return;

        if (sessionObject.connectionRetries >= this.maxRetries) {
            console.log(chalk.red(`❌ Max retries reached [${sessionObject.phone}]`));
            return;
        }

        sessionObject.connectionRetries++;

        console.log(
            chalk.yellow(
                `🔄 Reconnecting ${sessionObject.phone} (${sessionObject.connectionRetries}/${this.maxRetries})...`
            )
        );

        sessionObject.reconnectTimer = setTimeout(async () => {
            sessionObject.reconnectTimer = null;
            try {
                await this.reconnectSessionObject(sessionObject);
            } catch (error) {
                console.log(chalk.red(`❌ Reconnect failed [${sessionObject.phone}]:`), error.message);
                this.scheduleReconnect(sessionObject);
            }
        }, delay);
    }

    async reconnectSessionObject(sessionObject) {
        if (sessionObject.destroyed) return;

        const { useMultiFileAuthState } = await this.getBaileys();
        const { state, saveCreds } = await useMultiFileAuthState(sessionObject.path);

        sessionObject.authState = state;
        sessionObject.saveCreds = saveCreds;
        sessionObject.connecting = true;

        await this.createSocket(sessionObject);

        // الإصلاح: مفيش طلب كود تلقائي هنا، لأن الـ socket بيتقفل ويتعيد فتحه بعد الربط (515)
        return { connected: sessionObject.isConnected, pairingCode: null };
    }

    // =========================================================
    // TELEGRAM RECONNECT
    // =========================================================

    async reconnectWhatsAppSession(telegramId) {
        const ownerId = String(telegramId);
        const phone = this.getPhoneByTelegramId(ownerId);

        if (!phone) throw new Error("لا توجد Session مرتبطة بهذا الحساب");

        const sessionPath = this.getSessionPath(phone);
        if (!(await fs.pathExists(sessionPath))) throw new Error("Session غير موجودة");

        const current = this.sessions.get(phone);

        if (current?.isConnected) return { connected: true, phone };

        if (current?.connecting && current.sock) {
            return { connected: false, pairingCode: current.pairingCode || null, phone };
        }

        if (current) {
            current.destroyed = false;
            current.telegramId = ownerId;
            current.connectionRetries = 0;
            if (current.reconnectTimer) {
                clearTimeout(current.reconnectTimer);
                current.reconnectTimer = null;
            }
            const result = await this.reconnectSessionObject(current);
            return { ...result, phone };
        }

        const sessionObject = this.newSessionObject(phone, ownerId);
        this.sessions.set(phone, sessionObject);

        try {
            const result = await this.reconnectSessionObject(sessionObject);
            return { ...result, phone };
        } catch (error) {
            this.sessions.delete(phone);
            throw error;
        }
    }

    // =========================================================
    // STATUS
    // =========================================================

    getTelegramSessionStatus(telegramId) {
        const phone = this.getPhoneByTelegramId(String(telegramId));

        if (!phone) {
            return { exists: false, connected: false, connecting: false, phone: null };
        }

        const current = this.sessions.get(phone);

        return {
            exists: fs.existsSync(this.getSessionPath(phone)),
            connected: !!current?.isConnected,
            connecting: !!current?.connecting,
            phone
        };
    }

    // =========================================================
    // DISCONNECT / REMOVE
    // =========================================================

    async disconnectWhatsAppSession(telegramId) {
        const phone = this.getPhoneByTelegramId(String(telegramId));
        if (!phone) throw new Error("لا توجد Session لهذا الحساب");
        await this.removeSession(phone, false);
    }

    async removeSession(phone, notify = false) {
        const cleanPhone = this.normalizePhone(phone);
        const sessionObject = this.sessions.get(cleanPhone);

        if (sessionObject) {
            sessionObject.destroyed = true;
            sessionObject.connecting = false;
            sessionObject.isConnected = false;

            if (sessionObject.reconnectTimer) {
                clearTimeout(sessionObject.reconnectTimer);
                sessionObject.reconnectTimer = null;
            }

            await this.closeSocket(sessionObject);
            this.sessions.delete(cleanPhone);
        }

        const telegramId = this.sessionOwners.get(cleanPhone);

        this.sessionOwners.delete(cleanPhone);
        await this.saveSessionOwners();
        await fs.remove(this.getSessionPath(cleanPhone));

        if (notify && telegramId && this.telegram?.notifyTelegram) {
            try {
                await this.telegram.notifyTelegram(telegramId, { type: "logged_out", phone: cleanPhone });
            } catch {}
        }

        console.log(chalk.yellow(`🗑️ Session removed [${cleanPhone}]`));
    }

    // =========================================================
    // RESTORE SESSIONS
    // =========================================================

    async restoreSessions() {
        if (!(await fs.pathExists(this.directories.sessions))) return;

        const entries = await fs.readdir(this.directories.sessions, { withFileTypes: true });
        const { useMultiFileAuthState } = await this.getBaileys();

        for (const entry of entries) {
            if (!entry.isDirectory()) continue;

            const phone = this.normalizePhone(entry.name);
            if (phone.length < 8 || phone.length > 15) continue;

            const owner = this.sessionOwners.get(phone);
            if (!owner) {
                console.log(chalk.yellow(`⚠️ Session found without Telegram owner: ${phone}`));
                continue;
            }

            try {
                const sessionPath = this.getSessionPath(phone);
                const { state, saveCreds } = await useMultiFileAuthState(sessionPath);

                if (!state.creds.registered) {
                    console.log(chalk.yellow(`⚠️ Unregistered session waiting for Telegram: ${phone}`));
                    continue;
                }

                const sessionObject = this.newSessionObject(phone, owner, state, saveCreds);
                this.sessions.set(phone, sessionObject);

                console.log(chalk.cyan(`🔄 Restoring WhatsApp session: ${phone}`));

                await this.createSocket(sessionObject);
            } catch (error) {
                console.log(chalk.red(`❌ Failed restoring session [${phone}]:`), error.message);
                this.sessions.delete(phone);
            }
        }
    }

    // =========================================================
    // SYSTEMS
    // =========================================================

    async loadSystems(sessionObject) {
        if (sessionObject.handler) return;

        try {
            const botContext = this.createSessionContext(sessionObject);

            const { Handler } = await import("./handler.js");
            sessionObject.handler = new Handler(botContext);
            await sessionObject.handler.loadPlugins();

            try {
                const { MessageSystem } = await import("./messages.js");
                sessionObject.messages = new MessageSystem(botContext);
            } catch (error) {
                console.log(chalk.yellow(`⚠️ MessageSystem failed [${sessionObject.phone}]:`), error.message);
            }

            try {
                const { ConsoleSystem } = await import("./console.js");
                sessionObject.console = new ConsoleSystem(botContext);
            } catch (error) {
                console.log(chalk.yellow(`⚠️ ConsoleSystem failed [${sessionObject.phone}]:`), error.message);
            }

            console.log(chalk.green(`✅ Systems loaded [${sessionObject.phone}]`));

            if (sessionObject.handler?.plugins) {
                console.log(chalk.magentaBright(`⚡ Plugins loaded: ${sessionObject.handler.plugins.size}`));
            }
        } catch (error) {
            // نسيب handler فاضي عشان نحاول تاني في الاتصال الجاي
            sessionObject.handler = null;
            console.log(chalk.red(`❌ System loading failed [${sessionObject.phone}]:`), error.message);
        }
    }

    // =========================================================
    // SESSION CONTEXT (getters عشان دايماً يشاور على الـ socket الحالي)
    // =========================================================

    createSessionContext(sessionObject) {
        const s = sessionObject;
        const self = this;

        return {
            get sock() { return s.sock; },
            get authState() { return s.authState; },
            get saveCreds() { return s.saveCreds; },
            get isConnected() { return s.isConnected; },
            get handler() { return s.handler; },
            get messages() { return s.messages; },
            get console() { return s.console; },

            startTime: s.startTime,
            version: self.version,
            phone: s.phone,
            telegramId: s.telegramId,
            config: self.config,

            sendMessage: async (jid, content, options = {}) => {
                try {
                    return await self.safeSendMessage(s.sock, jid, content, options);
                } catch (error) {
                    console.log(chalk.red(`❌ Send message error [${s.phone}]:`), error.message);
                    throw error;
                }
            },

            isDeveloper: (jid) => {
                const d = String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
                if (!d) return false;
                const configured = (self.config?.DEVELOPERS || []).some((dev) => String(dev || '').split('@')[0].split(':')[0].replace(/\D/g, '') === d);
                const owners = (self.config?.OWNER_NUMBERS || [self.config?.OWNER_NUMBER]).map((n) => String(n || '').replace(/\D/g, ''));
                return owners.includes(d) || configured || self.sessionOwners.has(d);
            },

            softRestart: async () => {
                s.handler = null;
                s.messages = null;
                s.console = null;
                await self.reconnectSessionObject(s);
            }
        };
    }

    // =========================================================
    // MESSAGES
    // =========================================================

    async handleMessagesUpsert(sessionObject, update) {
        try {
            if (!update || !Array.isArray(update.messages)) return;

            for (const message of update.messages) {
                if (!message || !message.message) continue;
                if (message.key?.remoteJid === "status@broadcast") continue;

                const messageTime = message.messageTimestamp
                    ? Number(message.messageTimestamp) * 1000
                    : Date.now();

                if (messageTime < sessionObject.startTime - 10000) continue;

                if (sessionObject.console?.logMessage) {
                    try { sessionObject.console.logMessage(message); } catch {}
                }

                if (sessionObject.handler?.handleMessage) {
                    await sessionObject.handler.handleMessage(message);
                }
            }
        } catch (error) {
            console.log(chalk.red(`❌ Message handling error [${sessionObject.phone}]:`), error.message);
        }
    }

    // =========================================================
    // SEND MESSAGE
    // =========================================================

    async sendMessage(phone, jid, content, options = {}) {
        const session = this.sessions.get(this.normalizePhone(phone));
        if (!session?.sock) throw new Error("WhatsApp session غير متصلة");
        return await this.safeSendMessage(session.sock, jid, content, options);
    }

    isDeveloper(jid) {
        const d = String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
        if (!d) return false;
        const configured = (this.config?.DEVELOPERS || []).some((dev) => String(dev || '').split('@')[0].split(':')[0].replace(/\D/g, '') === d);
        const owners = (this.config?.OWNER_NUMBERS || [this.config?.OWNER_NUMBER]).map((n) => String(n || '').replace(/\D/g, ''));
        return owners.includes(d) || configured || this.sessionOwners.has(d);
    }

    async softRestart(phone) {
        const session = this.sessions.get(this.normalizePhone(phone));
        if (!session) throw new Error("Session غير موجودة");

        session.handler = null;
        session.messages = null;
        session.console = null;

        await this.reconnectSessionObject(session);
    }

    // =========================================================
    // SHUTDOWN
    // =========================================================

    async shutdown() {
        console.log(chalk.yellow("\n🛑 Shutting down SofaBot..."));

        for (const session of this.sessions.values()) {
            session.destroyed = true;
            if (session.reconnectTimer) clearTimeout(session.reconnectTimer);
            await this.closeSocket(session);
        }

        if (this.telegram) {
            try { await this.telegram.stop(); } catch {}
        }

        this.sessions.clear();
    }
}

// =============================================================
// MAIN
// =============================================================

async function main() {
    try {
        await import("@whiskeysockets/baileys");

        // تم إيقاف استبدال socket.js الخاص بـ Baileys: النسخة الأصلية بتدعم كود ربط مخصص،
        // والنسخة المعدّلة ممكن تتعارض مع إصدار المكتبة المثبّت وتخلّي الكود يطلع "خاطئ".
    } catch (error) {
        console.error(chalk.red("❌ Change initialization error:"), error);
        process.exit(1);
    }

    const bot = new SofaBot();
    try {
        await bot.initialize();
    } catch (error) {
        console.error(chalk.red("❌ Critical initialization error:"), error);
        process.exit(1);
    }
}

main();

process.on("unhandledRejection", (reason) => {
    console.log(chalk.red("⚠️ Unhandled rejection:"), reason?.message || reason);
});

process.on("uncaughtException", (error) => {
    console.log(chalk.red("⚠️ Uncaught exception:"), error?.message || error);
});

process.once("SIGINT", async () => {
    try { if (global.bot) await global.bot.shutdown(); } finally { process.exit(0); }
});

process.once("SIGTERM", async () => {
    try { if (global.bot) await global.bot.shutdown(); } finally { process.exit(0); }
});