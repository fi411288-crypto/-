#!/data/data/com.termux/files/usr/bin/bash
set -e
BASE="$HOME/SOFA-BOT"
SRC="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$BASE"
STAMP="$(date +%Y%m%d-%H%M%S)"
[ -f "$BASE/data/token.json" ] && cp "$BASE/data/token.json" "$BASE/data/token.json.backup-$STAMP" || true
[ -d "$BASE/session" ] && cp -a "$BASE/session" "$BASE/session.backup-$STAMP" || true
[ -d "$BASE/sessions" ] && cp -a "$BASE/sessions" "$BASE/sessions.backup-$STAMP" || true
[ -d "$BASE/auth_info" ] && cp -a "$BASE/auth_info" "$BASE/auth_info.backup-$STAMP" || true
# Copy application files only; protected runtime credentials/data are restored after copy.
rsync -a --delete --exclude 'data/token.json' --exclude 'session/' --exclude 'sessions/' --exclude 'auth_info/' --exclude 'node_modules/' "$SRC/" "$BASE/"
[ -f "$BASE/data/token.json.backup-$STAMP" ] && cp "$BASE/data/token.json.backup-$STAMP" "$BASE/data/token.json" || true
node --check "$BASE/index.js"
find "$BASE/plugins" -type f -name '*.js' -print0 | xargs -0 -n1 node --check
printf '\n✅ SOFA BOT installed safely. Telegram token and session data were preserved.\n'
